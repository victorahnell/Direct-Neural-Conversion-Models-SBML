src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1Zds
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Ze5
                      p_a1Zdr = double g_a1Zdq
                      (g_a1Zdq, gpart_a1Ze5) = Genome.Split.split gpart_a1Ze4
                      p_a1Zdp = double g_a1Zdo
                      (g_a1Zdo, gpart_a1Ze4) = Genome.Split.split gpart_a1Ze3
                      p_a1Zdn = double g_a1Zdm
                      (g_a1Zdm, gpart_a1Ze3) = Genome.Split.split gpart_a1Ze2
                      p_a1Zdl = double g_a1Zdk
                      (g_a1Zdk, gpart_a1Ze2) = Genome.Split.split gpart_a1Ze1
                      p_a1Zdj = double g_a1Zdi
                      (g_a1Zdi, gpart_a1Ze1) = Genome.Split.split gpart_a1Ze0
                      p_a1Zdh = Functions.belowten' g_a1Zdg
                      (g_a1Zdg, gpart_a1Ze0) = Genome.Split.split gpart_a1ZdZ
                      p_a1Zdf = double g_a1Zde
                      (g_a1Zde, gpart_a1ZdZ) = Genome.Split.split gpart_a1ZdY
                      p_a1Zdd = double g_a1Zdc
                      (g_a1Zdc, gpart_a1ZdY) = Genome.Split.split gpart_a1ZdX
                      p_a1Zdb = double g_a1Zda
                      (g_a1Zda, gpart_a1ZdX) = Genome.Split.split gpart_a1ZdW
                      p_a1Zd9 = Functions.belowten' g_a1Zd8
                      (g_a1Zd8, gpart_a1ZdW) = Genome.Split.split gpart_a1ZdV
                      p_a1Zd7 = double g_a1Zd6
                      (g_a1Zd6, gpart_a1ZdV) = Genome.Split.split gpart_a1ZdU
                      p_a1Zd5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zd4
                      (g_a1Zd4, gpart_a1ZdU) = Genome.Split.split gpart_a1ZdT
                      p_a1Zd3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zd2
                      (g_a1Zd2, gpart_a1ZdT) = Genome.Split.split gpart_a1ZdS
                      p_a1Zd1 = Functions.belowten' g_a1Zd0
                      (g_a1Zd0, gpart_a1ZdS) = Genome.Split.split gpart_a1ZdR
                      p_a1ZcZ = double g_a1ZcY
                      (g_a1ZcY, gpart_a1ZdR) = Genome.Split.split gpart_a1ZdQ
                      p_a1ZcX = double g_a1ZcW
                      (g_a1ZcW, gpart_a1ZdQ) = Genome.Split.split gpart_a1ZdP
                      p_a1ZcV = double g_a1ZcU
                      (g_a1ZcU, gpart_a1ZdP) = Genome.Split.split gpart_a1ZdO
                      p_a1ZcT = Functions.belowten' g_a1ZcS
                      (g_a1ZcS, gpart_a1ZdO) = Genome.Split.split gpart_a1ZdN
                      p_a1ZcR = double g_a1ZcQ
                      (g_a1ZcQ, gpart_a1ZdN) = Genome.Split.split gpart_a1ZdM
                      p_a1ZcP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcO
                      (g_a1ZcO, gpart_a1ZdM) = Genome.Split.split gpart_a1ZdL
                      p_a1ZcN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcM
                      (g_a1ZcM, gpart_a1ZdL) = Genome.Split.split gpart_a1ZdK
                      p_a1ZcL = double g_a1ZcK
                      (g_a1ZcK, gpart_a1ZdK) = Genome.Split.split gpart_a1ZdJ
                      p_a1ZcJ = Functions.belowten' g_a1ZcI
                      (g_a1ZcI, gpart_a1ZdJ) = Genome.Split.split gpart_a1ZdI
                      p_a1ZcH = double g_a1ZcG
                      (g_a1ZcG, gpart_a1ZdI) = Genome.Split.split gpart_a1ZdH
                      p_a1ZcF = Functions.belowten' g_a1ZcE
                      (g_a1ZcE, gpart_a1ZdH) = Genome.Split.split gpart_a1ZdG
                      p_a1ZcD = double g_a1ZcC
                      (g_a1ZcC, gpart_a1ZdG) = Genome.Split.split gpart_a1ZdF
                      p_a1ZcB = double g_a1ZcA
                      (g_a1ZcA, gpart_a1ZdF) = Genome.Split.split gpart_a1ZdE
                      p_a1Zcz = Functions.belowten' g_a1Zcy
                      (g_a1Zcy, gpart_a1ZdE) = Genome.Split.split gpart_a1ZdD
                      p_a1Zcx = double g_a1Zcw
                      (g_a1Zcw, gpart_a1ZdD) = Genome.Split.split gpart_a1ZdC
                      p_a1Zcv = Functions.belowten' g_a1Zcu
                      (g_a1Zcu, gpart_a1ZdC) = Genome.Split.split gpart_a1ZdB
                      p_a1Zct = double g_a1Zcs
                      (g_a1Zcs, gpart_a1ZdB) = Genome.Split.split gpart_a1ZdA
                      p_a1Zcr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zcq
                      (g_a1Zcq, gpart_a1ZdA) = Genome.Split.split gpart_a1Zdz
                      p_a1Zcp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zco
                      (g_a1Zco, gpart_a1Zdz) = Genome.Split.split gpart_a1Zdy
                      p_a1Zcn = double g_a1Zcm
                      (g_a1Zcm, gpart_a1Zdy) = Genome.Split.split gpart_a1Zdx
                      p_a1Zcl = double g_a1Zck
                      (g_a1Zck, gpart_a1Zdx) = Genome.Split.split gpart_a1Zdw
                      p_a1Zcj = double g_a1Zci
                      (g_a1Zci, gpart_a1Zdw) = Genome.Split.split gpart_a1Zdv
                      p_a1Zch = double g_a1Zcg
                      (g_a1Zcg, gpart_a1Zdv) = Genome.Split.split gpart_a1Zdu
                      p_a1Zcf = double g_a1Zce
                      (g_a1Zce, gpart_a1Zdu) = Genome.Split.split genome_a1Zds
                    in  \ x_a1Ze6
                          -> let
                               c_PTB_a1Zea
                                 = ((Data.Fixed.Vector.toVector x_a1Ze6) Data.Vector.Unboxed.! 0)
                               c_NPTB_a1Ze7
                                 = ((Data.Fixed.Vector.toVector x_a1Ze6) Data.Vector.Unboxed.! 1)
                               c_MiRs_a1Ze8
                                 = ((Data.Fixed.Vector.toVector x_a1Ze6) Data.Vector.Unboxed.! 2)
                               c_RESTc_a1Zef
                                 = ((Data.Fixed.Vector.toVector x_a1Ze6) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zep
                                 = ((Data.Fixed.Vector.toVector x_a1Ze6) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zcn
                                     / (1
                                        + (((c_NPTB_a1Ze7 / p_a1Zct) ** p_a1Zcv)
                                           + ((c_MiRs_a1Ze8 / p_a1Zcx) ** p_a1Zcz))))
                                    + (negate (p_a1Zdj * c_PTB_a1Zea))),
                                   ((p_a1ZcB
                                     / (1
                                        + (((c_MiRs_a1Ze8 / p_a1ZcD) ** p_a1ZcF)
                                           + ((c_PTB_a1Zea / p_a1ZcH) ** p_a1ZcJ))))
                                    + (negate (p_a1Zdl * c_NPTB_a1Ze7))),
                                   ((p_a1ZcL
                                     * ((p_a1ZcV + ((p_a1Zcj / p_a1ZcN) ** p_a1ZcP))
                                        / (((1 + p_a1ZcV) + ((p_a1Zcj / p_a1ZcN) ** p_a1ZcP))
                                           + ((c_RESTc_a1Zef / p_a1ZcR) ** p_a1ZcT))))
                                    + (negate (p_a1Zdn * c_MiRs_a1Ze8))),
                                   ((p_a1ZcX
                                     * ((p_a1Zdb + ((c_PTB_a1Zea / p_a1ZcZ) ** p_a1Zd1))
                                        / (((1 + p_a1Zdb) + ((c_PTB_a1Zea / p_a1ZcZ) ** p_a1Zd1))
                                           + (((p_a1Zcf / p_a1Zd3) ** p_a1Zd5)
                                              + ((c_MiRs_a1Ze8 / p_a1Zd7) ** p_a1Zd9)))))
                                    + (negate (p_a1Zdp * c_RESTc_a1Zef))),
                                   ((p_a1Zdd / (1 + ((c_RESTc_a1Zef / p_a1Zdf) ** p_a1Zdh)))
                                    + (negate (p_a1Zdr * c_EndoNeuroTFs_a1Zep)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483363",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483364",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483365",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483366",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483367",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483368",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483369",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483371",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483373",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483375",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483379",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483381",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483387",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483397",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483399",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483413",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483415",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483433",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zds
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zf1
                            p_a1Zdr = double g_a1Zdq
                            (g_a1Zdq, gpart_a1Zf1) = Genome.Split.split gpart_a1Zf0
                            p_a1Zdp = double g_a1Zdo
                            (g_a1Zdo, gpart_a1Zf0) = Genome.Split.split gpart_a1ZeZ
                            p_a1Zdn = double g_a1Zdm
                            (g_a1Zdm, gpart_a1ZeZ) = Genome.Split.split gpart_a1ZeY
                            p_a1Zdl = double g_a1Zdk
                            (g_a1Zdk, gpart_a1ZeY) = Genome.Split.split gpart_a1ZeX
                            p_a1Zdj = double g_a1Zdi
                            (g_a1Zdi, gpart_a1ZeX) = Genome.Split.split gpart_a1ZeW
                            p_a1Zdh = Functions.belowten' g_a1Zdg
                            (g_a1Zdg, gpart_a1ZeW) = Genome.Split.split gpart_a1ZeV
                            p_a1Zdf = double g_a1Zde
                            (g_a1Zde, gpart_a1ZeV) = Genome.Split.split gpart_a1ZeU
                            p_a1Zdd = double g_a1Zdc
                            (g_a1Zdc, gpart_a1ZeU) = Genome.Split.split gpart_a1ZeT
                            p_a1Zdb = double g_a1Zda
                            (g_a1Zda, gpart_a1ZeT) = Genome.Split.split gpart_a1ZeS
                            p_a1Zd9 = Functions.belowten' g_a1Zd8
                            (g_a1Zd8, gpart_a1ZeS) = Genome.Split.split gpart_a1ZeR
                            p_a1Zd7 = double g_a1Zd6
                            (g_a1Zd6, gpart_a1ZeR) = Genome.Split.split gpart_a1ZeQ
                            p_a1Zd5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zd4
                            (g_a1Zd4, gpart_a1ZeQ) = Genome.Split.split gpart_a1ZeP
                            p_a1Zd3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zd2
                            (g_a1Zd2, gpart_a1ZeP) = Genome.Split.split gpart_a1ZeO
                            p_a1Zd1 = Functions.belowten' g_a1Zd0
                            (g_a1Zd0, gpart_a1ZeO) = Genome.Split.split gpart_a1ZeN
                            p_a1ZcZ = double g_a1ZcY
                            (g_a1ZcY, gpart_a1ZeN) = Genome.Split.split gpart_a1ZeM
                            p_a1ZcX = double g_a1ZcW
                            (g_a1ZcW, gpart_a1ZeM) = Genome.Split.split gpart_a1ZeL
                            p_a1ZcV = double g_a1ZcU
                            (g_a1ZcU, gpart_a1ZeL) = Genome.Split.split gpart_a1ZeK
                            p_a1ZcT = Functions.belowten' g_a1ZcS
                            (g_a1ZcS, gpart_a1ZeK) = Genome.Split.split gpart_a1ZeJ
                            p_a1ZcR = double g_a1ZcQ
                            (g_a1ZcQ, gpart_a1ZeJ) = Genome.Split.split gpart_a1ZeI
                            p_a1ZcP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcO
                            (g_a1ZcO, gpart_a1ZeI) = Genome.Split.split gpart_a1ZeH
                            p_a1ZcN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcM
                            (g_a1ZcM, gpart_a1ZeH) = Genome.Split.split gpart_a1ZeG
                            p_a1ZcL = double g_a1ZcK
                            (g_a1ZcK, gpart_a1ZeG) = Genome.Split.split gpart_a1ZeF
                            p_a1ZcJ = Functions.belowten' g_a1ZcI
                            (g_a1ZcI, gpart_a1ZeF) = Genome.Split.split gpart_a1ZeE
                            p_a1ZcH = double g_a1ZcG
                            (g_a1ZcG, gpart_a1ZeE) = Genome.Split.split gpart_a1ZeD
                            p_a1ZcF = Functions.belowten' g_a1ZcE
                            (g_a1ZcE, gpart_a1ZeD) = Genome.Split.split gpart_a1ZeC
                            p_a1ZcD = double g_a1ZcC
                            (g_a1ZcC, gpart_a1ZeC) = Genome.Split.split gpart_a1ZeB
                            p_a1ZcB = double g_a1ZcA
                            (g_a1ZcA, gpart_a1ZeB) = Genome.Split.split gpart_a1ZeA
                            p_a1Zcz = Functions.belowten' g_a1Zcy
                            (g_a1Zcy, gpart_a1ZeA) = Genome.Split.split gpart_a1Zez
                            p_a1Zcx = double g_a1Zcw
                            (g_a1Zcw, gpart_a1Zez) = Genome.Split.split gpart_a1Zey
                            p_a1Zcv = Functions.belowten' g_a1Zcu
                            (g_a1Zcu, gpart_a1Zey) = Genome.Split.split gpart_a1Zex
                            p_a1Zct = double g_a1Zcs
                            (g_a1Zcs, gpart_a1Zex) = Genome.Split.split gpart_a1Zew
                            p_a1Zcr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zcq
                            (g_a1Zcq, gpart_a1Zew) = Genome.Split.split gpart_a1Zev
                            p_a1Zcp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zco
                            (g_a1Zco, gpart_a1Zev) = Genome.Split.split gpart_a1Zeu
                            p_a1Zcn = double g_a1Zcm
                            (g_a1Zcm, gpart_a1Zeu) = Genome.Split.split gpart_a1Zet
                            p_a1Zcl = double g_a1Zck
                            (g_a1Zck, gpart_a1Zet) = Genome.Split.split gpart_a1Zes
                            p_a1Zcj = double g_a1Zci
                            (g_a1Zci, gpart_a1Zes) = Genome.Split.split gpart_a1Zer
                            p_a1Zch = double g_a1Zcg
                            (g_a1Zcg, gpart_a1Zer) = Genome.Split.split gpart_a1Zeq
                            p_a1Zcf = double g_a1Zce
                            (g_a1Zce, gpart_a1Zeq) = Genome.Split.split genome_a1Zds
                          in
                            \ desc_a1Zdt
                              -> case desc_a1Zdt of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcf)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zch)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcj)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcl)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcn)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcp)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcr)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zct)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcv)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcx)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcz)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcB)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcD)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcF)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcH)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcJ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcL)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcN)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcP)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcR)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcT)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcV)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcX)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcZ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd1)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd3)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd5)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd7)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd9)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdb)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdd)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdf)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdh)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdr)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1Zhp
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zi2
                      p_a1Zho = double g_a1Zhn
                      (g_a1Zhn, gpart_a1Zi2) = Genome.Split.split gpart_a1Zi1
                      p_a1Zhm = double g_a1Zhl
                      (g_a1Zhl, gpart_a1Zi1) = Genome.Split.split gpart_a1Zi0
                      p_a1Zhk = double g_a1Zhj
                      (g_a1Zhj, gpart_a1Zi0) = Genome.Split.split gpart_a1ZhZ
                      p_a1Zhi = double g_a1Zhh
                      (g_a1Zhh, gpart_a1ZhZ) = Genome.Split.split gpart_a1ZhY
                      p_a1Zhg = double g_a1Zhf
                      (g_a1Zhf, gpart_a1ZhY) = Genome.Split.split gpart_a1ZhX
                      p_a1Zhe = Functions.belowten' g_a1Zhd
                      (g_a1Zhd, gpart_a1ZhX) = Genome.Split.split gpart_a1ZhW
                      p_a1Zhc = double g_a1Zhb
                      (g_a1Zhb, gpart_a1ZhW) = Genome.Split.split gpart_a1ZhV
                      p_a1Zha = double g_a1Zh9
                      (g_a1Zh9, gpart_a1ZhV) = Genome.Split.split gpart_a1ZhU
                      p_a1Zh8 = double g_a1Zh7
                      (g_a1Zh7, gpart_a1ZhU) = Genome.Split.split gpart_a1ZhT
                      p_a1Zh6 = Functions.belowten' g_a1Zh5
                      (g_a1Zh5, gpart_a1ZhT) = Genome.Split.split gpart_a1ZhS
                      p_a1Zh4 = double g_a1Zh3
                      (g_a1Zh3, gpart_a1ZhS) = Genome.Split.split gpart_a1ZhR
                      p_a1Zh2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zh1
                      (g_a1Zh1, gpart_a1ZhR) = Genome.Split.split gpart_a1ZhQ
                      p_a1Zh0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgZ
                      (g_a1ZgZ, gpart_a1ZhQ) = Genome.Split.split gpart_a1ZhP
                      p_a1ZgY = Functions.belowten' g_a1ZgX
                      (g_a1ZgX, gpart_a1ZhP) = Genome.Split.split gpart_a1ZhO
                      p_a1ZgW = double g_a1ZgV
                      (g_a1ZgV, gpart_a1ZhO) = Genome.Split.split gpart_a1ZhN
                      p_a1ZgU = double g_a1ZgT
                      (g_a1ZgT, gpart_a1ZhN) = Genome.Split.split gpart_a1ZhM
                      p_a1ZgS = double g_a1ZgR
                      (g_a1ZgR, gpart_a1ZhM) = Genome.Split.split gpart_a1ZhL
                      p_a1ZgQ = Functions.belowten' g_a1ZgP
                      (g_a1ZgP, gpart_a1ZhL) = Genome.Split.split gpart_a1ZhK
                      p_a1ZgO = double g_a1ZgN
                      (g_a1ZgN, gpart_a1ZhK) = Genome.Split.split gpart_a1ZhJ
                      p_a1ZgM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgL
                      (g_a1ZgL, gpart_a1ZhJ) = Genome.Split.split gpart_a1ZhI
                      p_a1ZgK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgJ
                      (g_a1ZgJ, gpart_a1ZhI) = Genome.Split.split gpart_a1ZhH
                      p_a1ZgI = double g_a1ZgH
                      (g_a1ZgH, gpart_a1ZhH) = Genome.Split.split gpart_a1ZhG
                      p_a1ZgG = Functions.belowten' g_a1ZgF
                      (g_a1ZgF, gpart_a1ZhG) = Genome.Split.split gpart_a1ZhF
                      p_a1ZgE = double g_a1ZgD
                      (g_a1ZgD, gpart_a1ZhF) = Genome.Split.split gpart_a1ZhE
                      p_a1ZgC = Functions.belowten' g_a1ZgB
                      (g_a1ZgB, gpart_a1ZhE) = Genome.Split.split gpart_a1ZhD
                      p_a1ZgA = double g_a1Zgz
                      (g_a1Zgz, gpart_a1ZhD) = Genome.Split.split gpart_a1ZhC
                      p_a1Zgy = double g_a1Zgx
                      (g_a1Zgx, gpart_a1ZhC) = Genome.Split.split gpart_a1ZhB
                      p_a1Zgw = Functions.belowten' g_a1Zgv
                      (g_a1Zgv, gpart_a1ZhB) = Genome.Split.split gpart_a1ZhA
                      p_a1Zgu = double g_a1Zgt
                      (g_a1Zgt, gpart_a1ZhA) = Genome.Split.split gpart_a1Zhz
                      p_a1Zgs = Functions.belowten' g_a1Zgr
                      (g_a1Zgr, gpart_a1Zhz) = Genome.Split.split gpart_a1Zhy
                      p_a1Zgq = double g_a1Zgp
                      (g_a1Zgp, gpart_a1Zhy) = Genome.Split.split gpart_a1Zhx
                      p_a1Zgo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgn
                      (g_a1Zgn, gpart_a1Zhx) = Genome.Split.split gpart_a1Zhw
                      p_a1Zgm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgl
                      (g_a1Zgl, gpart_a1Zhw) = Genome.Split.split gpart_a1Zhv
                      p_a1Zgk = double g_a1Zgj
                      (g_a1Zgj, gpart_a1Zhv) = Genome.Split.split gpart_a1Zhu
                      p_a1Zgi = double g_a1Zgh
                      (g_a1Zgh, gpart_a1Zhu) = Genome.Split.split gpart_a1Zht
                      p_a1Zgg = double g_a1Zgf
                      (g_a1Zgf, gpart_a1Zht) = Genome.Split.split gpart_a1Zhs
                      p_a1Zge = double g_a1Zgd
                      (g_a1Zgd, gpart_a1Zhs) = Genome.Split.split gpart_a1Zhr
                      p_a1Zgc = double g_a1Zgb
                      (g_a1Zgb, gpart_a1Zhr) = Genome.Split.split genome_a1Zhp
                    in  \ x_a1Zi3
                          -> let
                               c_PTB_a1Zi7
                                 = ((Data.Fixed.Vector.toVector x_a1Zi3) Data.Vector.Unboxed.! 0)
                               c_NPTB_a1Zi4
                                 = ((Data.Fixed.Vector.toVector x_a1Zi3) Data.Vector.Unboxed.! 1)
                               c_MiRs_a1Zi5
                                 = ((Data.Fixed.Vector.toVector x_a1Zi3) Data.Vector.Unboxed.! 2)
                               c_RESTc_a1Zic
                                 = ((Data.Fixed.Vector.toVector x_a1Zi3) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zim
                                 = ((Data.Fixed.Vector.toVector x_a1Zi3) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zgk
                                     / (1
                                        + (((c_NPTB_a1Zi4 / p_a1Zgq) ** p_a1Zgs)
                                           + ((c_MiRs_a1Zi5 / p_a1Zgu) ** p_a1Zgw))))
                                    + (negate (p_a1Zhg * c_PTB_a1Zi7))),
                                   ((p_a1Zgy
                                     / (1
                                        + (((c_MiRs_a1Zi5 / p_a1ZgA) ** p_a1ZgC)
                                           + ((c_PTB_a1Zi7 / p_a1ZgE) ** p_a1ZgG))))
                                    + (negate (p_a1Zhi * c_NPTB_a1Zi4))),
                                   ((p_a1ZgI
                                     * (p_a1ZgS
                                        / ((1 + p_a1ZgS) + ((c_RESTc_a1Zic / p_a1ZgO) ** p_a1ZgQ))))
                                    + (negate (p_a1Zhk * c_MiRs_a1Zi5))),
                                   ((p_a1ZgU
                                     * ((p_a1Zh8 + ((c_PTB_a1Zi7 / p_a1ZgW) ** p_a1ZgY))
                                        / (((1 + p_a1Zh8) + ((c_PTB_a1Zi7 / p_a1ZgW) ** p_a1ZgY))
                                           + (((p_a1Zgc / p_a1Zh0) ** p_a1Zh2)
                                              + ((c_MiRs_a1Zi5 / p_a1Zh4) ** p_a1Zh6)))))
                                    + (negate (p_a1Zhm * c_RESTc_a1Zic))),
                                   ((p_a1Zha / (1 + ((c_RESTc_a1Zic / p_a1Zhc) ** p_a1Zhe)))
                                    + (negate (p_a1Zho * c_EndoNeuroTFs_a1Zim)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483607",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483608",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483609",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483610",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483611",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483612",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483618",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483620",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483624",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483626",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483628",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483631",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483632",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483633",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483634",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483635",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483636",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483638",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483640",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483642",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483644",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483648",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483650",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483652",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483654",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483656",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483658",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483660",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483662",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483663",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483664",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483665",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483666",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483668",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483670",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483672",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483674",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483676",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483678",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zhp
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZiY
                            p_a1Zho = double g_a1Zhn
                            (g_a1Zhn, gpart_a1ZiY) = Genome.Split.split gpart_a1ZiX
                            p_a1Zhm = double g_a1Zhl
                            (g_a1Zhl, gpart_a1ZiX) = Genome.Split.split gpart_a1ZiW
                            p_a1Zhk = double g_a1Zhj
                            (g_a1Zhj, gpart_a1ZiW) = Genome.Split.split gpart_a1ZiV
                            p_a1Zhi = double g_a1Zhh
                            (g_a1Zhh, gpart_a1ZiV) = Genome.Split.split gpart_a1ZiU
                            p_a1Zhg = double g_a1Zhf
                            (g_a1Zhf, gpart_a1ZiU) = Genome.Split.split gpart_a1ZiT
                            p_a1Zhe = Functions.belowten' g_a1Zhd
                            (g_a1Zhd, gpart_a1ZiT) = Genome.Split.split gpart_a1ZiS
                            p_a1Zhc = double g_a1Zhb
                            (g_a1Zhb, gpart_a1ZiS) = Genome.Split.split gpart_a1ZiR
                            p_a1Zha = double g_a1Zh9
                            (g_a1Zh9, gpart_a1ZiR) = Genome.Split.split gpart_a1ZiQ
                            p_a1Zh8 = double g_a1Zh7
                            (g_a1Zh7, gpart_a1ZiQ) = Genome.Split.split gpart_a1ZiP
                            p_a1Zh6 = Functions.belowten' g_a1Zh5
                            (g_a1Zh5, gpart_a1ZiP) = Genome.Split.split gpart_a1ZiO
                            p_a1Zh4 = double g_a1Zh3
                            (g_a1Zh3, gpart_a1ZiO) = Genome.Split.split gpart_a1ZiN
                            p_a1Zh2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zh1
                            (g_a1Zh1, gpart_a1ZiN) = Genome.Split.split gpart_a1ZiM
                            p_a1Zh0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgZ
                            (g_a1ZgZ, gpart_a1ZiM) = Genome.Split.split gpart_a1ZiL
                            p_a1ZgY = Functions.belowten' g_a1ZgX
                            (g_a1ZgX, gpart_a1ZiL) = Genome.Split.split gpart_a1ZiK
                            p_a1ZgW = double g_a1ZgV
                            (g_a1ZgV, gpart_a1ZiK) = Genome.Split.split gpart_a1ZiJ
                            p_a1ZgU = double g_a1ZgT
                            (g_a1ZgT, gpart_a1ZiJ) = Genome.Split.split gpart_a1ZiI
                            p_a1ZgS = double g_a1ZgR
                            (g_a1ZgR, gpart_a1ZiI) = Genome.Split.split gpart_a1ZiH
                            p_a1ZgQ = Functions.belowten' g_a1ZgP
                            (g_a1ZgP, gpart_a1ZiH) = Genome.Split.split gpart_a1ZiG
                            p_a1ZgO = double g_a1ZgN
                            (g_a1ZgN, gpart_a1ZiG) = Genome.Split.split gpart_a1ZiF
                            p_a1ZgM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgL
                            (g_a1ZgL, gpart_a1ZiF) = Genome.Split.split gpart_a1ZiE
                            p_a1ZgK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgJ
                            (g_a1ZgJ, gpart_a1ZiE) = Genome.Split.split gpart_a1ZiD
                            p_a1ZgI = double g_a1ZgH
                            (g_a1ZgH, gpart_a1ZiD) = Genome.Split.split gpart_a1ZiC
                            p_a1ZgG = Functions.belowten' g_a1ZgF
                            (g_a1ZgF, gpart_a1ZiC) = Genome.Split.split gpart_a1ZiB
                            p_a1ZgE = double g_a1ZgD
                            (g_a1ZgD, gpart_a1ZiB) = Genome.Split.split gpart_a1ZiA
                            p_a1ZgC = Functions.belowten' g_a1ZgB
                            (g_a1ZgB, gpart_a1ZiA) = Genome.Split.split gpart_a1Ziz
                            p_a1ZgA = double g_a1Zgz
                            (g_a1Zgz, gpart_a1Ziz) = Genome.Split.split gpart_a1Ziy
                            p_a1Zgy = double g_a1Zgx
                            (g_a1Zgx, gpart_a1Ziy) = Genome.Split.split gpart_a1Zix
                            p_a1Zgw = Functions.belowten' g_a1Zgv
                            (g_a1Zgv, gpart_a1Zix) = Genome.Split.split gpart_a1Ziw
                            p_a1Zgu = double g_a1Zgt
                            (g_a1Zgt, gpart_a1Ziw) = Genome.Split.split gpart_a1Ziv
                            p_a1Zgs = Functions.belowten' g_a1Zgr
                            (g_a1Zgr, gpart_a1Ziv) = Genome.Split.split gpart_a1Ziu
                            p_a1Zgq = double g_a1Zgp
                            (g_a1Zgp, gpart_a1Ziu) = Genome.Split.split gpart_a1Zit
                            p_a1Zgo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgn
                            (g_a1Zgn, gpart_a1Zit) = Genome.Split.split gpart_a1Zis
                            p_a1Zgm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgl
                            (g_a1Zgl, gpart_a1Zis) = Genome.Split.split gpart_a1Zir
                            p_a1Zgk = double g_a1Zgj
                            (g_a1Zgj, gpart_a1Zir) = Genome.Split.split gpart_a1Ziq
                            p_a1Zgi = double g_a1Zgh
                            (g_a1Zgh, gpart_a1Ziq) = Genome.Split.split gpart_a1Zip
                            p_a1Zgg = double g_a1Zgf
                            (g_a1Zgf, gpart_a1Zip) = Genome.Split.split gpart_a1Zio
                            p_a1Zge = double g_a1Zgd
                            (g_a1Zgd, gpart_a1Zio) = Genome.Split.split gpart_a1Zin
                            p_a1Zgc = double g_a1Zgb
                            (g_a1Zgb, gpart_a1Zin) = Genome.Split.split genome_a1Zhp
                          in
                            \ desc_a1Zhq
                              -> case desc_a1Zhq of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgc)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zge)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgg)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgi)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgk)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgm)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgo)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgq)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgs)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgu)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgw)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgy)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgA)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgC)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgE)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgG)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgI)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgK)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgM)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgO)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgQ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgS)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgU)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgW)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgY)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh0)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh2)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh4)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh6)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh8)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zha)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhc)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhe)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhg)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhi)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhk)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhm)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zho)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1Zlm
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZlZ
                      p_a1Zll = double g_a1Zlk
                      (g_a1Zlk, gpart_a1ZlZ) = Genome.Split.split gpart_a1ZlY
                      p_a1Zlj = double g_a1Zli
                      (g_a1Zli, gpart_a1ZlY) = Genome.Split.split gpart_a1ZlX
                      p_a1Zlh = double g_a1Zlg
                      (g_a1Zlg, gpart_a1ZlX) = Genome.Split.split gpart_a1ZlW
                      p_a1Zlf = double g_a1Zle
                      (g_a1Zle, gpart_a1ZlW) = Genome.Split.split gpart_a1ZlV
                      p_a1Zld = double g_a1Zlc
                      (g_a1Zlc, gpart_a1ZlV) = Genome.Split.split gpart_a1ZlU
                      p_a1Zlb = Functions.belowten' g_a1Zla
                      (g_a1Zla, gpart_a1ZlU) = Genome.Split.split gpart_a1ZlT
                      p_a1Zl9 = double g_a1Zl8
                      (g_a1Zl8, gpart_a1ZlT) = Genome.Split.split gpart_a1ZlS
                      p_a1Zl7 = double g_a1Zl6
                      (g_a1Zl6, gpart_a1ZlS) = Genome.Split.split gpart_a1ZlR
                      p_a1Zl5 = double g_a1Zl4
                      (g_a1Zl4, gpart_a1ZlR) = Genome.Split.split gpart_a1ZlQ
                      p_a1Zl3 = Functions.belowten' g_a1Zl2
                      (g_a1Zl2, gpart_a1ZlQ) = Genome.Split.split gpart_a1ZlP
                      p_a1Zl1 = double g_a1Zl0
                      (g_a1Zl0, gpart_a1ZlP) = Genome.Split.split gpart_a1ZlO
                      p_a1ZkZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkY
                      (g_a1ZkY, gpart_a1ZlO) = Genome.Split.split gpart_a1ZlN
                      p_a1ZkX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkW
                      (g_a1ZkW, gpart_a1ZlN) = Genome.Split.split gpart_a1ZlM
                      p_a1ZkV = Functions.belowten' g_a1ZkU
                      (g_a1ZkU, gpart_a1ZlM) = Genome.Split.split gpart_a1ZlL
                      p_a1ZkT = double g_a1ZkS
                      (g_a1ZkS, gpart_a1ZlL) = Genome.Split.split gpart_a1ZlK
                      p_a1ZkR = double g_a1ZkQ
                      (g_a1ZkQ, gpart_a1ZlK) = Genome.Split.split gpart_a1ZlJ
                      p_a1ZkP = double g_a1ZkO
                      (g_a1ZkO, gpart_a1ZlJ) = Genome.Split.split gpart_a1ZlI
                      p_a1ZkN = Functions.belowten' g_a1ZkM
                      (g_a1ZkM, gpart_a1ZlI) = Genome.Split.split gpart_a1ZlH
                      p_a1ZkL = double g_a1ZkK
                      (g_a1ZkK, gpart_a1ZlH) = Genome.Split.split gpart_a1ZlG
                      p_a1ZkJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkI
                      (g_a1ZkI, gpart_a1ZlG) = Genome.Split.split gpart_a1ZlF
                      p_a1ZkH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkG
                      (g_a1ZkG, gpart_a1ZlF) = Genome.Split.split gpart_a1ZlE
                      p_a1ZkF = double g_a1ZkE
                      (g_a1ZkE, gpart_a1ZlE) = Genome.Split.split gpart_a1ZlD
                      p_a1ZkD = Functions.belowten' g_a1ZkC
                      (g_a1ZkC, gpart_a1ZlD) = Genome.Split.split gpart_a1ZlC
                      p_a1ZkB = double g_a1ZkA
                      (g_a1ZkA, gpart_a1ZlC) = Genome.Split.split gpart_a1ZlB
                      p_a1Zkz = Functions.belowten' g_a1Zky
                      (g_a1Zky, gpart_a1ZlB) = Genome.Split.split gpart_a1ZlA
                      p_a1Zkx = double g_a1Zkw
                      (g_a1Zkw, gpart_a1ZlA) = Genome.Split.split gpart_a1Zlz
                      p_a1Zkv = double g_a1Zku
                      (g_a1Zku, gpart_a1Zlz) = Genome.Split.split gpart_a1Zly
                      p_a1Zkt = Functions.belowten' g_a1Zks
                      (g_a1Zks, gpart_a1Zly) = Genome.Split.split gpart_a1Zlx
                      p_a1Zkr = double g_a1Zkq
                      (g_a1Zkq, gpart_a1Zlx) = Genome.Split.split gpart_a1Zlw
                      p_a1Zkp = Functions.belowten' g_a1Zko
                      (g_a1Zko, gpart_a1Zlw) = Genome.Split.split gpart_a1Zlv
                      p_a1Zkn = double g_a1Zkm
                      (g_a1Zkm, gpart_a1Zlv) = Genome.Split.split gpart_a1Zlu
                      p_a1Zkl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zkk
                      (g_a1Zkk, gpart_a1Zlu) = Genome.Split.split gpart_a1Zlt
                      p_a1Zkj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zki
                      (g_a1Zki, gpart_a1Zlt) = Genome.Split.split gpart_a1Zls
                      p_a1Zkh = double g_a1Zkg
                      (g_a1Zkg, gpart_a1Zls) = Genome.Split.split gpart_a1Zlr
                      p_a1Zkf = double g_a1Zke
                      (g_a1Zke, gpart_a1Zlr) = Genome.Split.split gpart_a1Zlq
                      p_a1Zkd = double g_a1Zkc
                      (g_a1Zkc, gpart_a1Zlq) = Genome.Split.split gpart_a1Zlp
                      p_a1Zkb = double g_a1Zka
                      (g_a1Zka, gpart_a1Zlp) = Genome.Split.split gpart_a1Zlo
                      p_a1Zk9 = double g_a1Zk8
                      (g_a1Zk8, gpart_a1Zlo) = Genome.Split.split genome_a1Zlm
                    in  \ x_a1Zm0
                          -> let
                               c_PTB_a1Zm4
                                 = ((Data.Fixed.Vector.toVector x_a1Zm0) Data.Vector.Unboxed.! 0)
                               c_NPTB_a1Zm1
                                 = ((Data.Fixed.Vector.toVector x_a1Zm0) Data.Vector.Unboxed.! 1)
                               c_MiRs_a1Zm2
                                 = ((Data.Fixed.Vector.toVector x_a1Zm0) Data.Vector.Unboxed.! 2)
                               c_RESTc_a1Zm9
                                 = ((Data.Fixed.Vector.toVector x_a1Zm0) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zmj
                                 = ((Data.Fixed.Vector.toVector x_a1Zm0) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zkh
                                     / (1
                                        + (((c_NPTB_a1Zm1 / p_a1Zkn) ** p_a1Zkp)
                                           + ((c_MiRs_a1Zm2 / p_a1Zkr) ** p_a1Zkt))))
                                    + (negate (p_a1Zld * c_PTB_a1Zm4))),
                                   ((p_a1Zkv
                                     / (1
                                        + (((c_MiRs_a1Zm2 / p_a1Zkx) ** p_a1Zkz)
                                           + ((c_PTB_a1Zm4 / p_a1ZkB) ** p_a1ZkD))))
                                    + (negate (p_a1Zlf * c_NPTB_a1Zm1))),
                                   ((p_a1ZkF
                                     * (p_a1ZkP
                                        / ((1 + p_a1ZkP) + ((c_RESTc_a1Zm9 / p_a1ZkL) ** p_a1ZkN))))
                                    + (negate (p_a1Zlh * c_MiRs_a1Zm2))),
                                   ((p_a1ZkR
                                     * ((p_a1Zl5 + ((c_PTB_a1Zm4 / p_a1ZkT) ** p_a1ZkV))
                                        / (((1 + p_a1Zl5) + ((c_PTB_a1Zm4 / p_a1ZkT) ** p_a1ZkV))
                                           + ((c_MiRs_a1Zm2 / p_a1Zl1) ** p_a1Zl3))))
                                    + (negate (p_a1Zlj * c_RESTc_a1Zm9))),
                                   ((p_a1Zl7 / (1 + ((c_RESTc_a1Zm9 / p_a1Zl9) ** p_a1Zlb)))
                                    + (negate (p_a1Zll * c_EndoNeuroTFs_a1Zmj)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483863",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483865",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483879",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483881",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483887",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483889",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483903",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483905",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zlm
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZmV
                            p_a1Zll = double g_a1Zlk
                            (g_a1Zlk, gpart_a1ZmV) = Genome.Split.split gpart_a1ZmU
                            p_a1Zlj = double g_a1Zli
                            (g_a1Zli, gpart_a1ZmU) = Genome.Split.split gpart_a1ZmT
                            p_a1Zlh = double g_a1Zlg
                            (g_a1Zlg, gpart_a1ZmT) = Genome.Split.split gpart_a1ZmS
                            p_a1Zlf = double g_a1Zle
                            (g_a1Zle, gpart_a1ZmS) = Genome.Split.split gpart_a1ZmR
                            p_a1Zld = double g_a1Zlc
                            (g_a1Zlc, gpart_a1ZmR) = Genome.Split.split gpart_a1ZmQ
                            p_a1Zlb = Functions.belowten' g_a1Zla
                            (g_a1Zla, gpart_a1ZmQ) = Genome.Split.split gpart_a1ZmP
                            p_a1Zl9 = double g_a1Zl8
                            (g_a1Zl8, gpart_a1ZmP) = Genome.Split.split gpart_a1ZmO
                            p_a1Zl7 = double g_a1Zl6
                            (g_a1Zl6, gpart_a1ZmO) = Genome.Split.split gpart_a1ZmN
                            p_a1Zl5 = double g_a1Zl4
                            (g_a1Zl4, gpart_a1ZmN) = Genome.Split.split gpart_a1ZmM
                            p_a1Zl3 = Functions.belowten' g_a1Zl2
                            (g_a1Zl2, gpart_a1ZmM) = Genome.Split.split gpart_a1ZmL
                            p_a1Zl1 = double g_a1Zl0
                            (g_a1Zl0, gpart_a1ZmL) = Genome.Split.split gpart_a1ZmK
                            p_a1ZkZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkY
                            (g_a1ZkY, gpart_a1ZmK) = Genome.Split.split gpart_a1ZmJ
                            p_a1ZkX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkW
                            (g_a1ZkW, gpart_a1ZmJ) = Genome.Split.split gpart_a1ZmI
                            p_a1ZkV = Functions.belowten' g_a1ZkU
                            (g_a1ZkU, gpart_a1ZmI) = Genome.Split.split gpart_a1ZmH
                            p_a1ZkT = double g_a1ZkS
                            (g_a1ZkS, gpart_a1ZmH) = Genome.Split.split gpart_a1ZmG
                            p_a1ZkR = double g_a1ZkQ
                            (g_a1ZkQ, gpart_a1ZmG) = Genome.Split.split gpart_a1ZmF
                            p_a1ZkP = double g_a1ZkO
                            (g_a1ZkO, gpart_a1ZmF) = Genome.Split.split gpart_a1ZmE
                            p_a1ZkN = Functions.belowten' g_a1ZkM
                            (g_a1ZkM, gpart_a1ZmE) = Genome.Split.split gpart_a1ZmD
                            p_a1ZkL = double g_a1ZkK
                            (g_a1ZkK, gpart_a1ZmD) = Genome.Split.split gpart_a1ZmC
                            p_a1ZkJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkI
                            (g_a1ZkI, gpart_a1ZmC) = Genome.Split.split gpart_a1ZmB
                            p_a1ZkH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkG
                            (g_a1ZkG, gpart_a1ZmB) = Genome.Split.split gpart_a1ZmA
                            p_a1ZkF = double g_a1ZkE
                            (g_a1ZkE, gpart_a1ZmA) = Genome.Split.split gpart_a1Zmz
                            p_a1ZkD = Functions.belowten' g_a1ZkC
                            (g_a1ZkC, gpart_a1Zmz) = Genome.Split.split gpart_a1Zmy
                            p_a1ZkB = double g_a1ZkA
                            (g_a1ZkA, gpart_a1Zmy) = Genome.Split.split gpart_a1Zmx
                            p_a1Zkz = Functions.belowten' g_a1Zky
                            (g_a1Zky, gpart_a1Zmx) = Genome.Split.split gpart_a1Zmw
                            p_a1Zkx = double g_a1Zkw
                            (g_a1Zkw, gpart_a1Zmw) = Genome.Split.split gpart_a1Zmv
                            p_a1Zkv = double g_a1Zku
                            (g_a1Zku, gpart_a1Zmv) = Genome.Split.split gpart_a1Zmu
                            p_a1Zkt = Functions.belowten' g_a1Zks
                            (g_a1Zks, gpart_a1Zmu) = Genome.Split.split gpart_a1Zmt
                            p_a1Zkr = double g_a1Zkq
                            (g_a1Zkq, gpart_a1Zmt) = Genome.Split.split gpart_a1Zms
                            p_a1Zkp = Functions.belowten' g_a1Zko
                            (g_a1Zko, gpart_a1Zms) = Genome.Split.split gpart_a1Zmr
                            p_a1Zkn = double g_a1Zkm
                            (g_a1Zkm, gpart_a1Zmr) = Genome.Split.split gpart_a1Zmq
                            p_a1Zkl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zkk
                            (g_a1Zkk, gpart_a1Zmq) = Genome.Split.split gpart_a1Zmp
                            p_a1Zkj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zki
                            (g_a1Zki, gpart_a1Zmp) = Genome.Split.split gpart_a1Zmo
                            p_a1Zkh = double g_a1Zkg
                            (g_a1Zkg, gpart_a1Zmo) = Genome.Split.split gpart_a1Zmn
                            p_a1Zkf = double g_a1Zke
                            (g_a1Zke, gpart_a1Zmn) = Genome.Split.split gpart_a1Zmm
                            p_a1Zkd = double g_a1Zkc
                            (g_a1Zkc, gpart_a1Zmm) = Genome.Split.split gpart_a1Zml
                            p_a1Zkb = double g_a1Zka
                            (g_a1Zka, gpart_a1Zml) = Genome.Split.split gpart_a1Zmk
                            p_a1Zk9 = double g_a1Zk8
                            (g_a1Zk8, gpart_a1Zmk) = Genome.Split.split genome_a1Zlm
                          in
                            \ desc_a1Zln
                              -> case desc_a1Zln of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk9)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkb)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkd)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkf)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkh)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkj)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkl)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkn)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkp)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkr)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkt)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkv)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkx)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkz)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkB)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkD)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkF)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkH)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkJ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkL)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkN)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkP)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkR)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkT)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkV)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkX)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl1)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl3)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl5)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl7)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl9)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlb)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zld)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlf)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlh)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlj)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zll)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1Zpj
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZpW
                      p_a1Zpi = double g_a1Zph
                      (g_a1Zph, gpart_a1ZpW) = Genome.Split.split gpart_a1ZpV
                      p_a1Zpg = double g_a1Zpf
                      (g_a1Zpf, gpart_a1ZpV) = Genome.Split.split gpart_a1ZpU
                      p_a1Zpe = double g_a1Zpd
                      (g_a1Zpd, gpart_a1ZpU) = Genome.Split.split gpart_a1ZpT
                      p_a1Zpc = double g_a1Zpb
                      (g_a1Zpb, gpart_a1ZpT) = Genome.Split.split gpart_a1ZpS
                      p_a1Zpa = double g_a1Zp9
                      (g_a1Zp9, gpart_a1ZpS) = Genome.Split.split gpart_a1ZpR
                      p_a1Zp8 = Functions.belowten' g_a1Zp7
                      (g_a1Zp7, gpart_a1ZpR) = Genome.Split.split gpart_a1ZpQ
                      p_a1Zp6 = double g_a1Zp5
                      (g_a1Zp5, gpart_a1ZpQ) = Genome.Split.split gpart_a1ZpP
                      p_a1Zp4 = double g_a1Zp3
                      (g_a1Zp3, gpart_a1ZpP) = Genome.Split.split gpart_a1ZpO
                      p_a1Zp2 = double g_a1Zp1
                      (g_a1Zp1, gpart_a1ZpO) = Genome.Split.split gpart_a1ZpN
                      p_a1Zp0 = Functions.belowten' g_a1ZoZ
                      (g_a1ZoZ, gpart_a1ZpN) = Genome.Split.split gpart_a1ZpM
                      p_a1ZoY = double g_a1ZoX
                      (g_a1ZoX, gpart_a1ZpM) = Genome.Split.split gpart_a1ZpL
                      p_a1ZoW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoV
                      (g_a1ZoV, gpart_a1ZpL) = Genome.Split.split gpart_a1ZpK
                      p_a1ZoU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoT
                      (g_a1ZoT, gpart_a1ZpK) = Genome.Split.split gpart_a1ZpJ
                      p_a1ZoS = Functions.belowten' g_a1ZoR
                      (g_a1ZoR, gpart_a1ZpJ) = Genome.Split.split gpart_a1ZpI
                      p_a1ZoQ = double g_a1ZoP
                      (g_a1ZoP, gpart_a1ZpI) = Genome.Split.split gpart_a1ZpH
                      p_a1ZoO = double g_a1ZoN
                      (g_a1ZoN, gpart_a1ZpH) = Genome.Split.split gpart_a1ZpG
                      p_a1ZoM = double g_a1ZoL
                      (g_a1ZoL, gpart_a1ZpG) = Genome.Split.split gpart_a1ZpF
                      p_a1ZoK = Functions.belowten' g_a1ZoJ
                      (g_a1ZoJ, gpart_a1ZpF) = Genome.Split.split gpart_a1ZpE
                      p_a1ZoI = double g_a1ZoH
                      (g_a1ZoH, gpart_a1ZpE) = Genome.Split.split gpart_a1ZpD
                      p_a1ZoG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoF
                      (g_a1ZoF, gpart_a1ZpD) = Genome.Split.split gpart_a1ZpC
                      p_a1ZoE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoD
                      (g_a1ZoD, gpart_a1ZpC) = Genome.Split.split gpart_a1ZpB
                      p_a1ZoC = double g_a1ZoB
                      (g_a1ZoB, gpart_a1ZpB) = Genome.Split.split gpart_a1ZpA
                      p_a1ZoA = Functions.belowten' g_a1Zoz
                      (g_a1Zoz, gpart_a1ZpA) = Genome.Split.split gpart_a1Zpz
                      p_a1Zoy = double g_a1Zox
                      (g_a1Zox, gpart_a1Zpz) = Genome.Split.split gpart_a1Zpy
                      p_a1Zow = Functions.belowten' g_a1Zov
                      (g_a1Zov, gpart_a1Zpy) = Genome.Split.split gpart_a1Zpx
                      p_a1Zou = double g_a1Zot
                      (g_a1Zot, gpart_a1Zpx) = Genome.Split.split gpart_a1Zpw
                      p_a1Zos = double g_a1Zor
                      (g_a1Zor, gpart_a1Zpw) = Genome.Split.split gpart_a1Zpv
                      p_a1Zoq = Functions.belowten' g_a1Zop
                      (g_a1Zop, gpart_a1Zpv) = Genome.Split.split gpart_a1Zpu
                      p_a1Zoo = double g_a1Zon
                      (g_a1Zon, gpart_a1Zpu) = Genome.Split.split gpart_a1Zpt
                      p_a1Zom = Functions.belowten' g_a1Zol
                      (g_a1Zol, gpart_a1Zpt) = Genome.Split.split gpart_a1Zps
                      p_a1Zok = double g_a1Zoj
                      (g_a1Zoj, gpart_a1Zps) = Genome.Split.split gpart_a1Zpr
                      p_a1Zoi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoh
                      (g_a1Zoh, gpart_a1Zpr) = Genome.Split.split gpart_a1Zpq
                      p_a1Zog
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zof
                      (g_a1Zof, gpart_a1Zpq) = Genome.Split.split gpart_a1Zpp
                      p_a1Zoe = double g_a1Zod
                      (g_a1Zod, gpart_a1Zpp) = Genome.Split.split gpart_a1Zpo
                      p_a1Zoc = double g_a1Zob
                      (g_a1Zob, gpart_a1Zpo) = Genome.Split.split gpart_a1Zpn
                      p_a1Zoa = double g_a1Zo9
                      (g_a1Zo9, gpart_a1Zpn) = Genome.Split.split gpart_a1Zpm
                      p_a1Zo8 = double g_a1Zo7
                      (g_a1Zo7, gpart_a1Zpm) = Genome.Split.split gpart_a1Zpl
                      p_a1Zo6 = double g_a1Zo5
                      (g_a1Zo5, gpart_a1Zpl) = Genome.Split.split genome_a1Zpj
                    in  \ x_a1ZpX
                          -> let
                               c_PTB_a1Zq1
                                 = ((Data.Fixed.Vector.toVector x_a1ZpX) Data.Vector.Unboxed.! 0)
                               c_NPTB_a1ZpY
                                 = ((Data.Fixed.Vector.toVector x_a1ZpX) Data.Vector.Unboxed.! 1)
                               c_MiRs_a1ZpZ
                                 = ((Data.Fixed.Vector.toVector x_a1ZpX) Data.Vector.Unboxed.! 2)
                               c_RESTc_a1Zq6
                                 = ((Data.Fixed.Vector.toVector x_a1ZpX) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zqg
                                 = ((Data.Fixed.Vector.toVector x_a1ZpX) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zoe
                                     / (1
                                        + ((((p_a1Zo6 / p_a1Zog) ** p_a1Zoi)
                                            + ((c_NPTB_a1ZpY / p_a1Zok) ** p_a1Zom))
                                           + ((c_MiRs_a1ZpZ / p_a1Zoo) ** p_a1Zoq))))
                                    + (negate (p_a1Zpa * c_PTB_a1Zq1))),
                                   ((p_a1Zos
                                     / (1
                                        + (((c_MiRs_a1ZpZ / p_a1Zou) ** p_a1Zow)
                                           + ((c_PTB_a1Zq1 / p_a1Zoy) ** p_a1ZoA))))
                                    + (negate (p_a1Zpc * c_NPTB_a1ZpY))),
                                   ((p_a1ZoC
                                     * (p_a1ZoM
                                        / ((1 + p_a1ZoM) + ((c_RESTc_a1Zq6 / p_a1ZoI) ** p_a1ZoK))))
                                    + (negate (p_a1Zpe * c_MiRs_a1ZpZ))),
                                   ((p_a1ZoO
                                     * ((p_a1Zp2 + ((c_PTB_a1Zq1 / p_a1ZoQ) ** p_a1ZoS))
                                        / (((1 + p_a1Zp2) + ((c_PTB_a1Zq1 / p_a1ZoQ) ** p_a1ZoS))
                                           + ((c_MiRs_a1ZpZ / p_a1ZoY) ** p_a1Zp0))))
                                    + (negate (p_a1Zpg * c_RESTc_a1Zq6))),
                                   ((p_a1Zp4 / (1 + ((c_RESTc_a1Zq6 / p_a1Zp6) ** p_a1Zp8)))
                                    + (negate (p_a1Zpi * c_EndoNeuroTFs_a1Zqg)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484097",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484098",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484099",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484100",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484101",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484102",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484103",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484104",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484105",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484106",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484107",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484108",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484110",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484122",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484124",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484126",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484128",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484132",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484134",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484138",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484140",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484148",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484150",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zpj
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZqS
                            p_a1Zpi = double g_a1Zph
                            (g_a1Zph, gpart_a1ZqS) = Genome.Split.split gpart_a1ZqR
                            p_a1Zpg = double g_a1Zpf
                            (g_a1Zpf, gpart_a1ZqR) = Genome.Split.split gpart_a1ZqQ
                            p_a1Zpe = double g_a1Zpd
                            (g_a1Zpd, gpart_a1ZqQ) = Genome.Split.split gpart_a1ZqP
                            p_a1Zpc = double g_a1Zpb
                            (g_a1Zpb, gpart_a1ZqP) = Genome.Split.split gpart_a1ZqO
                            p_a1Zpa = double g_a1Zp9
                            (g_a1Zp9, gpart_a1ZqO) = Genome.Split.split gpart_a1ZqN
                            p_a1Zp8 = Functions.belowten' g_a1Zp7
                            (g_a1Zp7, gpart_a1ZqN) = Genome.Split.split gpart_a1ZqM
                            p_a1Zp6 = double g_a1Zp5
                            (g_a1Zp5, gpart_a1ZqM) = Genome.Split.split gpart_a1ZqL
                            p_a1Zp4 = double g_a1Zp3
                            (g_a1Zp3, gpart_a1ZqL) = Genome.Split.split gpart_a1ZqK
                            p_a1Zp2 = double g_a1Zp1
                            (g_a1Zp1, gpart_a1ZqK) = Genome.Split.split gpart_a1ZqJ
                            p_a1Zp0 = Functions.belowten' g_a1ZoZ
                            (g_a1ZoZ, gpart_a1ZqJ) = Genome.Split.split gpart_a1ZqI
                            p_a1ZoY = double g_a1ZoX
                            (g_a1ZoX, gpart_a1ZqI) = Genome.Split.split gpart_a1ZqH
                            p_a1ZoW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoV
                            (g_a1ZoV, gpart_a1ZqH) = Genome.Split.split gpart_a1ZqG
                            p_a1ZoU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoT
                            (g_a1ZoT, gpart_a1ZqG) = Genome.Split.split gpart_a1ZqF
                            p_a1ZoS = Functions.belowten' g_a1ZoR
                            (g_a1ZoR, gpart_a1ZqF) = Genome.Split.split gpart_a1ZqE
                            p_a1ZoQ = double g_a1ZoP
                            (g_a1ZoP, gpart_a1ZqE) = Genome.Split.split gpart_a1ZqD
                            p_a1ZoO = double g_a1ZoN
                            (g_a1ZoN, gpart_a1ZqD) = Genome.Split.split gpart_a1ZqC
                            p_a1ZoM = double g_a1ZoL
                            (g_a1ZoL, gpart_a1ZqC) = Genome.Split.split gpart_a1ZqB
                            p_a1ZoK = Functions.belowten' g_a1ZoJ
                            (g_a1ZoJ, gpart_a1ZqB) = Genome.Split.split gpart_a1ZqA
                            p_a1ZoI = double g_a1ZoH
                            (g_a1ZoH, gpart_a1ZqA) = Genome.Split.split gpart_a1Zqz
                            p_a1ZoG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoF
                            (g_a1ZoF, gpart_a1Zqz) = Genome.Split.split gpart_a1Zqy
                            p_a1ZoE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoD
                            (g_a1ZoD, gpart_a1Zqy) = Genome.Split.split gpart_a1Zqx
                            p_a1ZoC = double g_a1ZoB
                            (g_a1ZoB, gpart_a1Zqx) = Genome.Split.split gpart_a1Zqw
                            p_a1ZoA = Functions.belowten' g_a1Zoz
                            (g_a1Zoz, gpart_a1Zqw) = Genome.Split.split gpart_a1Zqv
                            p_a1Zoy = double g_a1Zox
                            (g_a1Zox, gpart_a1Zqv) = Genome.Split.split gpart_a1Zqu
                            p_a1Zow = Functions.belowten' g_a1Zov
                            (g_a1Zov, gpart_a1Zqu) = Genome.Split.split gpart_a1Zqt
                            p_a1Zou = double g_a1Zot
                            (g_a1Zot, gpart_a1Zqt) = Genome.Split.split gpart_a1Zqs
                            p_a1Zos = double g_a1Zor
                            (g_a1Zor, gpart_a1Zqs) = Genome.Split.split gpart_a1Zqr
                            p_a1Zoq = Functions.belowten' g_a1Zop
                            (g_a1Zop, gpart_a1Zqr) = Genome.Split.split gpart_a1Zqq
                            p_a1Zoo = double g_a1Zon
                            (g_a1Zon, gpart_a1Zqq) = Genome.Split.split gpart_a1Zqp
                            p_a1Zom = Functions.belowten' g_a1Zol
                            (g_a1Zol, gpart_a1Zqp) = Genome.Split.split gpart_a1Zqo
                            p_a1Zok = double g_a1Zoj
                            (g_a1Zoj, gpart_a1Zqo) = Genome.Split.split gpart_a1Zqn
                            p_a1Zoi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoh
                            (g_a1Zoh, gpart_a1Zqn) = Genome.Split.split gpart_a1Zqm
                            p_a1Zog
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zof
                            (g_a1Zof, gpart_a1Zqm) = Genome.Split.split gpart_a1Zql
                            p_a1Zoe = double g_a1Zod
                            (g_a1Zod, gpart_a1Zql) = Genome.Split.split gpart_a1Zqk
                            p_a1Zoc = double g_a1Zob
                            (g_a1Zob, gpart_a1Zqk) = Genome.Split.split gpart_a1Zqj
                            p_a1Zoa = double g_a1Zo9
                            (g_a1Zo9, gpart_a1Zqj) = Genome.Split.split gpart_a1Zqi
                            p_a1Zo8 = double g_a1Zo7
                            (g_a1Zo7, gpart_a1Zqi) = Genome.Split.split gpart_a1Zqh
                            p_a1Zo6 = double g_a1Zo5
                            (g_a1Zo5, gpart_a1Zqh) = Genome.Split.split genome_a1Zpj
                          in
                            \ desc_a1Zpk
                              -> case desc_a1Zpk of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo6)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo8)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoa)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoc)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoe)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zog)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoi)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zok)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zom)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoo)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoq)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zos)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zou)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zow)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoy)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoA)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoC)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoE)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoG)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoI)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoK)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoM)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoO)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoQ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoS)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoU)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoW)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoY)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp0)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp2)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp4)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp6)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp8)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpa)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpc)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpe)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpg)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpi)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asTs
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asU5
                      p_asTr = code-0.1.0.0:Genome.FixedList.Functions.double g_asTq
                      (g_asTq, gpart_asU5) = Genome.Split.split gpart_asU4
                      p_asTp = code-0.1.0.0:Genome.FixedList.Functions.double g_asTo
                      (g_asTo, gpart_asU4) = Genome.Split.split gpart_asU3
                      p_asTn = code-0.1.0.0:Genome.FixedList.Functions.double g_asTm
                      (g_asTm, gpart_asU3) = Genome.Split.split gpart_asU2
                      p_asTl = code-0.1.0.0:Genome.FixedList.Functions.double g_asTk
                      (g_asTk, gpart_asU2) = Genome.Split.split gpart_asU1
                      p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                      (g_asTi, gpart_asU1) = Genome.Split.split gpart_asU0
                      p_asTh = Functions.belowten' g_asTg
                      (g_asTg, gpart_asU0) = Genome.Split.split gpart_asTZ
                      p_asTf = code-0.1.0.0:Genome.FixedList.Functions.double g_asTe
                      (g_asTe, gpart_asTZ) = Genome.Split.split gpart_asTY
                      p_asTd = code-0.1.0.0:Genome.FixedList.Functions.double g_asTc
                      (g_asTc, gpart_asTY) = Genome.Split.split gpart_asTX
                      p_asTb = code-0.1.0.0:Genome.FixedList.Functions.double g_asTa
                      (g_asTa, gpart_asTX) = Genome.Split.split gpart_asTW
                      p_asT9 = Functions.belowten' g_asT8
                      (g_asT8, gpart_asTW) = Genome.Split.split gpart_asTV
                      p_asT7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT6
                      (g_asT6, gpart_asTV) = Genome.Split.split gpart_asTU
                      p_asT5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT4
                      (g_asT4, gpart_asTU) = Genome.Split.split gpart_asTT
                      p_asT3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT2
                      (g_asT2, gpart_asTT) = Genome.Split.split gpart_asTS
                      p_asT1 = Functions.belowten' g_asT0
                      (g_asT0, gpart_asTS) = Genome.Split.split gpart_asTR
                      p_asSZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSY
                      (g_asSY, gpart_asTR) = Genome.Split.split gpart_asTQ
                      p_asSX = code-0.1.0.0:Genome.FixedList.Functions.double g_asSW
                      (g_asSW, gpart_asTQ) = Genome.Split.split gpart_asTP
                      p_asSV = code-0.1.0.0:Genome.FixedList.Functions.double g_asSU
                      (g_asSU, gpart_asTP) = Genome.Split.split gpart_asTO
                      p_asST = Functions.belowten' g_asSS
                      (g_asSS, gpart_asTO) = Genome.Split.split gpart_asTN
                      p_asSR = code-0.1.0.0:Genome.FixedList.Functions.double g_asSQ
                      (g_asSQ, gpart_asTN) = Genome.Split.split gpart_asTM
                      p_asSP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSO
                      (g_asSO, gpart_asTM) = Genome.Split.split gpart_asTL
                      p_asSN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSM
                      (g_asSM, gpart_asTL) = Genome.Split.split gpart_asTK
                      p_asSL = code-0.1.0.0:Genome.FixedList.Functions.double g_asSK
                      (g_asSK, gpart_asTK) = Genome.Split.split gpart_asTJ
                      p_asSJ = Functions.belowten' g_asSI
                      (g_asSI, gpart_asTJ) = Genome.Split.split gpart_asTI
                      p_asSH = code-0.1.0.0:Genome.FixedList.Functions.double g_asSG
                      (g_asSG, gpart_asTI) = Genome.Split.split gpart_asTH
                      p_asSF = Functions.belowten' g_asSE
                      (g_asSE, gpart_asTH) = Genome.Split.split gpart_asTG
                      p_asSD = code-0.1.0.0:Genome.FixedList.Functions.double g_asSC
                      (g_asSC, gpart_asTG) = Genome.Split.split gpart_asTF
                      p_asSB = code-0.1.0.0:Genome.FixedList.Functions.double g_asSA
                      (g_asSA, gpart_asTF) = Genome.Split.split gpart_asTE
                      p_asSz = Functions.belowten' g_asSy
                      (g_asSy, gpart_asTE) = Genome.Split.split gpart_asTD
                      p_asSx = code-0.1.0.0:Genome.FixedList.Functions.double g_asSw
                      (g_asSw, gpart_asTD) = Genome.Split.split gpart_asTC
                      p_asSv = Functions.belowten' g_asSu
                      (g_asSu, gpart_asTC) = Genome.Split.split gpart_asTB
                      p_asSt = code-0.1.0.0:Genome.FixedList.Functions.double g_asSs
                      (g_asSs, gpart_asTB) = Genome.Split.split gpart_asTA
                      p_asSr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSq
                      (g_asSq, gpart_asTA) = Genome.Split.split gpart_asTz
                      p_asSp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSo
                      (g_asSo, gpart_asTz) = Genome.Split.split gpart_asTy
                      p_asSn = code-0.1.0.0:Genome.FixedList.Functions.double g_asSm
                      (g_asSm, gpart_asTy) = Genome.Split.split gpart_asTx
                      p_asSl = code-0.1.0.0:Genome.FixedList.Functions.double g_asSk
                      (g_asSk, gpart_asTx) = Genome.Split.split gpart_asTw
                      p_asSj = code-0.1.0.0:Genome.FixedList.Functions.double g_asSi
                      (g_asSi, gpart_asTw) = Genome.Split.split gpart_asTv
                      p_asSh = code-0.1.0.0:Genome.FixedList.Functions.double g_asSg
                      (g_asSg, gpart_asTv) = Genome.Split.split gpart_asTu
                      p_asSf = code-0.1.0.0:Genome.FixedList.Functions.double g_asSe
                      (g_asSe, gpart_asTu) = Genome.Split.split genome_asTs
                    in
                      [Reaction
                         (\ x_asU6
                            -> let
                                 c_NPTB_asU7 = ((toVector x_asU6) Data.Vector.Unboxed.! 1)
                                 c_MiRs_asU8 = ((toVector x_asU6) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asSn
                                  / (1
                                     + (((c_NPTB_asU7 / p_asSt) ** p_asSv)
                                        + ((c_MiRs_asU8 / p_asSx) ** p_asSz)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asU9
                            -> let
                                 c_MiRs_asUa = ((toVector x_asU9) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUb = ((toVector x_asU9) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asSB
                                  / (1
                                     + (((c_MiRs_asUa / p_asSD) ** p_asSF)
                                        + ((c_PTB_asUb / p_asSH) ** p_asSJ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asUc
                            -> let c_RESTc_asUd = ((toVector x_asUc) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asSL
                                  * ((p_asSV + ((p_asSj / p_asSN) ** p_asSP))
                                     / (((1 + p_asSV) + ((p_asSj / p_asSN) ** p_asSP))
                                        + ((c_RESTc_asUd / p_asSR) ** p_asST)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asUe
                            -> let
                                 c_MiRs_asUh = ((toVector x_asUe) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUf = ((toVector x_asUe) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asSX
                                  * ((p_asTb + ((c_PTB_asUf / p_asSZ) ** p_asT1))
                                     / (((1 + p_asTb) + ((c_PTB_asUf / p_asSZ) ** p_asT1))
                                        + (((p_asSf / p_asT3) ** p_asT5)
                                           + ((c_MiRs_asUh / p_asT7) ** p_asT9))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asUi
                            -> let c_RESTc_asUj = ((toVector x_asUi) Data.Vector.Unboxed.! 3)
                               in (p_asTd / (1 + ((c_RESTc_asUj / p_asTf) ** p_asTh))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asUk
                            -> let c_PTB_asUl = ((toVector x_asUk) Data.Vector.Unboxed.! 0)
                               in (p_asTj * c_PTB_asUl))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asUm
                            -> let c_NPTB_asUn = ((toVector x_asUm) Data.Vector.Unboxed.! 1)
                               in (p_asTl * c_NPTB_asUn))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asUo
                            -> let c_MiRs_asUp = ((toVector x_asUo) Data.Vector.Unboxed.! 2)
                               in (p_asTn * c_MiRs_asUp))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asUq
                            -> let c_RESTc_asUr = ((toVector x_asUq) Data.Vector.Unboxed.! 3)
                               in (p_asTp * c_RESTc_asUr))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asUs
                            -> let
                                 c_EndoNeuroTFs_asUt = ((toVector x_asUs) Data.Vector.Unboxed.! 4)
                               in (p_asTr * c_EndoNeuroTFs_asUt))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120787",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120795",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120797",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120798",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120799",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120800",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120801",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120802",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120803",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120805",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120807",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120809",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120811",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120817",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120819",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120821",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120823",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120827",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120829",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120837",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120839",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120841",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120843",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120845",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120847",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asTs
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVa
                            p_asTr = code-0.1.0.0:Genome.FixedList.Functions.double g_asTq
                            (g_asTq, gpart_asVa) = Genome.Split.split gpart_asV9
                            p_asTp = code-0.1.0.0:Genome.FixedList.Functions.double g_asTo
                            (g_asTo, gpart_asV9) = Genome.Split.split gpart_asV8
                            p_asTn = code-0.1.0.0:Genome.FixedList.Functions.double g_asTm
                            (g_asTm, gpart_asV8) = Genome.Split.split gpart_asV7
                            p_asTl = code-0.1.0.0:Genome.FixedList.Functions.double g_asTk
                            (g_asTk, gpart_asV7) = Genome.Split.split gpart_asV6
                            p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                            (g_asTi, gpart_asV6) = Genome.Split.split gpart_asV5
                            p_asTh = Functions.belowten' g_asTg
                            (g_asTg, gpart_asV5) = Genome.Split.split gpart_asV4
                            p_asTf = code-0.1.0.0:Genome.FixedList.Functions.double g_asTe
                            (g_asTe, gpart_asV4) = Genome.Split.split gpart_asV3
                            p_asTd = code-0.1.0.0:Genome.FixedList.Functions.double g_asTc
                            (g_asTc, gpart_asV3) = Genome.Split.split gpart_asV2
                            p_asTb = code-0.1.0.0:Genome.FixedList.Functions.double g_asTa
                            (g_asTa, gpart_asV2) = Genome.Split.split gpart_asV1
                            p_asT9 = Functions.belowten' g_asT8
                            (g_asT8, gpart_asV1) = Genome.Split.split gpart_asV0
                            p_asT7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT6
                            (g_asT6, gpart_asV0) = Genome.Split.split gpart_asUZ
                            p_asT5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT4
                            (g_asT4, gpart_asUZ) = Genome.Split.split gpart_asUY
                            p_asT3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT2
                            (g_asT2, gpart_asUY) = Genome.Split.split gpart_asUX
                            p_asT1 = Functions.belowten' g_asT0
                            (g_asT0, gpart_asUX) = Genome.Split.split gpart_asUW
                            p_asSZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSY
                            (g_asSY, gpart_asUW) = Genome.Split.split gpart_asUV
                            p_asSX = code-0.1.0.0:Genome.FixedList.Functions.double g_asSW
                            (g_asSW, gpart_asUV) = Genome.Split.split gpart_asUU
                            p_asSV = code-0.1.0.0:Genome.FixedList.Functions.double g_asSU
                            (g_asSU, gpart_asUU) = Genome.Split.split gpart_asUT
                            p_asST = Functions.belowten' g_asSS
                            (g_asSS, gpart_asUT) = Genome.Split.split gpart_asUS
                            p_asSR = code-0.1.0.0:Genome.FixedList.Functions.double g_asSQ
                            (g_asSQ, gpart_asUS) = Genome.Split.split gpart_asUR
                            p_asSP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSO
                            (g_asSO, gpart_asUR) = Genome.Split.split gpart_asUQ
                            p_asSN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSM
                            (g_asSM, gpart_asUQ) = Genome.Split.split gpart_asUP
                            p_asSL = code-0.1.0.0:Genome.FixedList.Functions.double g_asSK
                            (g_asSK, gpart_asUP) = Genome.Split.split gpart_asUO
                            p_asSJ = Functions.belowten' g_asSI
                            (g_asSI, gpart_asUO) = Genome.Split.split gpart_asUN
                            p_asSH = code-0.1.0.0:Genome.FixedList.Functions.double g_asSG
                            (g_asSG, gpart_asUN) = Genome.Split.split gpart_asUM
                            p_asSF = Functions.belowten' g_asSE
                            (g_asSE, gpart_asUM) = Genome.Split.split gpart_asUL
                            p_asSD = code-0.1.0.0:Genome.FixedList.Functions.double g_asSC
                            (g_asSC, gpart_asUL) = Genome.Split.split gpart_asUK
                            p_asSB = code-0.1.0.0:Genome.FixedList.Functions.double g_asSA
                            (g_asSA, gpart_asUK) = Genome.Split.split gpart_asUJ
                            p_asSz = Functions.belowten' g_asSy
                            (g_asSy, gpart_asUJ) = Genome.Split.split gpart_asUI
                            p_asSx = code-0.1.0.0:Genome.FixedList.Functions.double g_asSw
                            (g_asSw, gpart_asUI) = Genome.Split.split gpart_asUH
                            p_asSv = Functions.belowten' g_asSu
                            (g_asSu, gpart_asUH) = Genome.Split.split gpart_asUG
                            p_asSt = code-0.1.0.0:Genome.FixedList.Functions.double g_asSs
                            (g_asSs, gpart_asUG) = Genome.Split.split gpart_asUF
                            p_asSr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSq
                            (g_asSq, gpart_asUF) = Genome.Split.split gpart_asUE
                            p_asSp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSo
                            (g_asSo, gpart_asUE) = Genome.Split.split gpart_asUD
                            p_asSn = code-0.1.0.0:Genome.FixedList.Functions.double g_asSm
                            (g_asSm, gpart_asUD) = Genome.Split.split gpart_asUC
                            p_asSl = code-0.1.0.0:Genome.FixedList.Functions.double g_asSk
                            (g_asSk, gpart_asUC) = Genome.Split.split gpart_asUB
                            p_asSj = code-0.1.0.0:Genome.FixedList.Functions.double g_asSi
                            (g_asSi, gpart_asUB) = Genome.Split.split gpart_asUA
                            p_asSh = code-0.1.0.0:Genome.FixedList.Functions.double g_asSg
                            (g_asSg, gpart_asUA) = Genome.Split.split gpart_asUz
                            p_asSf = code-0.1.0.0:Genome.FixedList.Functions.double g_asSe
                            (g_asSe, gpart_asUz) = Genome.Split.split genome_asTs
                          in
                            \ desc_asTt
                              -> case desc_asTt of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSf)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSh)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSj)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSl)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSn)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSp)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSr)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSt)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSv)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSx)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSz)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSB)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSD)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSF)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSH)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSJ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSL)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSN)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSP)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSR)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asST)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSV)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSX)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSZ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT1)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT3)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT5)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT7)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT9)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTb)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTd)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTf)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTh)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTr)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asX5
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXI
                      p_asX4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX3
                      (g_asX3, gpart_asXI) = Genome.Split.split gpart_asXH
                      p_asX2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX1
                      (g_asX1, gpart_asXH) = Genome.Split.split gpart_asXG
                      p_asX0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asWZ
                      (g_asWZ, gpart_asXG) = Genome.Split.split gpart_asXF
                      p_asWY = code-0.1.0.0:Genome.FixedList.Functions.double g_asWX
                      (g_asWX, gpart_asXF) = Genome.Split.split gpart_asXE
                      p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                      (g_asWV, gpart_asXE) = Genome.Split.split gpart_asXD
                      p_asWU = Functions.belowten' g_asWT
                      (g_asWT, gpart_asXD) = Genome.Split.split gpart_asXC
                      p_asWS = code-0.1.0.0:Genome.FixedList.Functions.double g_asWR
                      (g_asWR, gpart_asXC) = Genome.Split.split gpart_asXB
                      p_asWQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWP
                      (g_asWP, gpart_asXB) = Genome.Split.split gpart_asXA
                      p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                      (g_asWN, gpart_asXA) = Genome.Split.split gpart_asXz
                      p_asWM = Functions.belowten' g_asWL
                      (g_asWL, gpart_asXz) = Genome.Split.split gpart_asXy
                      p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                      (g_asWJ, gpart_asXy) = Genome.Split.split gpart_asXx
                      p_asWI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWH
                      (g_asWH, gpart_asXx) = Genome.Split.split gpart_asXw
                      p_asWG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWF
                      (g_asWF, gpart_asXw) = Genome.Split.split gpart_asXv
                      p_asWE = Functions.belowten' g_asWD
                      (g_asWD, gpart_asXv) = Genome.Split.split gpart_asXu
                      p_asWC = code-0.1.0.0:Genome.FixedList.Functions.double g_asWB
                      (g_asWB, gpart_asXu) = Genome.Split.split gpart_asXt
                      p_asWA = code-0.1.0.0:Genome.FixedList.Functions.double g_asWz
                      (g_asWz, gpart_asXt) = Genome.Split.split gpart_asXs
                      p_asWy = code-0.1.0.0:Genome.FixedList.Functions.double g_asWx
                      (g_asWx, gpart_asXs) = Genome.Split.split gpart_asXr
                      p_asWw = Functions.belowten' g_asWv
                      (g_asWv, gpart_asXr) = Genome.Split.split gpart_asXq
                      p_asWu = code-0.1.0.0:Genome.FixedList.Functions.double g_asWt
                      (g_asWt, gpart_asXq) = Genome.Split.split gpart_asXp
                      p_asWs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWr
                      (g_asWr, gpart_asXp) = Genome.Split.split gpart_asXo
                      p_asWq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWp
                      (g_asWp, gpart_asXo) = Genome.Split.split gpart_asXn
                      p_asWo = code-0.1.0.0:Genome.FixedList.Functions.double g_asWn
                      (g_asWn, gpart_asXn) = Genome.Split.split gpart_asXm
                      p_asWm = Functions.belowten' g_asWl
                      (g_asWl, gpart_asXm) = Genome.Split.split gpart_asXl
                      p_asWk = code-0.1.0.0:Genome.FixedList.Functions.double g_asWj
                      (g_asWj, gpart_asXl) = Genome.Split.split gpart_asXk
                      p_asWi = Functions.belowten' g_asWh
                      (g_asWh, gpart_asXk) = Genome.Split.split gpart_asXj
                      p_asWg = code-0.1.0.0:Genome.FixedList.Functions.double g_asWf
                      (g_asWf, gpart_asXj) = Genome.Split.split gpart_asXi
                      p_asWe = code-0.1.0.0:Genome.FixedList.Functions.double g_asWd
                      (g_asWd, gpart_asXi) = Genome.Split.split gpart_asXh
                      p_asWc = Functions.belowten' g_asWb
                      (g_asWb, gpart_asXh) = Genome.Split.split gpart_asXg
                      p_asWa = code-0.1.0.0:Genome.FixedList.Functions.double g_asW9
                      (g_asW9, gpart_asXg) = Genome.Split.split gpart_asXf
                      p_asW8 = Functions.belowten' g_asW7
                      (g_asW7, gpart_asXf) = Genome.Split.split gpart_asXe
                      p_asW6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW5
                      (g_asW5, gpart_asXe) = Genome.Split.split gpart_asXd
                      p_asW4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW3
                      (g_asW3, gpart_asXd) = Genome.Split.split gpart_asXc
                      p_asW2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW1
                      (g_asW1, gpart_asXc) = Genome.Split.split gpart_asXb
                      p_asW0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asVZ
                      (g_asVZ, gpart_asXb) = Genome.Split.split gpart_asXa
                      p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                      (g_asVX, gpart_asXa) = Genome.Split.split gpart_asX9
                      p_asVW = code-0.1.0.0:Genome.FixedList.Functions.double g_asVV
                      (g_asVV, gpart_asX9) = Genome.Split.split gpart_asX8
                      p_asVU = code-0.1.0.0:Genome.FixedList.Functions.double g_asVT
                      (g_asVT, gpart_asX8) = Genome.Split.split gpart_asX7
                      p_asVS = code-0.1.0.0:Genome.FixedList.Functions.double g_asVR
                      (g_asVR, gpart_asX7) = Genome.Split.split genome_asX5
                    in
                      [Reaction
                         (\ x_asXJ
                            -> let
                                 c_NPTB_asXK = ((toVector x_asXJ) Data.Vector.Unboxed.! 1)
                                 c_MiRs_asXL = ((toVector x_asXJ) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asW0
                                  / (1
                                     + (((c_NPTB_asXK / p_asW6) ** p_asW8)
                                        + ((c_MiRs_asXL / p_asWa) ** p_asWc)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXM
                            -> let
                                 c_MiRs_asXN = ((toVector x_asXM) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXO = ((toVector x_asXM) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWe
                                  / (1
                                     + (((c_MiRs_asXN / p_asWg) ** p_asWi)
                                        + ((c_PTB_asXO / p_asWk) ** p_asWm)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asXP
                            -> let c_RESTc_asXQ = ((toVector x_asXP) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asWo
                                  * (p_asWy
                                     / ((1 + p_asWy) + ((c_RESTc_asXQ / p_asWu) ** p_asWw)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asXR
                            -> let
                                 c_MiRs_asXU = ((toVector x_asXR) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXS = ((toVector x_asXR) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWA
                                  * ((p_asWO + ((c_PTB_asXS / p_asWC) ** p_asWE))
                                     / (((1 + p_asWO) + ((c_PTB_asXS / p_asWC) ** p_asWE))
                                        + (((p_asVS / p_asWG) ** p_asWI)
                                           + ((c_MiRs_asXU / p_asWK) ** p_asWM))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asXV
                            -> let c_RESTc_asXW = ((toVector x_asXV) Data.Vector.Unboxed.! 3)
                               in (p_asWQ / (1 + ((c_RESTc_asXW / p_asWS) ** p_asWU))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asXX
                            -> let c_PTB_asXY = ((toVector x_asXX) Data.Vector.Unboxed.! 0)
                               in (p_asWW * c_PTB_asXY))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXZ
                            -> let c_NPTB_asY0 = ((toVector x_asXZ) Data.Vector.Unboxed.! 1)
                               in (p_asWY * c_NPTB_asY0))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asY1
                            -> let c_MiRs_asY2 = ((toVector x_asY1) Data.Vector.Unboxed.! 2)
                               in (p_asX0 * c_MiRs_asY2))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asY3
                            -> let c_RESTc_asY4 = ((toVector x_asY3) Data.Vector.Unboxed.! 3)
                               in (p_asX2 * c_RESTc_asY4))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asY5
                            -> let
                                 c_EndoNeuroTFs_asY6 = ((toVector x_asY5) Data.Vector.Unboxed.! 4)
                               in (p_asX4 * c_EndoNeuroTFs_asY6))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121020",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121022",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121024",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121028",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121036",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121038",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121040",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121042",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121046",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121048",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121051",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121052",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121053",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121054",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121055",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121056",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121057",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121058",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121059",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121060",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121061",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121062",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121063",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121064",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121067",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121068",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121069",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121070",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121071",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121072",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121073",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121074",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121075",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121076",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121077",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121078",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121079",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121080",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121081",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121082",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121083",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121084",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121085",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121086",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asX5
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYI
                            p_asX4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX3
                            (g_asX3, gpart_asYI) = Genome.Split.split gpart_asYH
                            p_asX2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX1
                            (g_asX1, gpart_asYH) = Genome.Split.split gpart_asYG
                            p_asX0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asWZ
                            (g_asWZ, gpart_asYG) = Genome.Split.split gpart_asYF
                            p_asWY = code-0.1.0.0:Genome.FixedList.Functions.double g_asWX
                            (g_asWX, gpart_asYF) = Genome.Split.split gpart_asYE
                            p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                            (g_asWV, gpart_asYE) = Genome.Split.split gpart_asYD
                            p_asWU = Functions.belowten' g_asWT
                            (g_asWT, gpart_asYD) = Genome.Split.split gpart_asYC
                            p_asWS = code-0.1.0.0:Genome.FixedList.Functions.double g_asWR
                            (g_asWR, gpart_asYC) = Genome.Split.split gpart_asYB
                            p_asWQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWP
                            (g_asWP, gpart_asYB) = Genome.Split.split gpart_asYA
                            p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                            (g_asWN, gpart_asYA) = Genome.Split.split gpart_asYz
                            p_asWM = Functions.belowten' g_asWL
                            (g_asWL, gpart_asYz) = Genome.Split.split gpart_asYy
                            p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                            (g_asWJ, gpart_asYy) = Genome.Split.split gpart_asYx
                            p_asWI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWH
                            (g_asWH, gpart_asYx) = Genome.Split.split gpart_asYw
                            p_asWG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWF
                            (g_asWF, gpart_asYw) = Genome.Split.split gpart_asYv
                            p_asWE = Functions.belowten' g_asWD
                            (g_asWD, gpart_asYv) = Genome.Split.split gpart_asYu
                            p_asWC = code-0.1.0.0:Genome.FixedList.Functions.double g_asWB
                            (g_asWB, gpart_asYu) = Genome.Split.split gpart_asYt
                            p_asWA = code-0.1.0.0:Genome.FixedList.Functions.double g_asWz
                            (g_asWz, gpart_asYt) = Genome.Split.split gpart_asYs
                            p_asWy = code-0.1.0.0:Genome.FixedList.Functions.double g_asWx
                            (g_asWx, gpart_asYs) = Genome.Split.split gpart_asYr
                            p_asWw = Functions.belowten' g_asWv
                            (g_asWv, gpart_asYr) = Genome.Split.split gpart_asYq
                            p_asWu = code-0.1.0.0:Genome.FixedList.Functions.double g_asWt
                            (g_asWt, gpart_asYq) = Genome.Split.split gpart_asYp
                            p_asWs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWr
                            (g_asWr, gpart_asYp) = Genome.Split.split gpart_asYo
                            p_asWq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWp
                            (g_asWp, gpart_asYo) = Genome.Split.split gpart_asYn
                            p_asWo = code-0.1.0.0:Genome.FixedList.Functions.double g_asWn
                            (g_asWn, gpart_asYn) = Genome.Split.split gpart_asYm
                            p_asWm = Functions.belowten' g_asWl
                            (g_asWl, gpart_asYm) = Genome.Split.split gpart_asYl
                            p_asWk = code-0.1.0.0:Genome.FixedList.Functions.double g_asWj
                            (g_asWj, gpart_asYl) = Genome.Split.split gpart_asYk
                            p_asWi = Functions.belowten' g_asWh
                            (g_asWh, gpart_asYk) = Genome.Split.split gpart_asYj
                            p_asWg = code-0.1.0.0:Genome.FixedList.Functions.double g_asWf
                            (g_asWf, gpart_asYj) = Genome.Split.split gpart_asYi
                            p_asWe = code-0.1.0.0:Genome.FixedList.Functions.double g_asWd
                            (g_asWd, gpart_asYi) = Genome.Split.split gpart_asYh
                            p_asWc = Functions.belowten' g_asWb
                            (g_asWb, gpart_asYh) = Genome.Split.split gpart_asYg
                            p_asWa = code-0.1.0.0:Genome.FixedList.Functions.double g_asW9
                            (g_asW9, gpart_asYg) = Genome.Split.split gpart_asYf
                            p_asW8 = Functions.belowten' g_asW7
                            (g_asW7, gpart_asYf) = Genome.Split.split gpart_asYe
                            p_asW6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW5
                            (g_asW5, gpart_asYe) = Genome.Split.split gpart_asYd
                            p_asW4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW3
                            (g_asW3, gpart_asYd) = Genome.Split.split gpart_asYc
                            p_asW2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW1
                            (g_asW1, gpart_asYc) = Genome.Split.split gpart_asYb
                            p_asW0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asVZ
                            (g_asVZ, gpart_asYb) = Genome.Split.split gpart_asYa
                            p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                            (g_asVX, gpart_asYa) = Genome.Split.split gpart_asY9
                            p_asVW = code-0.1.0.0:Genome.FixedList.Functions.double g_asVV
                            (g_asVV, gpart_asY9) = Genome.Split.split gpart_asY8
                            p_asVU = code-0.1.0.0:Genome.FixedList.Functions.double g_asVT
                            (g_asVT, gpart_asY8) = Genome.Split.split gpart_asY7
                            p_asVS = code-0.1.0.0:Genome.FixedList.Functions.double g_asVR
                            (g_asVR, gpart_asY7) = Genome.Split.split genome_asX5
                          in
                            \ desc_asX6
                              -> case desc_asX6 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVS)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVU)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVW)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVY)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW0)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW2)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW4)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW6)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW8)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWa)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWc)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWe)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWg)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWi)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWk)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWm)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWo)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWq)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWs)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWu)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWw)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWy)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWA)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWC)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWE)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWG)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWI)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWK)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWM)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWO)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWQ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWS)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWU)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWW)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWY)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX0)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX2)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX4)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at0D
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1g
                      p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                      (g_at0B, gpart_at1g) = Genome.Split.split gpart_at1f
                      p_at0A = code-0.1.0.0:Genome.FixedList.Functions.double g_at0z
                      (g_at0z, gpart_at1f) = Genome.Split.split gpart_at1e
                      p_at0y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0x
                      (g_at0x, gpart_at1e) = Genome.Split.split gpart_at1d
                      p_at0w = code-0.1.0.0:Genome.FixedList.Functions.double g_at0v
                      (g_at0v, gpart_at1d) = Genome.Split.split gpart_at1c
                      p_at0u = code-0.1.0.0:Genome.FixedList.Functions.double g_at0t
                      (g_at0t, gpart_at1c) = Genome.Split.split gpart_at1b
                      p_at0s = Functions.belowten' g_at0r
                      (g_at0r, gpart_at1b) = Genome.Split.split gpart_at1a
                      p_at0q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0p
                      (g_at0p, gpart_at1a) = Genome.Split.split gpart_at19
                      p_at0o = code-0.1.0.0:Genome.FixedList.Functions.double g_at0n
                      (g_at0n, gpart_at19) = Genome.Split.split gpart_at18
                      p_at0m = code-0.1.0.0:Genome.FixedList.Functions.double g_at0l
                      (g_at0l, gpart_at18) = Genome.Split.split gpart_at17
                      p_at0k = Functions.belowten' g_at0j
                      (g_at0j, gpart_at17) = Genome.Split.split gpart_at16
                      p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                      (g_at0h, gpart_at16) = Genome.Split.split gpart_at15
                      p_at0g
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0f
                      (g_at0f, gpart_at15) = Genome.Split.split gpart_at14
                      p_at0e
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0d
                      (g_at0d, gpart_at14) = Genome.Split.split gpart_at13
                      p_at0c = Functions.belowten' g_at0b
                      (g_at0b, gpart_at13) = Genome.Split.split gpart_at12
                      p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                      (g_at09, gpart_at12) = Genome.Split.split gpart_at11
                      p_at08 = code-0.1.0.0:Genome.FixedList.Functions.double g_at07
                      (g_at07, gpart_at11) = Genome.Split.split gpart_at10
                      p_at06 = code-0.1.0.0:Genome.FixedList.Functions.double g_at05
                      (g_at05, gpart_at10) = Genome.Split.split gpart_at0Z
                      p_at04 = Functions.belowten' g_at03
                      (g_at03, gpart_at0Z) = Genome.Split.split gpart_at0Y
                      p_at02 = code-0.1.0.0:Genome.FixedList.Functions.double g_at01
                      (g_at01, gpart_at0Y) = Genome.Split.split gpart_at0X
                      p_at00
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZZ
                      (g_asZZ, gpart_at0X) = Genome.Split.split gpart_at0W
                      p_asZY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZX
                      (g_asZX, gpart_at0W) = Genome.Split.split gpart_at0V
                      p_asZW = code-0.1.0.0:Genome.FixedList.Functions.double g_asZV
                      (g_asZV, gpart_at0V) = Genome.Split.split gpart_at0U
                      p_asZU = Functions.belowten' g_asZT
                      (g_asZT, gpart_at0U) = Genome.Split.split gpart_at0T
                      p_asZS = code-0.1.0.0:Genome.FixedList.Functions.double g_asZR
                      (g_asZR, gpart_at0T) = Genome.Split.split gpart_at0S
                      p_asZQ = Functions.belowten' g_asZP
                      (g_asZP, gpart_at0S) = Genome.Split.split gpart_at0R
                      p_asZO = code-0.1.0.0:Genome.FixedList.Functions.double g_asZN
                      (g_asZN, gpart_at0R) = Genome.Split.split gpart_at0Q
                      p_asZM = code-0.1.0.0:Genome.FixedList.Functions.double g_asZL
                      (g_asZL, gpart_at0Q) = Genome.Split.split gpart_at0P
                      p_asZK = Functions.belowten' g_asZJ
                      (g_asZJ, gpart_at0P) = Genome.Split.split gpart_at0O
                      p_asZI = code-0.1.0.0:Genome.FixedList.Functions.double g_asZH
                      (g_asZH, gpart_at0O) = Genome.Split.split gpart_at0N
                      p_asZG = Functions.belowten' g_asZF
                      (g_asZF, gpart_at0N) = Genome.Split.split gpart_at0M
                      p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                      (g_asZD, gpart_at0M) = Genome.Split.split gpart_at0L
                      p_asZC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZB
                      (g_asZB, gpart_at0L) = Genome.Split.split gpart_at0K
                      p_asZA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZz
                      (g_asZz, gpart_at0K) = Genome.Split.split gpart_at0J
                      p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                      (g_asZx, gpart_at0J) = Genome.Split.split gpart_at0I
                      p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                      (g_asZv, gpart_at0I) = Genome.Split.split gpart_at0H
                      p_asZu = code-0.1.0.0:Genome.FixedList.Functions.double g_asZt
                      (g_asZt, gpart_at0H) = Genome.Split.split gpart_at0G
                      p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                      (g_asZr, gpart_at0G) = Genome.Split.split gpart_at0F
                      p_asZq = code-0.1.0.0:Genome.FixedList.Functions.double g_asZp
                      (g_asZp, gpart_at0F) = Genome.Split.split genome_at0D
                    in
                      [Reaction
                         (\ x_at1h
                            -> let
                                 c_NPTB_at1i = ((toVector x_at1h) Data.Vector.Unboxed.! 1)
                                 c_MiRs_at1j = ((toVector x_at1h) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asZy
                                  / (1
                                     + (((c_NPTB_at1i / p_asZE) ** p_asZG)
                                        + ((c_MiRs_at1j / p_asZI) ** p_asZK)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1k
                            -> let
                                 c_MiRs_at1l = ((toVector x_at1k) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1m = ((toVector x_at1k) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZM
                                  / (1
                                     + (((c_MiRs_at1l / p_asZO) ** p_asZQ)
                                        + ((c_PTB_at1m / p_asZS) ** p_asZU)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at1n
                            -> let c_RESTc_at1o = ((toVector x_at1n) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asZW
                                  * (p_at06
                                     / ((1 + p_at06) + ((c_RESTc_at1o / p_at02) ** p_at04)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at1p
                            -> let
                                 c_MiRs_at1s = ((toVector x_at1p) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1q = ((toVector x_at1p) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at08
                                  * ((p_at0m + ((c_PTB_at1q / p_at0a) ** p_at0c))
                                     / (((1 + p_at0m) + ((c_PTB_at1q / p_at0a) ** p_at0c))
                                        + ((c_MiRs_at1s / p_at0i) ** p_at0k)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at1t
                            -> let c_RESTc_at1u = ((toVector x_at1t) Data.Vector.Unboxed.! 3)
                               in (p_at0o / (1 + ((c_RESTc_at1u / p_at0q) ** p_at0s))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at1v
                            -> let c_PTB_at1w = ((toVector x_at1v) Data.Vector.Unboxed.! 0)
                               in (p_at0u * c_PTB_at1w))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1x
                            -> let c_NPTB_at1y = ((toVector x_at1x) Data.Vector.Unboxed.! 1)
                               in (p_at0w * c_NPTB_at1y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at1z
                            -> let c_MiRs_at1A = ((toVector x_at1z) Data.Vector.Unboxed.! 2)
                               in (p_at0y * c_MiRs_at1A))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at1B
                            -> let c_RESTc_at1C = ((toVector x_at1B) Data.Vector.Unboxed.! 3)
                               in (p_at0A * c_RESTc_at1C))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at1D
                            -> let
                                 c_EndoNeuroTFs_at1E = ((toVector x_at1D) Data.Vector.Unboxed.! 4)
                               in (p_at0C * c_EndoNeuroTFs_at1E))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121232",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121234",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121242",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121244",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121250",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121252",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121253",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121254",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121257",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121258",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121259",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121260",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121261",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121262",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121263",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121264",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121265",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121266",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121268",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121270",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121272",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121274",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121276",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121282",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121284",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121286",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121298",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121300",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121302",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at0D
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2g
                            p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                            (g_at0B, gpart_at2g) = Genome.Split.split gpart_at2f
                            p_at0A = code-0.1.0.0:Genome.FixedList.Functions.double g_at0z
                            (g_at0z, gpart_at2f) = Genome.Split.split gpart_at2e
                            p_at0y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0x
                            (g_at0x, gpart_at2e) = Genome.Split.split gpart_at2d
                            p_at0w = code-0.1.0.0:Genome.FixedList.Functions.double g_at0v
                            (g_at0v, gpart_at2d) = Genome.Split.split gpart_at2c
                            p_at0u = code-0.1.0.0:Genome.FixedList.Functions.double g_at0t
                            (g_at0t, gpart_at2c) = Genome.Split.split gpart_at2b
                            p_at0s = Functions.belowten' g_at0r
                            (g_at0r, gpart_at2b) = Genome.Split.split gpart_at2a
                            p_at0q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0p
                            (g_at0p, gpart_at2a) = Genome.Split.split gpart_at29
                            p_at0o = code-0.1.0.0:Genome.FixedList.Functions.double g_at0n
                            (g_at0n, gpart_at29) = Genome.Split.split gpart_at28
                            p_at0m = code-0.1.0.0:Genome.FixedList.Functions.double g_at0l
                            (g_at0l, gpart_at28) = Genome.Split.split gpart_at27
                            p_at0k = Functions.belowten' g_at0j
                            (g_at0j, gpart_at27) = Genome.Split.split gpart_at26
                            p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                            (g_at0h, gpart_at26) = Genome.Split.split gpart_at25
                            p_at0g
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0f
                            (g_at0f, gpart_at25) = Genome.Split.split gpart_at24
                            p_at0e
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0d
                            (g_at0d, gpart_at24) = Genome.Split.split gpart_at23
                            p_at0c = Functions.belowten' g_at0b
                            (g_at0b, gpart_at23) = Genome.Split.split gpart_at22
                            p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                            (g_at09, gpart_at22) = Genome.Split.split gpart_at21
                            p_at08 = code-0.1.0.0:Genome.FixedList.Functions.double g_at07
                            (g_at07, gpart_at21) = Genome.Split.split gpart_at20
                            p_at06 = code-0.1.0.0:Genome.FixedList.Functions.double g_at05
                            (g_at05, gpart_at20) = Genome.Split.split gpart_at1Z
                            p_at04 = Functions.belowten' g_at03
                            (g_at03, gpart_at1Z) = Genome.Split.split gpart_at1Y
                            p_at02 = code-0.1.0.0:Genome.FixedList.Functions.double g_at01
                            (g_at01, gpart_at1Y) = Genome.Split.split gpart_at1X
                            p_at00
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZZ
                            (g_asZZ, gpart_at1X) = Genome.Split.split gpart_at1W
                            p_asZY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZX
                            (g_asZX, gpart_at1W) = Genome.Split.split gpart_at1V
                            p_asZW = code-0.1.0.0:Genome.FixedList.Functions.double g_asZV
                            (g_asZV, gpart_at1V) = Genome.Split.split gpart_at1U
                            p_asZU = Functions.belowten' g_asZT
                            (g_asZT, gpart_at1U) = Genome.Split.split gpart_at1T
                            p_asZS = code-0.1.0.0:Genome.FixedList.Functions.double g_asZR
                            (g_asZR, gpart_at1T) = Genome.Split.split gpart_at1S
                            p_asZQ = Functions.belowten' g_asZP
                            (g_asZP, gpart_at1S) = Genome.Split.split gpart_at1R
                            p_asZO = code-0.1.0.0:Genome.FixedList.Functions.double g_asZN
                            (g_asZN, gpart_at1R) = Genome.Split.split gpart_at1Q
                            p_asZM = code-0.1.0.0:Genome.FixedList.Functions.double g_asZL
                            (g_asZL, gpart_at1Q) = Genome.Split.split gpart_at1P
                            p_asZK = Functions.belowten' g_asZJ
                            (g_asZJ, gpart_at1P) = Genome.Split.split gpart_at1O
                            p_asZI = code-0.1.0.0:Genome.FixedList.Functions.double g_asZH
                            (g_asZH, gpart_at1O) = Genome.Split.split gpart_at1N
                            p_asZG = Functions.belowten' g_asZF
                            (g_asZF, gpart_at1N) = Genome.Split.split gpart_at1M
                            p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                            (g_asZD, gpart_at1M) = Genome.Split.split gpart_at1L
                            p_asZC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZB
                            (g_asZB, gpart_at1L) = Genome.Split.split gpart_at1K
                            p_asZA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZz
                            (g_asZz, gpart_at1K) = Genome.Split.split gpart_at1J
                            p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                            (g_asZx, gpart_at1J) = Genome.Split.split gpart_at1I
                            p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                            (g_asZv, gpart_at1I) = Genome.Split.split gpart_at1H
                            p_asZu = code-0.1.0.0:Genome.FixedList.Functions.double g_asZt
                            (g_asZt, gpart_at1H) = Genome.Split.split gpart_at1G
                            p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                            (g_asZr, gpart_at1G) = Genome.Split.split gpart_at1F
                            p_asZq = code-0.1.0.0:Genome.FixedList.Functions.double g_asZp
                            (g_asZp, gpart_at1F) = Genome.Split.split genome_at0D
                          in
                            \ desc_at0E
                              -> case desc_at0E of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZq)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZs)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZu)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZw)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZy)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZA)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZC)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZE)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZG)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZI)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZK)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZM)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZO)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZQ)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZS)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZU)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZW)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZY)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at00)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at02)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at04)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at06)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at08)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0a)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0c)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0e)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0g)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0i)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0k)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0m)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0o)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0q)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0s)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0u)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0w)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0y)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0A)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0C)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at4b
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4O
                      p_at4a = code-0.1.0.0:Genome.FixedList.Functions.double g_at49
                      (g_at49, gpart_at4O) = Genome.Split.split gpart_at4N
                      p_at48 = code-0.1.0.0:Genome.FixedList.Functions.double g_at47
                      (g_at47, gpart_at4N) = Genome.Split.split gpart_at4M
                      p_at46 = code-0.1.0.0:Genome.FixedList.Functions.double g_at45
                      (g_at45, gpart_at4M) = Genome.Split.split gpart_at4L
                      p_at44 = code-0.1.0.0:Genome.FixedList.Functions.double g_at43
                      (g_at43, gpart_at4L) = Genome.Split.split gpart_at4K
                      p_at42 = code-0.1.0.0:Genome.FixedList.Functions.double g_at41
                      (g_at41, gpart_at4K) = Genome.Split.split gpart_at4J
                      p_at40 = Functions.belowten' g_at3Z
                      (g_at3Z, gpart_at4J) = Genome.Split.split gpart_at4I
                      p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                      (g_at3X, gpart_at4I) = Genome.Split.split gpart_at4H
                      p_at3W = code-0.1.0.0:Genome.FixedList.Functions.double g_at3V
                      (g_at3V, gpart_at4H) = Genome.Split.split gpart_at4G
                      p_at3U = code-0.1.0.0:Genome.FixedList.Functions.double g_at3T
                      (g_at3T, gpart_at4G) = Genome.Split.split gpart_at4F
                      p_at3S = Functions.belowten' g_at3R
                      (g_at3R, gpart_at4F) = Genome.Split.split gpart_at4E
                      p_at3Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3P
                      (g_at3P, gpart_at4E) = Genome.Split.split gpart_at4D
                      p_at3O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3N
                      (g_at3N, gpart_at4D) = Genome.Split.split gpart_at4C
                      p_at3M
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3L
                      (g_at3L, gpart_at4C) = Genome.Split.split gpart_at4B
                      p_at3K = Functions.belowten' g_at3J
                      (g_at3J, gpart_at4B) = Genome.Split.split gpart_at4A
                      p_at3I = code-0.1.0.0:Genome.FixedList.Functions.double g_at3H
                      (g_at3H, gpart_at4A) = Genome.Split.split gpart_at4z
                      p_at3G = code-0.1.0.0:Genome.FixedList.Functions.double g_at3F
                      (g_at3F, gpart_at4z) = Genome.Split.split gpart_at4y
                      p_at3E = code-0.1.0.0:Genome.FixedList.Functions.double g_at3D
                      (g_at3D, gpart_at4y) = Genome.Split.split gpart_at4x
                      p_at3C = Functions.belowten' g_at3B
                      (g_at3B, gpart_at4x) = Genome.Split.split gpart_at4w
                      p_at3A = code-0.1.0.0:Genome.FixedList.Functions.double g_at3z
                      (g_at3z, gpart_at4w) = Genome.Split.split gpart_at4v
                      p_at3y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3x
                      (g_at3x, gpart_at4v) = Genome.Split.split gpart_at4u
                      p_at3w
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3v
                      (g_at3v, gpart_at4u) = Genome.Split.split gpart_at4t
                      p_at3u = code-0.1.0.0:Genome.FixedList.Functions.double g_at3t
                      (g_at3t, gpart_at4t) = Genome.Split.split gpart_at4s
                      p_at3s = Functions.belowten' g_at3r
                      (g_at3r, gpart_at4s) = Genome.Split.split gpart_at4r
                      p_at3q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3p
                      (g_at3p, gpart_at4r) = Genome.Split.split gpart_at4q
                      p_at3o = Functions.belowten' g_at3n
                      (g_at3n, gpart_at4q) = Genome.Split.split gpart_at4p
                      p_at3m = code-0.1.0.0:Genome.FixedList.Functions.double g_at3l
                      (g_at3l, gpart_at4p) = Genome.Split.split gpart_at4o
                      p_at3k = code-0.1.0.0:Genome.FixedList.Functions.double g_at3j
                      (g_at3j, gpart_at4o) = Genome.Split.split gpart_at4n
                      p_at3i = Functions.belowten' g_at3h
                      (g_at3h, gpart_at4n) = Genome.Split.split gpart_at4m
                      p_at3g = code-0.1.0.0:Genome.FixedList.Functions.double g_at3f
                      (g_at3f, gpart_at4m) = Genome.Split.split gpart_at4l
                      p_at3e = Functions.belowten' g_at3d
                      (g_at3d, gpart_at4l) = Genome.Split.split gpart_at4k
                      p_at3c = code-0.1.0.0:Genome.FixedList.Functions.double g_at3b
                      (g_at3b, gpart_at4k) = Genome.Split.split gpart_at4j
                      p_at3a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at39
                      (g_at39, gpart_at4j) = Genome.Split.split gpart_at4i
                      p_at38
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at37
                      (g_at37, gpart_at4i) = Genome.Split.split gpart_at4h
                      p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                      (g_at35, gpart_at4h) = Genome.Split.split gpart_at4g
                      p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                      (g_at33, gpart_at4g) = Genome.Split.split gpart_at4f
                      p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                      (g_at31, gpart_at4f) = Genome.Split.split gpart_at4e
                      p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                      (g_at2Z, gpart_at4e) = Genome.Split.split gpart_at4d
                      p_at2Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2X
                      (g_at2X, gpart_at4d) = Genome.Split.split genome_at4b
                    in
                      [Reaction
                         (\ x_at4P
                            -> let
                                 c_NPTB_at4Q = ((toVector x_at4P) Data.Vector.Unboxed.! 1)
                                 c_MiRs_at4R = ((toVector x_at4P) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at36
                                  / (1
                                     + ((((p_at2Y / p_at38) ** p_at3a)
                                         + ((c_NPTB_at4Q / p_at3c) ** p_at3e))
                                        + ((c_MiRs_at4R / p_at3g) ** p_at3i)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4S
                            -> let
                                 c_MiRs_at4T = ((toVector x_at4S) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4U = ((toVector x_at4S) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3k
                                  / (1
                                     + (((c_MiRs_at4T / p_at3m) ** p_at3o)
                                        + ((c_PTB_at4U / p_at3q) ** p_at3s)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at4V
                            -> let c_RESTc_at4W = ((toVector x_at4V) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at3u
                                  * (p_at3E
                                     / ((1 + p_at3E) + ((c_RESTc_at4W / p_at3A) ** p_at3C)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at4X
                            -> let
                                 c_MiRs_at50 = ((toVector x_at4X) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4Y = ((toVector x_at4X) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3G
                                  * ((p_at3U + ((c_PTB_at4Y / p_at3I) ** p_at3K))
                                     / (((1 + p_at3U) + ((c_PTB_at4Y / p_at3I) ** p_at3K))
                                        + ((c_MiRs_at50 / p_at3Q) ** p_at3S)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at51
                            -> let c_RESTc_at52 = ((toVector x_at51) Data.Vector.Unboxed.! 3)
                               in (p_at3W / (1 + ((c_RESTc_at52 / p_at3Y) ** p_at40))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at53
                            -> let c_PTB_at54 = ((toVector x_at53) Data.Vector.Unboxed.! 0)
                               in (p_at42 * c_PTB_at54))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at55
                            -> let c_NPTB_at56 = ((toVector x_at55) Data.Vector.Unboxed.! 1)
                               in (p_at44 * c_NPTB_at56))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at57
                            -> let c_MiRs_at58 = ((toVector x_at57) Data.Vector.Unboxed.! 2)
                               in (p_at46 * c_MiRs_at58))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at59
                            -> let c_RESTc_at5a = ((toVector x_at59) Data.Vector.Unboxed.! 3)
                               in (p_at48 * c_RESTc_at5a))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at5b
                            -> let
                                 c_EndoNeuroTFs_at5c = ((toVector x_at5b) Data.Vector.Unboxed.! 4)
                               in (p_at4a * c_EndoNeuroTFs_at5c))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121462",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121464",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121486",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121488",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121490",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121492",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121502",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121504",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121510",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121518",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121520",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121524",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121526",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at4b
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5O
                            p_at4a = code-0.1.0.0:Genome.FixedList.Functions.double g_at49
                            (g_at49, gpart_at5O) = Genome.Split.split gpart_at5N
                            p_at48 = code-0.1.0.0:Genome.FixedList.Functions.double g_at47
                            (g_at47, gpart_at5N) = Genome.Split.split gpart_at5M
                            p_at46 = code-0.1.0.0:Genome.FixedList.Functions.double g_at45
                            (g_at45, gpart_at5M) = Genome.Split.split gpart_at5L
                            p_at44 = code-0.1.0.0:Genome.FixedList.Functions.double g_at43
                            (g_at43, gpart_at5L) = Genome.Split.split gpart_at5K
                            p_at42 = code-0.1.0.0:Genome.FixedList.Functions.double g_at41
                            (g_at41, gpart_at5K) = Genome.Split.split gpart_at5J
                            p_at40 = Functions.belowten' g_at3Z
                            (g_at3Z, gpart_at5J) = Genome.Split.split gpart_at5I
                            p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                            (g_at3X, gpart_at5I) = Genome.Split.split gpart_at5H
                            p_at3W = code-0.1.0.0:Genome.FixedList.Functions.double g_at3V
                            (g_at3V, gpart_at5H) = Genome.Split.split gpart_at5G
                            p_at3U = code-0.1.0.0:Genome.FixedList.Functions.double g_at3T
                            (g_at3T, gpart_at5G) = Genome.Split.split gpart_at5F
                            p_at3S = Functions.belowten' g_at3R
                            (g_at3R, gpart_at5F) = Genome.Split.split gpart_at5E
                            p_at3Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3P
                            (g_at3P, gpart_at5E) = Genome.Split.split gpart_at5D
                            p_at3O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3N
                            (g_at3N, gpart_at5D) = Genome.Split.split gpart_at5C
                            p_at3M
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3L
                            (g_at3L, gpart_at5C) = Genome.Split.split gpart_at5B
                            p_at3K = Functions.belowten' g_at3J
                            (g_at3J, gpart_at5B) = Genome.Split.split gpart_at5A
                            p_at3I = code-0.1.0.0:Genome.FixedList.Functions.double g_at3H
                            (g_at3H, gpart_at5A) = Genome.Split.split gpart_at5z
                            p_at3G = code-0.1.0.0:Genome.FixedList.Functions.double g_at3F
                            (g_at3F, gpart_at5z) = Genome.Split.split gpart_at5y
                            p_at3E = code-0.1.0.0:Genome.FixedList.Functions.double g_at3D
                            (g_at3D, gpart_at5y) = Genome.Split.split gpart_at5x
                            p_at3C = Functions.belowten' g_at3B
                            (g_at3B, gpart_at5x) = Genome.Split.split gpart_at5w
                            p_at3A = code-0.1.0.0:Genome.FixedList.Functions.double g_at3z
                            (g_at3z, gpart_at5w) = Genome.Split.split gpart_at5v
                            p_at3y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3x
                            (g_at3x, gpart_at5v) = Genome.Split.split gpart_at5u
                            p_at3w
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3v
                            (g_at3v, gpart_at5u) = Genome.Split.split gpart_at5t
                            p_at3u = code-0.1.0.0:Genome.FixedList.Functions.double g_at3t
                            (g_at3t, gpart_at5t) = Genome.Split.split gpart_at5s
                            p_at3s = Functions.belowten' g_at3r
                            (g_at3r, gpart_at5s) = Genome.Split.split gpart_at5r
                            p_at3q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3p
                            (g_at3p, gpart_at5r) = Genome.Split.split gpart_at5q
                            p_at3o = Functions.belowten' g_at3n
                            (g_at3n, gpart_at5q) = Genome.Split.split gpart_at5p
                            p_at3m = code-0.1.0.0:Genome.FixedList.Functions.double g_at3l
                            (g_at3l, gpart_at5p) = Genome.Split.split gpart_at5o
                            p_at3k = code-0.1.0.0:Genome.FixedList.Functions.double g_at3j
                            (g_at3j, gpart_at5o) = Genome.Split.split gpart_at5n
                            p_at3i = Functions.belowten' g_at3h
                            (g_at3h, gpart_at5n) = Genome.Split.split gpart_at5m
                            p_at3g = code-0.1.0.0:Genome.FixedList.Functions.double g_at3f
                            (g_at3f, gpart_at5m) = Genome.Split.split gpart_at5l
                            p_at3e = Functions.belowten' g_at3d
                            (g_at3d, gpart_at5l) = Genome.Split.split gpart_at5k
                            p_at3c = code-0.1.0.0:Genome.FixedList.Functions.double g_at3b
                            (g_at3b, gpart_at5k) = Genome.Split.split gpart_at5j
                            p_at3a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at39
                            (g_at39, gpart_at5j) = Genome.Split.split gpart_at5i
                            p_at38
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at37
                            (g_at37, gpart_at5i) = Genome.Split.split gpart_at5h
                            p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                            (g_at35, gpart_at5h) = Genome.Split.split gpart_at5g
                            p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                            (g_at33, gpart_at5g) = Genome.Split.split gpart_at5f
                            p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                            (g_at31, gpart_at5f) = Genome.Split.split gpart_at5e
                            p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                            (g_at2Z, gpart_at5e) = Genome.Split.split gpart_at5d
                            p_at2Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2X
                            (g_at2X, gpart_at5d) = Genome.Split.split genome_at4b
                          in
                            \ desc_at4c
                              -> case desc_at4c of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Y)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at30)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at32)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at34)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at36)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at38)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3a)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3c)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3e)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3g)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3i)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3k)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3m)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3o)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3q)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3s)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3u)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3w)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3y)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3A)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3C)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3E)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3G)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3I)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3K)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3M)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3O)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Q)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3S)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3U)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3W)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Y)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at40)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at42)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at44)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at46)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at48)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4a)
                                   _ -> Nothing }}
