src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1Znl
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZnY
                      p_a1Znk = double g_a1Znj
                      (g_a1Znj, gpart_a1ZnY) = Genome.Split.split gpart_a1ZnX
                      p_a1Zni = double g_a1Znh
                      (g_a1Znh, gpart_a1ZnX) = Genome.Split.split gpart_a1ZnW
                      p_a1Zng = double g_a1Znf
                      (g_a1Znf, gpart_a1ZnW) = Genome.Split.split gpart_a1ZnV
                      p_a1Zne = double g_a1Znd
                      (g_a1Znd, gpart_a1ZnV) = Genome.Split.split gpart_a1ZnU
                      p_a1Znc = double g_a1Znb
                      (g_a1Znb, gpart_a1ZnU) = Genome.Split.split gpart_a1ZnT
                      p_a1Zna = Functions.belowten' g_a1Zn9
                      (g_a1Zn9, gpart_a1ZnT) = Genome.Split.split gpart_a1ZnS
                      p_a1Zn8 = double g_a1Zn7
                      (g_a1Zn7, gpart_a1ZnS) = Genome.Split.split gpart_a1ZnR
                      p_a1Zn6 = double g_a1Zn5
                      (g_a1Zn5, gpart_a1ZnR) = Genome.Split.split gpart_a1ZnQ
                      p_a1Zn4 = double g_a1Zn3
                      (g_a1Zn3, gpart_a1ZnQ) = Genome.Split.split gpart_a1ZnP
                      p_a1Zn2 = Functions.belowten' g_a1Zn1
                      (g_a1Zn1, gpart_a1ZnP) = Genome.Split.split gpart_a1ZnO
                      p_a1Zn0 = double g_a1ZmZ
                      (g_a1ZmZ, gpart_a1ZnO) = Genome.Split.split gpart_a1ZnN
                      p_a1ZmY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmX
                      (g_a1ZmX, gpart_a1ZnN) = Genome.Split.split gpart_a1ZnM
                      p_a1ZmW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmV
                      (g_a1ZmV, gpart_a1ZnM) = Genome.Split.split gpart_a1ZnL
                      p_a1ZmU = Functions.belowten' g_a1ZmT
                      (g_a1ZmT, gpart_a1ZnL) = Genome.Split.split gpart_a1ZnK
                      p_a1ZmS = double g_a1ZmR
                      (g_a1ZmR, gpart_a1ZnK) = Genome.Split.split gpart_a1ZnJ
                      p_a1ZmQ = Functions.belowten' g_a1ZmP
                      (g_a1ZmP, gpart_a1ZnJ) = Genome.Split.split gpart_a1ZnI
                      p_a1ZmO = double g_a1ZmN
                      (g_a1ZmN, gpart_a1ZnI) = Genome.Split.split gpart_a1ZnH
                      p_a1ZmM = double g_a1ZmL
                      (g_a1ZmL, gpart_a1ZnH) = Genome.Split.split gpart_a1ZnG
                      p_a1ZmK = double g_a1ZmJ
                      (g_a1ZmJ, gpart_a1ZnG) = Genome.Split.split gpart_a1ZnF
                      p_a1ZmI = Functions.belowten' g_a1ZmH
                      (g_a1ZmH, gpart_a1ZnF) = Genome.Split.split gpart_a1ZnE
                      p_a1ZmG = double g_a1ZmF
                      (g_a1ZmF, gpart_a1ZnE) = Genome.Split.split gpart_a1ZnD
                      p_a1ZmE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmD
                      (g_a1ZmD, gpart_a1ZnD) = Genome.Split.split gpart_a1ZnC
                      p_a1ZmC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmB
                      (g_a1ZmB, gpart_a1ZnC) = Genome.Split.split gpart_a1ZnB
                      p_a1ZmA = double g_a1Zmz
                      (g_a1Zmz, gpart_a1ZnB) = Genome.Split.split gpart_a1ZnA
                      p_a1Zmy = Functions.belowten' g_a1Zmx
                      (g_a1Zmx, gpart_a1ZnA) = Genome.Split.split gpart_a1Znz
                      p_a1Zmw = double g_a1Zmv
                      (g_a1Zmv, gpart_a1Znz) = Genome.Split.split gpart_a1Zny
                      p_a1Zmu = Functions.belowten' g_a1Zmt
                      (g_a1Zmt, gpart_a1Zny) = Genome.Split.split gpart_a1Znx
                      p_a1Zms = double g_a1Zmr
                      (g_a1Zmr, gpart_a1Znx) = Genome.Split.split gpart_a1Znw
                      p_a1Zmq = double g_a1Zmp
                      (g_a1Zmp, gpart_a1Znw) = Genome.Split.split gpart_a1Znv
                      p_a1Zmo = Functions.belowten' g_a1Zmn
                      (g_a1Zmn, gpart_a1Znv) = Genome.Split.split gpart_a1Znu
                      p_a1Zmm = double g_a1Zml
                      (g_a1Zml, gpart_a1Znu) = Genome.Split.split gpart_a1Znt
                      p_a1Zmk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmj
                      (g_a1Zmj, gpart_a1Znt) = Genome.Split.split gpart_a1Zns
                      p_a1Zmi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmh
                      (g_a1Zmh, gpart_a1Zns) = Genome.Split.split gpart_a1Znr
                      p_a1Zmg = double g_a1Zmf
                      (g_a1Zmf, gpart_a1Znr) = Genome.Split.split gpart_a1Znq
                      p_a1Zme = double g_a1Zmd
                      (g_a1Zmd, gpart_a1Znq) = Genome.Split.split gpart_a1Znp
                      p_a1Zmc = double g_a1Zmb
                      (g_a1Zmb, gpart_a1Znp) = Genome.Split.split gpart_a1Zno
                      p_a1Zma = double g_a1Zm9
                      (g_a1Zm9, gpart_a1Zno) = Genome.Split.split gpart_a1Znn
                      p_a1Zm8 = double g_a1Zm7
                      (g_a1Zm7, gpart_a1Znn) = Genome.Split.split genome_a1Znl
                    in  \ x_a1ZnZ
                          -> let
                               c_PTB_a1Zo2
                                 = ((Data.Fixed.Vector.toVector x_a1ZnZ) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1Zo0
                                 = ((Data.Fixed.Vector.toVector x_a1ZnZ) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zo6
                                 = ((Data.Fixed.Vector.toVector x_a1ZnZ) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zo7
                                 = ((Data.Fixed.Vector.toVector x_a1ZnZ) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zoj
                                 = ((Data.Fixed.Vector.toVector x_a1ZnZ) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zmg / (1 + ((c_MiRs_a1Zo0 / p_a1Zmm) ** p_a1Zmo)))
                                    + (negate (p_a1Znc * c_PTB_a1Zo2))),
                                   ((p_a1Zmq
                                     / (1
                                        + (((c_MiRs_a1Zo0 / p_a1Zms) ** p_a1Zmu)
                                           + ((c_PTB_a1Zo2 / p_a1Zmw) ** p_a1Zmy))))
                                    + (negate (p_a1Zne * c_NPTB_a1Zo6))),
                                   ((p_a1ZmA
                                     * ((p_a1ZmK + ((p_a1Zmc / p_a1ZmC) ** p_a1ZmE))
                                        / (((1 + p_a1ZmK) + ((p_a1Zmc / p_a1ZmC) ** p_a1ZmE))
                                           + ((c_RESTc_a1Zo7 / p_a1ZmG) ** p_a1ZmI))))
                                    + (negate (p_a1Zng * c_MiRs_a1Zo0))),
                                   ((p_a1ZmM
                                     * ((p_a1Zn4
                                         + (((c_NPTB_a1Zo6 / p_a1ZmO) ** p_a1ZmQ)
                                            + ((c_PTB_a1Zo2 / p_a1ZmS) ** p_a1ZmU)))
                                        / (((1 + p_a1Zn4)
                                            + (((c_NPTB_a1Zo6 / p_a1ZmO) ** p_a1ZmQ)
                                               + ((c_PTB_a1Zo2 / p_a1ZmS) ** p_a1ZmU)))
                                           + (((p_a1Zm8 / p_a1ZmW) ** p_a1ZmY)
                                              + ((c_MiRs_a1Zo0 / p_a1Zn0) ** p_a1Zn2)))))
                                    + (negate (p_a1Zni * c_RESTc_a1Zo7))),
                                   ((p_a1Zn6 / (1 + ((c_RESTc_a1Zo7 / p_a1Zn8) ** p_a1Zna)))
                                    + (negate (p_a1Znk * c_EndoNeuroTFs_a1Zoj)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483986",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483988",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484006",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484008",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484020",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484022",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484026",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484028",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484036",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484038",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484040",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484042",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484046",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484048",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Znl
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZoV
                            p_a1Znk = double g_a1Znj
                            (g_a1Znj, gpart_a1ZoV) = Genome.Split.split gpart_a1ZoU
                            p_a1Zni = double g_a1Znh
                            (g_a1Znh, gpart_a1ZoU) = Genome.Split.split gpart_a1ZoT
                            p_a1Zng = double g_a1Znf
                            (g_a1Znf, gpart_a1ZoT) = Genome.Split.split gpart_a1ZoS
                            p_a1Zne = double g_a1Znd
                            (g_a1Znd, gpart_a1ZoS) = Genome.Split.split gpart_a1ZoR
                            p_a1Znc = double g_a1Znb
                            (g_a1Znb, gpart_a1ZoR) = Genome.Split.split gpart_a1ZoQ
                            p_a1Zna = Functions.belowten' g_a1Zn9
                            (g_a1Zn9, gpart_a1ZoQ) = Genome.Split.split gpart_a1ZoP
                            p_a1Zn8 = double g_a1Zn7
                            (g_a1Zn7, gpart_a1ZoP) = Genome.Split.split gpart_a1ZoO
                            p_a1Zn6 = double g_a1Zn5
                            (g_a1Zn5, gpart_a1ZoO) = Genome.Split.split gpart_a1ZoN
                            p_a1Zn4 = double g_a1Zn3
                            (g_a1Zn3, gpart_a1ZoN) = Genome.Split.split gpart_a1ZoM
                            p_a1Zn2 = Functions.belowten' g_a1Zn1
                            (g_a1Zn1, gpart_a1ZoM) = Genome.Split.split gpart_a1ZoL
                            p_a1Zn0 = double g_a1ZmZ
                            (g_a1ZmZ, gpart_a1ZoL) = Genome.Split.split gpart_a1ZoK
                            p_a1ZmY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmX
                            (g_a1ZmX, gpart_a1ZoK) = Genome.Split.split gpart_a1ZoJ
                            p_a1ZmW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmV
                            (g_a1ZmV, gpart_a1ZoJ) = Genome.Split.split gpart_a1ZoI
                            p_a1ZmU = Functions.belowten' g_a1ZmT
                            (g_a1ZmT, gpart_a1ZoI) = Genome.Split.split gpart_a1ZoH
                            p_a1ZmS = double g_a1ZmR
                            (g_a1ZmR, gpart_a1ZoH) = Genome.Split.split gpart_a1ZoG
                            p_a1ZmQ = Functions.belowten' g_a1ZmP
                            (g_a1ZmP, gpart_a1ZoG) = Genome.Split.split gpart_a1ZoF
                            p_a1ZmO = double g_a1ZmN
                            (g_a1ZmN, gpart_a1ZoF) = Genome.Split.split gpart_a1ZoE
                            p_a1ZmM = double g_a1ZmL
                            (g_a1ZmL, gpart_a1ZoE) = Genome.Split.split gpart_a1ZoD
                            p_a1ZmK = double g_a1ZmJ
                            (g_a1ZmJ, gpart_a1ZoD) = Genome.Split.split gpart_a1ZoC
                            p_a1ZmI = Functions.belowten' g_a1ZmH
                            (g_a1ZmH, gpart_a1ZoC) = Genome.Split.split gpart_a1ZoB
                            p_a1ZmG = double g_a1ZmF
                            (g_a1ZmF, gpart_a1ZoB) = Genome.Split.split gpart_a1ZoA
                            p_a1ZmE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmD
                            (g_a1ZmD, gpart_a1ZoA) = Genome.Split.split gpart_a1Zoz
                            p_a1ZmC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmB
                            (g_a1ZmB, gpart_a1Zoz) = Genome.Split.split gpart_a1Zoy
                            p_a1ZmA = double g_a1Zmz
                            (g_a1Zmz, gpart_a1Zoy) = Genome.Split.split gpart_a1Zox
                            p_a1Zmy = Functions.belowten' g_a1Zmx
                            (g_a1Zmx, gpart_a1Zox) = Genome.Split.split gpart_a1Zow
                            p_a1Zmw = double g_a1Zmv
                            (g_a1Zmv, gpart_a1Zow) = Genome.Split.split gpart_a1Zov
                            p_a1Zmu = Functions.belowten' g_a1Zmt
                            (g_a1Zmt, gpart_a1Zov) = Genome.Split.split gpart_a1Zou
                            p_a1Zms = double g_a1Zmr
                            (g_a1Zmr, gpart_a1Zou) = Genome.Split.split gpart_a1Zot
                            p_a1Zmq = double g_a1Zmp
                            (g_a1Zmp, gpart_a1Zot) = Genome.Split.split gpart_a1Zos
                            p_a1Zmo = Functions.belowten' g_a1Zmn
                            (g_a1Zmn, gpart_a1Zos) = Genome.Split.split gpart_a1Zor
                            p_a1Zmm = double g_a1Zml
                            (g_a1Zml, gpart_a1Zor) = Genome.Split.split gpart_a1Zoq
                            p_a1Zmk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmj
                            (g_a1Zmj, gpart_a1Zoq) = Genome.Split.split gpart_a1Zop
                            p_a1Zmi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmh
                            (g_a1Zmh, gpart_a1Zop) = Genome.Split.split gpart_a1Zoo
                            p_a1Zmg = double g_a1Zmf
                            (g_a1Zmf, gpart_a1Zoo) = Genome.Split.split gpart_a1Zon
                            p_a1Zme = double g_a1Zmd
                            (g_a1Zmd, gpart_a1Zon) = Genome.Split.split gpart_a1Zom
                            p_a1Zmc = double g_a1Zmb
                            (g_a1Zmb, gpart_a1Zom) = Genome.Split.split gpart_a1Zol
                            p_a1Zma = double g_a1Zm9
                            (g_a1Zm9, gpart_a1Zol) = Genome.Split.split gpart_a1Zok
                            p_a1Zm8 = double g_a1Zm7
                            (g_a1Zm7, gpart_a1Zok) = Genome.Split.split genome_a1Znl
                          in
                            \ desc_a1Znm
                              -> case desc_a1Znm of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm8)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zma)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmc)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zme)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmg)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmi)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmk)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmm)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmo)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmq)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zms)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmu)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmw)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmy)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmA)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmC)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmE)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmG)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmI)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmK)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmM)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmO)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmQ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmS)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmU)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmW)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmY)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn0)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn2)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn4)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn6)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn8)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zna)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Znc)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zne)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zng)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zni)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Znk)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1Zrj
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZrW
                      p_a1Zri = double g_a1Zrh
                      (g_a1Zrh, gpart_a1ZrW) = Genome.Split.split gpart_a1ZrV
                      p_a1Zrg = double g_a1Zrf
                      (g_a1Zrf, gpart_a1ZrV) = Genome.Split.split gpart_a1ZrU
                      p_a1Zre = double g_a1Zrd
                      (g_a1Zrd, gpart_a1ZrU) = Genome.Split.split gpart_a1ZrT
                      p_a1Zrc = double g_a1Zrb
                      (g_a1Zrb, gpart_a1ZrT) = Genome.Split.split gpart_a1ZrS
                      p_a1Zra = double g_a1Zr9
                      (g_a1Zr9, gpart_a1ZrS) = Genome.Split.split gpart_a1ZrR
                      p_a1Zr8 = Functions.belowten' g_a1Zr7
                      (g_a1Zr7, gpart_a1ZrR) = Genome.Split.split gpart_a1ZrQ
                      p_a1Zr6 = double g_a1Zr5
                      (g_a1Zr5, gpart_a1ZrQ) = Genome.Split.split gpart_a1ZrP
                      p_a1Zr4 = double g_a1Zr3
                      (g_a1Zr3, gpart_a1ZrP) = Genome.Split.split gpart_a1ZrO
                      p_a1Zr2 = double g_a1Zr1
                      (g_a1Zr1, gpart_a1ZrO) = Genome.Split.split gpart_a1ZrN
                      p_a1Zr0 = Functions.belowten' g_a1ZqZ
                      (g_a1ZqZ, gpart_a1ZrN) = Genome.Split.split gpart_a1ZrM
                      p_a1ZqY = double g_a1ZqX
                      (g_a1ZqX, gpart_a1ZrM) = Genome.Split.split gpart_a1ZrL
                      p_a1ZqW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZqV
                      (g_a1ZqV, gpart_a1ZrL) = Genome.Split.split gpart_a1ZrK
                      p_a1ZqU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZqT
                      (g_a1ZqT, gpart_a1ZrK) = Genome.Split.split gpart_a1ZrJ
                      p_a1ZqS = Functions.belowten' g_a1ZqR
                      (g_a1ZqR, gpart_a1ZrJ) = Genome.Split.split gpart_a1ZrI
                      p_a1ZqQ = double g_a1ZqP
                      (g_a1ZqP, gpart_a1ZrI) = Genome.Split.split gpart_a1ZrH
                      p_a1ZqO = Functions.belowten' g_a1ZqN
                      (g_a1ZqN, gpart_a1ZrH) = Genome.Split.split gpart_a1ZrG
                      p_a1ZqM = double g_a1ZqL
                      (g_a1ZqL, gpart_a1ZrG) = Genome.Split.split gpart_a1ZrF
                      p_a1ZqK = double g_a1ZqJ
                      (g_a1ZqJ, gpart_a1ZrF) = Genome.Split.split gpart_a1ZrE
                      p_a1ZqI = double g_a1ZqH
                      (g_a1ZqH, gpart_a1ZrE) = Genome.Split.split gpart_a1ZrD
                      p_a1ZqG = Functions.belowten' g_a1ZqF
                      (g_a1ZqF, gpart_a1ZrD) = Genome.Split.split gpart_a1ZrC
                      p_a1ZqE = double g_a1ZqD
                      (g_a1ZqD, gpart_a1ZrC) = Genome.Split.split gpart_a1ZrB
                      p_a1ZqC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZqB
                      (g_a1ZqB, gpart_a1ZrB) = Genome.Split.split gpart_a1ZrA
                      p_a1ZqA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zqz
                      (g_a1Zqz, gpart_a1ZrA) = Genome.Split.split gpart_a1Zrz
                      p_a1Zqy = double g_a1Zqx
                      (g_a1Zqx, gpart_a1Zrz) = Genome.Split.split gpart_a1Zry
                      p_a1Zqw = Functions.belowten' g_a1Zqv
                      (g_a1Zqv, gpart_a1Zry) = Genome.Split.split gpart_a1Zrx
                      p_a1Zqu = double g_a1Zqt
                      (g_a1Zqt, gpart_a1Zrx) = Genome.Split.split gpart_a1Zrw
                      p_a1Zqs = Functions.belowten' g_a1Zqr
                      (g_a1Zqr, gpart_a1Zrw) = Genome.Split.split gpart_a1Zrv
                      p_a1Zqq = double g_a1Zqp
                      (g_a1Zqp, gpart_a1Zrv) = Genome.Split.split gpart_a1Zru
                      p_a1Zqo = double g_a1Zqn
                      (g_a1Zqn, gpart_a1Zru) = Genome.Split.split gpart_a1Zrt
                      p_a1Zqm = Functions.belowten' g_a1Zql
                      (g_a1Zql, gpart_a1Zrt) = Genome.Split.split gpart_a1Zrs
                      p_a1Zqk = double g_a1Zqj
                      (g_a1Zqj, gpart_a1Zrs) = Genome.Split.split gpart_a1Zrr
                      p_a1Zqi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zqh
                      (g_a1Zqh, gpart_a1Zrr) = Genome.Split.split gpart_a1Zrq
                      p_a1Zqg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zqf
                      (g_a1Zqf, gpart_a1Zrq) = Genome.Split.split gpart_a1Zrp
                      p_a1Zqe = double g_a1Zqd
                      (g_a1Zqd, gpart_a1Zrp) = Genome.Split.split gpart_a1Zro
                      p_a1Zqc = double g_a1Zqb
                      (g_a1Zqb, gpart_a1Zro) = Genome.Split.split gpart_a1Zrn
                      p_a1Zqa = double g_a1Zq9
                      (g_a1Zq9, gpart_a1Zrn) = Genome.Split.split gpart_a1Zrm
                      p_a1Zq8 = double g_a1Zq7
                      (g_a1Zq7, gpart_a1Zrm) = Genome.Split.split gpart_a1Zrl
                      p_a1Zq6 = double g_a1Zq5
                      (g_a1Zq5, gpart_a1Zrl) = Genome.Split.split genome_a1Zrj
                    in  \ x_a1ZrX
                          -> let
                               c_PTB_a1Zs0
                                 = ((Data.Fixed.Vector.toVector x_a1ZrX) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZrY
                                 = ((Data.Fixed.Vector.toVector x_a1ZrX) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zs4
                                 = ((Data.Fixed.Vector.toVector x_a1ZrX) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zs5
                                 = ((Data.Fixed.Vector.toVector x_a1ZrX) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zsh
                                 = ((Data.Fixed.Vector.toVector x_a1ZrX) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zqe / (1 + ((c_MiRs_a1ZrY / p_a1Zqk) ** p_a1Zqm)))
                                    + (negate (p_a1Zra * c_PTB_a1Zs0))),
                                   ((p_a1Zqo
                                     / (1
                                        + (((c_MiRs_a1ZrY / p_a1Zqq) ** p_a1Zqs)
                                           + ((c_PTB_a1Zs0 / p_a1Zqu) ** p_a1Zqw))))
                                    + (negate (p_a1Zrc * c_NPTB_a1Zs4))),
                                   ((p_a1Zqy
                                     * (p_a1ZqI
                                        / ((1 + p_a1ZqI) + ((c_RESTc_a1Zs5 / p_a1ZqE) ** p_a1ZqG))))
                                    + (negate (p_a1Zre * c_MiRs_a1ZrY))),
                                   ((p_a1ZqK
                                     * ((p_a1Zr2
                                         + (((c_NPTB_a1Zs4 / p_a1ZqM) ** p_a1ZqO)
                                            + ((c_PTB_a1Zs0 / p_a1ZqQ) ** p_a1ZqS)))
                                        / (((1 + p_a1Zr2)
                                            + (((c_NPTB_a1Zs4 / p_a1ZqM) ** p_a1ZqO)
                                               + ((c_PTB_a1Zs0 / p_a1ZqQ) ** p_a1ZqS)))
                                           + (((p_a1Zq6 / p_a1ZqU) ** p_a1ZqW)
                                              + ((c_MiRs_a1ZrY / p_a1ZqY) ** p_a1Zr0)))))
                                    + (negate (p_a1Zrg * c_RESTc_a1Zs5))),
                                   ((p_a1Zr4 / (1 + ((c_RESTc_a1Zs5 / p_a1Zr6) ** p_a1Zr8)))
                                    + (negate (p_a1Zri * c_EndoNeuroTFs_a1Zsh)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484232",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484234",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484244",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484250",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484252",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484253",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484254",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484257",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484258",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484259",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484260",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484261",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484262",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484263",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484264",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484265",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484266",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484268",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484270",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484272",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484274",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484276",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484284",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484286",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zrj
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZsT
                            p_a1Zri = double g_a1Zrh
                            (g_a1Zrh, gpart_a1ZsT) = Genome.Split.split gpart_a1ZsS
                            p_a1Zrg = double g_a1Zrf
                            (g_a1Zrf, gpart_a1ZsS) = Genome.Split.split gpart_a1ZsR
                            p_a1Zre = double g_a1Zrd
                            (g_a1Zrd, gpart_a1ZsR) = Genome.Split.split gpart_a1ZsQ
                            p_a1Zrc = double g_a1Zrb
                            (g_a1Zrb, gpart_a1ZsQ) = Genome.Split.split gpart_a1ZsP
                            p_a1Zra = double g_a1Zr9
                            (g_a1Zr9, gpart_a1ZsP) = Genome.Split.split gpart_a1ZsO
                            p_a1Zr8 = Functions.belowten' g_a1Zr7
                            (g_a1Zr7, gpart_a1ZsO) = Genome.Split.split gpart_a1ZsN
                            p_a1Zr6 = double g_a1Zr5
                            (g_a1Zr5, gpart_a1ZsN) = Genome.Split.split gpart_a1ZsM
                            p_a1Zr4 = double g_a1Zr3
                            (g_a1Zr3, gpart_a1ZsM) = Genome.Split.split gpart_a1ZsL
                            p_a1Zr2 = double g_a1Zr1
                            (g_a1Zr1, gpart_a1ZsL) = Genome.Split.split gpart_a1ZsK
                            p_a1Zr0 = Functions.belowten' g_a1ZqZ
                            (g_a1ZqZ, gpart_a1ZsK) = Genome.Split.split gpart_a1ZsJ
                            p_a1ZqY = double g_a1ZqX
                            (g_a1ZqX, gpart_a1ZsJ) = Genome.Split.split gpart_a1ZsI
                            p_a1ZqW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZqV
                            (g_a1ZqV, gpart_a1ZsI) = Genome.Split.split gpart_a1ZsH
                            p_a1ZqU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZqT
                            (g_a1ZqT, gpart_a1ZsH) = Genome.Split.split gpart_a1ZsG
                            p_a1ZqS = Functions.belowten' g_a1ZqR
                            (g_a1ZqR, gpart_a1ZsG) = Genome.Split.split gpart_a1ZsF
                            p_a1ZqQ = double g_a1ZqP
                            (g_a1ZqP, gpart_a1ZsF) = Genome.Split.split gpart_a1ZsE
                            p_a1ZqO = Functions.belowten' g_a1ZqN
                            (g_a1ZqN, gpart_a1ZsE) = Genome.Split.split gpart_a1ZsD
                            p_a1ZqM = double g_a1ZqL
                            (g_a1ZqL, gpart_a1ZsD) = Genome.Split.split gpart_a1ZsC
                            p_a1ZqK = double g_a1ZqJ
                            (g_a1ZqJ, gpart_a1ZsC) = Genome.Split.split gpart_a1ZsB
                            p_a1ZqI = double g_a1ZqH
                            (g_a1ZqH, gpart_a1ZsB) = Genome.Split.split gpart_a1ZsA
                            p_a1ZqG = Functions.belowten' g_a1ZqF
                            (g_a1ZqF, gpart_a1ZsA) = Genome.Split.split gpart_a1Zsz
                            p_a1ZqE = double g_a1ZqD
                            (g_a1ZqD, gpart_a1Zsz) = Genome.Split.split gpart_a1Zsy
                            p_a1ZqC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZqB
                            (g_a1ZqB, gpart_a1Zsy) = Genome.Split.split gpart_a1Zsx
                            p_a1ZqA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zqz
                            (g_a1Zqz, gpart_a1Zsx) = Genome.Split.split gpart_a1Zsw
                            p_a1Zqy = double g_a1Zqx
                            (g_a1Zqx, gpart_a1Zsw) = Genome.Split.split gpart_a1Zsv
                            p_a1Zqw = Functions.belowten' g_a1Zqv
                            (g_a1Zqv, gpart_a1Zsv) = Genome.Split.split gpart_a1Zsu
                            p_a1Zqu = double g_a1Zqt
                            (g_a1Zqt, gpart_a1Zsu) = Genome.Split.split gpart_a1Zst
                            p_a1Zqs = Functions.belowten' g_a1Zqr
                            (g_a1Zqr, gpart_a1Zst) = Genome.Split.split gpart_a1Zss
                            p_a1Zqq = double g_a1Zqp
                            (g_a1Zqp, gpart_a1Zss) = Genome.Split.split gpart_a1Zsr
                            p_a1Zqo = double g_a1Zqn
                            (g_a1Zqn, gpart_a1Zsr) = Genome.Split.split gpart_a1Zsq
                            p_a1Zqm = Functions.belowten' g_a1Zql
                            (g_a1Zql, gpart_a1Zsq) = Genome.Split.split gpart_a1Zsp
                            p_a1Zqk = double g_a1Zqj
                            (g_a1Zqj, gpart_a1Zsp) = Genome.Split.split gpart_a1Zso
                            p_a1Zqi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zqh
                            (g_a1Zqh, gpart_a1Zso) = Genome.Split.split gpart_a1Zsn
                            p_a1Zqg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zqf
                            (g_a1Zqf, gpart_a1Zsn) = Genome.Split.split gpart_a1Zsm
                            p_a1Zqe = double g_a1Zqd
                            (g_a1Zqd, gpart_a1Zsm) = Genome.Split.split gpart_a1Zsl
                            p_a1Zqc = double g_a1Zqb
                            (g_a1Zqb, gpart_a1Zsl) = Genome.Split.split gpart_a1Zsk
                            p_a1Zqa = double g_a1Zq9
                            (g_a1Zq9, gpart_a1Zsk) = Genome.Split.split gpart_a1Zsj
                            p_a1Zq8 = double g_a1Zq7
                            (g_a1Zq7, gpart_a1Zsj) = Genome.Split.split gpart_a1Zsi
                            p_a1Zq6 = double g_a1Zq5
                            (g_a1Zq5, gpart_a1Zsi) = Genome.Split.split genome_a1Zrj
                          in
                            \ desc_a1Zrk
                              -> case desc_a1Zrk of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zq6)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zq8)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqa)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqc)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqe)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqg)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqi)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqk)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqm)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqo)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqq)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqs)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqu)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqw)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zqy)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqA)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqC)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqE)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqG)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqI)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqK)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqM)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqO)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqQ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqS)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqU)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqW)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZqY)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zr0)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zr2)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zr4)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zr6)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zr8)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zra)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrc)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zre)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrg)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zri)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1Zvh
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZvU
                      p_a1Zvg = double g_a1Zvf
                      (g_a1Zvf, gpart_a1ZvU) = Genome.Split.split gpart_a1ZvT
                      p_a1Zve = double g_a1Zvd
                      (g_a1Zvd, gpart_a1ZvT) = Genome.Split.split gpart_a1ZvS
                      p_a1Zvc = double g_a1Zvb
                      (g_a1Zvb, gpart_a1ZvS) = Genome.Split.split gpart_a1ZvR
                      p_a1Zva = double g_a1Zv9
                      (g_a1Zv9, gpart_a1ZvR) = Genome.Split.split gpart_a1ZvQ
                      p_a1Zv8 = double g_a1Zv7
                      (g_a1Zv7, gpart_a1ZvQ) = Genome.Split.split gpart_a1ZvP
                      p_a1Zv6 = Functions.belowten' g_a1Zv5
                      (g_a1Zv5, gpart_a1ZvP) = Genome.Split.split gpart_a1ZvO
                      p_a1Zv4 = double g_a1Zv3
                      (g_a1Zv3, gpart_a1ZvO) = Genome.Split.split gpart_a1ZvN
                      p_a1Zv2 = double g_a1Zv1
                      (g_a1Zv1, gpart_a1ZvN) = Genome.Split.split gpart_a1ZvM
                      p_a1Zv0 = double g_a1ZuZ
                      (g_a1ZuZ, gpart_a1ZvM) = Genome.Split.split gpart_a1ZvL
                      p_a1ZuY = Functions.belowten' g_a1ZuX
                      (g_a1ZuX, gpart_a1ZvL) = Genome.Split.split gpart_a1ZvK
                      p_a1ZuW = double g_a1ZuV
                      (g_a1ZuV, gpart_a1ZvK) = Genome.Split.split gpart_a1ZvJ
                      p_a1ZuU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZuT
                      (g_a1ZuT, gpart_a1ZvJ) = Genome.Split.split gpart_a1ZvI
                      p_a1ZuS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZuR
                      (g_a1ZuR, gpart_a1ZvI) = Genome.Split.split gpart_a1ZvH
                      p_a1ZuQ = Functions.belowten' g_a1ZuP
                      (g_a1ZuP, gpart_a1ZvH) = Genome.Split.split gpart_a1ZvG
                      p_a1ZuO = double g_a1ZuN
                      (g_a1ZuN, gpart_a1ZvG) = Genome.Split.split gpart_a1ZvF
                      p_a1ZuM = Functions.belowten' g_a1ZuL
                      (g_a1ZuL, gpart_a1ZvF) = Genome.Split.split gpart_a1ZvE
                      p_a1ZuK = double g_a1ZuJ
                      (g_a1ZuJ, gpart_a1ZvE) = Genome.Split.split gpart_a1ZvD
                      p_a1ZuI = double g_a1ZuH
                      (g_a1ZuH, gpart_a1ZvD) = Genome.Split.split gpart_a1ZvC
                      p_a1ZuG = double g_a1ZuF
                      (g_a1ZuF, gpart_a1ZvC) = Genome.Split.split gpart_a1ZvB
                      p_a1ZuE = Functions.belowten' g_a1ZuD
                      (g_a1ZuD, gpart_a1ZvB) = Genome.Split.split gpart_a1ZvA
                      p_a1ZuC = double g_a1ZuB
                      (g_a1ZuB, gpart_a1ZvA) = Genome.Split.split gpart_a1Zvz
                      p_a1ZuA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zuz
                      (g_a1Zuz, gpart_a1Zvz) = Genome.Split.split gpart_a1Zvy
                      p_a1Zuy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zux
                      (g_a1Zux, gpart_a1Zvy) = Genome.Split.split gpart_a1Zvx
                      p_a1Zuw = double g_a1Zuv
                      (g_a1Zuv, gpart_a1Zvx) = Genome.Split.split gpart_a1Zvw
                      p_a1Zuu = Functions.belowten' g_a1Zut
                      (g_a1Zut, gpart_a1Zvw) = Genome.Split.split gpart_a1Zvv
                      p_a1Zus = double g_a1Zur
                      (g_a1Zur, gpart_a1Zvv) = Genome.Split.split gpart_a1Zvu
                      p_a1Zuq = Functions.belowten' g_a1Zup
                      (g_a1Zup, gpart_a1Zvu) = Genome.Split.split gpart_a1Zvt
                      p_a1Zuo = double g_a1Zun
                      (g_a1Zun, gpart_a1Zvt) = Genome.Split.split gpart_a1Zvs
                      p_a1Zum = double g_a1Zul
                      (g_a1Zul, gpart_a1Zvs) = Genome.Split.split gpart_a1Zvr
                      p_a1Zuk = Functions.belowten' g_a1Zuj
                      (g_a1Zuj, gpart_a1Zvr) = Genome.Split.split gpart_a1Zvq
                      p_a1Zui = double g_a1Zuh
                      (g_a1Zuh, gpart_a1Zvq) = Genome.Split.split gpart_a1Zvp
                      p_a1Zug
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zuf
                      (g_a1Zuf, gpart_a1Zvp) = Genome.Split.split gpart_a1Zvo
                      p_a1Zue
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zud
                      (g_a1Zud, gpart_a1Zvo) = Genome.Split.split gpart_a1Zvn
                      p_a1Zuc = double g_a1Zub
                      (g_a1Zub, gpart_a1Zvn) = Genome.Split.split gpart_a1Zvm
                      p_a1Zua = double g_a1Zu9
                      (g_a1Zu9, gpart_a1Zvm) = Genome.Split.split gpart_a1Zvl
                      p_a1Zu8 = double g_a1Zu7
                      (g_a1Zu7, gpart_a1Zvl) = Genome.Split.split gpart_a1Zvk
                      p_a1Zu6 = double g_a1Zu5
                      (g_a1Zu5, gpart_a1Zvk) = Genome.Split.split gpart_a1Zvj
                      p_a1Zu4 = double g_a1Zu3
                      (g_a1Zu3, gpart_a1Zvj) = Genome.Split.split genome_a1Zvh
                    in  \ x_a1ZvV
                          -> let
                               c_PTB_a1ZvY
                                 = ((Data.Fixed.Vector.toVector x_a1ZvV) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZvW
                                 = ((Data.Fixed.Vector.toVector x_a1ZvV) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zw2
                                 = ((Data.Fixed.Vector.toVector x_a1ZvV) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zw3
                                 = ((Data.Fixed.Vector.toVector x_a1ZvV) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zwf
                                 = ((Data.Fixed.Vector.toVector x_a1ZvV) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zuc / (1 + ((c_MiRs_a1ZvW / p_a1Zui) ** p_a1Zuk)))
                                    + (negate (p_a1Zv8 * c_PTB_a1ZvY))),
                                   ((p_a1Zum
                                     / (1
                                        + (((c_MiRs_a1ZvW / p_a1Zuo) ** p_a1Zuq)
                                           + ((c_PTB_a1ZvY / p_a1Zus) ** p_a1Zuu))))
                                    + (negate (p_a1Zva * c_NPTB_a1Zw2))),
                                   ((p_a1Zuw
                                     * (p_a1ZuG
                                        / ((1 + p_a1ZuG) + ((c_RESTc_a1Zw3 / p_a1ZuC) ** p_a1ZuE))))
                                    + (negate (p_a1Zvc * c_MiRs_a1ZvW))),
                                   ((p_a1ZuI
                                     * ((p_a1Zv0
                                         + (((c_NPTB_a1Zw2 / p_a1ZuK) ** p_a1ZuM)
                                            + ((c_PTB_a1ZvY / p_a1ZuO) ** p_a1ZuQ)))
                                        / (((1 + p_a1Zv0)
                                            + (((c_NPTB_a1Zw2 / p_a1ZuK) ** p_a1ZuM)
                                               + ((c_PTB_a1ZvY / p_a1ZuO) ** p_a1ZuQ)))
                                           + ((c_MiRs_a1ZvW / p_a1ZuW) ** p_a1ZuY))))
                                    + (negate (p_a1Zve * c_RESTc_a1Zw3))),
                                   ((p_a1Zv2 / (1 + ((c_RESTc_a1Zw3 / p_a1Zv4) ** p_a1Zv6)))
                                    + (negate (p_a1Zvg * c_EndoNeuroTFs_a1Zwf)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484478",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484480",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484490",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484492",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484498",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484500",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484510",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484518",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484520",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484524",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484526",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484528",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484530",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484532",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484536",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484538",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zvh
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZwR
                            p_a1Zvg = double g_a1Zvf
                            (g_a1Zvf, gpart_a1ZwR) = Genome.Split.split gpart_a1ZwQ
                            p_a1Zve = double g_a1Zvd
                            (g_a1Zvd, gpart_a1ZwQ) = Genome.Split.split gpart_a1ZwP
                            p_a1Zvc = double g_a1Zvb
                            (g_a1Zvb, gpart_a1ZwP) = Genome.Split.split gpart_a1ZwO
                            p_a1Zva = double g_a1Zv9
                            (g_a1Zv9, gpart_a1ZwO) = Genome.Split.split gpart_a1ZwN
                            p_a1Zv8 = double g_a1Zv7
                            (g_a1Zv7, gpart_a1ZwN) = Genome.Split.split gpart_a1ZwM
                            p_a1Zv6 = Functions.belowten' g_a1Zv5
                            (g_a1Zv5, gpart_a1ZwM) = Genome.Split.split gpart_a1ZwL
                            p_a1Zv4 = double g_a1Zv3
                            (g_a1Zv3, gpart_a1ZwL) = Genome.Split.split gpart_a1ZwK
                            p_a1Zv2 = double g_a1Zv1
                            (g_a1Zv1, gpart_a1ZwK) = Genome.Split.split gpart_a1ZwJ
                            p_a1Zv0 = double g_a1ZuZ
                            (g_a1ZuZ, gpart_a1ZwJ) = Genome.Split.split gpart_a1ZwI
                            p_a1ZuY = Functions.belowten' g_a1ZuX
                            (g_a1ZuX, gpart_a1ZwI) = Genome.Split.split gpart_a1ZwH
                            p_a1ZuW = double g_a1ZuV
                            (g_a1ZuV, gpart_a1ZwH) = Genome.Split.split gpart_a1ZwG
                            p_a1ZuU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZuT
                            (g_a1ZuT, gpart_a1ZwG) = Genome.Split.split gpart_a1ZwF
                            p_a1ZuS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZuR
                            (g_a1ZuR, gpart_a1ZwF) = Genome.Split.split gpart_a1ZwE
                            p_a1ZuQ = Functions.belowten' g_a1ZuP
                            (g_a1ZuP, gpart_a1ZwE) = Genome.Split.split gpart_a1ZwD
                            p_a1ZuO = double g_a1ZuN
                            (g_a1ZuN, gpart_a1ZwD) = Genome.Split.split gpart_a1ZwC
                            p_a1ZuM = Functions.belowten' g_a1ZuL
                            (g_a1ZuL, gpart_a1ZwC) = Genome.Split.split gpart_a1ZwB
                            p_a1ZuK = double g_a1ZuJ
                            (g_a1ZuJ, gpart_a1ZwB) = Genome.Split.split gpart_a1ZwA
                            p_a1ZuI = double g_a1ZuH
                            (g_a1ZuH, gpart_a1ZwA) = Genome.Split.split gpart_a1Zwz
                            p_a1ZuG = double g_a1ZuF
                            (g_a1ZuF, gpart_a1Zwz) = Genome.Split.split gpart_a1Zwy
                            p_a1ZuE = Functions.belowten' g_a1ZuD
                            (g_a1ZuD, gpart_a1Zwy) = Genome.Split.split gpart_a1Zwx
                            p_a1ZuC = double g_a1ZuB
                            (g_a1ZuB, gpart_a1Zwx) = Genome.Split.split gpart_a1Zww
                            p_a1ZuA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zuz
                            (g_a1Zuz, gpart_a1Zww) = Genome.Split.split gpart_a1Zwv
                            p_a1Zuy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zux
                            (g_a1Zux, gpart_a1Zwv) = Genome.Split.split gpart_a1Zwu
                            p_a1Zuw = double g_a1Zuv
                            (g_a1Zuv, gpart_a1Zwu) = Genome.Split.split gpart_a1Zwt
                            p_a1Zuu = Functions.belowten' g_a1Zut
                            (g_a1Zut, gpart_a1Zwt) = Genome.Split.split gpart_a1Zws
                            p_a1Zus = double g_a1Zur
                            (g_a1Zur, gpart_a1Zws) = Genome.Split.split gpart_a1Zwr
                            p_a1Zuq = Functions.belowten' g_a1Zup
                            (g_a1Zup, gpart_a1Zwr) = Genome.Split.split gpart_a1Zwq
                            p_a1Zuo = double g_a1Zun
                            (g_a1Zun, gpart_a1Zwq) = Genome.Split.split gpart_a1Zwp
                            p_a1Zum = double g_a1Zul
                            (g_a1Zul, gpart_a1Zwp) = Genome.Split.split gpart_a1Zwo
                            p_a1Zuk = Functions.belowten' g_a1Zuj
                            (g_a1Zuj, gpart_a1Zwo) = Genome.Split.split gpart_a1Zwn
                            p_a1Zui = double g_a1Zuh
                            (g_a1Zuh, gpart_a1Zwn) = Genome.Split.split gpart_a1Zwm
                            p_a1Zug
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zuf
                            (g_a1Zuf, gpart_a1Zwm) = Genome.Split.split gpart_a1Zwl
                            p_a1Zue
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zud
                            (g_a1Zud, gpart_a1Zwl) = Genome.Split.split gpart_a1Zwk
                            p_a1Zuc = double g_a1Zub
                            (g_a1Zub, gpart_a1Zwk) = Genome.Split.split gpart_a1Zwj
                            p_a1Zua = double g_a1Zu9
                            (g_a1Zu9, gpart_a1Zwj) = Genome.Split.split gpart_a1Zwi
                            p_a1Zu8 = double g_a1Zu7
                            (g_a1Zu7, gpart_a1Zwi) = Genome.Split.split gpart_a1Zwh
                            p_a1Zu6 = double g_a1Zu5
                            (g_a1Zu5, gpart_a1Zwh) = Genome.Split.split gpart_a1Zwg
                            p_a1Zu4 = double g_a1Zu3
                            (g_a1Zu3, gpart_a1Zwg) = Genome.Split.split genome_a1Zvh
                          in
                            \ desc_a1Zvi
                              -> case desc_a1Zvi of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zu4)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zu6)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zu8)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zua)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zuc)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zue)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zug)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zui)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zuk)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zum)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zuo)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zuq)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zus)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zuu)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zuw)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zuy)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuA)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuC)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuE)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuG)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuI)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuK)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuM)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuO)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuQ)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuS)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuU)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuW)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZuY)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zv0)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zv2)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zv4)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zv6)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zv8)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zva)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zvc)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zve)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zvg)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1Zzf
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZzS
                      p_a1Zze = double g_a1Zzd
                      (g_a1Zzd, gpart_a1ZzS) = Genome.Split.split gpart_a1ZzR
                      p_a1Zzc = double g_a1Zzb
                      (g_a1Zzb, gpart_a1ZzR) = Genome.Split.split gpart_a1ZzQ
                      p_a1Zza = double g_a1Zz9
                      (g_a1Zz9, gpart_a1ZzQ) = Genome.Split.split gpart_a1ZzP
                      p_a1Zz8 = double g_a1Zz7
                      (g_a1Zz7, gpart_a1ZzP) = Genome.Split.split gpart_a1ZzO
                      p_a1Zz6 = double g_a1Zz5
                      (g_a1Zz5, gpart_a1ZzO) = Genome.Split.split gpart_a1ZzN
                      p_a1Zz4 = Functions.belowten' g_a1Zz3
                      (g_a1Zz3, gpart_a1ZzN) = Genome.Split.split gpart_a1ZzM
                      p_a1Zz2 = double g_a1Zz1
                      (g_a1Zz1, gpart_a1ZzM) = Genome.Split.split gpart_a1ZzL
                      p_a1Zz0 = double g_a1ZyZ
                      (g_a1ZyZ, gpart_a1ZzL) = Genome.Split.split gpart_a1ZzK
                      p_a1ZyY = double g_a1ZyX
                      (g_a1ZyX, gpart_a1ZzK) = Genome.Split.split gpart_a1ZzJ
                      p_a1ZyW = Functions.belowten' g_a1ZyV
                      (g_a1ZyV, gpart_a1ZzJ) = Genome.Split.split gpart_a1ZzI
                      p_a1ZyU = double g_a1ZyT
                      (g_a1ZyT, gpart_a1ZzI) = Genome.Split.split gpart_a1ZzH
                      p_a1ZyS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZyR
                      (g_a1ZyR, gpart_a1ZzH) = Genome.Split.split gpart_a1ZzG
                      p_a1ZyQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZyP
                      (g_a1ZyP, gpart_a1ZzG) = Genome.Split.split gpart_a1ZzF
                      p_a1ZyO = Functions.belowten' g_a1ZyN
                      (g_a1ZyN, gpart_a1ZzF) = Genome.Split.split gpart_a1ZzE
                      p_a1ZyM = double g_a1ZyL
                      (g_a1ZyL, gpart_a1ZzE) = Genome.Split.split gpart_a1ZzD
                      p_a1ZyK = Functions.belowten' g_a1ZyJ
                      (g_a1ZyJ, gpart_a1ZzD) = Genome.Split.split gpart_a1ZzC
                      p_a1ZyI = double g_a1ZyH
                      (g_a1ZyH, gpart_a1ZzC) = Genome.Split.split gpart_a1ZzB
                      p_a1ZyG = double g_a1ZyF
                      (g_a1ZyF, gpart_a1ZzB) = Genome.Split.split gpart_a1ZzA
                      p_a1ZyE = double g_a1ZyD
                      (g_a1ZyD, gpart_a1ZzA) = Genome.Split.split gpart_a1Zzz
                      p_a1ZyC = Functions.belowten' g_a1ZyB
                      (g_a1ZyB, gpart_a1Zzz) = Genome.Split.split gpart_a1Zzy
                      p_a1ZyA = double g_a1Zyz
                      (g_a1Zyz, gpart_a1Zzy) = Genome.Split.split gpart_a1Zzx
                      p_a1Zyy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zyx
                      (g_a1Zyx, gpart_a1Zzx) = Genome.Split.split gpart_a1Zzw
                      p_a1Zyw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zyv
                      (g_a1Zyv, gpart_a1Zzw) = Genome.Split.split gpart_a1Zzv
                      p_a1Zyu = double g_a1Zyt
                      (g_a1Zyt, gpart_a1Zzv) = Genome.Split.split gpart_a1Zzu
                      p_a1Zys = Functions.belowten' g_a1Zyr
                      (g_a1Zyr, gpart_a1Zzu) = Genome.Split.split gpart_a1Zzt
                      p_a1Zyq = double g_a1Zyp
                      (g_a1Zyp, gpart_a1Zzt) = Genome.Split.split gpart_a1Zzs
                      p_a1Zyo = Functions.belowten' g_a1Zyn
                      (g_a1Zyn, gpart_a1Zzs) = Genome.Split.split gpart_a1Zzr
                      p_a1Zym = double g_a1Zyl
                      (g_a1Zyl, gpart_a1Zzr) = Genome.Split.split gpart_a1Zzq
                      p_a1Zyk = double g_a1Zyj
                      (g_a1Zyj, gpart_a1Zzq) = Genome.Split.split gpart_a1Zzp
                      p_a1Zyi = Functions.belowten' g_a1Zyh
                      (g_a1Zyh, gpart_a1Zzp) = Genome.Split.split gpart_a1Zzo
                      p_a1Zyg = double g_a1Zyf
                      (g_a1Zyf, gpart_a1Zzo) = Genome.Split.split gpart_a1Zzn
                      p_a1Zye
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zyd
                      (g_a1Zyd, gpart_a1Zzn) = Genome.Split.split gpart_a1Zzm
                      p_a1Zyc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zyb
                      (g_a1Zyb, gpart_a1Zzm) = Genome.Split.split gpart_a1Zzl
                      p_a1Zya = double g_a1Zy9
                      (g_a1Zy9, gpart_a1Zzl) = Genome.Split.split gpart_a1Zzk
                      p_a1Zy8 = double g_a1Zy7
                      (g_a1Zy7, gpart_a1Zzk) = Genome.Split.split gpart_a1Zzj
                      p_a1Zy6 = double g_a1Zy5
                      (g_a1Zy5, gpart_a1Zzj) = Genome.Split.split gpart_a1Zzi
                      p_a1Zy4 = double g_a1Zy3
                      (g_a1Zy3, gpart_a1Zzi) = Genome.Split.split gpart_a1Zzh
                      p_a1Zy2 = double g_a1Zy1
                      (g_a1Zy1, gpart_a1Zzh) = Genome.Split.split genome_a1Zzf
                    in  \ x_a1ZzT
                          -> let
                               c_PTB_a1ZzW
                                 = ((Data.Fixed.Vector.toVector x_a1ZzT) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZzU
                                 = ((Data.Fixed.Vector.toVector x_a1ZzT) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZA0
                                 = ((Data.Fixed.Vector.toVector x_a1ZzT) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZA1
                                 = ((Data.Fixed.Vector.toVector x_a1ZzT) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1ZAd
                                 = ((Data.Fixed.Vector.toVector x_a1ZzT) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zya
                                     / (1
                                        + (((p_a1Zy2 / p_a1Zyc) ** p_a1Zye)
                                           + ((c_MiRs_a1ZzU / p_a1Zyg) ** p_a1Zyi))))
                                    + (negate (p_a1Zz6 * c_PTB_a1ZzW))),
                                   ((p_a1Zyk
                                     / (1
                                        + (((c_MiRs_a1ZzU / p_a1Zym) ** p_a1Zyo)
                                           + ((c_PTB_a1ZzW / p_a1Zyq) ** p_a1Zys))))
                                    + (negate (p_a1Zz8 * c_NPTB_a1ZA0))),
                                   ((p_a1Zyu
                                     * (p_a1ZyE
                                        / ((1 + p_a1ZyE) + ((c_RESTc_a1ZA1 / p_a1ZyA) ** p_a1ZyC))))
                                    + (negate (p_a1Zza * c_MiRs_a1ZzU))),
                                   ((p_a1ZyG
                                     * ((p_a1ZyY
                                         + (((c_NPTB_a1ZA0 / p_a1ZyI) ** p_a1ZyK)
                                            + ((c_PTB_a1ZzW / p_a1ZyM) ** p_a1ZyO)))
                                        / (((1 + p_a1ZyY)
                                            + (((c_NPTB_a1ZA0 / p_a1ZyI) ** p_a1ZyK)
                                               + ((c_PTB_a1ZzW / p_a1ZyM) ** p_a1ZyO)))
                                           + ((c_MiRs_a1ZzU / p_a1ZyU) ** p_a1ZyW))))
                                    + (negate (p_a1Zzc * c_RESTc_a1ZA1))),
                                   ((p_a1Zz0 / (1 + ((c_RESTc_a1ZA1 / p_a1Zz2) ** p_a1Zz4)))
                                    + (negate (p_a1Zze * c_EndoNeuroTFs_a1ZAd)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484714",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484716",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484718",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484720",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484722",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484724",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484726",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484728",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484730",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484744",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484746",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484764",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484766",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484768",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484770",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484771",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484772",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484773",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484774",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484777",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484778",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484779",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484780",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484781",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484782",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484783",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484784",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484785",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484786",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484787",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484788",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zzf
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZAP
                            p_a1Zze = double g_a1Zzd
                            (g_a1Zzd, gpart_a1ZAP) = Genome.Split.split gpart_a1ZAO
                            p_a1Zzc = double g_a1Zzb
                            (g_a1Zzb, gpart_a1ZAO) = Genome.Split.split gpart_a1ZAN
                            p_a1Zza = double g_a1Zz9
                            (g_a1Zz9, gpart_a1ZAN) = Genome.Split.split gpart_a1ZAM
                            p_a1Zz8 = double g_a1Zz7
                            (g_a1Zz7, gpart_a1ZAM) = Genome.Split.split gpart_a1ZAL
                            p_a1Zz6 = double g_a1Zz5
                            (g_a1Zz5, gpart_a1ZAL) = Genome.Split.split gpart_a1ZAK
                            p_a1Zz4 = Functions.belowten' g_a1Zz3
                            (g_a1Zz3, gpart_a1ZAK) = Genome.Split.split gpart_a1ZAJ
                            p_a1Zz2 = double g_a1Zz1
                            (g_a1Zz1, gpart_a1ZAJ) = Genome.Split.split gpart_a1ZAI
                            p_a1Zz0 = double g_a1ZyZ
                            (g_a1ZyZ, gpart_a1ZAI) = Genome.Split.split gpart_a1ZAH
                            p_a1ZyY = double g_a1ZyX
                            (g_a1ZyX, gpart_a1ZAH) = Genome.Split.split gpart_a1ZAG
                            p_a1ZyW = Functions.belowten' g_a1ZyV
                            (g_a1ZyV, gpart_a1ZAG) = Genome.Split.split gpart_a1ZAF
                            p_a1ZyU = double g_a1ZyT
                            (g_a1ZyT, gpart_a1ZAF) = Genome.Split.split gpart_a1ZAE
                            p_a1ZyS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZyR
                            (g_a1ZyR, gpart_a1ZAE) = Genome.Split.split gpart_a1ZAD
                            p_a1ZyQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZyP
                            (g_a1ZyP, gpart_a1ZAD) = Genome.Split.split gpart_a1ZAC
                            p_a1ZyO = Functions.belowten' g_a1ZyN
                            (g_a1ZyN, gpart_a1ZAC) = Genome.Split.split gpart_a1ZAB
                            p_a1ZyM = double g_a1ZyL
                            (g_a1ZyL, gpart_a1ZAB) = Genome.Split.split gpart_a1ZAA
                            p_a1ZyK = Functions.belowten' g_a1ZyJ
                            (g_a1ZyJ, gpart_a1ZAA) = Genome.Split.split gpart_a1ZAz
                            p_a1ZyI = double g_a1ZyH
                            (g_a1ZyH, gpart_a1ZAz) = Genome.Split.split gpart_a1ZAy
                            p_a1ZyG = double g_a1ZyF
                            (g_a1ZyF, gpart_a1ZAy) = Genome.Split.split gpart_a1ZAx
                            p_a1ZyE = double g_a1ZyD
                            (g_a1ZyD, gpart_a1ZAx) = Genome.Split.split gpart_a1ZAw
                            p_a1ZyC = Functions.belowten' g_a1ZyB
                            (g_a1ZyB, gpart_a1ZAw) = Genome.Split.split gpart_a1ZAv
                            p_a1ZyA = double g_a1Zyz
                            (g_a1Zyz, gpart_a1ZAv) = Genome.Split.split gpart_a1ZAu
                            p_a1Zyy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zyx
                            (g_a1Zyx, gpart_a1ZAu) = Genome.Split.split gpart_a1ZAt
                            p_a1Zyw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zyv
                            (g_a1Zyv, gpart_a1ZAt) = Genome.Split.split gpart_a1ZAs
                            p_a1Zyu = double g_a1Zyt
                            (g_a1Zyt, gpart_a1ZAs) = Genome.Split.split gpart_a1ZAr
                            p_a1Zys = Functions.belowten' g_a1Zyr
                            (g_a1Zyr, gpart_a1ZAr) = Genome.Split.split gpart_a1ZAq
                            p_a1Zyq = double g_a1Zyp
                            (g_a1Zyp, gpart_a1ZAq) = Genome.Split.split gpart_a1ZAp
                            p_a1Zyo = Functions.belowten' g_a1Zyn
                            (g_a1Zyn, gpart_a1ZAp) = Genome.Split.split gpart_a1ZAo
                            p_a1Zym = double g_a1Zyl
                            (g_a1Zyl, gpart_a1ZAo) = Genome.Split.split gpart_a1ZAn
                            p_a1Zyk = double g_a1Zyj
                            (g_a1Zyj, gpart_a1ZAn) = Genome.Split.split gpart_a1ZAm
                            p_a1Zyi = Functions.belowten' g_a1Zyh
                            (g_a1Zyh, gpart_a1ZAm) = Genome.Split.split gpart_a1ZAl
                            p_a1Zyg = double g_a1Zyf
                            (g_a1Zyf, gpart_a1ZAl) = Genome.Split.split gpart_a1ZAk
                            p_a1Zye
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zyd
                            (g_a1Zyd, gpart_a1ZAk) = Genome.Split.split gpart_a1ZAj
                            p_a1Zyc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zyb
                            (g_a1Zyb, gpart_a1ZAj) = Genome.Split.split gpart_a1ZAi
                            p_a1Zya = double g_a1Zy9
                            (g_a1Zy9, gpart_a1ZAi) = Genome.Split.split gpart_a1ZAh
                            p_a1Zy8 = double g_a1Zy7
                            (g_a1Zy7, gpart_a1ZAh) = Genome.Split.split gpart_a1ZAg
                            p_a1Zy6 = double g_a1Zy5
                            (g_a1Zy5, gpart_a1ZAg) = Genome.Split.split gpart_a1ZAf
                            p_a1Zy4 = double g_a1Zy3
                            (g_a1Zy3, gpart_a1ZAf) = Genome.Split.split gpart_a1ZAe
                            p_a1Zy2 = double g_a1Zy1
                            (g_a1Zy1, gpart_a1ZAe) = Genome.Split.split genome_a1Zzf
                          in
                            \ desc_a1Zzg
                              -> case desc_a1Zzg of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zy2)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zy4)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zy6)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zy8)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zya)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zyc)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zye)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zyg)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zyi)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zyk)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zym)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zyo)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zyq)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zys)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zyu)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zyw)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zyy)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyA)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyC)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyE)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyG)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyI)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyK)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyM)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyO)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyQ)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyS)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyU)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyW)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZyY)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zz0)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zz2)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zz4)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zz6)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zz8)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zza)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zzc)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zze)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asWI
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXl
                      p_asWH = code-0.1.0.0:Genome.FixedList.Functions.double g_asWG
                      (g_asWG, gpart_asXl) = Genome.Split.split gpart_asXk
                      p_asWF = code-0.1.0.0:Genome.FixedList.Functions.double g_asWE
                      (g_asWE, gpart_asXk) = Genome.Split.split gpart_asXj
                      p_asWD = code-0.1.0.0:Genome.FixedList.Functions.double g_asWC
                      (g_asWC, gpart_asXj) = Genome.Split.split gpart_asXi
                      p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                      (g_asWA, gpart_asXi) = Genome.Split.split gpart_asXh
                      p_asWz = code-0.1.0.0:Genome.FixedList.Functions.double g_asWy
                      (g_asWy, gpart_asXh) = Genome.Split.split gpart_asXg
                      p_asWx = Functions.belowten' g_asWw
                      (g_asWw, gpart_asXg) = Genome.Split.split gpart_asXf
                      p_asWv = code-0.1.0.0:Genome.FixedList.Functions.double g_asWu
                      (g_asWu, gpart_asXf) = Genome.Split.split gpart_asXe
                      p_asWt = code-0.1.0.0:Genome.FixedList.Functions.double g_asWs
                      (g_asWs, gpart_asXe) = Genome.Split.split gpart_asXd
                      p_asWr = code-0.1.0.0:Genome.FixedList.Functions.double g_asWq
                      (g_asWq, gpart_asXd) = Genome.Split.split gpart_asXc
                      p_asWp = Functions.belowten' g_asWo
                      (g_asWo, gpart_asXc) = Genome.Split.split gpart_asXb
                      p_asWn = code-0.1.0.0:Genome.FixedList.Functions.double g_asWm
                      (g_asWm, gpart_asXb) = Genome.Split.split gpart_asXa
                      p_asWl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWk
                      (g_asWk, gpart_asXa) = Genome.Split.split gpart_asX9
                      p_asWj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWi
                      (g_asWi, gpart_asX9) = Genome.Split.split gpart_asX8
                      p_asWh = Functions.belowten' g_asWg
                      (g_asWg, gpart_asX8) = Genome.Split.split gpart_asX7
                      p_asWf = code-0.1.0.0:Genome.FixedList.Functions.double g_asWe
                      (g_asWe, gpart_asX7) = Genome.Split.split gpart_asX6
                      p_asWd = Functions.belowten' g_asWc
                      (g_asWc, gpart_asX6) = Genome.Split.split gpart_asX5
                      p_asWb = code-0.1.0.0:Genome.FixedList.Functions.double g_asWa
                      (g_asWa, gpart_asX5) = Genome.Split.split gpart_asX4
                      p_asW9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW8
                      (g_asW8, gpart_asX4) = Genome.Split.split gpart_asX3
                      p_asW7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW6
                      (g_asW6, gpart_asX3) = Genome.Split.split gpart_asX2
                      p_asW5 = Functions.belowten' g_asW4
                      (g_asW4, gpart_asX2) = Genome.Split.split gpart_asX1
                      p_asW3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW2
                      (g_asW2, gpart_asX1) = Genome.Split.split gpart_asX0
                      p_asW1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW0
                      (g_asW0, gpart_asX0) = Genome.Split.split gpart_asWZ
                      p_asVZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVY
                      (g_asVY, gpart_asWZ) = Genome.Split.split gpart_asWY
                      p_asVX = code-0.1.0.0:Genome.FixedList.Functions.double g_asVW
                      (g_asVW, gpart_asWY) = Genome.Split.split gpart_asWX
                      p_asVV = Functions.belowten' g_asVU
                      (g_asVU, gpart_asWX) = Genome.Split.split gpart_asWW
                      p_asVT = code-0.1.0.0:Genome.FixedList.Functions.double g_asVS
                      (g_asVS, gpart_asWW) = Genome.Split.split gpart_asWV
                      p_asVR = Functions.belowten' g_asVQ
                      (g_asVQ, gpart_asWV) = Genome.Split.split gpart_asWU
                      p_asVP = code-0.1.0.0:Genome.FixedList.Functions.double g_asVO
                      (g_asVO, gpart_asWU) = Genome.Split.split gpart_asWT
                      p_asVN = code-0.1.0.0:Genome.FixedList.Functions.double g_asVM
                      (g_asVM, gpart_asWT) = Genome.Split.split gpart_asWS
                      p_asVL = Functions.belowten' g_asVK
                      (g_asVK, gpart_asWS) = Genome.Split.split gpart_asWR
                      p_asVJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVI
                      (g_asVI, gpart_asWR) = Genome.Split.split gpart_asWQ
                      p_asVH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVG
                      (g_asVG, gpart_asWQ) = Genome.Split.split gpart_asWP
                      p_asVF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVE
                      (g_asVE, gpart_asWP) = Genome.Split.split gpart_asWO
                      p_asVD = code-0.1.0.0:Genome.FixedList.Functions.double g_asVC
                      (g_asVC, gpart_asWO) = Genome.Split.split gpart_asWN
                      p_asVB = code-0.1.0.0:Genome.FixedList.Functions.double g_asVA
                      (g_asVA, gpart_asWN) = Genome.Split.split gpart_asWM
                      p_asVz = code-0.1.0.0:Genome.FixedList.Functions.double g_asVy
                      (g_asVy, gpart_asWM) = Genome.Split.split gpart_asWL
                      p_asVx = code-0.1.0.0:Genome.FixedList.Functions.double g_asVw
                      (g_asVw, gpart_asWL) = Genome.Split.split gpart_asWK
                      p_asVv = code-0.1.0.0:Genome.FixedList.Functions.double g_asVu
                      (g_asVu, gpart_asWK) = Genome.Split.split genome_asWI
                    in
                      [Reaction
                         (\ x_asXm
                            -> let c_MiRs_asXn = ((toVector x_asXm) Data.Vector.Unboxed.! 2)
                               in (p_asVD / (1 + ((c_MiRs_asXn / p_asVJ) ** p_asVL))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXo
                            -> let
                                 c_MiRs_asXp = ((toVector x_asXo) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXq = ((toVector x_asXo) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVN
                                  / (1
                                     + (((c_MiRs_asXp / p_asVP) ** p_asVR)
                                        + ((c_PTB_asXq / p_asVT) ** p_asVV)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asXr
                            -> let c_RESTc_asXs = ((toVector x_asXr) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asVX
                                  * ((p_asW7 + ((p_asVz / p_asVZ) ** p_asW1))
                                     / (((1 + p_asW7) + ((p_asVz / p_asVZ) ** p_asW1))
                                        + ((c_RESTc_asXs / p_asW3) ** p_asW5)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asXt
                            -> let
                                 c_MiRs_asXy = ((toVector x_asXt) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXv = ((toVector x_asXt) Data.Vector.Unboxed.! 0)
                                 c_NPTB_asXu = ((toVector x_asXt) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asW9
                                  * ((p_asWr
                                      + (((c_NPTB_asXu / p_asWb) ** p_asWd)
                                         + ((c_PTB_asXv / p_asWf) ** p_asWh)))
                                     / (((1 + p_asWr)
                                         + (((c_NPTB_asXu / p_asWb) ** p_asWd)
                                            + ((c_PTB_asXv / p_asWf) ** p_asWh)))
                                        + (((p_asVv / p_asWj) ** p_asWl)
                                           + ((c_MiRs_asXy / p_asWn) ** p_asWp))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asXz
                            -> let c_RESTc_asXA = ((toVector x_asXz) Data.Vector.Unboxed.! 3)
                               in (p_asWt / (1 + ((c_RESTc_asXA / p_asWv) ** p_asWx))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asXB
                            -> let c_PTB_asXC = ((toVector x_asXB) Data.Vector.Unboxed.! 0)
                               in (p_asWz * c_PTB_asXC))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXD
                            -> let c_NPTB_asXE = ((toVector x_asXD) Data.Vector.Unboxed.! 1)
                               in (p_asWB * c_NPTB_asXE))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asXF
                            -> let c_MiRs_asXG = ((toVector x_asXF) Data.Vector.Unboxed.! 2)
                               in (p_asWD * c_MiRs_asXG))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asXH
                            -> let c_RESTc_asXI = ((toVector x_asXH) Data.Vector.Unboxed.! 3)
                               in (p_asWF * c_RESTc_asXI))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asXJ
                            -> let
                                 c_EndoNeuroTFs_asXK = ((toVector x_asXJ) Data.Vector.Unboxed.! 4)
                               in (p_asWH * c_EndoNeuroTFs_asXK))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120988",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120989",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120990",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120991",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120992",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120993",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120994",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120995",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120996",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120997",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120998",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120999",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121000",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121001",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121002",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121003",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121004",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121005",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121006",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121007",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121008",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121009",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121010",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121011",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121012",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121013",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121014",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121015",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121016",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121017",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121018",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121019",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121020",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121021",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121023",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121025",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121027",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121034",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121035",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121036",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121037",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121038",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121039",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121040",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121041",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121042",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121043",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121044",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121045",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121046",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121047",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121048",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121049",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121050",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121051",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121059",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121061",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121063",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asWI
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYr
                            p_asWH = code-0.1.0.0:Genome.FixedList.Functions.double g_asWG
                            (g_asWG, gpart_asYr) = Genome.Split.split gpart_asYq
                            p_asWF = code-0.1.0.0:Genome.FixedList.Functions.double g_asWE
                            (g_asWE, gpart_asYq) = Genome.Split.split gpart_asYp
                            p_asWD = code-0.1.0.0:Genome.FixedList.Functions.double g_asWC
                            (g_asWC, gpart_asYp) = Genome.Split.split gpart_asYo
                            p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                            (g_asWA, gpart_asYo) = Genome.Split.split gpart_asYn
                            p_asWz = code-0.1.0.0:Genome.FixedList.Functions.double g_asWy
                            (g_asWy, gpart_asYn) = Genome.Split.split gpart_asYm
                            p_asWx = Functions.belowten' g_asWw
                            (g_asWw, gpart_asYm) = Genome.Split.split gpart_asYl
                            p_asWv = code-0.1.0.0:Genome.FixedList.Functions.double g_asWu
                            (g_asWu, gpart_asYl) = Genome.Split.split gpart_asYk
                            p_asWt = code-0.1.0.0:Genome.FixedList.Functions.double g_asWs
                            (g_asWs, gpart_asYk) = Genome.Split.split gpart_asYj
                            p_asWr = code-0.1.0.0:Genome.FixedList.Functions.double g_asWq
                            (g_asWq, gpart_asYj) = Genome.Split.split gpart_asYi
                            p_asWp = Functions.belowten' g_asWo
                            (g_asWo, gpart_asYi) = Genome.Split.split gpart_asYh
                            p_asWn = code-0.1.0.0:Genome.FixedList.Functions.double g_asWm
                            (g_asWm, gpart_asYh) = Genome.Split.split gpart_asYg
                            p_asWl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWk
                            (g_asWk, gpart_asYg) = Genome.Split.split gpart_asYf
                            p_asWj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWi
                            (g_asWi, gpart_asYf) = Genome.Split.split gpart_asYe
                            p_asWh = Functions.belowten' g_asWg
                            (g_asWg, gpart_asYe) = Genome.Split.split gpart_asYd
                            p_asWf = code-0.1.0.0:Genome.FixedList.Functions.double g_asWe
                            (g_asWe, gpart_asYd) = Genome.Split.split gpart_asYc
                            p_asWd = Functions.belowten' g_asWc
                            (g_asWc, gpart_asYc) = Genome.Split.split gpart_asYb
                            p_asWb = code-0.1.0.0:Genome.FixedList.Functions.double g_asWa
                            (g_asWa, gpart_asYb) = Genome.Split.split gpart_asYa
                            p_asW9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW8
                            (g_asW8, gpart_asYa) = Genome.Split.split gpart_asY9
                            p_asW7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW6
                            (g_asW6, gpart_asY9) = Genome.Split.split gpart_asY8
                            p_asW5 = Functions.belowten' g_asW4
                            (g_asW4, gpart_asY8) = Genome.Split.split gpart_asY7
                            p_asW3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW2
                            (g_asW2, gpart_asY7) = Genome.Split.split gpart_asY6
                            p_asW1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW0
                            (g_asW0, gpart_asY6) = Genome.Split.split gpart_asY5
                            p_asVZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVY
                            (g_asVY, gpart_asY5) = Genome.Split.split gpart_asY4
                            p_asVX = code-0.1.0.0:Genome.FixedList.Functions.double g_asVW
                            (g_asVW, gpart_asY4) = Genome.Split.split gpart_asY3
                            p_asVV = Functions.belowten' g_asVU
                            (g_asVU, gpart_asY3) = Genome.Split.split gpart_asY2
                            p_asVT = code-0.1.0.0:Genome.FixedList.Functions.double g_asVS
                            (g_asVS, gpart_asY2) = Genome.Split.split gpart_asY1
                            p_asVR = Functions.belowten' g_asVQ
                            (g_asVQ, gpart_asY1) = Genome.Split.split gpart_asY0
                            p_asVP = code-0.1.0.0:Genome.FixedList.Functions.double g_asVO
                            (g_asVO, gpart_asY0) = Genome.Split.split gpart_asXZ
                            p_asVN = code-0.1.0.0:Genome.FixedList.Functions.double g_asVM
                            (g_asVM, gpart_asXZ) = Genome.Split.split gpart_asXY
                            p_asVL = Functions.belowten' g_asVK
                            (g_asVK, gpart_asXY) = Genome.Split.split gpart_asXX
                            p_asVJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVI
                            (g_asVI, gpart_asXX) = Genome.Split.split gpart_asXW
                            p_asVH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVG
                            (g_asVG, gpart_asXW) = Genome.Split.split gpart_asXV
                            p_asVF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVE
                            (g_asVE, gpart_asXV) = Genome.Split.split gpart_asXU
                            p_asVD = code-0.1.0.0:Genome.FixedList.Functions.double g_asVC
                            (g_asVC, gpart_asXU) = Genome.Split.split gpart_asXT
                            p_asVB = code-0.1.0.0:Genome.FixedList.Functions.double g_asVA
                            (g_asVA, gpart_asXT) = Genome.Split.split gpart_asXS
                            p_asVz = code-0.1.0.0:Genome.FixedList.Functions.double g_asVy
                            (g_asVy, gpart_asXS) = Genome.Split.split gpart_asXR
                            p_asVx = code-0.1.0.0:Genome.FixedList.Functions.double g_asVw
                            (g_asVw, gpart_asXR) = Genome.Split.split gpart_asXQ
                            p_asVv = code-0.1.0.0:Genome.FixedList.Functions.double g_asVu
                            (g_asVu, gpart_asXQ) = Genome.Split.split genome_asWI
                          in
                            \ desc_asWJ
                              -> case desc_asWJ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVv)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVx)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVz)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVB)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVD)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVF)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVH)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVJ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVL)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVN)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVP)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVR)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVT)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVV)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVX)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVZ)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW1)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW3)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW5)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW7)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW9)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWb)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWd)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWf)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWh)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWj)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWl)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWn)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWp)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWr)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWt)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWv)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWx)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWz)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWB)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWD)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWF)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWH)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_at0m
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0Z
                      p_at0l = code-0.1.0.0:Genome.FixedList.Functions.double g_at0k
                      (g_at0k, gpart_at0Z) = Genome.Split.split gpart_at0Y
                      p_at0j = code-0.1.0.0:Genome.FixedList.Functions.double g_at0i
                      (g_at0i, gpart_at0Y) = Genome.Split.split gpart_at0X
                      p_at0h = code-0.1.0.0:Genome.FixedList.Functions.double g_at0g
                      (g_at0g, gpart_at0X) = Genome.Split.split gpart_at0W
                      p_at0f = code-0.1.0.0:Genome.FixedList.Functions.double g_at0e
                      (g_at0e, gpart_at0W) = Genome.Split.split gpart_at0V
                      p_at0d = code-0.1.0.0:Genome.FixedList.Functions.double g_at0c
                      (g_at0c, gpart_at0V) = Genome.Split.split gpart_at0U
                      p_at0b = Functions.belowten' g_at0a
                      (g_at0a, gpart_at0U) = Genome.Split.split gpart_at0T
                      p_at09 = code-0.1.0.0:Genome.FixedList.Functions.double g_at08
                      (g_at08, gpart_at0T) = Genome.Split.split gpart_at0S
                      p_at07 = code-0.1.0.0:Genome.FixedList.Functions.double g_at06
                      (g_at06, gpart_at0S) = Genome.Split.split gpart_at0R
                      p_at05 = code-0.1.0.0:Genome.FixedList.Functions.double g_at04
                      (g_at04, gpart_at0R) = Genome.Split.split gpart_at0Q
                      p_at03 = Functions.belowten' g_at02
                      (g_at02, gpart_at0Q) = Genome.Split.split gpart_at0P
                      p_at01 = code-0.1.0.0:Genome.FixedList.Functions.double g_at00
                      (g_at00, gpart_at0P) = Genome.Split.split gpart_at0O
                      p_asZZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZY
                      (g_asZY, gpart_at0O) = Genome.Split.split gpart_at0N
                      p_asZX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZW
                      (g_asZW, gpart_at0N) = Genome.Split.split gpart_at0M
                      p_asZV = Functions.belowten' g_asZU
                      (g_asZU, gpart_at0M) = Genome.Split.split gpart_at0L
                      p_asZT = code-0.1.0.0:Genome.FixedList.Functions.double g_asZS
                      (g_asZS, gpart_at0L) = Genome.Split.split gpart_at0K
                      p_asZR = Functions.belowten' g_asZQ
                      (g_asZQ, gpart_at0K) = Genome.Split.split gpart_at0J
                      p_asZP = code-0.1.0.0:Genome.FixedList.Functions.double g_asZO
                      (g_asZO, gpart_at0J) = Genome.Split.split gpart_at0I
                      p_asZN = code-0.1.0.0:Genome.FixedList.Functions.double g_asZM
                      (g_asZM, gpart_at0I) = Genome.Split.split gpart_at0H
                      p_asZL = code-0.1.0.0:Genome.FixedList.Functions.double g_asZK
                      (g_asZK, gpart_at0H) = Genome.Split.split gpart_at0G
                      p_asZJ = Functions.belowten' g_asZI
                      (g_asZI, gpart_at0G) = Genome.Split.split gpart_at0F
                      p_asZH = code-0.1.0.0:Genome.FixedList.Functions.double g_asZG
                      (g_asZG, gpart_at0F) = Genome.Split.split gpart_at0E
                      p_asZF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZE
                      (g_asZE, gpart_at0E) = Genome.Split.split gpart_at0D
                      p_asZD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZC
                      (g_asZC, gpart_at0D) = Genome.Split.split gpart_at0C
                      p_asZB = code-0.1.0.0:Genome.FixedList.Functions.double g_asZA
                      (g_asZA, gpart_at0C) = Genome.Split.split gpart_at0B
                      p_asZz = Functions.belowten' g_asZy
                      (g_asZy, gpart_at0B) = Genome.Split.split gpart_at0A
                      p_asZx = code-0.1.0.0:Genome.FixedList.Functions.double g_asZw
                      (g_asZw, gpart_at0A) = Genome.Split.split gpart_at0z
                      p_asZv = Functions.belowten' g_asZu
                      (g_asZu, gpart_at0z) = Genome.Split.split gpart_at0y
                      p_asZt = code-0.1.0.0:Genome.FixedList.Functions.double g_asZs
                      (g_asZs, gpart_at0y) = Genome.Split.split gpart_at0x
                      p_asZr = code-0.1.0.0:Genome.FixedList.Functions.double g_asZq
                      (g_asZq, gpart_at0x) = Genome.Split.split gpart_at0w
                      p_asZp = Functions.belowten' g_asZo
                      (g_asZo, gpart_at0w) = Genome.Split.split gpart_at0v
                      p_asZn = code-0.1.0.0:Genome.FixedList.Functions.double g_asZm
                      (g_asZm, gpart_at0v) = Genome.Split.split gpart_at0u
                      p_asZl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZk
                      (g_asZk, gpart_at0u) = Genome.Split.split gpart_at0t
                      p_asZj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZi
                      (g_asZi, gpart_at0t) = Genome.Split.split gpart_at0s
                      p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                      (g_asZg, gpart_at0s) = Genome.Split.split gpart_at0r
                      p_asZf = code-0.1.0.0:Genome.FixedList.Functions.double g_asZe
                      (g_asZe, gpart_at0r) = Genome.Split.split gpart_at0q
                      p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                      (g_asZc, gpart_at0q) = Genome.Split.split gpart_at0p
                      p_asZb = code-0.1.0.0:Genome.FixedList.Functions.double g_asZa
                      (g_asZa, gpart_at0p) = Genome.Split.split gpart_at0o
                      p_asZ9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ8
                      (g_asZ8, gpart_at0o) = Genome.Split.split genome_at0m
                    in
                      [Reaction
                         (\ x_at10
                            -> let c_MiRs_at11 = ((toVector x_at10) Data.Vector.Unboxed.! 2)
                               in (p_asZh / (1 + ((c_MiRs_at11 / p_asZn) ** p_asZp))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at12
                            -> let
                                 c_MiRs_at13 = ((toVector x_at12) Data.Vector.Unboxed.! 2)
                                 c_PTB_at14 = ((toVector x_at12) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZr
                                  / (1
                                     + (((c_MiRs_at13 / p_asZt) ** p_asZv)
                                        + ((c_PTB_at14 / p_asZx) ** p_asZz)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at15
                            -> let c_RESTc_at16 = ((toVector x_at15) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asZB
                                  * (p_asZL
                                     / ((1 + p_asZL) + ((c_RESTc_at16 / p_asZH) ** p_asZJ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at17
                            -> let
                                 c_MiRs_at1c = ((toVector x_at17) Data.Vector.Unboxed.! 2)
                                 c_PTB_at19 = ((toVector x_at17) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at18 = ((toVector x_at17) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asZN
                                  * ((p_at05
                                      + (((c_NPTB_at18 / p_asZP) ** p_asZR)
                                         + ((c_PTB_at19 / p_asZT) ** p_asZV)))
                                     / (((1 + p_at05)
                                         + (((c_NPTB_at18 / p_asZP) ** p_asZR)
                                            + ((c_PTB_at19 / p_asZT) ** p_asZV)))
                                        + (((p_asZ9 / p_asZX) ** p_asZZ)
                                           + ((c_MiRs_at1c / p_at01) ** p_at03))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at1d
                            -> let c_RESTc_at1e = ((toVector x_at1d) Data.Vector.Unboxed.! 3)
                               in (p_at07 / (1 + ((c_RESTc_at1e / p_at09) ** p_at0b))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at1f
                            -> let c_PTB_at1g = ((toVector x_at1f) Data.Vector.Unboxed.! 0)
                               in (p_at0d * c_PTB_at1g))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1h
                            -> let c_NPTB_at1i = ((toVector x_at1h) Data.Vector.Unboxed.! 1)
                               in (p_at0f * c_NPTB_at1i))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at1j
                            -> let c_MiRs_at1k = ((toVector x_at1j) Data.Vector.Unboxed.! 2)
                               in (p_at0h * c_MiRs_at1k))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at1l
                            -> let c_RESTc_at1m = ((toVector x_at1l) Data.Vector.Unboxed.! 3)
                               in (p_at0j * c_RESTc_at1m))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at1n
                            -> let
                                 c_EndoNeuroTFs_at1o = ((toVector x_at1n) Data.Vector.Unboxed.! 4)
                               in (p_at0l * c_EndoNeuroTFs_at1o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121225",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121227",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121245",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121247",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121265",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121267",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121271",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121273",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121275",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at0m
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at20
                            p_at0l = code-0.1.0.0:Genome.FixedList.Functions.double g_at0k
                            (g_at0k, gpart_at20) = Genome.Split.split gpart_at1Z
                            p_at0j = code-0.1.0.0:Genome.FixedList.Functions.double g_at0i
                            (g_at0i, gpart_at1Z) = Genome.Split.split gpart_at1Y
                            p_at0h = code-0.1.0.0:Genome.FixedList.Functions.double g_at0g
                            (g_at0g, gpart_at1Y) = Genome.Split.split gpart_at1X
                            p_at0f = code-0.1.0.0:Genome.FixedList.Functions.double g_at0e
                            (g_at0e, gpart_at1X) = Genome.Split.split gpart_at1W
                            p_at0d = code-0.1.0.0:Genome.FixedList.Functions.double g_at0c
                            (g_at0c, gpart_at1W) = Genome.Split.split gpart_at1V
                            p_at0b = Functions.belowten' g_at0a
                            (g_at0a, gpart_at1V) = Genome.Split.split gpart_at1U
                            p_at09 = code-0.1.0.0:Genome.FixedList.Functions.double g_at08
                            (g_at08, gpart_at1U) = Genome.Split.split gpart_at1T
                            p_at07 = code-0.1.0.0:Genome.FixedList.Functions.double g_at06
                            (g_at06, gpart_at1T) = Genome.Split.split gpart_at1S
                            p_at05 = code-0.1.0.0:Genome.FixedList.Functions.double g_at04
                            (g_at04, gpart_at1S) = Genome.Split.split gpart_at1R
                            p_at03 = Functions.belowten' g_at02
                            (g_at02, gpart_at1R) = Genome.Split.split gpart_at1Q
                            p_at01 = code-0.1.0.0:Genome.FixedList.Functions.double g_at00
                            (g_at00, gpart_at1Q) = Genome.Split.split gpart_at1P
                            p_asZZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZY
                            (g_asZY, gpart_at1P) = Genome.Split.split gpart_at1O
                            p_asZX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZW
                            (g_asZW, gpart_at1O) = Genome.Split.split gpart_at1N
                            p_asZV = Functions.belowten' g_asZU
                            (g_asZU, gpart_at1N) = Genome.Split.split gpart_at1M
                            p_asZT = code-0.1.0.0:Genome.FixedList.Functions.double g_asZS
                            (g_asZS, gpart_at1M) = Genome.Split.split gpart_at1L
                            p_asZR = Functions.belowten' g_asZQ
                            (g_asZQ, gpart_at1L) = Genome.Split.split gpart_at1K
                            p_asZP = code-0.1.0.0:Genome.FixedList.Functions.double g_asZO
                            (g_asZO, gpart_at1K) = Genome.Split.split gpart_at1J
                            p_asZN = code-0.1.0.0:Genome.FixedList.Functions.double g_asZM
                            (g_asZM, gpart_at1J) = Genome.Split.split gpart_at1I
                            p_asZL = code-0.1.0.0:Genome.FixedList.Functions.double g_asZK
                            (g_asZK, gpart_at1I) = Genome.Split.split gpart_at1H
                            p_asZJ = Functions.belowten' g_asZI
                            (g_asZI, gpart_at1H) = Genome.Split.split gpart_at1G
                            p_asZH = code-0.1.0.0:Genome.FixedList.Functions.double g_asZG
                            (g_asZG, gpart_at1G) = Genome.Split.split gpart_at1F
                            p_asZF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZE
                            (g_asZE, gpart_at1F) = Genome.Split.split gpart_at1E
                            p_asZD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZC
                            (g_asZC, gpart_at1E) = Genome.Split.split gpart_at1D
                            p_asZB = code-0.1.0.0:Genome.FixedList.Functions.double g_asZA
                            (g_asZA, gpart_at1D) = Genome.Split.split gpart_at1C
                            p_asZz = Functions.belowten' g_asZy
                            (g_asZy, gpart_at1C) = Genome.Split.split gpart_at1B
                            p_asZx = code-0.1.0.0:Genome.FixedList.Functions.double g_asZw
                            (g_asZw, gpart_at1B) = Genome.Split.split gpart_at1A
                            p_asZv = Functions.belowten' g_asZu
                            (g_asZu, gpart_at1A) = Genome.Split.split gpart_at1z
                            p_asZt = code-0.1.0.0:Genome.FixedList.Functions.double g_asZs
                            (g_asZs, gpart_at1z) = Genome.Split.split gpart_at1y
                            p_asZr = code-0.1.0.0:Genome.FixedList.Functions.double g_asZq
                            (g_asZq, gpart_at1y) = Genome.Split.split gpart_at1x
                            p_asZp = Functions.belowten' g_asZo
                            (g_asZo, gpart_at1x) = Genome.Split.split gpart_at1w
                            p_asZn = code-0.1.0.0:Genome.FixedList.Functions.double g_asZm
                            (g_asZm, gpart_at1w) = Genome.Split.split gpart_at1v
                            p_asZl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZk
                            (g_asZk, gpart_at1v) = Genome.Split.split gpart_at1u
                            p_asZj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZi
                            (g_asZi, gpart_at1u) = Genome.Split.split gpart_at1t
                            p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                            (g_asZg, gpart_at1t) = Genome.Split.split gpart_at1s
                            p_asZf = code-0.1.0.0:Genome.FixedList.Functions.double g_asZe
                            (g_asZe, gpart_at1s) = Genome.Split.split gpart_at1r
                            p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                            (g_asZc, gpart_at1r) = Genome.Split.split gpart_at1q
                            p_asZb = code-0.1.0.0:Genome.FixedList.Functions.double g_asZa
                            (g_asZa, gpart_at1q) = Genome.Split.split gpart_at1p
                            p_asZ9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ8
                            (g_asZ8, gpart_at1p) = Genome.Split.split genome_at0m
                          in
                            \ desc_at0n
                              -> case desc_at0n of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ9)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZb)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZd)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZf)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZh)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZj)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZl)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZn)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZp)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZr)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZt)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZv)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZx)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZB)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZD)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZF)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZH)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZJ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZL)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZN)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZP)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZR)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZT)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZV)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZX)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at01)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at03)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at05)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at07)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at09)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0b)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0d)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0f)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0h)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0j)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0l)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at3V
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4y
                      p_at3U = code-0.1.0.0:Genome.FixedList.Functions.double g_at3T
                      (g_at3T, gpart_at4y) = Genome.Split.split gpart_at4x
                      p_at3S = code-0.1.0.0:Genome.FixedList.Functions.double g_at3R
                      (g_at3R, gpart_at4x) = Genome.Split.split gpart_at4w
                      p_at3Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3P
                      (g_at3P, gpart_at4w) = Genome.Split.split gpart_at4v
                      p_at3O = code-0.1.0.0:Genome.FixedList.Functions.double g_at3N
                      (g_at3N, gpart_at4v) = Genome.Split.split gpart_at4u
                      p_at3M = code-0.1.0.0:Genome.FixedList.Functions.double g_at3L
                      (g_at3L, gpart_at4u) = Genome.Split.split gpart_at4t
                      p_at3K = Functions.belowten' g_at3J
                      (g_at3J, gpart_at4t) = Genome.Split.split gpart_at4s
                      p_at3I = code-0.1.0.0:Genome.FixedList.Functions.double g_at3H
                      (g_at3H, gpart_at4s) = Genome.Split.split gpart_at4r
                      p_at3G = code-0.1.0.0:Genome.FixedList.Functions.double g_at3F
                      (g_at3F, gpart_at4r) = Genome.Split.split gpart_at4q
                      p_at3E = code-0.1.0.0:Genome.FixedList.Functions.double g_at3D
                      (g_at3D, gpart_at4q) = Genome.Split.split gpart_at4p
                      p_at3C = Functions.belowten' g_at3B
                      (g_at3B, gpart_at4p) = Genome.Split.split gpart_at4o
                      p_at3A = code-0.1.0.0:Genome.FixedList.Functions.double g_at3z
                      (g_at3z, gpart_at4o) = Genome.Split.split gpart_at4n
                      p_at3y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3x
                      (g_at3x, gpart_at4n) = Genome.Split.split gpart_at4m
                      p_at3w
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3v
                      (g_at3v, gpart_at4m) = Genome.Split.split gpart_at4l
                      p_at3u = Functions.belowten' g_at3t
                      (g_at3t, gpart_at4l) = Genome.Split.split gpart_at4k
                      p_at3s = code-0.1.0.0:Genome.FixedList.Functions.double g_at3r
                      (g_at3r, gpart_at4k) = Genome.Split.split gpart_at4j
                      p_at3q = Functions.belowten' g_at3p
                      (g_at3p, gpart_at4j) = Genome.Split.split gpart_at4i
                      p_at3o = code-0.1.0.0:Genome.FixedList.Functions.double g_at3n
                      (g_at3n, gpart_at4i) = Genome.Split.split gpart_at4h
                      p_at3m = code-0.1.0.0:Genome.FixedList.Functions.double g_at3l
                      (g_at3l, gpart_at4h) = Genome.Split.split gpart_at4g
                      p_at3k = code-0.1.0.0:Genome.FixedList.Functions.double g_at3j
                      (g_at3j, gpart_at4g) = Genome.Split.split gpart_at4f
                      p_at3i = Functions.belowten' g_at3h
                      (g_at3h, gpart_at4f) = Genome.Split.split gpart_at4e
                      p_at3g = code-0.1.0.0:Genome.FixedList.Functions.double g_at3f
                      (g_at3f, gpart_at4e) = Genome.Split.split gpart_at4d
                      p_at3e
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3d
                      (g_at3d, gpart_at4d) = Genome.Split.split gpart_at4c
                      p_at3c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3b
                      (g_at3b, gpart_at4c) = Genome.Split.split gpart_at4b
                      p_at3a = code-0.1.0.0:Genome.FixedList.Functions.double g_at39
                      (g_at39, gpart_at4b) = Genome.Split.split gpart_at4a
                      p_at38 = Functions.belowten' g_at37
                      (g_at37, gpart_at4a) = Genome.Split.split gpart_at49
                      p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                      (g_at35, gpart_at49) = Genome.Split.split gpart_at48
                      p_at34 = Functions.belowten' g_at33
                      (g_at33, gpart_at48) = Genome.Split.split gpart_at47
                      p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                      (g_at31, gpart_at47) = Genome.Split.split gpart_at46
                      p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                      (g_at2Z, gpart_at46) = Genome.Split.split gpart_at45
                      p_at2Y = Functions.belowten' g_at2X
                      (g_at2X, gpart_at45) = Genome.Split.split gpart_at44
                      p_at2W = code-0.1.0.0:Genome.FixedList.Functions.double g_at2V
                      (g_at2V, gpart_at44) = Genome.Split.split gpart_at43
                      p_at2U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2T
                      (g_at2T, gpart_at43) = Genome.Split.split gpart_at42
                      p_at2S
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2R
                      (g_at2R, gpart_at42) = Genome.Split.split gpart_at41
                      p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                      (g_at2P, gpart_at41) = Genome.Split.split gpart_at40
                      p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                      (g_at2N, gpart_at40) = Genome.Split.split gpart_at3Z
                      p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                      (g_at2L, gpart_at3Z) = Genome.Split.split gpart_at3Y
                      p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                      (g_at2J, gpart_at3Y) = Genome.Split.split gpart_at3X
                      p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                      (g_at2H, gpart_at3X) = Genome.Split.split genome_at3V
                    in
                      [Reaction
                         (\ x_at4z
                            -> let c_MiRs_at4A = ((toVector x_at4z) Data.Vector.Unboxed.! 2)
                               in (p_at2Q / (1 + ((c_MiRs_at4A / p_at2W) ** p_at2Y))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4B
                            -> let
                                 c_MiRs_at4C = ((toVector x_at4B) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4D = ((toVector x_at4B) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at30
                                  / (1
                                     + (((c_MiRs_at4C / p_at32) ** p_at34)
                                        + ((c_PTB_at4D / p_at36) ** p_at38)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at4E
                            -> let c_RESTc_at4F = ((toVector x_at4E) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at3a
                                  * (p_at3k
                                     / ((1 + p_at3k) + ((c_RESTc_at4F / p_at3g) ** p_at3i)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at4G
                            -> let
                                 c_MiRs_at4L = ((toVector x_at4G) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4I = ((toVector x_at4G) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at4H = ((toVector x_at4G) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at3m
                                  * ((p_at3E
                                      + (((c_NPTB_at4H / p_at3o) ** p_at3q)
                                         + ((c_PTB_at4I / p_at3s) ** p_at3u)))
                                     / (((1 + p_at3E)
                                         + (((c_NPTB_at4H / p_at3o) ** p_at3q)
                                            + ((c_PTB_at4I / p_at3s) ** p_at3u)))
                                        + ((c_MiRs_at4L / p_at3A) ** p_at3C)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at4M
                            -> let c_RESTc_at4N = ((toVector x_at4M) Data.Vector.Unboxed.! 3)
                               in (p_at3G / (1 + ((c_RESTc_at4N / p_at3I) ** p_at3K))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at4O
                            -> let c_PTB_at4P = ((toVector x_at4O) Data.Vector.Unboxed.! 0)
                               in (p_at3M * c_PTB_at4P))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4Q
                            -> let c_NPTB_at4R = ((toVector x_at4Q) Data.Vector.Unboxed.! 1)
                               in (p_at3O * c_NPTB_at4R))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at4S
                            -> let c_MiRs_at4T = ((toVector x_at4S) Data.Vector.Unboxed.! 2)
                               in (p_at3Q * c_MiRs_at4T))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at4U
                            -> let c_RESTc_at4V = ((toVector x_at4U) Data.Vector.Unboxed.! 3)
                               in (p_at3S * c_RESTc_at4V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4W
                            -> let
                                 c_EndoNeuroTFs_at4X = ((toVector x_at4W) Data.Vector.Unboxed.! 4)
                               in (p_at3U * c_EndoNeuroTFs_at4X))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121446",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121448",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121466",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121468",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121486",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121488",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121490",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121492",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121510",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at3V
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5z
                            p_at3U = code-0.1.0.0:Genome.FixedList.Functions.double g_at3T
                            (g_at3T, gpart_at5z) = Genome.Split.split gpart_at5y
                            p_at3S = code-0.1.0.0:Genome.FixedList.Functions.double g_at3R
                            (g_at3R, gpart_at5y) = Genome.Split.split gpart_at5x
                            p_at3Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3P
                            (g_at3P, gpart_at5x) = Genome.Split.split gpart_at5w
                            p_at3O = code-0.1.0.0:Genome.FixedList.Functions.double g_at3N
                            (g_at3N, gpart_at5w) = Genome.Split.split gpart_at5v
                            p_at3M = code-0.1.0.0:Genome.FixedList.Functions.double g_at3L
                            (g_at3L, gpart_at5v) = Genome.Split.split gpart_at5u
                            p_at3K = Functions.belowten' g_at3J
                            (g_at3J, gpart_at5u) = Genome.Split.split gpart_at5t
                            p_at3I = code-0.1.0.0:Genome.FixedList.Functions.double g_at3H
                            (g_at3H, gpart_at5t) = Genome.Split.split gpart_at5s
                            p_at3G = code-0.1.0.0:Genome.FixedList.Functions.double g_at3F
                            (g_at3F, gpart_at5s) = Genome.Split.split gpart_at5r
                            p_at3E = code-0.1.0.0:Genome.FixedList.Functions.double g_at3D
                            (g_at3D, gpart_at5r) = Genome.Split.split gpart_at5q
                            p_at3C = Functions.belowten' g_at3B
                            (g_at3B, gpart_at5q) = Genome.Split.split gpart_at5p
                            p_at3A = code-0.1.0.0:Genome.FixedList.Functions.double g_at3z
                            (g_at3z, gpart_at5p) = Genome.Split.split gpart_at5o
                            p_at3y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3x
                            (g_at3x, gpart_at5o) = Genome.Split.split gpart_at5n
                            p_at3w
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3v
                            (g_at3v, gpart_at5n) = Genome.Split.split gpart_at5m
                            p_at3u = Functions.belowten' g_at3t
                            (g_at3t, gpart_at5m) = Genome.Split.split gpart_at5l
                            p_at3s = code-0.1.0.0:Genome.FixedList.Functions.double g_at3r
                            (g_at3r, gpart_at5l) = Genome.Split.split gpart_at5k
                            p_at3q = Functions.belowten' g_at3p
                            (g_at3p, gpart_at5k) = Genome.Split.split gpart_at5j
                            p_at3o = code-0.1.0.0:Genome.FixedList.Functions.double g_at3n
                            (g_at3n, gpart_at5j) = Genome.Split.split gpart_at5i
                            p_at3m = code-0.1.0.0:Genome.FixedList.Functions.double g_at3l
                            (g_at3l, gpart_at5i) = Genome.Split.split gpart_at5h
                            p_at3k = code-0.1.0.0:Genome.FixedList.Functions.double g_at3j
                            (g_at3j, gpart_at5h) = Genome.Split.split gpart_at5g
                            p_at3i = Functions.belowten' g_at3h
                            (g_at3h, gpart_at5g) = Genome.Split.split gpart_at5f
                            p_at3g = code-0.1.0.0:Genome.FixedList.Functions.double g_at3f
                            (g_at3f, gpart_at5f) = Genome.Split.split gpart_at5e
                            p_at3e
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3d
                            (g_at3d, gpart_at5e) = Genome.Split.split gpart_at5d
                            p_at3c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3b
                            (g_at3b, gpart_at5d) = Genome.Split.split gpart_at5c
                            p_at3a = code-0.1.0.0:Genome.FixedList.Functions.double g_at39
                            (g_at39, gpart_at5c) = Genome.Split.split gpart_at5b
                            p_at38 = Functions.belowten' g_at37
                            (g_at37, gpart_at5b) = Genome.Split.split gpart_at5a
                            p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                            (g_at35, gpart_at5a) = Genome.Split.split gpart_at59
                            p_at34 = Functions.belowten' g_at33
                            (g_at33, gpart_at59) = Genome.Split.split gpart_at58
                            p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                            (g_at31, gpart_at58) = Genome.Split.split gpart_at57
                            p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                            (g_at2Z, gpart_at57) = Genome.Split.split gpart_at56
                            p_at2Y = Functions.belowten' g_at2X
                            (g_at2X, gpart_at56) = Genome.Split.split gpart_at55
                            p_at2W = code-0.1.0.0:Genome.FixedList.Functions.double g_at2V
                            (g_at2V, gpart_at55) = Genome.Split.split gpart_at54
                            p_at2U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2T
                            (g_at2T, gpart_at54) = Genome.Split.split gpart_at53
                            p_at2S
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2R
                            (g_at2R, gpart_at53) = Genome.Split.split gpart_at52
                            p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                            (g_at2P, gpart_at52) = Genome.Split.split gpart_at51
                            p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                            (g_at2N, gpart_at51) = Genome.Split.split gpart_at50
                            p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                            (g_at2L, gpart_at50) = Genome.Split.split gpart_at4Z
                            p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                            (g_at2J, gpart_at4Z) = Genome.Split.split gpart_at4Y
                            p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                            (g_at2H, gpart_at4Y) = Genome.Split.split genome_at3V
                          in
                            \ desc_at3W
                              -> case desc_at3W of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2M)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2O)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Q)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2S)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2U)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2W)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Y)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at30)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at32)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at34)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at36)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at38)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3a)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3c)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3e)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3g)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3i)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3k)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3m)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3o)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3q)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3s)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3u)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3w)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3y)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3A)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3C)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3E)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3G)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3I)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3K)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3M)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3O)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Q)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3S)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3U)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at7u
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at87
                      p_at7t = code-0.1.0.0:Genome.FixedList.Functions.double g_at7s
                      (g_at7s, gpart_at87) = Genome.Split.split gpart_at86
                      p_at7r = code-0.1.0.0:Genome.FixedList.Functions.double g_at7q
                      (g_at7q, gpart_at86) = Genome.Split.split gpart_at85
                      p_at7p = code-0.1.0.0:Genome.FixedList.Functions.double g_at7o
                      (g_at7o, gpart_at85) = Genome.Split.split gpart_at84
                      p_at7n = code-0.1.0.0:Genome.FixedList.Functions.double g_at7m
                      (g_at7m, gpart_at84) = Genome.Split.split gpart_at83
                      p_at7l = code-0.1.0.0:Genome.FixedList.Functions.double g_at7k
                      (g_at7k, gpart_at83) = Genome.Split.split gpart_at82
                      p_at7j = Functions.belowten' g_at7i
                      (g_at7i, gpart_at82) = Genome.Split.split gpart_at81
                      p_at7h = code-0.1.0.0:Genome.FixedList.Functions.double g_at7g
                      (g_at7g, gpart_at81) = Genome.Split.split gpart_at80
                      p_at7f = code-0.1.0.0:Genome.FixedList.Functions.double g_at7e
                      (g_at7e, gpart_at80) = Genome.Split.split gpart_at7Z
                      p_at7d = code-0.1.0.0:Genome.FixedList.Functions.double g_at7c
                      (g_at7c, gpart_at7Z) = Genome.Split.split gpart_at7Y
                      p_at7b = Functions.belowten' g_at7a
                      (g_at7a, gpart_at7Y) = Genome.Split.split gpart_at7X
                      p_at79 = code-0.1.0.0:Genome.FixedList.Functions.double g_at78
                      (g_at78, gpart_at7X) = Genome.Split.split gpart_at7W
                      p_at77
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at76
                      (g_at76, gpart_at7W) = Genome.Split.split gpart_at7V
                      p_at75
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at74
                      (g_at74, gpart_at7V) = Genome.Split.split gpart_at7U
                      p_at73 = Functions.belowten' g_at72
                      (g_at72, gpart_at7U) = Genome.Split.split gpart_at7T
                      p_at71 = code-0.1.0.0:Genome.FixedList.Functions.double g_at70
                      (g_at70, gpart_at7T) = Genome.Split.split gpart_at7S
                      p_at6Z = Functions.belowten' g_at6Y
                      (g_at6Y, gpart_at7S) = Genome.Split.split gpart_at7R
                      p_at6X = code-0.1.0.0:Genome.FixedList.Functions.double g_at6W
                      (g_at6W, gpart_at7R) = Genome.Split.split gpart_at7Q
                      p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                      (g_at6U, gpart_at7Q) = Genome.Split.split gpart_at7P
                      p_at6T = code-0.1.0.0:Genome.FixedList.Functions.double g_at6S
                      (g_at6S, gpart_at7P) = Genome.Split.split gpart_at7O
                      p_at6R = Functions.belowten' g_at6Q
                      (g_at6Q, gpart_at7O) = Genome.Split.split gpart_at7N
                      p_at6P = code-0.1.0.0:Genome.FixedList.Functions.double g_at6O
                      (g_at6O, gpart_at7N) = Genome.Split.split gpart_at7M
                      p_at6N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6M
                      (g_at6M, gpart_at7M) = Genome.Split.split gpart_at7L
                      p_at6L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6K
                      (g_at6K, gpart_at7L) = Genome.Split.split gpart_at7K
                      p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                      (g_at6I, gpart_at7K) = Genome.Split.split gpart_at7J
                      p_at6H = Functions.belowten' g_at6G
                      (g_at6G, gpart_at7J) = Genome.Split.split gpart_at7I
                      p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                      (g_at6E, gpart_at7I) = Genome.Split.split gpart_at7H
                      p_at6D = Functions.belowten' g_at6C
                      (g_at6C, gpart_at7H) = Genome.Split.split gpart_at7G
                      p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                      (g_at6A, gpart_at7G) = Genome.Split.split gpart_at7F
                      p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                      (g_at6y, gpart_at7F) = Genome.Split.split gpart_at7E
                      p_at6x = Functions.belowten' g_at6w
                      (g_at6w, gpart_at7E) = Genome.Split.split gpart_at7D
                      p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                      (g_at6u, gpart_at7D) = Genome.Split.split gpart_at7C
                      p_at6t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6s
                      (g_at6s, gpart_at7C) = Genome.Split.split gpart_at7B
                      p_at6r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6q
                      (g_at6q, gpart_at7B) = Genome.Split.split gpart_at7A
                      p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                      (g_at6o, gpart_at7A) = Genome.Split.split gpart_at7z
                      p_at6n = code-0.1.0.0:Genome.FixedList.Functions.double g_at6m
                      (g_at6m, gpart_at7z) = Genome.Split.split gpart_at7y
                      p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                      (g_at6k, gpart_at7y) = Genome.Split.split gpart_at7x
                      p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                      (g_at6i, gpart_at7x) = Genome.Split.split gpart_at7w
                      p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                      (g_at6g, gpart_at7w) = Genome.Split.split genome_at7u
                    in
                      [Reaction
                         (\ x_at88
                            -> let c_MiRs_at89 = ((toVector x_at88) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6p
                                  / (1
                                     + (((p_at6h / p_at6r) ** p_at6t)
                                        + ((c_MiRs_at89 / p_at6v) ** p_at6x)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at8a
                            -> let
                                 c_MiRs_at8b = ((toVector x_at8a) Data.Vector.Unboxed.! 2)
                                 c_PTB_at8c = ((toVector x_at8a) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6z
                                  / (1
                                     + (((c_MiRs_at8b / p_at6B) ** p_at6D)
                                        + ((c_PTB_at8c / p_at6F) ** p_at6H)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at8d
                            -> let c_RESTc_at8e = ((toVector x_at8d) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at6J
                                  * (p_at6T
                                     / ((1 + p_at6T) + ((c_RESTc_at8e / p_at6P) ** p_at6R)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at8f
                            -> let
                                 c_MiRs_at8k = ((toVector x_at8f) Data.Vector.Unboxed.! 2)
                                 c_PTB_at8h = ((toVector x_at8f) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at8g = ((toVector x_at8f) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at6V
                                  * ((p_at7d
                                      + (((c_NPTB_at8g / p_at6X) ** p_at6Z)
                                         + ((c_PTB_at8h / p_at71) ** p_at73)))
                                     / (((1 + p_at7d)
                                         + (((c_NPTB_at8g / p_at6X) ** p_at6Z)
                                            + ((c_PTB_at8h / p_at71) ** p_at73)))
                                        + ((c_MiRs_at8k / p_at79) ** p_at7b)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at8l
                            -> let c_RESTc_at8m = ((toVector x_at8l) Data.Vector.Unboxed.! 3)
                               in (p_at7f / (1 + ((c_RESTc_at8m / p_at7h) ** p_at7j))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at8n
                            -> let c_PTB_at8o = ((toVector x_at8n) Data.Vector.Unboxed.! 0)
                               in (p_at7l * c_PTB_at8o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at8p
                            -> let c_NPTB_at8q = ((toVector x_at8p) Data.Vector.Unboxed.! 1)
                               in (p_at7n * c_NPTB_at8q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at8r
                            -> let c_MiRs_at8s = ((toVector x_at8r) Data.Vector.Unboxed.! 2)
                               in (p_at7p * c_MiRs_at8s))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at8t
                            -> let c_RESTc_at8u = ((toVector x_at8t) Data.Vector.Unboxed.! 3)
                               in (p_at7r * c_RESTc_at8u))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at8v
                            -> let
                                 c_EndoNeuroTFs_at8w = ((toVector x_at8v) Data.Vector.Unboxed.! 4)
                               in (p_at7t * c_EndoNeuroTFs_at8w))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121667",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121669",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121687",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121689",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121707",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121709",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121711",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121713",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121717",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121719",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at7u
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at98
                            p_at7t = code-0.1.0.0:Genome.FixedList.Functions.double g_at7s
                            (g_at7s, gpart_at98) = Genome.Split.split gpart_at97
                            p_at7r = code-0.1.0.0:Genome.FixedList.Functions.double g_at7q
                            (g_at7q, gpart_at97) = Genome.Split.split gpart_at96
                            p_at7p = code-0.1.0.0:Genome.FixedList.Functions.double g_at7o
                            (g_at7o, gpart_at96) = Genome.Split.split gpart_at95
                            p_at7n = code-0.1.0.0:Genome.FixedList.Functions.double g_at7m
                            (g_at7m, gpart_at95) = Genome.Split.split gpart_at94
                            p_at7l = code-0.1.0.0:Genome.FixedList.Functions.double g_at7k
                            (g_at7k, gpart_at94) = Genome.Split.split gpart_at93
                            p_at7j = Functions.belowten' g_at7i
                            (g_at7i, gpart_at93) = Genome.Split.split gpart_at92
                            p_at7h = code-0.1.0.0:Genome.FixedList.Functions.double g_at7g
                            (g_at7g, gpart_at92) = Genome.Split.split gpart_at91
                            p_at7f = code-0.1.0.0:Genome.FixedList.Functions.double g_at7e
                            (g_at7e, gpart_at91) = Genome.Split.split gpart_at90
                            p_at7d = code-0.1.0.0:Genome.FixedList.Functions.double g_at7c
                            (g_at7c, gpart_at90) = Genome.Split.split gpart_at8Z
                            p_at7b = Functions.belowten' g_at7a
                            (g_at7a, gpart_at8Z) = Genome.Split.split gpart_at8Y
                            p_at79 = code-0.1.0.0:Genome.FixedList.Functions.double g_at78
                            (g_at78, gpart_at8Y) = Genome.Split.split gpart_at8X
                            p_at77
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at76
                            (g_at76, gpart_at8X) = Genome.Split.split gpart_at8W
                            p_at75
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at74
                            (g_at74, gpart_at8W) = Genome.Split.split gpart_at8V
                            p_at73 = Functions.belowten' g_at72
                            (g_at72, gpart_at8V) = Genome.Split.split gpart_at8U
                            p_at71 = code-0.1.0.0:Genome.FixedList.Functions.double g_at70
                            (g_at70, gpart_at8U) = Genome.Split.split gpart_at8T
                            p_at6Z = Functions.belowten' g_at6Y
                            (g_at6Y, gpart_at8T) = Genome.Split.split gpart_at8S
                            p_at6X = code-0.1.0.0:Genome.FixedList.Functions.double g_at6W
                            (g_at6W, gpart_at8S) = Genome.Split.split gpart_at8R
                            p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                            (g_at6U, gpart_at8R) = Genome.Split.split gpart_at8Q
                            p_at6T = code-0.1.0.0:Genome.FixedList.Functions.double g_at6S
                            (g_at6S, gpart_at8Q) = Genome.Split.split gpart_at8P
                            p_at6R = Functions.belowten' g_at6Q
                            (g_at6Q, gpart_at8P) = Genome.Split.split gpart_at8O
                            p_at6P = code-0.1.0.0:Genome.FixedList.Functions.double g_at6O
                            (g_at6O, gpart_at8O) = Genome.Split.split gpart_at8N
                            p_at6N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6M
                            (g_at6M, gpart_at8N) = Genome.Split.split gpart_at8M
                            p_at6L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6K
                            (g_at6K, gpart_at8M) = Genome.Split.split gpart_at8L
                            p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                            (g_at6I, gpart_at8L) = Genome.Split.split gpart_at8K
                            p_at6H = Functions.belowten' g_at6G
                            (g_at6G, gpart_at8K) = Genome.Split.split gpart_at8J
                            p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                            (g_at6E, gpart_at8J) = Genome.Split.split gpart_at8I
                            p_at6D = Functions.belowten' g_at6C
                            (g_at6C, gpart_at8I) = Genome.Split.split gpart_at8H
                            p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                            (g_at6A, gpart_at8H) = Genome.Split.split gpart_at8G
                            p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                            (g_at6y, gpart_at8G) = Genome.Split.split gpart_at8F
                            p_at6x = Functions.belowten' g_at6w
                            (g_at6w, gpart_at8F) = Genome.Split.split gpart_at8E
                            p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                            (g_at6u, gpart_at8E) = Genome.Split.split gpart_at8D
                            p_at6t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6s
                            (g_at6s, gpart_at8D) = Genome.Split.split gpart_at8C
                            p_at6r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6q
                            (g_at6q, gpart_at8C) = Genome.Split.split gpart_at8B
                            p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                            (g_at6o, gpart_at8B) = Genome.Split.split gpart_at8A
                            p_at6n = code-0.1.0.0:Genome.FixedList.Functions.double g_at6m
                            (g_at6m, gpart_at8A) = Genome.Split.split gpart_at8z
                            p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                            (g_at6k, gpart_at8z) = Genome.Split.split gpart_at8y
                            p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                            (g_at6i, gpart_at8y) = Genome.Split.split gpart_at8x
                            p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                            (g_at6g, gpart_at8x) = Genome.Split.split genome_at7u
                          in
                            \ desc_at7v
                              -> case desc_at7v of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6h)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6j)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6l)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6n)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6p)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6r)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6t)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6v)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6x)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6z)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6B)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6D)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6F)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6H)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6J)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6L)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6N)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6P)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6R)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6T)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6V)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6X)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Z)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at71)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at73)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at75)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at77)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at79)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7b)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7d)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7f)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7h)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7j)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7l)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7n)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7p)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7r)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7t)
                                   _ -> Nothing }}
