src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24GK
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Hq
                      p_a24GJ = double g_a24GI
                      (g_a24GI, gpart_a24Hq) = Genome.Split.split gpart_a24Hp
                      p_a24GH = double g_a24GG
                      (g_a24GG, gpart_a24Hp) = Genome.Split.split gpart_a24Ho
                      p_a24GF = double g_a24GE
                      (g_a24GE, gpart_a24Ho) = Genome.Split.split gpart_a24Hn
                      p_a24GD = double g_a24GC
                      (g_a24GC, gpart_a24Hn) = Genome.Split.split gpart_a24Hm
                      p_a24GB = double g_a24GA
                      (g_a24GA, gpart_a24Hm) = Genome.Split.split gpart_a24Hl
                      p_a24Gz = Functions.belowten' g_a24Gy
                      (g_a24Gy, gpart_a24Hl) = Genome.Split.split gpart_a24Hk
                      p_a24Gx = double g_a24Gw
                      (g_a24Gw, gpart_a24Hk) = Genome.Split.split gpart_a24Hj
                      p_a24Gv = double g_a24Gu
                      (g_a24Gu, gpart_a24Hj) = Genome.Split.split gpart_a24Hi
                      p_a24Gt = double g_a24Gs
                      (g_a24Gs, gpart_a24Hi) = Genome.Split.split gpart_a24Hh
                      p_a24Gr = Functions.belowten' g_a24Gq
                      (g_a24Gq, gpart_a24Hh) = Genome.Split.split gpart_a24Hg
                      p_a24Gp = double g_a24Go
                      (g_a24Go, gpart_a24Hg) = Genome.Split.split gpart_a24Hf
                      p_a24Gn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Gm
                      (g_a24Gm, gpart_a24Hf) = Genome.Split.split gpart_a24He
                      p_a24Gl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Gk
                      (g_a24Gk, gpart_a24He) = Genome.Split.split gpart_a24Hd
                      p_a24Gj = Functions.belowten' g_a24Gi
                      (g_a24Gi, gpart_a24Hd) = Genome.Split.split gpart_a24Hc
                      p_a24Gh = double g_a24Gg
                      (g_a24Gg, gpart_a24Hc) = Genome.Split.split gpart_a24Hb
                      p_a24Gf = Functions.belowten' g_a24Ge
                      (g_a24Ge, gpart_a24Hb) = Genome.Split.split gpart_a24Ha
                      p_a24Gd = double g_a24Gc
                      (g_a24Gc, gpart_a24Ha) = Genome.Split.split gpart_a24H9
                      p_a24Gb = double g_a24Ga
                      (g_a24Ga, gpart_a24H9) = Genome.Split.split gpart_a24H8
                      p_a24G9 = double g_a24G8
                      (g_a24G8, gpart_a24H8) = Genome.Split.split gpart_a24H7
                      p_a24G7 = Functions.belowten' g_a24G6
                      (g_a24G6, gpart_a24H7) = Genome.Split.split gpart_a24H6
                      p_a24G5 = double g_a24G4
                      (g_a24G4, gpart_a24H6) = Genome.Split.split gpart_a24H5
                      p_a24G3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24G2
                      (g_a24G2, gpart_a24H5) = Genome.Split.split gpart_a24H4
                      p_a24G1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24G0
                      (g_a24G0, gpart_a24H4) = Genome.Split.split gpart_a24H3
                      p_a24FZ = double g_a24FY
                      (g_a24FY, gpart_a24H3) = Genome.Split.split gpart_a24H2
                      p_a24FX = Functions.belowten' g_a24FW
                      (g_a24FW, gpart_a24H2) = Genome.Split.split gpart_a24H1
                      p_a24FV = double g_a24FU
                      (g_a24FU, gpart_a24H1) = Genome.Split.split gpart_a24H0
                      p_a24FT = Functions.belowten' g_a24FS
                      (g_a24FS, gpart_a24H0) = Genome.Split.split gpart_a24GZ
                      p_a24FR = double g_a24FQ
                      (g_a24FQ, gpart_a24GZ) = Genome.Split.split gpart_a24GY
                      p_a24FP = double g_a24FO
                      (g_a24FO, gpart_a24GY) = Genome.Split.split gpart_a24GX
                      p_a24FN = double g_a24FM
                      (g_a24FM, gpart_a24GX) = Genome.Split.split gpart_a24GW
                      p_a24FL = Functions.belowten' g_a24FK
                      (g_a24FK, gpart_a24GW) = Genome.Split.split gpart_a24GV
                      p_a24FJ = double g_a24FI
                      (g_a24FI, gpart_a24GV) = Genome.Split.split gpart_a24GU
                      p_a24FH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24FG
                      (g_a24FG, gpart_a24GU) = Genome.Split.split gpart_a24GT
                      p_a24FF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24FE
                      (g_a24FE, gpart_a24GT) = Genome.Split.split gpart_a24GS
                      p_a24FD = Functions.belowten' g_a24FC
                      (g_a24FC, gpart_a24GS) = Genome.Split.split gpart_a24GR
                      p_a24FB = double g_a24FA
                      (g_a24FA, gpart_a24GR) = Genome.Split.split gpart_a24GQ
                      p_a24Fz = double g_a24Fy
                      (g_a24Fy, gpart_a24GQ) = Genome.Split.split gpart_a24GP
                      p_a24Fx = double g_a24Fw
                      (g_a24Fw, gpart_a24GP) = Genome.Split.split gpart_a24GO
                      p_a24Fv = double g_a24Fu
                      (g_a24Fu, gpart_a24GO) = Genome.Split.split gpart_a24GN
                      p_a24Ft = double g_a24Fs
                      (g_a24Fs, gpart_a24GN) = Genome.Split.split gpart_a24GM
                      p_a24Fr = double g_a24Fq
                      (g_a24Fq, gpart_a24GM) = Genome.Split.split genome_a24GK
                    in  \ x_a24Hr
                          -> let
                               c_PTB_a24Hw
                                 = ((Data.Fixed.Vector.toVector x_a24Hr) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Hu
                                 = ((Data.Fixed.Vector.toVector x_a24Hr) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Hs
                                 = ((Data.Fixed.Vector.toVector x_a24Hr) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24HB
                                 = ((Data.Fixed.Vector.toVector x_a24Hr) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24HN
                                 = ((Data.Fixed.Vector.toVector x_a24Hr) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Fz
                                     * ((p_a24FN + ((c_NPTB_a24Hs / p_a24FB) ** p_a24FD))
                                        / (((1 + p_a24FN) + ((c_NPTB_a24Hs / p_a24FB) ** p_a24FD))
                                           + ((c_MiRs_a24Hu / p_a24FJ) ** p_a24FL))))
                                    + (negate (p_a24GB * c_PTB_a24Hw))),
                                   ((p_a24FP
                                     / (1
                                        + (((c_MiRs_a24Hu / p_a24FR) ** p_a24FT)
                                           + ((c_PTB_a24Hw / p_a24FV) ** p_a24FX))))
                                    + (negate (p_a24GD * c_NPTB_a24Hs))),
                                   ((p_a24FZ
                                     * ((p_a24G9 + ((p_a24Fv / p_a24G1) ** p_a24G3))
                                        / (((1 + p_a24G9) + ((p_a24Fv / p_a24G1) ** p_a24G3))
                                           + ((c_RESTc_a24HB / p_a24G5) ** p_a24G7))))
                                    + (negate (p_a24GF * c_MiRs_a24Hu))),
                                   ((p_a24Gb
                                     * ((p_a24Gt
                                         + (((c_NPTB_a24Hs / p_a24Gd) ** p_a24Gf)
                                            + ((c_PTB_a24Hw / p_a24Gh) ** p_a24Gj)))
                                        / (((1 + p_a24Gt)
                                            + (((c_NPTB_a24Hs / p_a24Gd) ** p_a24Gf)
                                               + ((c_PTB_a24Hw / p_a24Gh) ** p_a24Gj)))
                                           + (((p_a24Fr / p_a24Gl) ** p_a24Gn)
                                              + ((c_MiRs_a24Hu / p_a24Gp) ** p_a24Gr)))))
                                    + (negate (p_a24GH * c_RESTc_a24HB))),
                                   ((p_a24Gv / (1 + ((c_RESTc_a24HB / p_a24Gx) ** p_a24Gz)))
                                    + (negate (p_a24GJ * c_EndoNeuroTFs_a24HN)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504407",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504409",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504429",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504431",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504433",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504449",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504451",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504457",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504459",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504465",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24GK
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Is
                            p_a24GJ = double g_a24GI
                            (g_a24GI, gpart_a24Is) = Genome.Split.split gpart_a24Ir
                            p_a24GH = double g_a24GG
                            (g_a24GG, gpart_a24Ir) = Genome.Split.split gpart_a24Iq
                            p_a24GF = double g_a24GE
                            (g_a24GE, gpart_a24Iq) = Genome.Split.split gpart_a24Ip
                            p_a24GD = double g_a24GC
                            (g_a24GC, gpart_a24Ip) = Genome.Split.split gpart_a24Io
                            p_a24GB = double g_a24GA
                            (g_a24GA, gpart_a24Io) = Genome.Split.split gpart_a24In
                            p_a24Gz = Functions.belowten' g_a24Gy
                            (g_a24Gy, gpart_a24In) = Genome.Split.split gpart_a24Im
                            p_a24Gx = double g_a24Gw
                            (g_a24Gw, gpart_a24Im) = Genome.Split.split gpart_a24Il
                            p_a24Gv = double g_a24Gu
                            (g_a24Gu, gpart_a24Il) = Genome.Split.split gpart_a24Ik
                            p_a24Gt = double g_a24Gs
                            (g_a24Gs, gpart_a24Ik) = Genome.Split.split gpart_a24Ij
                            p_a24Gr = Functions.belowten' g_a24Gq
                            (g_a24Gq, gpart_a24Ij) = Genome.Split.split gpart_a24Ii
                            p_a24Gp = double g_a24Go
                            (g_a24Go, gpart_a24Ii) = Genome.Split.split gpart_a24Ih
                            p_a24Gn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Gm
                            (g_a24Gm, gpart_a24Ih) = Genome.Split.split gpart_a24Ig
                            p_a24Gl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Gk
                            (g_a24Gk, gpart_a24Ig) = Genome.Split.split gpart_a24If
                            p_a24Gj = Functions.belowten' g_a24Gi
                            (g_a24Gi, gpart_a24If) = Genome.Split.split gpart_a24Ie
                            p_a24Gh = double g_a24Gg
                            (g_a24Gg, gpart_a24Ie) = Genome.Split.split gpart_a24Id
                            p_a24Gf = Functions.belowten' g_a24Ge
                            (g_a24Ge, gpart_a24Id) = Genome.Split.split gpart_a24Ic
                            p_a24Gd = double g_a24Gc
                            (g_a24Gc, gpart_a24Ic) = Genome.Split.split gpart_a24Ib
                            p_a24Gb = double g_a24Ga
                            (g_a24Ga, gpart_a24Ib) = Genome.Split.split gpart_a24Ia
                            p_a24G9 = double g_a24G8
                            (g_a24G8, gpart_a24Ia) = Genome.Split.split gpart_a24I9
                            p_a24G7 = Functions.belowten' g_a24G6
                            (g_a24G6, gpart_a24I9) = Genome.Split.split gpart_a24I8
                            p_a24G5 = double g_a24G4
                            (g_a24G4, gpart_a24I8) = Genome.Split.split gpart_a24I7
                            p_a24G3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24G2
                            (g_a24G2, gpart_a24I7) = Genome.Split.split gpart_a24I6
                            p_a24G1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24G0
                            (g_a24G0, gpart_a24I6) = Genome.Split.split gpart_a24I5
                            p_a24FZ = double g_a24FY
                            (g_a24FY, gpart_a24I5) = Genome.Split.split gpart_a24I4
                            p_a24FX = Functions.belowten' g_a24FW
                            (g_a24FW, gpart_a24I4) = Genome.Split.split gpart_a24I3
                            p_a24FV = double g_a24FU
                            (g_a24FU, gpart_a24I3) = Genome.Split.split gpart_a24I2
                            p_a24FT = Functions.belowten' g_a24FS
                            (g_a24FS, gpart_a24I2) = Genome.Split.split gpart_a24I1
                            p_a24FR = double g_a24FQ
                            (g_a24FQ, gpart_a24I1) = Genome.Split.split gpart_a24I0
                            p_a24FP = double g_a24FO
                            (g_a24FO, gpart_a24I0) = Genome.Split.split gpart_a24HZ
                            p_a24FN = double g_a24FM
                            (g_a24FM, gpart_a24HZ) = Genome.Split.split gpart_a24HY
                            p_a24FL = Functions.belowten' g_a24FK
                            (g_a24FK, gpart_a24HY) = Genome.Split.split gpart_a24HX
                            p_a24FJ = double g_a24FI
                            (g_a24FI, gpart_a24HX) = Genome.Split.split gpart_a24HW
                            p_a24FH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24FG
                            (g_a24FG, gpart_a24HW) = Genome.Split.split gpart_a24HV
                            p_a24FF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24FE
                            (g_a24FE, gpart_a24HV) = Genome.Split.split gpart_a24HU
                            p_a24FD = Functions.belowten' g_a24FC
                            (g_a24FC, gpart_a24HU) = Genome.Split.split gpart_a24HT
                            p_a24FB = double g_a24FA
                            (g_a24FA, gpart_a24HT) = Genome.Split.split gpart_a24HS
                            p_a24Fz = double g_a24Fy
                            (g_a24Fy, gpart_a24HS) = Genome.Split.split gpart_a24HR
                            p_a24Fx = double g_a24Fw
                            (g_a24Fw, gpart_a24HR) = Genome.Split.split gpart_a24HQ
                            p_a24Fv = double g_a24Fu
                            (g_a24Fu, gpart_a24HQ) = Genome.Split.split gpart_a24HP
                            p_a24Ft = double g_a24Fs
                            (g_a24Fs, gpart_a24HP) = Genome.Split.split gpart_a24HO
                            p_a24Fr = double g_a24Fq
                            (g_a24Fq, gpart_a24HO) = Genome.Split.split genome_a24GK
                          in
                            \ desc_a24GL
                              -> case desc_a24GL of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Fr)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ft)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Fv)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Fx)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Fz)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FB)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FD)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FF)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FH)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FJ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FL)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FN)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FP)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FR)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FT)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FV)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FX)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FZ)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G1)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G3)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G5)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G7)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G9)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gb)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gd)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gf)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gh)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gj)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gl)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gn)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gp)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gr)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gt)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gv)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gx)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gz)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GB)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GD)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GF)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GH)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GJ)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24KW
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24LC
                      p_a24KV = double g_a24KU
                      (g_a24KU, gpart_a24LC) = Genome.Split.split gpart_a24LB
                      p_a24KT = double g_a24KS
                      (g_a24KS, gpart_a24LB) = Genome.Split.split gpart_a24LA
                      p_a24KR = double g_a24KQ
                      (g_a24KQ, gpart_a24LA) = Genome.Split.split gpart_a24Lz
                      p_a24KP = double g_a24KO
                      (g_a24KO, gpart_a24Lz) = Genome.Split.split gpart_a24Ly
                      p_a24KN = double g_a24KM
                      (g_a24KM, gpart_a24Ly) = Genome.Split.split gpart_a24Lx
                      p_a24KL = Functions.belowten' g_a24KK
                      (g_a24KK, gpart_a24Lx) = Genome.Split.split gpart_a24Lw
                      p_a24KJ = double g_a24KI
                      (g_a24KI, gpart_a24Lw) = Genome.Split.split gpart_a24Lv
                      p_a24KH = double g_a24KG
                      (g_a24KG, gpart_a24Lv) = Genome.Split.split gpart_a24Lu
                      p_a24KF = double g_a24KE
                      (g_a24KE, gpart_a24Lu) = Genome.Split.split gpart_a24Lt
                      p_a24KD = Functions.belowten' g_a24KC
                      (g_a24KC, gpart_a24Lt) = Genome.Split.split gpart_a24Ls
                      p_a24KB = double g_a24KA
                      (g_a24KA, gpart_a24Ls) = Genome.Split.split gpart_a24Lr
                      p_a24Kz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ky
                      (g_a24Ky, gpart_a24Lr) = Genome.Split.split gpart_a24Lq
                      p_a24Kx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kw
                      (g_a24Kw, gpart_a24Lq) = Genome.Split.split gpart_a24Lp
                      p_a24Kv = Functions.belowten' g_a24Ku
                      (g_a24Ku, gpart_a24Lp) = Genome.Split.split gpart_a24Lo
                      p_a24Kt = double g_a24Ks
                      (g_a24Ks, gpart_a24Lo) = Genome.Split.split gpart_a24Ln
                      p_a24Kr = Functions.belowten' g_a24Kq
                      (g_a24Kq, gpart_a24Ln) = Genome.Split.split gpart_a24Lm
                      p_a24Kp = double g_a24Ko
                      (g_a24Ko, gpart_a24Lm) = Genome.Split.split gpart_a24Ll
                      p_a24Kn = double g_a24Km
                      (g_a24Km, gpart_a24Ll) = Genome.Split.split gpart_a24Lk
                      p_a24Kl = double g_a24Kk
                      (g_a24Kk, gpart_a24Lk) = Genome.Split.split gpart_a24Lj
                      p_a24Kj = Functions.belowten' g_a24Ki
                      (g_a24Ki, gpart_a24Lj) = Genome.Split.split gpart_a24Li
                      p_a24Kh = double g_a24Kg
                      (g_a24Kg, gpart_a24Li) = Genome.Split.split gpart_a24Lh
                      p_a24Kf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ke
                      (g_a24Ke, gpart_a24Lh) = Genome.Split.split gpart_a24Lg
                      p_a24Kd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kc
                      (g_a24Kc, gpart_a24Lg) = Genome.Split.split gpart_a24Lf
                      p_a24Kb = double g_a24Ka
                      (g_a24Ka, gpart_a24Lf) = Genome.Split.split gpart_a24Le
                      p_a24K9 = Functions.belowten' g_a24K8
                      (g_a24K8, gpart_a24Le) = Genome.Split.split gpart_a24Ld
                      p_a24K7 = double g_a24K6
                      (g_a24K6, gpart_a24Ld) = Genome.Split.split gpart_a24Lc
                      p_a24K5 = Functions.belowten' g_a24K4
                      (g_a24K4, gpart_a24Lc) = Genome.Split.split gpart_a24Lb
                      p_a24K3 = double g_a24K2
                      (g_a24K2, gpart_a24Lb) = Genome.Split.split gpart_a24La
                      p_a24K1 = double g_a24K0
                      (g_a24K0, gpart_a24La) = Genome.Split.split gpart_a24L9
                      p_a24JZ = double g_a24JY
                      (g_a24JY, gpart_a24L9) = Genome.Split.split gpart_a24L8
                      p_a24JX = Functions.belowten' g_a24JW
                      (g_a24JW, gpart_a24L8) = Genome.Split.split gpart_a24L7
                      p_a24JV = double g_a24JU
                      (g_a24JU, gpart_a24L7) = Genome.Split.split gpart_a24L6
                      p_a24JT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JS
                      (g_a24JS, gpart_a24L6) = Genome.Split.split gpart_a24L5
                      p_a24JR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JQ
                      (g_a24JQ, gpart_a24L5) = Genome.Split.split gpart_a24L4
                      p_a24JP = Functions.belowten' g_a24JO
                      (g_a24JO, gpart_a24L4) = Genome.Split.split gpart_a24L3
                      p_a24JN = double g_a24JM
                      (g_a24JM, gpart_a24L3) = Genome.Split.split gpart_a24L2
                      p_a24JL = double g_a24JK
                      (g_a24JK, gpart_a24L2) = Genome.Split.split gpart_a24L1
                      p_a24JJ = double g_a24JI
                      (g_a24JI, gpart_a24L1) = Genome.Split.split gpart_a24L0
                      p_a24JH = double g_a24JG
                      (g_a24JG, gpart_a24L0) = Genome.Split.split gpart_a24KZ
                      p_a24JF = double g_a24JE
                      (g_a24JE, gpart_a24KZ) = Genome.Split.split gpart_a24KY
                      p_a24JD = double g_a24JC
                      (g_a24JC, gpart_a24KY) = Genome.Split.split genome_a24KW
                    in  \ x_a24LD
                          -> let
                               c_PTB_a24LI
                                 = ((Data.Fixed.Vector.toVector x_a24LD) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24LG
                                 = ((Data.Fixed.Vector.toVector x_a24LD) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24LE
                                 = ((Data.Fixed.Vector.toVector x_a24LD) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24LN
                                 = ((Data.Fixed.Vector.toVector x_a24LD) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24LZ
                                 = ((Data.Fixed.Vector.toVector x_a24LD) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24JL
                                     * ((p_a24JZ + ((c_NPTB_a24LE / p_a24JN) ** p_a24JP))
                                        / (((1 + p_a24JZ) + ((c_NPTB_a24LE / p_a24JN) ** p_a24JP))
                                           + ((c_MiRs_a24LG / p_a24JV) ** p_a24JX))))
                                    + (negate (p_a24KN * c_PTB_a24LI))),
                                   ((p_a24K1
                                     / (1
                                        + (((c_MiRs_a24LG / p_a24K3) ** p_a24K5)
                                           + ((c_PTB_a24LI / p_a24K7) ** p_a24K9))))
                                    + (negate (p_a24KP * c_NPTB_a24LE))),
                                   ((p_a24Kb
                                     * (p_a24Kl
                                        / ((1 + p_a24Kl) + ((c_RESTc_a24LN / p_a24Kh) ** p_a24Kj))))
                                    + (negate (p_a24KR * c_MiRs_a24LG))),
                                   ((p_a24Kn
                                     * ((p_a24KF
                                         + (((c_NPTB_a24LE / p_a24Kp) ** p_a24Kr)
                                            + ((c_PTB_a24LI / p_a24Kt) ** p_a24Kv)))
                                        / (((1 + p_a24KF)
                                            + (((c_NPTB_a24LE / p_a24Kp) ** p_a24Kr)
                                               + ((c_PTB_a24LI / p_a24Kt) ** p_a24Kv)))
                                           + (((p_a24JD / p_a24Kx) ** p_a24Kz)
                                              + ((c_MiRs_a24LG / p_a24KB) ** p_a24KD)))))
                                    + (negate (p_a24KT * c_RESTc_a24LN))),
                                   ((p_a24KH / (1 + ((c_RESTc_a24LN / p_a24KJ) ** p_a24KL)))
                                    + (negate (p_a24KV * c_EndoNeuroTFs_a24LZ)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504667",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504669",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504689",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504691",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504709",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504711",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504713",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504717",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504719",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24KW
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24ME
                            p_a24KV = double g_a24KU
                            (g_a24KU, gpart_a24ME) = Genome.Split.split gpart_a24MD
                            p_a24KT = double g_a24KS
                            (g_a24KS, gpart_a24MD) = Genome.Split.split gpart_a24MC
                            p_a24KR = double g_a24KQ
                            (g_a24KQ, gpart_a24MC) = Genome.Split.split gpart_a24MB
                            p_a24KP = double g_a24KO
                            (g_a24KO, gpart_a24MB) = Genome.Split.split gpart_a24MA
                            p_a24KN = double g_a24KM
                            (g_a24KM, gpart_a24MA) = Genome.Split.split gpart_a24Mz
                            p_a24KL = Functions.belowten' g_a24KK
                            (g_a24KK, gpart_a24Mz) = Genome.Split.split gpart_a24My
                            p_a24KJ = double g_a24KI
                            (g_a24KI, gpart_a24My) = Genome.Split.split gpart_a24Mx
                            p_a24KH = double g_a24KG
                            (g_a24KG, gpart_a24Mx) = Genome.Split.split gpart_a24Mw
                            p_a24KF = double g_a24KE
                            (g_a24KE, gpart_a24Mw) = Genome.Split.split gpart_a24Mv
                            p_a24KD = Functions.belowten' g_a24KC
                            (g_a24KC, gpart_a24Mv) = Genome.Split.split gpart_a24Mu
                            p_a24KB = double g_a24KA
                            (g_a24KA, gpart_a24Mu) = Genome.Split.split gpart_a24Mt
                            p_a24Kz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ky
                            (g_a24Ky, gpart_a24Mt) = Genome.Split.split gpart_a24Ms
                            p_a24Kx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kw
                            (g_a24Kw, gpart_a24Ms) = Genome.Split.split gpart_a24Mr
                            p_a24Kv = Functions.belowten' g_a24Ku
                            (g_a24Ku, gpart_a24Mr) = Genome.Split.split gpart_a24Mq
                            p_a24Kt = double g_a24Ks
                            (g_a24Ks, gpart_a24Mq) = Genome.Split.split gpart_a24Mp
                            p_a24Kr = Functions.belowten' g_a24Kq
                            (g_a24Kq, gpart_a24Mp) = Genome.Split.split gpart_a24Mo
                            p_a24Kp = double g_a24Ko
                            (g_a24Ko, gpart_a24Mo) = Genome.Split.split gpart_a24Mn
                            p_a24Kn = double g_a24Km
                            (g_a24Km, gpart_a24Mn) = Genome.Split.split gpart_a24Mm
                            p_a24Kl = double g_a24Kk
                            (g_a24Kk, gpart_a24Mm) = Genome.Split.split gpart_a24Ml
                            p_a24Kj = Functions.belowten' g_a24Ki
                            (g_a24Ki, gpart_a24Ml) = Genome.Split.split gpart_a24Mk
                            p_a24Kh = double g_a24Kg
                            (g_a24Kg, gpart_a24Mk) = Genome.Split.split gpart_a24Mj
                            p_a24Kf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ke
                            (g_a24Ke, gpart_a24Mj) = Genome.Split.split gpart_a24Mi
                            p_a24Kd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kc
                            (g_a24Kc, gpart_a24Mi) = Genome.Split.split gpart_a24Mh
                            p_a24Kb = double g_a24Ka
                            (g_a24Ka, gpart_a24Mh) = Genome.Split.split gpart_a24Mg
                            p_a24K9 = Functions.belowten' g_a24K8
                            (g_a24K8, gpart_a24Mg) = Genome.Split.split gpart_a24Mf
                            p_a24K7 = double g_a24K6
                            (g_a24K6, gpart_a24Mf) = Genome.Split.split gpart_a24Me
                            p_a24K5 = Functions.belowten' g_a24K4
                            (g_a24K4, gpart_a24Me) = Genome.Split.split gpart_a24Md
                            p_a24K3 = double g_a24K2
                            (g_a24K2, gpart_a24Md) = Genome.Split.split gpart_a24Mc
                            p_a24K1 = double g_a24K0
                            (g_a24K0, gpart_a24Mc) = Genome.Split.split gpart_a24Mb
                            p_a24JZ = double g_a24JY
                            (g_a24JY, gpart_a24Mb) = Genome.Split.split gpart_a24Ma
                            p_a24JX = Functions.belowten' g_a24JW
                            (g_a24JW, gpart_a24Ma) = Genome.Split.split gpart_a24M9
                            p_a24JV = double g_a24JU
                            (g_a24JU, gpart_a24M9) = Genome.Split.split gpart_a24M8
                            p_a24JT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JS
                            (g_a24JS, gpart_a24M8) = Genome.Split.split gpart_a24M7
                            p_a24JR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JQ
                            (g_a24JQ, gpart_a24M7) = Genome.Split.split gpart_a24M6
                            p_a24JP = Functions.belowten' g_a24JO
                            (g_a24JO, gpart_a24M6) = Genome.Split.split gpart_a24M5
                            p_a24JN = double g_a24JM
                            (g_a24JM, gpart_a24M5) = Genome.Split.split gpart_a24M4
                            p_a24JL = double g_a24JK
                            (g_a24JK, gpart_a24M4) = Genome.Split.split gpart_a24M3
                            p_a24JJ = double g_a24JI
                            (g_a24JI, gpart_a24M3) = Genome.Split.split gpart_a24M2
                            p_a24JH = double g_a24JG
                            (g_a24JG, gpart_a24M2) = Genome.Split.split gpart_a24M1
                            p_a24JF = double g_a24JE
                            (g_a24JE, gpart_a24M1) = Genome.Split.split gpart_a24M0
                            p_a24JD = double g_a24JC
                            (g_a24JC, gpart_a24M0) = Genome.Split.split genome_a24KW
                          in
                            \ desc_a24KX
                              -> case desc_a24KX of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JD)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JF)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JH)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JJ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JL)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JN)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JP)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JR)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JT)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JV)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JX)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JZ)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K1)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K3)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K5)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K7)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K9)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kb)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kd)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kf)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kh)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kj)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kl)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kn)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kp)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kr)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kt)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kv)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kx)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kz)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KB)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KD)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KF)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KH)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KJ)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KL)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KN)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KP)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KR)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KT)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KV)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24P8
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24PO
                      p_a24P7 = double g_a24P6
                      (g_a24P6, gpart_a24PO) = Genome.Split.split gpart_a24PN
                      p_a24P5 = double g_a24P4
                      (g_a24P4, gpart_a24PN) = Genome.Split.split gpart_a24PM
                      p_a24P3 = double g_a24P2
                      (g_a24P2, gpart_a24PM) = Genome.Split.split gpart_a24PL
                      p_a24P1 = double g_a24P0
                      (g_a24P0, gpart_a24PL) = Genome.Split.split gpart_a24PK
                      p_a24OZ = double g_a24OY
                      (g_a24OY, gpart_a24PK) = Genome.Split.split gpart_a24PJ
                      p_a24OX = Functions.belowten' g_a24OW
                      (g_a24OW, gpart_a24PJ) = Genome.Split.split gpart_a24PI
                      p_a24OV = double g_a24OU
                      (g_a24OU, gpart_a24PI) = Genome.Split.split gpart_a24PH
                      p_a24OT = double g_a24OS
                      (g_a24OS, gpart_a24PH) = Genome.Split.split gpart_a24PG
                      p_a24OR = double g_a24OQ
                      (g_a24OQ, gpart_a24PG) = Genome.Split.split gpart_a24PF
                      p_a24OP = Functions.belowten' g_a24OO
                      (g_a24OO, gpart_a24PF) = Genome.Split.split gpart_a24PE
                      p_a24ON = double g_a24OM
                      (g_a24OM, gpart_a24PE) = Genome.Split.split gpart_a24PD
                      p_a24OL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OK
                      (g_a24OK, gpart_a24PD) = Genome.Split.split gpart_a24PC
                      p_a24OJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OI
                      (g_a24OI, gpart_a24PC) = Genome.Split.split gpart_a24PB
                      p_a24OH = Functions.belowten' g_a24OG
                      (g_a24OG, gpart_a24PB) = Genome.Split.split gpart_a24PA
                      p_a24OF = double g_a24OE
                      (g_a24OE, gpart_a24PA) = Genome.Split.split gpart_a24Pz
                      p_a24OD = Functions.belowten' g_a24OC
                      (g_a24OC, gpart_a24Pz) = Genome.Split.split gpart_a24Py
                      p_a24OB = double g_a24OA
                      (g_a24OA, gpart_a24Py) = Genome.Split.split gpart_a24Px
                      p_a24Oz = double g_a24Oy
                      (g_a24Oy, gpart_a24Px) = Genome.Split.split gpart_a24Pw
                      p_a24Ox = double g_a24Ow
                      (g_a24Ow, gpart_a24Pw) = Genome.Split.split gpart_a24Pv
                      p_a24Ov = Functions.belowten' g_a24Ou
                      (g_a24Ou, gpart_a24Pv) = Genome.Split.split gpart_a24Pu
                      p_a24Ot = double g_a24Os
                      (g_a24Os, gpart_a24Pu) = Genome.Split.split gpart_a24Pt
                      p_a24Or
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oq
                      (g_a24Oq, gpart_a24Pt) = Genome.Split.split gpart_a24Ps
                      p_a24Op
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oo
                      (g_a24Oo, gpart_a24Ps) = Genome.Split.split gpart_a24Pr
                      p_a24On = double g_a24Om
                      (g_a24Om, gpart_a24Pr) = Genome.Split.split gpart_a24Pq
                      p_a24Ol = Functions.belowten' g_a24Ok
                      (g_a24Ok, gpart_a24Pq) = Genome.Split.split gpart_a24Pp
                      p_a24Oj = double g_a24Oi
                      (g_a24Oi, gpart_a24Pp) = Genome.Split.split gpart_a24Po
                      p_a24Oh = Functions.belowten' g_a24Og
                      (g_a24Og, gpart_a24Po) = Genome.Split.split gpart_a24Pn
                      p_a24Of = double g_a24Oe
                      (g_a24Oe, gpart_a24Pn) = Genome.Split.split gpart_a24Pm
                      p_a24Od = double g_a24Oc
                      (g_a24Oc, gpart_a24Pm) = Genome.Split.split gpart_a24Pl
                      p_a24Ob = double g_a24Oa
                      (g_a24Oa, gpart_a24Pl) = Genome.Split.split gpart_a24Pk
                      p_a24O9 = Functions.belowten' g_a24O8
                      (g_a24O8, gpart_a24Pk) = Genome.Split.split gpart_a24Pj
                      p_a24O7 = double g_a24O6
                      (g_a24O6, gpart_a24Pj) = Genome.Split.split gpart_a24Pi
                      p_a24O5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O4
                      (g_a24O4, gpart_a24Pi) = Genome.Split.split gpart_a24Ph
                      p_a24O3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O2
                      (g_a24O2, gpart_a24Ph) = Genome.Split.split gpart_a24Pg
                      p_a24O1 = Functions.belowten' g_a24O0
                      (g_a24O0, gpart_a24Pg) = Genome.Split.split gpart_a24Pf
                      p_a24NZ = double g_a24NY
                      (g_a24NY, gpart_a24Pf) = Genome.Split.split gpart_a24Pe
                      p_a24NX = double g_a24NW
                      (g_a24NW, gpart_a24Pe) = Genome.Split.split gpart_a24Pd
                      p_a24NV = double g_a24NU
                      (g_a24NU, gpart_a24Pd) = Genome.Split.split gpart_a24Pc
                      p_a24NT = double g_a24NS
                      (g_a24NS, gpart_a24Pc) = Genome.Split.split gpart_a24Pb
                      p_a24NR = double g_a24NQ
                      (g_a24NQ, gpart_a24Pb) = Genome.Split.split gpart_a24Pa
                      p_a24NP = double g_a24NO
                      (g_a24NO, gpart_a24Pa) = Genome.Split.split genome_a24P8
                    in  \ x_a24PP
                          -> let
                               c_PTB_a24PU
                                 = ((Data.Fixed.Vector.toVector x_a24PP) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24PS
                                 = ((Data.Fixed.Vector.toVector x_a24PP) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24PQ
                                 = ((Data.Fixed.Vector.toVector x_a24PP) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24PZ
                                 = ((Data.Fixed.Vector.toVector x_a24PP) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Qb
                                 = ((Data.Fixed.Vector.toVector x_a24PP) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24NX
                                     * ((p_a24Ob + ((c_NPTB_a24PQ / p_a24NZ) ** p_a24O1))
                                        / (((1 + p_a24Ob) + ((c_NPTB_a24PQ / p_a24NZ) ** p_a24O1))
                                           + ((c_MiRs_a24PS / p_a24O7) ** p_a24O9))))
                                    + (negate (p_a24OZ * c_PTB_a24PU))),
                                   ((p_a24Od
                                     / (1
                                        + (((c_MiRs_a24PS / p_a24Of) ** p_a24Oh)
                                           + ((c_PTB_a24PU / p_a24Oj) ** p_a24Ol))))
                                    + (negate (p_a24P1 * c_NPTB_a24PQ))),
                                   ((p_a24On
                                     * (p_a24Ox
                                        / ((1 + p_a24Ox) + ((c_RESTc_a24PZ / p_a24Ot) ** p_a24Ov))))
                                    + (negate (p_a24P3 * c_MiRs_a24PS))),
                                   ((p_a24Oz
                                     * ((p_a24OR
                                         + (((c_NPTB_a24PQ / p_a24OB) ** p_a24OD)
                                            + ((c_PTB_a24PU / p_a24OF) ** p_a24OH)))
                                        / (((1 + p_a24OR)
                                            + (((c_NPTB_a24PQ / p_a24OB) ** p_a24OD)
                                               + ((c_PTB_a24PU / p_a24OF) ** p_a24OH)))
                                           + ((c_MiRs_a24PS / p_a24ON) ** p_a24OP))))
                                    + (negate (p_a24P5 * c_RESTc_a24PZ))),
                                   ((p_a24OT / (1 + ((c_RESTc_a24PZ / p_a24OV) ** p_a24OX)))
                                    + (negate (p_a24P7 * c_EndoNeuroTFs_a24Qb)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504927",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504929",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504939",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504941",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504949",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504951",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504957",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504969",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504971",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504973",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504975",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504981",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504983",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504986",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504987",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504988",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504989",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504990",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504991",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504992",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504993",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24P8
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24QQ
                            p_a24P7 = double g_a24P6
                            (g_a24P6, gpart_a24QQ) = Genome.Split.split gpart_a24QP
                            p_a24P5 = double g_a24P4
                            (g_a24P4, gpart_a24QP) = Genome.Split.split gpart_a24QO
                            p_a24P3 = double g_a24P2
                            (g_a24P2, gpart_a24QO) = Genome.Split.split gpart_a24QN
                            p_a24P1 = double g_a24P0
                            (g_a24P0, gpart_a24QN) = Genome.Split.split gpart_a24QM
                            p_a24OZ = double g_a24OY
                            (g_a24OY, gpart_a24QM) = Genome.Split.split gpart_a24QL
                            p_a24OX = Functions.belowten' g_a24OW
                            (g_a24OW, gpart_a24QL) = Genome.Split.split gpart_a24QK
                            p_a24OV = double g_a24OU
                            (g_a24OU, gpart_a24QK) = Genome.Split.split gpart_a24QJ
                            p_a24OT = double g_a24OS
                            (g_a24OS, gpart_a24QJ) = Genome.Split.split gpart_a24QI
                            p_a24OR = double g_a24OQ
                            (g_a24OQ, gpart_a24QI) = Genome.Split.split gpart_a24QH
                            p_a24OP = Functions.belowten' g_a24OO
                            (g_a24OO, gpart_a24QH) = Genome.Split.split gpart_a24QG
                            p_a24ON = double g_a24OM
                            (g_a24OM, gpart_a24QG) = Genome.Split.split gpart_a24QF
                            p_a24OL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OK
                            (g_a24OK, gpart_a24QF) = Genome.Split.split gpart_a24QE
                            p_a24OJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OI
                            (g_a24OI, gpart_a24QE) = Genome.Split.split gpart_a24QD
                            p_a24OH = Functions.belowten' g_a24OG
                            (g_a24OG, gpart_a24QD) = Genome.Split.split gpart_a24QC
                            p_a24OF = double g_a24OE
                            (g_a24OE, gpart_a24QC) = Genome.Split.split gpart_a24QB
                            p_a24OD = Functions.belowten' g_a24OC
                            (g_a24OC, gpart_a24QB) = Genome.Split.split gpart_a24QA
                            p_a24OB = double g_a24OA
                            (g_a24OA, gpart_a24QA) = Genome.Split.split gpart_a24Qz
                            p_a24Oz = double g_a24Oy
                            (g_a24Oy, gpart_a24Qz) = Genome.Split.split gpart_a24Qy
                            p_a24Ox = double g_a24Ow
                            (g_a24Ow, gpart_a24Qy) = Genome.Split.split gpart_a24Qx
                            p_a24Ov = Functions.belowten' g_a24Ou
                            (g_a24Ou, gpart_a24Qx) = Genome.Split.split gpart_a24Qw
                            p_a24Ot = double g_a24Os
                            (g_a24Os, gpart_a24Qw) = Genome.Split.split gpart_a24Qv
                            p_a24Or
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oq
                            (g_a24Oq, gpart_a24Qv) = Genome.Split.split gpart_a24Qu
                            p_a24Op
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oo
                            (g_a24Oo, gpart_a24Qu) = Genome.Split.split gpart_a24Qt
                            p_a24On = double g_a24Om
                            (g_a24Om, gpart_a24Qt) = Genome.Split.split gpart_a24Qs
                            p_a24Ol = Functions.belowten' g_a24Ok
                            (g_a24Ok, gpart_a24Qs) = Genome.Split.split gpart_a24Qr
                            p_a24Oj = double g_a24Oi
                            (g_a24Oi, gpart_a24Qr) = Genome.Split.split gpart_a24Qq
                            p_a24Oh = Functions.belowten' g_a24Og
                            (g_a24Og, gpart_a24Qq) = Genome.Split.split gpart_a24Qp
                            p_a24Of = double g_a24Oe
                            (g_a24Oe, gpart_a24Qp) = Genome.Split.split gpart_a24Qo
                            p_a24Od = double g_a24Oc
                            (g_a24Oc, gpart_a24Qo) = Genome.Split.split gpart_a24Qn
                            p_a24Ob = double g_a24Oa
                            (g_a24Oa, gpart_a24Qn) = Genome.Split.split gpart_a24Qm
                            p_a24O9 = Functions.belowten' g_a24O8
                            (g_a24O8, gpart_a24Qm) = Genome.Split.split gpart_a24Ql
                            p_a24O7 = double g_a24O6
                            (g_a24O6, gpart_a24Ql) = Genome.Split.split gpart_a24Qk
                            p_a24O5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O4
                            (g_a24O4, gpart_a24Qk) = Genome.Split.split gpart_a24Qj
                            p_a24O3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O2
                            (g_a24O2, gpart_a24Qj) = Genome.Split.split gpart_a24Qi
                            p_a24O1 = Functions.belowten' g_a24O0
                            (g_a24O0, gpart_a24Qi) = Genome.Split.split gpart_a24Qh
                            p_a24NZ = double g_a24NY
                            (g_a24NY, gpart_a24Qh) = Genome.Split.split gpart_a24Qg
                            p_a24NX = double g_a24NW
                            (g_a24NW, gpart_a24Qg) = Genome.Split.split gpart_a24Qf
                            p_a24NV = double g_a24NU
                            (g_a24NU, gpart_a24Qf) = Genome.Split.split gpart_a24Qe
                            p_a24NT = double g_a24NS
                            (g_a24NS, gpart_a24Qe) = Genome.Split.split gpart_a24Qd
                            p_a24NR = double g_a24NQ
                            (g_a24NQ, gpart_a24Qd) = Genome.Split.split gpart_a24Qc
                            p_a24NP = double g_a24NO
                            (g_a24NO, gpart_a24Qc) = Genome.Split.split genome_a24P8
                          in
                            \ desc_a24P9
                              -> case desc_a24P9 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NP)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NR)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NT)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NV)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NX)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NZ)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O1)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O3)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O5)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O7)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O9)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ob)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Od)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Of)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oh)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oj)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ol)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24On)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Op)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Or)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ot)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ov)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ox)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oz)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OB)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OD)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OF)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OH)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OJ)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OL)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ON)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OP)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OR)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OT)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OV)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OX)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OZ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P1)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P3)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P5)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P7)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a24Tk
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24U0
                      p_a24Tj = double g_a24Ti
                      (g_a24Ti, gpart_a24U0) = Genome.Split.split gpart_a24TZ
                      p_a24Th = double g_a24Tg
                      (g_a24Tg, gpart_a24TZ) = Genome.Split.split gpart_a24TY
                      p_a24Tf = double g_a24Te
                      (g_a24Te, gpart_a24TY) = Genome.Split.split gpart_a24TX
                      p_a24Td = double g_a24Tc
                      (g_a24Tc, gpart_a24TX) = Genome.Split.split gpart_a24TW
                      p_a24Tb = double g_a24Ta
                      (g_a24Ta, gpart_a24TW) = Genome.Split.split gpart_a24TV
                      p_a24T9 = Functions.belowten' g_a24T8
                      (g_a24T8, gpart_a24TV) = Genome.Split.split gpart_a24TU
                      p_a24T7 = double g_a24T6
                      (g_a24T6, gpart_a24TU) = Genome.Split.split gpart_a24TT
                      p_a24T5 = double g_a24T4
                      (g_a24T4, gpart_a24TT) = Genome.Split.split gpart_a24TS
                      p_a24T3 = double g_a24T2
                      (g_a24T2, gpart_a24TS) = Genome.Split.split gpart_a24TR
                      p_a24T1 = Functions.belowten' g_a24T0
                      (g_a24T0, gpart_a24TR) = Genome.Split.split gpart_a24TQ
                      p_a24SZ = double g_a24SY
                      (g_a24SY, gpart_a24TQ) = Genome.Split.split gpart_a24TP
                      p_a24SX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SW
                      (g_a24SW, gpart_a24TP) = Genome.Split.split gpart_a24TO
                      p_a24SV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SU
                      (g_a24SU, gpart_a24TO) = Genome.Split.split gpart_a24TN
                      p_a24ST = Functions.belowten' g_a24SS
                      (g_a24SS, gpart_a24TN) = Genome.Split.split gpart_a24TM
                      p_a24SR = double g_a24SQ
                      (g_a24SQ, gpart_a24TM) = Genome.Split.split gpart_a24TL
                      p_a24SP = Functions.belowten' g_a24SO
                      (g_a24SO, gpart_a24TL) = Genome.Split.split gpart_a24TK
                      p_a24SN = double g_a24SM
                      (g_a24SM, gpart_a24TK) = Genome.Split.split gpart_a24TJ
                      p_a24SL = double g_a24SK
                      (g_a24SK, gpart_a24TJ) = Genome.Split.split gpart_a24TI
                      p_a24SJ = double g_a24SI
                      (g_a24SI, gpart_a24TI) = Genome.Split.split gpart_a24TH
                      p_a24SH = Functions.belowten' g_a24SG
                      (g_a24SG, gpart_a24TH) = Genome.Split.split gpart_a24TG
                      p_a24SF = double g_a24SE
                      (g_a24SE, gpart_a24TG) = Genome.Split.split gpart_a24TF
                      p_a24SD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SC
                      (g_a24SC, gpart_a24TF) = Genome.Split.split gpart_a24TE
                      p_a24SB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SA
                      (g_a24SA, gpart_a24TE) = Genome.Split.split gpart_a24TD
                      p_a24Sz = double g_a24Sy
                      (g_a24Sy, gpart_a24TD) = Genome.Split.split gpart_a24TC
                      p_a24Sx = Functions.belowten' g_a24Sw
                      (g_a24Sw, gpart_a24TC) = Genome.Split.split gpart_a24TB
                      p_a24Sv = double g_a24Su
                      (g_a24Su, gpart_a24TB) = Genome.Split.split gpart_a24TA
                      p_a24St = Functions.belowten' g_a24Ss
                      (g_a24Ss, gpart_a24TA) = Genome.Split.split gpart_a24Tz
                      p_a24Sr = double g_a24Sq
                      (g_a24Sq, gpart_a24Tz) = Genome.Split.split gpart_a24Ty
                      p_a24Sp = double g_a24So
                      (g_a24So, gpart_a24Ty) = Genome.Split.split gpart_a24Tx
                      p_a24Sn = double g_a24Sm
                      (g_a24Sm, gpart_a24Tx) = Genome.Split.split gpart_a24Tw
                      p_a24Sl = Functions.belowten' g_a24Sk
                      (g_a24Sk, gpart_a24Tw) = Genome.Split.split gpart_a24Tv
                      p_a24Sj = double g_a24Si
                      (g_a24Si, gpart_a24Tv) = Genome.Split.split gpart_a24Tu
                      p_a24Sh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sg
                      (g_a24Sg, gpart_a24Tu) = Genome.Split.split gpart_a24Tt
                      p_a24Sf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Se
                      (g_a24Se, gpart_a24Tt) = Genome.Split.split gpart_a24Ts
                      p_a24Sd = Functions.belowten' g_a24Sc
                      (g_a24Sc, gpart_a24Ts) = Genome.Split.split gpart_a24Tr
                      p_a24Sb = double g_a24Sa
                      (g_a24Sa, gpart_a24Tr) = Genome.Split.split gpart_a24Tq
                      p_a24S9 = double g_a24S8
                      (g_a24S8, gpart_a24Tq) = Genome.Split.split gpart_a24Tp
                      p_a24S7 = double g_a24S6
                      (g_a24S6, gpart_a24Tp) = Genome.Split.split gpart_a24To
                      p_a24S5 = double g_a24S4
                      (g_a24S4, gpart_a24To) = Genome.Split.split gpart_a24Tn
                      p_a24S3 = double g_a24S2
                      (g_a24S2, gpart_a24Tn) = Genome.Split.split gpart_a24Tm
                      p_a24S1 = double g_a24S0
                      (g_a24S0, gpart_a24Tm) = Genome.Split.split genome_a24Tk
                    in  \ x_a24U1
                          -> let
                               c_PTB_a24U6
                                 = ((Data.Fixed.Vector.toVector x_a24U1) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24U4
                                 = ((Data.Fixed.Vector.toVector x_a24U1) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24U2
                                 = ((Data.Fixed.Vector.toVector x_a24U1) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Ub
                                 = ((Data.Fixed.Vector.toVector x_a24U1) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Un
                                 = ((Data.Fixed.Vector.toVector x_a24U1) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24S9
                                     * ((p_a24Sn + ((c_NPTB_a24U2 / p_a24Sb) ** p_a24Sd))
                                        / (((1 + p_a24Sn) + ((c_NPTB_a24U2 / p_a24Sb) ** p_a24Sd))
                                           + (((p_a24S1 / p_a24Sf) ** p_a24Sh)
                                              + ((c_MiRs_a24U4 / p_a24Sj) ** p_a24Sl)))))
                                    + (negate (p_a24Tb * c_PTB_a24U6))),
                                   ((p_a24Sp
                                     / (1
                                        + (((c_MiRs_a24U4 / p_a24Sr) ** p_a24St)
                                           + ((c_PTB_a24U6 / p_a24Sv) ** p_a24Sx))))
                                    + (negate (p_a24Td * c_NPTB_a24U2))),
                                   ((p_a24Sz
                                     * (p_a24SJ
                                        / ((1 + p_a24SJ) + ((c_RESTc_a24Ub / p_a24SF) ** p_a24SH))))
                                    + (negate (p_a24Tf * c_MiRs_a24U4))),
                                   ((p_a24SL
                                     * ((p_a24T3
                                         + (((c_NPTB_a24U2 / p_a24SN) ** p_a24SP)
                                            + ((c_PTB_a24U6 / p_a24SR) ** p_a24ST)))
                                        / (((1 + p_a24T3)
                                            + (((c_NPTB_a24U2 / p_a24SN) ** p_a24SP)
                                               + ((c_PTB_a24U6 / p_a24SR) ** p_a24ST)))
                                           + ((c_MiRs_a24U4 / p_a24SZ) ** p_a24T1))))
                                    + (negate (p_a24Th * c_RESTc_a24Ub))),
                                   ((p_a24T5 / (1 + ((c_RESTc_a24Ub / p_a24T7) ** p_a24T9)))
                                    + (negate (p_a24Tj * c_EndoNeuroTFs_a24Un)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505187",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505189",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505209",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505211",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505229",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505231",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505247",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Tk
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24V2
                            p_a24Tj = double g_a24Ti
                            (g_a24Ti, gpart_a24V2) = Genome.Split.split gpart_a24V1
                            p_a24Th = double g_a24Tg
                            (g_a24Tg, gpart_a24V1) = Genome.Split.split gpart_a24V0
                            p_a24Tf = double g_a24Te
                            (g_a24Te, gpart_a24V0) = Genome.Split.split gpart_a24UZ
                            p_a24Td = double g_a24Tc
                            (g_a24Tc, gpart_a24UZ) = Genome.Split.split gpart_a24UY
                            p_a24Tb = double g_a24Ta
                            (g_a24Ta, gpart_a24UY) = Genome.Split.split gpart_a24UX
                            p_a24T9 = Functions.belowten' g_a24T8
                            (g_a24T8, gpart_a24UX) = Genome.Split.split gpart_a24UW
                            p_a24T7 = double g_a24T6
                            (g_a24T6, gpart_a24UW) = Genome.Split.split gpart_a24UV
                            p_a24T5 = double g_a24T4
                            (g_a24T4, gpart_a24UV) = Genome.Split.split gpart_a24UU
                            p_a24T3 = double g_a24T2
                            (g_a24T2, gpart_a24UU) = Genome.Split.split gpart_a24UT
                            p_a24T1 = Functions.belowten' g_a24T0
                            (g_a24T0, gpart_a24UT) = Genome.Split.split gpart_a24US
                            p_a24SZ = double g_a24SY
                            (g_a24SY, gpart_a24US) = Genome.Split.split gpart_a24UR
                            p_a24SX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SW
                            (g_a24SW, gpart_a24UR) = Genome.Split.split gpart_a24UQ
                            p_a24SV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SU
                            (g_a24SU, gpart_a24UQ) = Genome.Split.split gpart_a24UP
                            p_a24ST = Functions.belowten' g_a24SS
                            (g_a24SS, gpart_a24UP) = Genome.Split.split gpart_a24UO
                            p_a24SR = double g_a24SQ
                            (g_a24SQ, gpart_a24UO) = Genome.Split.split gpart_a24UN
                            p_a24SP = Functions.belowten' g_a24SO
                            (g_a24SO, gpart_a24UN) = Genome.Split.split gpart_a24UM
                            p_a24SN = double g_a24SM
                            (g_a24SM, gpart_a24UM) = Genome.Split.split gpart_a24UL
                            p_a24SL = double g_a24SK
                            (g_a24SK, gpart_a24UL) = Genome.Split.split gpart_a24UK
                            p_a24SJ = double g_a24SI
                            (g_a24SI, gpart_a24UK) = Genome.Split.split gpart_a24UJ
                            p_a24SH = Functions.belowten' g_a24SG
                            (g_a24SG, gpart_a24UJ) = Genome.Split.split gpart_a24UI
                            p_a24SF = double g_a24SE
                            (g_a24SE, gpart_a24UI) = Genome.Split.split gpart_a24UH
                            p_a24SD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SC
                            (g_a24SC, gpart_a24UH) = Genome.Split.split gpart_a24UG
                            p_a24SB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SA
                            (g_a24SA, gpart_a24UG) = Genome.Split.split gpart_a24UF
                            p_a24Sz = double g_a24Sy
                            (g_a24Sy, gpart_a24UF) = Genome.Split.split gpart_a24UE
                            p_a24Sx = Functions.belowten' g_a24Sw
                            (g_a24Sw, gpart_a24UE) = Genome.Split.split gpart_a24UD
                            p_a24Sv = double g_a24Su
                            (g_a24Su, gpart_a24UD) = Genome.Split.split gpart_a24UC
                            p_a24St = Functions.belowten' g_a24Ss
                            (g_a24Ss, gpart_a24UC) = Genome.Split.split gpart_a24UB
                            p_a24Sr = double g_a24Sq
                            (g_a24Sq, gpart_a24UB) = Genome.Split.split gpart_a24UA
                            p_a24Sp = double g_a24So
                            (g_a24So, gpart_a24UA) = Genome.Split.split gpart_a24Uz
                            p_a24Sn = double g_a24Sm
                            (g_a24Sm, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                            p_a24Sl = Functions.belowten' g_a24Sk
                            (g_a24Sk, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                            p_a24Sj = double g_a24Si
                            (g_a24Si, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                            p_a24Sh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sg
                            (g_a24Sg, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                            p_a24Sf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Se
                            (g_a24Se, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                            p_a24Sd = Functions.belowten' g_a24Sc
                            (g_a24Sc, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                            p_a24Sb = double g_a24Sa
                            (g_a24Sa, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                            p_a24S9 = double g_a24S8
                            (g_a24S8, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                            p_a24S7 = double g_a24S6
                            (g_a24S6, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                            p_a24S5 = double g_a24S4
                            (g_a24S4, gpart_a24Uq) = Genome.Split.split gpart_a24Up
                            p_a24S3 = double g_a24S2
                            (g_a24S2, gpart_a24Up) = Genome.Split.split gpart_a24Uo
                            p_a24S1 = double g_a24S0
                            (g_a24S0, gpart_a24Uo) = Genome.Split.split genome_a24Tk
                          in
                            \ desc_a24Tl
                              -> case desc_a24Tl of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S1)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S3)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S5)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S7)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S9)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sb)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sd)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sf)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sh)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sj)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sl)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sn)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sp)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sr)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24St)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sv)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sx)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sz)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SB)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SD)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SF)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SH)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SJ)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SL)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SN)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SP)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SR)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ST)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SV)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SX)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SZ)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T1)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T3)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T5)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T7)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T9)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tb)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Td)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tf)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Th)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tj)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asV6
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVM
                      p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                      (g_asV4, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                      (g_asV2, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                      (g_asV0, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                      (g_asUY, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUX = code-0.1.0.0:Genome.FixedList.Functions.double g_asUW
                      (g_asUW, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUV = Functions.belowten' g_asUU
                      (g_asUU, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                      (g_asUS, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                      (g_asUQ, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUP = code-0.1.0.0:Genome.FixedList.Functions.double g_asUO
                      (g_asUO, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUN = Functions.belowten' g_asUM
                      (g_asUM, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUL = code-0.1.0.0:Genome.FixedList.Functions.double g_asUK
                      (g_asUK, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUI
                      (g_asUI, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUG
                      (g_asUG, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUF = Functions.belowten' g_asUE
                      (g_asUE, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                      (g_asUC, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUB = Functions.belowten' g_asUA
                      (g_asUA, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                      (g_asUy, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                      (g_asUw, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                      (g_asUu, gpart_asVu) = Genome.Split.split gpart_asVt
                      p_asUt = Functions.belowten' g_asUs
                      (g_asUs, gpart_asVt) = Genome.Split.split gpart_asVs
                      p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                      (g_asUq, gpart_asVs) = Genome.Split.split gpart_asVr
                      p_asUp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUo
                      (g_asUo, gpart_asVr) = Genome.Split.split gpart_asVq
                      p_asUn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                      (g_asUm, gpart_asVq) = Genome.Split.split gpart_asVp
                      p_asUl = code-0.1.0.0:Genome.FixedList.Functions.double g_asUk
                      (g_asUk, gpart_asVp) = Genome.Split.split gpart_asVo
                      p_asUj = Functions.belowten' g_asUi
                      (g_asUi, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                      (g_asUg, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asUf = Functions.belowten' g_asUe
                      (g_asUe, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                      (g_asUa, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                      (g_asU8, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asU7 = Functions.belowten' g_asU6
                      (g_asU6, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                      (g_asU4, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asU3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU2
                      (g_asU2, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asU1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU0
                      (g_asU0, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asTZ = Functions.belowten' g_asTY
                      (g_asTY, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                      (g_asTW, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                      (g_asTU, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                      (g_asTS, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                      (g_asTQ, gpart_asVa) = Genome.Split.split gpart_asV9
                      p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                      (g_asTO, gpart_asV9) = Genome.Split.split gpart_asV8
                      p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                      (g_asTM, gpart_asV8) = Genome.Split.split genome_asV6
                    in
                      [Reaction
                         (\ x_asVN
                            -> let
                                 c_MiRs_asVQ = ((toVector x_asVN) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asVO = ((toVector x_asVN) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asTV
                                  * ((p_asU9 + ((c_NPTB_asVO / p_asTX) ** p_asTZ))
                                     / (((1 + p_asU9) + ((c_NPTB_asVO / p_asTX) ** p_asTZ))
                                        + ((c_MiRs_asVQ / p_asU5) ** p_asU7)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVR
                            -> let
                                 c_MiRs_asVS = ((toVector x_asVR) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVT = ((toVector x_asVR) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUb
                                  / (1
                                     + (((c_MiRs_asVS / p_asUd) ** p_asUf)
                                        + ((c_PTB_asVT / p_asUh) ** p_asUj)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVU
                            -> let c_RESTc_asVV = ((toVector x_asVU) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUl
                                  * ((p_asUv + ((p_asTR / p_asUn) ** p_asUp))
                                     / (((1 + p_asUv) + ((p_asTR / p_asUn) ** p_asUp))
                                        + ((c_RESTc_asVV / p_asUr) ** p_asUt)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVW
                            -> let
                                 c_MiRs_asW1 = ((toVector x_asVW) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVY = ((toVector x_asVW) Data.Vector.Unboxed.! 0)
                                 c_NPTB_asVX = ((toVector x_asVW) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asUx
                                  * ((p_asUP
                                      + (((c_NPTB_asVX / p_asUz) ** p_asUB)
                                         + ((c_PTB_asVY / p_asUD) ** p_asUF)))
                                     / (((1 + p_asUP)
                                         + (((c_NPTB_asVX / p_asUz) ** p_asUB)
                                            + ((c_PTB_asVY / p_asUD) ** p_asUF)))
                                        + (((p_asTN / p_asUH) ** p_asUJ)
                                           + ((c_MiRs_asW1 / p_asUL) ** p_asUN))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asW2
                            -> let c_RESTc_asW3 = ((toVector x_asW2) Data.Vector.Unboxed.! 3)
                               in (p_asUR / (1 + ((c_RESTc_asW3 / p_asUT) ** p_asUV))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asW4
                            -> let c_PTB_asW5 = ((toVector x_asW4) Data.Vector.Unboxed.! 0)
                               in (p_asUX * c_PTB_asW5))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asW6
                            -> let c_NPTB_asW7 = ((toVector x_asW6) Data.Vector.Unboxed.! 1)
                               in (p_asUZ * c_NPTB_asW7))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asW8
                            -> let c_MiRs_asW9 = ((toVector x_asW8) Data.Vector.Unboxed.! 2)
                               in (p_asV1 * c_MiRs_asW9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWa
                            -> let c_RESTc_asWb = ((toVector x_asWa) Data.Vector.Unboxed.! 3)
                               in (p_asV3 * c_RESTc_asWb))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWc
                            -> let
                                 c_EndoNeuroTFs_asWd = ((toVector x_asWc) Data.Vector.Unboxed.! 4)
                               in (p_asV5 * c_EndoNeuroTFs_asWd))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120897",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120899",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120939",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120941",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120957",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asV6
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWX
                            p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                            (g_asV4, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                            (g_asV2, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                            (g_asV0, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                            (g_asUY, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUX = code-0.1.0.0:Genome.FixedList.Functions.double g_asUW
                            (g_asUW, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUV = Functions.belowten' g_asUU
                            (g_asUU, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                            (g_asUS, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                            (g_asUQ, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUP = code-0.1.0.0:Genome.FixedList.Functions.double g_asUO
                            (g_asUO, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUN = Functions.belowten' g_asUM
                            (g_asUM, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUL = code-0.1.0.0:Genome.FixedList.Functions.double g_asUK
                            (g_asUK, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUI
                            (g_asUI, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUG
                            (g_asUG, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUF = Functions.belowten' g_asUE
                            (g_asUE, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                            (g_asUC, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUB = Functions.belowten' g_asUA
                            (g_asUA, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                            (g_asUy, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                            (g_asUw, gpart_asWG) = Genome.Split.split gpart_asWF
                            p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                            (g_asUu, gpart_asWF) = Genome.Split.split gpart_asWE
                            p_asUt = Functions.belowten' g_asUs
                            (g_asUs, gpart_asWE) = Genome.Split.split gpart_asWD
                            p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                            (g_asUq, gpart_asWD) = Genome.Split.split gpart_asWC
                            p_asUp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUo
                            (g_asUo, gpart_asWC) = Genome.Split.split gpart_asWB
                            p_asUn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                            (g_asUm, gpart_asWB) = Genome.Split.split gpart_asWA
                            p_asUl = code-0.1.0.0:Genome.FixedList.Functions.double g_asUk
                            (g_asUk, gpart_asWA) = Genome.Split.split gpart_asWz
                            p_asUj = Functions.belowten' g_asUi
                            (g_asUi, gpart_asWz) = Genome.Split.split gpart_asWy
                            p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                            (g_asUg, gpart_asWy) = Genome.Split.split gpart_asWx
                            p_asUf = Functions.belowten' g_asUe
                            (g_asUe, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                            (g_asUa, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                            (g_asU8, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asU7 = Functions.belowten' g_asU6
                            (g_asU6, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                            (g_asU4, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asU3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU2
                            (g_asU2, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asU1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU0
                            (g_asU0, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asTZ = Functions.belowten' g_asTY
                            (g_asTY, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                            (g_asTW, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                            (g_asTU, gpart_asWn) = Genome.Split.split gpart_asWm
                            p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                            (g_asTS, gpart_asWm) = Genome.Split.split gpart_asWl
                            p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                            (g_asTQ, gpart_asWl) = Genome.Split.split gpart_asWk
                            p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                            (g_asTO, gpart_asWk) = Genome.Split.split gpart_asWj
                            p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                            (g_asTM, gpart_asWj) = Genome.Split.split genome_asV6
                          in
                            \ desc_asV7
                              -> case desc_asV7 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTN)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTP)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTR)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTT)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTV)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTX)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTZ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU1)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU3)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU5)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUH)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUJ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUL)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUN)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUP)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUR)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUT)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUV)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUX)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUZ)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV1)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV5)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYY
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZE
                      p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                      (g_asYW, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                      (g_asYU, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYT = code-0.1.0.0:Genome.FixedList.Functions.double g_asYS
                      (g_asYS, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                      (g_asYQ, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYP = code-0.1.0.0:Genome.FixedList.Functions.double g_asYO
                      (g_asYO, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYN = Functions.belowten' g_asYM
                      (g_asYM, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                      (g_asYK, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                      (g_asYI, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                      (g_asYG, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYF = Functions.belowten' g_asYE
                      (g_asYE, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                      (g_asYC, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYA
                      (g_asYA, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYy
                      (g_asYy, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asYx = Functions.belowten' g_asYw
                      (g_asYw, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                      (g_asYu, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asYt = Functions.belowten' g_asYs
                      (g_asYs, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                      (g_asYq, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                      (g_asYo, gpart_asZn) = Genome.Split.split gpart_asZm
                      p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                      (g_asYm, gpart_asZm) = Genome.Split.split gpart_asZl
                      p_asYl = Functions.belowten' g_asYk
                      (g_asYk, gpart_asZl) = Genome.Split.split gpart_asZk
                      p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                      (g_asYi, gpart_asZk) = Genome.Split.split gpart_asZj
                      p_asYh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYg
                      (g_asYg, gpart_asZj) = Genome.Split.split gpart_asZi
                      p_asYf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYe
                      (g_asYe, gpart_asZi) = Genome.Split.split gpart_asZh
                      p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                      (g_asYc, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asYb = Functions.belowten' g_asYa
                      (g_asYa, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                      (g_asY8, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asY7 = Functions.belowten' g_asY6
                      (g_asY6, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                      (g_asY4, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                      (g_asY2, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                      (g_asY0, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asXZ = Functions.belowten' g_asXY
                      (g_asXY, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                      (g_asXW, gpart_asZ9) = Genome.Split.split gpart_asZ8
                      p_asXV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXU
                      (g_asXU, gpart_asZ8) = Genome.Split.split gpart_asZ7
                      p_asXT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXS
                      (g_asXS, gpart_asZ7) = Genome.Split.split gpart_asZ6
                      p_asXR = Functions.belowten' g_asXQ
                      (g_asXQ, gpart_asZ6) = Genome.Split.split gpart_asZ5
                      p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                      (g_asXO, gpart_asZ5) = Genome.Split.split gpart_asZ4
                      p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                      (g_asXM, gpart_asZ4) = Genome.Split.split gpart_asZ3
                      p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                      (g_asXK, gpart_asZ3) = Genome.Split.split gpart_asZ2
                      p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                      (g_asXI, gpart_asZ2) = Genome.Split.split gpart_asZ1
                      p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                      (g_asXG, gpart_asZ1) = Genome.Split.split gpart_asZ0
                      p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                      (g_asXE, gpart_asZ0) = Genome.Split.split genome_asYY
                    in
                      [Reaction
                         (\ x_asZF
                            -> let
                                 c_MiRs_asZI = ((toVector x_asZF) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asZG = ((toVector x_asZF) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asXN
                                  * ((p_asY1 + ((c_NPTB_asZG / p_asXP) ** p_asXR))
                                     / (((1 + p_asY1) + ((c_NPTB_asZG / p_asXP) ** p_asXR))
                                        + ((c_MiRs_asZI / p_asXX) ** p_asXZ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZJ
                            -> let
                                 c_MiRs_asZK = ((toVector x_asZJ) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZL = ((toVector x_asZJ) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asY3
                                  / (1
                                     + (((c_MiRs_asZK / p_asY5) ** p_asY7)
                                        + ((c_PTB_asZL / p_asY9) ** p_asYb)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZM
                            -> let c_RESTc_asZN = ((toVector x_asZM) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYd
                                  * (p_asYn
                                     / ((1 + p_asYn) + ((c_RESTc_asZN / p_asYj) ** p_asYl)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZO
                            -> let
                                 c_MiRs_asZT = ((toVector x_asZO) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZQ = ((toVector x_asZO) Data.Vector.Unboxed.! 0)
                                 c_NPTB_asZP = ((toVector x_asZO) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asYp
                                  * ((p_asYH
                                      + (((c_NPTB_asZP / p_asYr) ** p_asYt)
                                         + ((c_PTB_asZQ / p_asYv) ** p_asYx)))
                                     / (((1 + p_asYH)
                                         + (((c_NPTB_asZP / p_asYr) ** p_asYt)
                                            + ((c_PTB_asZQ / p_asYv) ** p_asYx)))
                                        + (((p_asXF / p_asYz) ** p_asYB)
                                           + ((c_MiRs_asZT / p_asYD) ** p_asYF))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZU
                            -> let c_RESTc_asZV = ((toVector x_asZU) Data.Vector.Unboxed.! 3)
                               in (p_asYJ / (1 + ((c_RESTc_asZV / p_asYL) ** p_asYN))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZW
                            -> let c_PTB_asZX = ((toVector x_asZW) Data.Vector.Unboxed.! 0)
                               in (p_asYP * c_PTB_asZX))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZY
                            -> let c_NPTB_asZZ = ((toVector x_asZY) Data.Vector.Unboxed.! 1)
                               in (p_asYR * c_NPTB_asZZ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at00
                            -> let c_MiRs_at01 = ((toVector x_at00) Data.Vector.Unboxed.! 2)
                               in (p_asYT * c_MiRs_at01))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at02
                            -> let c_RESTc_at03 = ((toVector x_at02) Data.Vector.Unboxed.! 3)
                               in (p_asYV * c_RESTc_at03))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at04
                            -> let
                                 c_EndoNeuroTFs_at05 = ((toVector x_at04) Data.Vector.Unboxed.! 4)
                               in (p_asYX * c_EndoNeuroTFs_at05))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121137",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121139",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121179",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121181",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYY
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0K
                            p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                            (g_asYW, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                            (g_asYU, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYT = code-0.1.0.0:Genome.FixedList.Functions.double g_asYS
                            (g_asYS, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                            (g_asYQ, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYP = code-0.1.0.0:Genome.FixedList.Functions.double g_asYO
                            (g_asYO, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYN = Functions.belowten' g_asYM
                            (g_asYM, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                            (g_asYK, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                            (g_asYI, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                            (g_asYG, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYF = Functions.belowten' g_asYE
                            (g_asYE, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                            (g_asYC, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYA
                            (g_asYA, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYy
                            (g_asYy, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asYx = Functions.belowten' g_asYw
                            (g_asYw, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                            (g_asYu, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asYt = Functions.belowten' g_asYs
                            (g_asYs, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                            (g_asYq, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                            (g_asYo, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                            (g_asYm, gpart_at0s) = Genome.Split.split gpart_at0r
                            p_asYl = Functions.belowten' g_asYk
                            (g_asYk, gpart_at0r) = Genome.Split.split gpart_at0q
                            p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                            (g_asYi, gpart_at0q) = Genome.Split.split gpart_at0p
                            p_asYh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYg
                            (g_asYg, gpart_at0p) = Genome.Split.split gpart_at0o
                            p_asYf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYe
                            (g_asYe, gpart_at0o) = Genome.Split.split gpart_at0n
                            p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                            (g_asYc, gpart_at0n) = Genome.Split.split gpart_at0m
                            p_asYb = Functions.belowten' g_asYa
                            (g_asYa, gpart_at0m) = Genome.Split.split gpart_at0l
                            p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                            (g_asY8, gpart_at0l) = Genome.Split.split gpart_at0k
                            p_asY7 = Functions.belowten' g_asY6
                            (g_asY6, gpart_at0k) = Genome.Split.split gpart_at0j
                            p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                            (g_asY4, gpart_at0j) = Genome.Split.split gpart_at0i
                            p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                            (g_asY2, gpart_at0i) = Genome.Split.split gpart_at0h
                            p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                            (g_asY0, gpart_at0h) = Genome.Split.split gpart_at0g
                            p_asXZ = Functions.belowten' g_asXY
                            (g_asXY, gpart_at0g) = Genome.Split.split gpart_at0f
                            p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                            (g_asXW, gpart_at0f) = Genome.Split.split gpart_at0e
                            p_asXV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXU
                            (g_asXU, gpart_at0e) = Genome.Split.split gpart_at0d
                            p_asXT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXS
                            (g_asXS, gpart_at0d) = Genome.Split.split gpart_at0c
                            p_asXR = Functions.belowten' g_asXQ
                            (g_asXQ, gpart_at0c) = Genome.Split.split gpart_at0b
                            p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                            (g_asXO, gpart_at0b) = Genome.Split.split gpart_at0a
                            p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                            (g_asXM, gpart_at0a) = Genome.Split.split gpart_at09
                            p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                            (g_asXK, gpart_at09) = Genome.Split.split gpart_at08
                            p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                            (g_asXI, gpart_at08) = Genome.Split.split gpart_at07
                            p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                            (g_asXG, gpart_at07) = Genome.Split.split gpart_at06
                            p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                            (g_asXE, gpart_at06) = Genome.Split.split genome_asYY
                          in
                            \ desc_asYZ
                              -> case desc_asYZ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXF)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXH)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXP)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXR)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXT)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXV)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXX)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXZ)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY1)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYz)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYB)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYF)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYH)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYJ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYL)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYN)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYP)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYR)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYT)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYV)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYX)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at2L
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3r
                      p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                      (g_at2J, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                      (g_at2H, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                      (g_at2F, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                      (g_at2D, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                      (g_at2B, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2A = Functions.belowten' g_at2z
                      (g_at2z, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                      (g_at2x, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                      (g_at2v, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at2u = code-0.1.0.0:Genome.FixedList.Functions.double g_at2t
                      (g_at2t, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at2s = Functions.belowten' g_at2r
                      (g_at2r, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                      (g_at2p, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at2o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2n
                      (g_at2n, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at2m
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2l
                      (g_at2l, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at2k = Functions.belowten' g_at2j
                      (g_at2j, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                      (g_at2h, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at2g = Functions.belowten' g_at2f
                      (g_at2f, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                      (g_at2d, gpart_at3b) = Genome.Split.split gpart_at3a
                      p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                      (g_at2b, gpart_at3a) = Genome.Split.split gpart_at39
                      p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                      (g_at29, gpart_at39) = Genome.Split.split gpart_at38
                      p_at28 = Functions.belowten' g_at27
                      (g_at27, gpart_at38) = Genome.Split.split gpart_at37
                      p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                      (g_at25, gpart_at37) = Genome.Split.split gpart_at36
                      p_at24
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at23
                      (g_at23, gpart_at36) = Genome.Split.split gpart_at35
                      p_at22
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at21
                      (g_at21, gpart_at35) = Genome.Split.split gpart_at34
                      p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                      (g_at1Z, gpart_at34) = Genome.Split.split gpart_at33
                      p_at1Y = Functions.belowten' g_at1X
                      (g_at1X, gpart_at33) = Genome.Split.split gpart_at32
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at32) = Genome.Split.split gpart_at31
                      p_at1U = Functions.belowten' g_at1T
                      (g_at1T, gpart_at31) = Genome.Split.split gpart_at30
                      p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                      (g_at1R, gpart_at30) = Genome.Split.split gpart_at2Z
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at2Z) = Genome.Split.split gpart_at2Y
                      p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                      (g_at1N, gpart_at2Y) = Genome.Split.split gpart_at2X
                      p_at1M = Functions.belowten' g_at1L
                      (g_at1L, gpart_at2X) = Genome.Split.split gpart_at2W
                      p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                      (g_at1J, gpart_at2W) = Genome.Split.split gpart_at2V
                      p_at1I
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1H
                      (g_at1H, gpart_at2V) = Genome.Split.split gpart_at2U
                      p_at1G
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1F
                      (g_at1F, gpart_at2U) = Genome.Split.split gpart_at2T
                      p_at1E = Functions.belowten' g_at1D
                      (g_at1D, gpart_at2T) = Genome.Split.split gpart_at2S
                      p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                      (g_at1B, gpart_at2S) = Genome.Split.split gpart_at2R
                      p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                      (g_at1z, gpart_at2R) = Genome.Split.split gpart_at2Q
                      p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                      (g_at1x, gpart_at2Q) = Genome.Split.split gpart_at2P
                      p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                      (g_at1v, gpart_at2P) = Genome.Split.split gpart_at2O
                      p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                      (g_at1t, gpart_at2O) = Genome.Split.split gpart_at2N
                      p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                      (g_at1r, gpart_at2N) = Genome.Split.split genome_at2L
                    in
                      [Reaction
                         (\ x_at3s
                            -> let
                                 c_MiRs_at3v = ((toVector x_at3s) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at3t = ((toVector x_at3s) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at1A
                                  * ((p_at1O + ((c_NPTB_at3t / p_at1C) ** p_at1E))
                                     / (((1 + p_at1O) + ((c_NPTB_at3t / p_at1C) ** p_at1E))
                                        + ((c_MiRs_at3v / p_at1K) ** p_at1M)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3w
                            -> let
                                 c_MiRs_at3x = ((toVector x_at3w) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3y = ((toVector x_at3w) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1Q
                                  / (1
                                     + (((c_MiRs_at3x / p_at1S) ** p_at1U)
                                        + ((c_PTB_at3y / p_at1W) ** p_at1Y)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3z
                            -> let c_RESTc_at3A = ((toVector x_at3z) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at20
                                  * (p_at2a
                                     / ((1 + p_at2a) + ((c_RESTc_at3A / p_at26) ** p_at28)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3B
                            -> let
                                 c_MiRs_at3G = ((toVector x_at3B) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3D = ((toVector x_at3B) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at3C = ((toVector x_at3B) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at2c
                                  * ((p_at2u
                                      + (((c_NPTB_at3C / p_at2e) ** p_at2g)
                                         + ((c_PTB_at3D / p_at2i) ** p_at2k)))
                                     / (((1 + p_at2u)
                                         + (((c_NPTB_at3C / p_at2e) ** p_at2g)
                                            + ((c_PTB_at3D / p_at2i) ** p_at2k)))
                                        + ((c_MiRs_at3G / p_at2q) ** p_at2s)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3H
                            -> let c_RESTc_at3I = ((toVector x_at3H) Data.Vector.Unboxed.! 3)
                               in (p_at2w / (1 + ((c_RESTc_at3I / p_at2y) ** p_at2A))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at3J
                            -> let c_PTB_at3K = ((toVector x_at3J) Data.Vector.Unboxed.! 0)
                               in (p_at2C * c_PTB_at3K))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3L
                            -> let c_NPTB_at3M = ((toVector x_at3L) Data.Vector.Unboxed.! 1)
                               in (p_at2E * c_NPTB_at3M))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at3N
                            -> let c_MiRs_at3O = ((toVector x_at3N) Data.Vector.Unboxed.! 2)
                               in (p_at2G * c_MiRs_at3O))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at3P
                            -> let c_RESTc_at3Q = ((toVector x_at3P) Data.Vector.Unboxed.! 3)
                               in (p_at2I * c_RESTc_at3Q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at3R
                            -> let
                                 c_EndoNeuroTFs_at3S = ((toVector x_at3R) Data.Vector.Unboxed.! 4)
                               in (p_at2K * c_EndoNeuroTFs_at3S))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121364",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2L
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4x
                            p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                            (g_at2J, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                            (g_at2H, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                            (g_at2F, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                            (g_at2D, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                            (g_at2B, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at2A = Functions.belowten' g_at2z
                            (g_at2z, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                            (g_at2x, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                            (g_at2v, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at2u = code-0.1.0.0:Genome.FixedList.Functions.double g_at2t
                            (g_at2t, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at2s = Functions.belowten' g_at2r
                            (g_at2r, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                            (g_at2p, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at2o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2n
                            (g_at2n, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at2m
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2l
                            (g_at2l, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at2k = Functions.belowten' g_at2j
                            (g_at2j, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                            (g_at2h, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at2g = Functions.belowten' g_at2f
                            (g_at2f, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                            (g_at2d, gpart_at4h) = Genome.Split.split gpart_at4g
                            p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                            (g_at2b, gpart_at4g) = Genome.Split.split gpart_at4f
                            p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                            (g_at29, gpart_at4f) = Genome.Split.split gpart_at4e
                            p_at28 = Functions.belowten' g_at27
                            (g_at27, gpart_at4e) = Genome.Split.split gpart_at4d
                            p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                            (g_at25, gpart_at4d) = Genome.Split.split gpart_at4c
                            p_at24
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at23
                            (g_at23, gpart_at4c) = Genome.Split.split gpart_at4b
                            p_at22
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at21
                            (g_at21, gpart_at4b) = Genome.Split.split gpart_at4a
                            p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                            (g_at1Z, gpart_at4a) = Genome.Split.split gpart_at49
                            p_at1Y = Functions.belowten' g_at1X
                            (g_at1X, gpart_at49) = Genome.Split.split gpart_at48
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at48) = Genome.Split.split gpart_at47
                            p_at1U = Functions.belowten' g_at1T
                            (g_at1T, gpart_at47) = Genome.Split.split gpart_at46
                            p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                            (g_at1R, gpart_at46) = Genome.Split.split gpart_at45
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at45) = Genome.Split.split gpart_at44
                            p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                            (g_at1N, gpart_at44) = Genome.Split.split gpart_at43
                            p_at1M = Functions.belowten' g_at1L
                            (g_at1L, gpart_at43) = Genome.Split.split gpart_at42
                            p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                            (g_at1J, gpart_at42) = Genome.Split.split gpart_at41
                            p_at1I
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1H
                            (g_at1H, gpart_at41) = Genome.Split.split gpart_at40
                            p_at1G
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1F
                            (g_at1F, gpart_at40) = Genome.Split.split gpart_at3Z
                            p_at1E = Functions.belowten' g_at1D
                            (g_at1D, gpart_at3Z) = Genome.Split.split gpart_at3Y
                            p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                            (g_at1B, gpart_at3Y) = Genome.Split.split gpart_at3X
                            p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                            (g_at1z, gpart_at3X) = Genome.Split.split gpart_at3W
                            p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                            (g_at1x, gpart_at3W) = Genome.Split.split gpart_at3V
                            p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                            (g_at1v, gpart_at3V) = Genome.Split.split gpart_at3U
                            p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                            (g_at1t, gpart_at3U) = Genome.Split.split gpart_at3T
                            p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                            (g_at1r, gpart_at3T) = Genome.Split.split genome_at2L
                          in
                            \ desc_at2M
                              -> case desc_at2M of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1s)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1u)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1w)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1y)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2u)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2w)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2y)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2A)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2C)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2E)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2G)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at6y
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7e
                      p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                      (g_at6w, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                      (g_at6u, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at6t = code-0.1.0.0:Genome.FixedList.Functions.double g_at6s
                      (g_at6s, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at6r = code-0.1.0.0:Genome.FixedList.Functions.double g_at6q
                      (g_at6q, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                      (g_at6o, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at6n = Functions.belowten' g_at6m
                      (g_at6m, gpart_at79) = Genome.Split.split gpart_at78
                      p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                      (g_at6k, gpart_at78) = Genome.Split.split gpart_at77
                      p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                      (g_at6i, gpart_at77) = Genome.Split.split gpart_at76
                      p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                      (g_at6g, gpart_at76) = Genome.Split.split gpart_at75
                      p_at6f = Functions.belowten' g_at6e
                      (g_at6e, gpart_at75) = Genome.Split.split gpart_at74
                      p_at6d = code-0.1.0.0:Genome.FixedList.Functions.double g_at6c
                      (g_at6c, gpart_at74) = Genome.Split.split gpart_at73
                      p_at6b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6a
                      (g_at6a, gpart_at73) = Genome.Split.split gpart_at72
                      p_at69
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at68
                      (g_at68, gpart_at72) = Genome.Split.split gpart_at71
                      p_at67 = Functions.belowten' g_at66
                      (g_at66, gpart_at71) = Genome.Split.split gpart_at70
                      p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                      (g_at64, gpart_at70) = Genome.Split.split gpart_at6Z
                      p_at63 = Functions.belowten' g_at62
                      (g_at62, gpart_at6Z) = Genome.Split.split gpart_at6Y
                      p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                      (g_at60, gpart_at6Y) = Genome.Split.split gpart_at6X
                      p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                      (g_at5Y, gpart_at6X) = Genome.Split.split gpart_at6W
                      p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                      (g_at5W, gpart_at6W) = Genome.Split.split gpart_at6V
                      p_at5V = Functions.belowten' g_at5U
                      (g_at5U, gpart_at6V) = Genome.Split.split gpart_at6U
                      p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                      (g_at5S, gpart_at6U) = Genome.Split.split gpart_at6T
                      p_at5R
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5Q
                      (g_at5Q, gpart_at6T) = Genome.Split.split gpart_at6S
                      p_at5P
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5O
                      (g_at5O, gpart_at6S) = Genome.Split.split gpart_at6R
                      p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                      (g_at5M, gpart_at6R) = Genome.Split.split gpart_at6Q
                      p_at5L = Functions.belowten' g_at5K
                      (g_at5K, gpart_at6Q) = Genome.Split.split gpart_at6P
                      p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                      (g_at5I, gpart_at6P) = Genome.Split.split gpart_at6O
                      p_at5H = Functions.belowten' g_at5G
                      (g_at5G, gpart_at6O) = Genome.Split.split gpart_at6N
                      p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                      (g_at5E, gpart_at6N) = Genome.Split.split gpart_at6M
                      p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                      (g_at5C, gpart_at6M) = Genome.Split.split gpart_at6L
                      p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                      (g_at5A, gpart_at6L) = Genome.Split.split gpart_at6K
                      p_at5z = Functions.belowten' g_at5y
                      (g_at5y, gpart_at6K) = Genome.Split.split gpart_at6J
                      p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                      (g_at5w, gpart_at6J) = Genome.Split.split gpart_at6I
                      p_at5v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5u
                      (g_at5u, gpart_at6I) = Genome.Split.split gpart_at6H
                      p_at5t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5s
                      (g_at5s, gpart_at6H) = Genome.Split.split gpart_at6G
                      p_at5r = Functions.belowten' g_at5q
                      (g_at5q, gpart_at6G) = Genome.Split.split gpart_at6F
                      p_at5p = code-0.1.0.0:Genome.FixedList.Functions.double g_at5o
                      (g_at5o, gpart_at6F) = Genome.Split.split gpart_at6E
                      p_at5n = code-0.1.0.0:Genome.FixedList.Functions.double g_at5m
                      (g_at5m, gpart_at6E) = Genome.Split.split gpart_at6D
                      p_at5l = code-0.1.0.0:Genome.FixedList.Functions.double g_at5k
                      (g_at5k, gpart_at6D) = Genome.Split.split gpart_at6C
                      p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                      (g_at5i, gpart_at6C) = Genome.Split.split gpart_at6B
                      p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                      (g_at5g, gpart_at6B) = Genome.Split.split gpart_at6A
                      p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                      (g_at5e, gpart_at6A) = Genome.Split.split genome_at6y
                    in
                      [Reaction
                         (\ x_at7f
                            -> let
                                 c_MiRs_at7i = ((toVector x_at7f) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at7g = ((toVector x_at7f) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at5n
                                  * ((p_at5B + ((c_NPTB_at7g / p_at5p) ** p_at5r))
                                     / (((1 + p_at5B) + ((c_NPTB_at7g / p_at5p) ** p_at5r))
                                        + (((p_at5f / p_at5t) ** p_at5v)
                                           + ((c_MiRs_at7i / p_at5x) ** p_at5z))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7j
                            -> let
                                 c_MiRs_at7k = ((toVector x_at7j) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7l = ((toVector x_at7j) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5D
                                  / (1
                                     + (((c_MiRs_at7k / p_at5F) ** p_at5H)
                                        + ((c_PTB_at7l / p_at5J) ** p_at5L)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7m
                            -> let c_RESTc_at7n = ((toVector x_at7m) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at5N
                                  * (p_at5X
                                     / ((1 + p_at5X) + ((c_RESTc_at7n / p_at5T) ** p_at5V)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7o
                            -> let
                                 c_MiRs_at7t = ((toVector x_at7o) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7q = ((toVector x_at7o) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at7p = ((toVector x_at7o) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at5Z
                                  * ((p_at6h
                                      + (((c_NPTB_at7p / p_at61) ** p_at63)
                                         + ((c_PTB_at7q / p_at65) ** p_at67)))
                                     / (((1 + p_at6h)
                                         + (((c_NPTB_at7p / p_at61) ** p_at63)
                                            + ((c_PTB_at7q / p_at65) ** p_at67)))
                                        + ((c_MiRs_at7t / p_at6d) ** p_at6f)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7u
                            -> let c_RESTc_at7v = ((toVector x_at7u) Data.Vector.Unboxed.! 3)
                               in (p_at6j / (1 + ((c_RESTc_at7v / p_at6l) ** p_at6n))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at7w
                            -> let c_PTB_at7x = ((toVector x_at7w) Data.Vector.Unboxed.! 0)
                               in (p_at6p * c_PTB_at7x))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7y
                            -> let c_NPTB_at7z = ((toVector x_at7y) Data.Vector.Unboxed.! 1)
                               in (p_at6r * c_NPTB_at7z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at7A
                            -> let c_MiRs_at7B = ((toVector x_at7A) Data.Vector.Unboxed.! 2)
                               in (p_at6t * c_MiRs_at7B))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at7C
                            -> let c_RESTc_at7D = ((toVector x_at7C) Data.Vector.Unboxed.! 3)
                               in (p_at6v * c_RESTc_at7D))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at7E
                            -> let
                                 c_EndoNeuroTFs_at7F = ((toVector x_at7E) Data.Vector.Unboxed.! 4)
                               in (p_at6x * c_EndoNeuroTFs_at7F))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121599",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121607",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121609",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121629",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121631",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121647",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121649",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121651",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6y
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8k
                            p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                            (g_at6w, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                            (g_at6u, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at6t = code-0.1.0.0:Genome.FixedList.Functions.double g_at6s
                            (g_at6s, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at6r = code-0.1.0.0:Genome.FixedList.Functions.double g_at6q
                            (g_at6q, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                            (g_at6o, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at6n = Functions.belowten' g_at6m
                            (g_at6m, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                            (g_at6k, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                            (g_at6i, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                            (g_at6g, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at6f = Functions.belowten' g_at6e
                            (g_at6e, gpart_at8b) = Genome.Split.split gpart_at8a
                            p_at6d = code-0.1.0.0:Genome.FixedList.Functions.double g_at6c
                            (g_at6c, gpart_at8a) = Genome.Split.split gpart_at89
                            p_at6b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6a
                            (g_at6a, gpart_at89) = Genome.Split.split gpart_at88
                            p_at69
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at68
                            (g_at68, gpart_at88) = Genome.Split.split gpart_at87
                            p_at67 = Functions.belowten' g_at66
                            (g_at66, gpart_at87) = Genome.Split.split gpart_at86
                            p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                            (g_at64, gpart_at86) = Genome.Split.split gpart_at85
                            p_at63 = Functions.belowten' g_at62
                            (g_at62, gpart_at85) = Genome.Split.split gpart_at84
                            p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                            (g_at60, gpart_at84) = Genome.Split.split gpart_at83
                            p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                            (g_at5Y, gpart_at83) = Genome.Split.split gpart_at82
                            p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                            (g_at5W, gpart_at82) = Genome.Split.split gpart_at81
                            p_at5V = Functions.belowten' g_at5U
                            (g_at5U, gpart_at81) = Genome.Split.split gpart_at80
                            p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                            (g_at5S, gpart_at80) = Genome.Split.split gpart_at7Z
                            p_at5R
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5Q
                            (g_at5Q, gpart_at7Z) = Genome.Split.split gpart_at7Y
                            p_at5P
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5O
                            (g_at5O, gpart_at7Y) = Genome.Split.split gpart_at7X
                            p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                            (g_at5M, gpart_at7X) = Genome.Split.split gpart_at7W
                            p_at5L = Functions.belowten' g_at5K
                            (g_at5K, gpart_at7W) = Genome.Split.split gpart_at7V
                            p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                            (g_at5I, gpart_at7V) = Genome.Split.split gpart_at7U
                            p_at5H = Functions.belowten' g_at5G
                            (g_at5G, gpart_at7U) = Genome.Split.split gpart_at7T
                            p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                            (g_at5E, gpart_at7T) = Genome.Split.split gpart_at7S
                            p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                            (g_at5C, gpart_at7S) = Genome.Split.split gpart_at7R
                            p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                            (g_at5A, gpart_at7R) = Genome.Split.split gpart_at7Q
                            p_at5z = Functions.belowten' g_at5y
                            (g_at5y, gpart_at7Q) = Genome.Split.split gpart_at7P
                            p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                            (g_at5w, gpart_at7P) = Genome.Split.split gpart_at7O
                            p_at5v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5u
                            (g_at5u, gpart_at7O) = Genome.Split.split gpart_at7N
                            p_at5t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5s
                            (g_at5s, gpart_at7N) = Genome.Split.split gpart_at7M
                            p_at5r = Functions.belowten' g_at5q
                            (g_at5q, gpart_at7M) = Genome.Split.split gpart_at7L
                            p_at5p = code-0.1.0.0:Genome.FixedList.Functions.double g_at5o
                            (g_at5o, gpart_at7L) = Genome.Split.split gpart_at7K
                            p_at5n = code-0.1.0.0:Genome.FixedList.Functions.double g_at5m
                            (g_at5m, gpart_at7K) = Genome.Split.split gpart_at7J
                            p_at5l = code-0.1.0.0:Genome.FixedList.Functions.double g_at5k
                            (g_at5k, gpart_at7J) = Genome.Split.split gpart_at7I
                            p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                            (g_at5i, gpart_at7I) = Genome.Split.split gpart_at7H
                            p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                            (g_at5g, gpart_at7H) = Genome.Split.split gpart_at7G
                            p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                            (g_at5e, gpart_at7G) = Genome.Split.split genome_at6y
                          in
                            \ desc_at6z
                              -> case desc_at6z of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5f)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5h)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5j)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5l)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5n)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5p)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5r)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5t)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5v)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5x)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5z)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5B)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5J)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5L)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5N)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5P)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5R)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5T)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5V)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5X)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Z)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at61)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at63)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at65)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at67)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at69)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6b)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6d)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6f)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6h)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6j)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6l)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6n)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6p)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6r)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6t)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6v)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6x)
                                   _ -> Nothing }}
