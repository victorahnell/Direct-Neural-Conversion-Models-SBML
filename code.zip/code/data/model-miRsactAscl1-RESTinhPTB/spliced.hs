src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24J2
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24JI
                      p_a24J1 = double g_a24J0
                      (g_a24J0, gpart_a24JI) = Genome.Split.split gpart_a24JH
                      p_a24IZ = double g_a24IY
                      (g_a24IY, gpart_a24JH) = Genome.Split.split gpart_a24JG
                      p_a24IX = double g_a24IW
                      (g_a24IW, gpart_a24JG) = Genome.Split.split gpart_a24JF
                      p_a24IV = double g_a24IU
                      (g_a24IU, gpart_a24JF) = Genome.Split.split gpart_a24JE
                      p_a24IT = double g_a24IS
                      (g_a24IS, gpart_a24JE) = Genome.Split.split gpart_a24JD
                      p_a24IR = double g_a24IQ
                      (g_a24IQ, gpart_a24JD) = Genome.Split.split gpart_a24JC
                      p_a24IP = Functions.belowten' g_a24IO
                      (g_a24IO, gpart_a24JC) = Genome.Split.split gpart_a24JB
                      p_a24IN = double g_a24IM
                      (g_a24IM, gpart_a24JB) = Genome.Split.split gpart_a24JA
                      p_a24IL = Functions.belowten' g_a24IK
                      (g_a24IK, gpart_a24JA) = Genome.Split.split gpart_a24Jz
                      p_a24IJ = double g_a24II
                      (g_a24II, gpart_a24Jz) = Genome.Split.split gpart_a24Jy
                      p_a24IH = double g_a24IG
                      (g_a24IG, gpart_a24Jy) = Genome.Split.split gpart_a24Jx
                      p_a24IF = double g_a24IE
                      (g_a24IE, gpart_a24Jx) = Genome.Split.split gpart_a24Jw
                      p_a24ID = Functions.belowten' g_a24IC
                      (g_a24IC, gpart_a24Jw) = Genome.Split.split gpart_a24Jv
                      p_a24IB = double g_a24IA
                      (g_a24IA, gpart_a24Jv) = Genome.Split.split gpart_a24Ju
                      p_a24Iz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Iy
                      (g_a24Iy, gpart_a24Ju) = Genome.Split.split gpart_a24Jt
                      p_a24Ix
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Iw
                      (g_a24Iw, gpart_a24Jt) = Genome.Split.split gpart_a24Js
                      p_a24Iv = Functions.belowten' g_a24Iu
                      (g_a24Iu, gpart_a24Js) = Genome.Split.split gpart_a24Jr
                      p_a24It = double g_a24Is
                      (g_a24Is, gpart_a24Jr) = Genome.Split.split gpart_a24Jq
                      p_a24Ir = double g_a24Iq
                      (g_a24Iq, gpart_a24Jq) = Genome.Split.split gpart_a24Jp
                      p_a24Ip = double g_a24Io
                      (g_a24Io, gpart_a24Jp) = Genome.Split.split gpart_a24Jo
                      p_a24In = Functions.belowten' g_a24Im
                      (g_a24Im, gpart_a24Jo) = Genome.Split.split gpart_a24Jn
                      p_a24Il = double g_a24Ik
                      (g_a24Ik, gpart_a24Jn) = Genome.Split.split gpart_a24Jm
                      p_a24Ij
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ii
                      (g_a24Ii, gpart_a24Jm) = Genome.Split.split gpart_a24Jl
                      p_a24Ih
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ig
                      (g_a24Ig, gpart_a24Jl) = Genome.Split.split gpart_a24Jk
                      p_a24If = double g_a24Ie
                      (g_a24Ie, gpart_a24Jk) = Genome.Split.split gpart_a24Jj
                      p_a24Id = Functions.belowten' g_a24Ic
                      (g_a24Ic, gpart_a24Jj) = Genome.Split.split gpart_a24Ji
                      p_a24Ib = double g_a24Ia
                      (g_a24Ia, gpart_a24Ji) = Genome.Split.split gpart_a24Jh
                      p_a24I9 = Functions.belowten' g_a24I8
                      (g_a24I8, gpart_a24Jh) = Genome.Split.split gpart_a24Jg
                      p_a24I7 = double g_a24I6
                      (g_a24I6, gpart_a24Jg) = Genome.Split.split gpart_a24Jf
                      p_a24I5 = double g_a24I4
                      (g_a24I4, gpart_a24Jf) = Genome.Split.split gpart_a24Je
                      p_a24I3 = Functions.belowten' g_a24I2
                      (g_a24I2, gpart_a24Je) = Genome.Split.split gpart_a24Jd
                      p_a24I1 = double g_a24I0
                      (g_a24I0, gpart_a24Jd) = Genome.Split.split gpart_a24Jc
                      p_a24HZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24HY
                      (g_a24HY, gpart_a24Jc) = Genome.Split.split gpart_a24Jb
                      p_a24HX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24HW
                      (g_a24HW, gpart_a24Jb) = Genome.Split.split gpart_a24Ja
                      p_a24HV = Functions.belowten' g_a24HU
                      (g_a24HU, gpart_a24Ja) = Genome.Split.split gpart_a24J9
                      p_a24HT = double g_a24HS
                      (g_a24HS, gpart_a24J9) = Genome.Split.split gpart_a24J8
                      p_a24HR = double g_a24HQ
                      (g_a24HQ, gpart_a24J8) = Genome.Split.split gpart_a24J7
                      p_a24HP = double g_a24HO
                      (g_a24HO, gpart_a24J7) = Genome.Split.split gpart_a24J6
                      p_a24HN = double g_a24HM
                      (g_a24HM, gpart_a24J6) = Genome.Split.split gpart_a24J5
                      p_a24HL = double g_a24HK
                      (g_a24HK, gpart_a24J5) = Genome.Split.split gpart_a24J4
                      p_a24HJ = double g_a24HI
                      (g_a24HI, gpart_a24J4) = Genome.Split.split genome_a24J2
                    in  \ x_a24JJ
                          -> let
                               c_PTB_a24JN
                                 = ((Data.Fixed.Vector.toVector x_a24JJ) Data.Vector.Unboxed.! 0)
                               c_RESTc_a24JK
                                 = ((Data.Fixed.Vector.toVector x_a24JJ) Data.Vector.Unboxed.! 3)
                               c_MiRs_a24JL
                                 = ((Data.Fixed.Vector.toVector x_a24JJ) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24JR
                                 = ((Data.Fixed.Vector.toVector x_a24JJ) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a24K4
                                 = ((Data.Fixed.Vector.toVector x_a24JJ) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24HR
                                     / (1
                                        + (((c_RESTc_a24JK / p_a24HT) ** p_a24HV)
                                           + ((c_MiRs_a24JL / p_a24I1) ** p_a24I3))))
                                    + (negate (p_a24IT * c_PTB_a24JN))),
                                   ((p_a24I5
                                     / (1
                                        + (((c_MiRs_a24JL / p_a24I7) ** p_a24I9)
                                           + ((c_PTB_a24JN / p_a24Ib) ** p_a24Id))))
                                    + (negate (p_a24IV * c_NPTB_a24JR))),
                                   ((p_a24If
                                     * ((p_a24Ip + ((p_a24HN / p_a24Ih) ** p_a24Ij))
                                        / (((1 + p_a24Ip) + ((p_a24HN / p_a24Ih) ** p_a24Ij))
                                           + ((c_RESTc_a24JK / p_a24Il) ** p_a24In))))
                                    + (negate (p_a24IX * c_MiRs_a24JL))),
                                   ((p_a24Ir
                                     * ((p_a24IF + ((c_PTB_a24JN / p_a24It) ** p_a24Iv))
                                        / (((1 + p_a24IF) + ((c_PTB_a24JN / p_a24It) ** p_a24Iv))
                                           + (((p_a24HJ / p_a24Ix) ** p_a24Iz)
                                              + ((c_MiRs_a24JL / p_a24IB) ** p_a24ID)))))
                                    + (negate (p_a24IZ * c_RESTc_a24JK))),
                                   ((p_a24IH
                                     * ((p_a24IR + ((c_MiRs_a24JL / p_a24IJ) ** p_a24IL))
                                        / (((1 + p_a24IR) + ((c_MiRs_a24JL / p_a24IJ) ** p_a24IL))
                                           + ((c_RESTc_a24JK / p_a24IN) ** p_a24IP))))
                                    + (negate (p_a24J1 * c_EndoNeuroTFs_a24K4)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504549",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504551",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504569",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504571",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504581",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504583",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504585",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504587",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504599",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24J2
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24KJ
                            p_a24J1 = double g_a24J0
                            (g_a24J0, gpart_a24KJ) = Genome.Split.split gpart_a24KI
                            p_a24IZ = double g_a24IY
                            (g_a24IY, gpart_a24KI) = Genome.Split.split gpart_a24KH
                            p_a24IX = double g_a24IW
                            (g_a24IW, gpart_a24KH) = Genome.Split.split gpart_a24KG
                            p_a24IV = double g_a24IU
                            (g_a24IU, gpart_a24KG) = Genome.Split.split gpart_a24KF
                            p_a24IT = double g_a24IS
                            (g_a24IS, gpart_a24KF) = Genome.Split.split gpart_a24KE
                            p_a24IR = double g_a24IQ
                            (g_a24IQ, gpart_a24KE) = Genome.Split.split gpart_a24KD
                            p_a24IP = Functions.belowten' g_a24IO
                            (g_a24IO, gpart_a24KD) = Genome.Split.split gpart_a24KC
                            p_a24IN = double g_a24IM
                            (g_a24IM, gpart_a24KC) = Genome.Split.split gpart_a24KB
                            p_a24IL = Functions.belowten' g_a24IK
                            (g_a24IK, gpart_a24KB) = Genome.Split.split gpart_a24KA
                            p_a24IJ = double g_a24II
                            (g_a24II, gpart_a24KA) = Genome.Split.split gpart_a24Kz
                            p_a24IH = double g_a24IG
                            (g_a24IG, gpart_a24Kz) = Genome.Split.split gpart_a24Ky
                            p_a24IF = double g_a24IE
                            (g_a24IE, gpart_a24Ky) = Genome.Split.split gpart_a24Kx
                            p_a24ID = Functions.belowten' g_a24IC
                            (g_a24IC, gpart_a24Kx) = Genome.Split.split gpart_a24Kw
                            p_a24IB = double g_a24IA
                            (g_a24IA, gpart_a24Kw) = Genome.Split.split gpart_a24Kv
                            p_a24Iz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Iy
                            (g_a24Iy, gpart_a24Kv) = Genome.Split.split gpart_a24Ku
                            p_a24Ix
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Iw
                            (g_a24Iw, gpart_a24Ku) = Genome.Split.split gpart_a24Kt
                            p_a24Iv = Functions.belowten' g_a24Iu
                            (g_a24Iu, gpart_a24Kt) = Genome.Split.split gpart_a24Ks
                            p_a24It = double g_a24Is
                            (g_a24Is, gpart_a24Ks) = Genome.Split.split gpart_a24Kr
                            p_a24Ir = double g_a24Iq
                            (g_a24Iq, gpart_a24Kr) = Genome.Split.split gpart_a24Kq
                            p_a24Ip = double g_a24Io
                            (g_a24Io, gpart_a24Kq) = Genome.Split.split gpart_a24Kp
                            p_a24In = Functions.belowten' g_a24Im
                            (g_a24Im, gpart_a24Kp) = Genome.Split.split gpart_a24Ko
                            p_a24Il = double g_a24Ik
                            (g_a24Ik, gpart_a24Ko) = Genome.Split.split gpart_a24Kn
                            p_a24Ij
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ii
                            (g_a24Ii, gpart_a24Kn) = Genome.Split.split gpart_a24Km
                            p_a24Ih
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ig
                            (g_a24Ig, gpart_a24Km) = Genome.Split.split gpart_a24Kl
                            p_a24If = double g_a24Ie
                            (g_a24Ie, gpart_a24Kl) = Genome.Split.split gpart_a24Kk
                            p_a24Id = Functions.belowten' g_a24Ic
                            (g_a24Ic, gpart_a24Kk) = Genome.Split.split gpart_a24Kj
                            p_a24Ib = double g_a24Ia
                            (g_a24Ia, gpart_a24Kj) = Genome.Split.split gpart_a24Ki
                            p_a24I9 = Functions.belowten' g_a24I8
                            (g_a24I8, gpart_a24Ki) = Genome.Split.split gpart_a24Kh
                            p_a24I7 = double g_a24I6
                            (g_a24I6, gpart_a24Kh) = Genome.Split.split gpart_a24Kg
                            p_a24I5 = double g_a24I4
                            (g_a24I4, gpart_a24Kg) = Genome.Split.split gpart_a24Kf
                            p_a24I3 = Functions.belowten' g_a24I2
                            (g_a24I2, gpart_a24Kf) = Genome.Split.split gpart_a24Ke
                            p_a24I1 = double g_a24I0
                            (g_a24I0, gpart_a24Ke) = Genome.Split.split gpart_a24Kd
                            p_a24HZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24HY
                            (g_a24HY, gpart_a24Kd) = Genome.Split.split gpart_a24Kc
                            p_a24HX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24HW
                            (g_a24HW, gpart_a24Kc) = Genome.Split.split gpart_a24Kb
                            p_a24HV = Functions.belowten' g_a24HU
                            (g_a24HU, gpart_a24Kb) = Genome.Split.split gpart_a24Ka
                            p_a24HT = double g_a24HS
                            (g_a24HS, gpart_a24Ka) = Genome.Split.split gpart_a24K9
                            p_a24HR = double g_a24HQ
                            (g_a24HQ, gpart_a24K9) = Genome.Split.split gpart_a24K8
                            p_a24HP = double g_a24HO
                            (g_a24HO, gpart_a24K8) = Genome.Split.split gpart_a24K7
                            p_a24HN = double g_a24HM
                            (g_a24HM, gpart_a24K7) = Genome.Split.split gpart_a24K6
                            p_a24HL = double g_a24HK
                            (g_a24HK, gpart_a24K6) = Genome.Split.split gpart_a24K5
                            p_a24HJ = double g_a24HI
                            (g_a24HI, gpart_a24K5) = Genome.Split.split genome_a24J2
                          in
                            \ desc_a24J3
                              -> case desc_a24J3 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HJ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HL)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HN)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HP)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HR)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HT)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HV)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HX)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HZ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I1)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I3)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I5)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I7)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I9)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ib)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Id)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24If)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ih)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ij)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Il)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24In)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ip)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ir)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24It)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Iv)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ix)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Iz)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IB)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ID)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IF)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IH)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IJ)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IL)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IN)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IP)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IR)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IT)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IV)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IX)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IZ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24J1)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24Nd
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24NT
                      p_a24Nc = double g_a24Nb
                      (g_a24Nb, gpart_a24NT) = Genome.Split.split gpart_a24NS
                      p_a24Na = double g_a24N9
                      (g_a24N9, gpart_a24NS) = Genome.Split.split gpart_a24NR
                      p_a24N8 = double g_a24N7
                      (g_a24N7, gpart_a24NR) = Genome.Split.split gpart_a24NQ
                      p_a24N6 = double g_a24N5
                      (g_a24N5, gpart_a24NQ) = Genome.Split.split gpart_a24NP
                      p_a24N4 = double g_a24N3
                      (g_a24N3, gpart_a24NP) = Genome.Split.split gpart_a24NO
                      p_a24N2 = double g_a24N1
                      (g_a24N1, gpart_a24NO) = Genome.Split.split gpart_a24NN
                      p_a24N0 = Functions.belowten' g_a24MZ
                      (g_a24MZ, gpart_a24NN) = Genome.Split.split gpart_a24NM
                      p_a24MY = double g_a24MX
                      (g_a24MX, gpart_a24NM) = Genome.Split.split gpart_a24NL
                      p_a24MW = Functions.belowten' g_a24MV
                      (g_a24MV, gpart_a24NL) = Genome.Split.split gpart_a24NK
                      p_a24MU = double g_a24MT
                      (g_a24MT, gpart_a24NK) = Genome.Split.split gpart_a24NJ
                      p_a24MS = double g_a24MR
                      (g_a24MR, gpart_a24NJ) = Genome.Split.split gpart_a24NI
                      p_a24MQ = double g_a24MP
                      (g_a24MP, gpart_a24NI) = Genome.Split.split gpart_a24NH
                      p_a24MO = Functions.belowten' g_a24MN
                      (g_a24MN, gpart_a24NH) = Genome.Split.split gpart_a24NG
                      p_a24MM = double g_a24ML
                      (g_a24ML, gpart_a24NG) = Genome.Split.split gpart_a24NF
                      p_a24MK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MJ
                      (g_a24MJ, gpart_a24NF) = Genome.Split.split gpart_a24NE
                      p_a24MI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MH
                      (g_a24MH, gpart_a24NE) = Genome.Split.split gpart_a24ND
                      p_a24MG = Functions.belowten' g_a24MF
                      (g_a24MF, gpart_a24ND) = Genome.Split.split gpart_a24NC
                      p_a24ME = double g_a24MD
                      (g_a24MD, gpart_a24NC) = Genome.Split.split gpart_a24NB
                      p_a24MC = double g_a24MB
                      (g_a24MB, gpart_a24NB) = Genome.Split.split gpart_a24NA
                      p_a24MA = double g_a24Mz
                      (g_a24Mz, gpart_a24NA) = Genome.Split.split gpart_a24Nz
                      p_a24My = Functions.belowten' g_a24Mx
                      (g_a24Mx, gpart_a24Nz) = Genome.Split.split gpart_a24Ny
                      p_a24Mw = double g_a24Mv
                      (g_a24Mv, gpart_a24Ny) = Genome.Split.split gpart_a24Nx
                      p_a24Mu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Mt
                      (g_a24Mt, gpart_a24Nx) = Genome.Split.split gpart_a24Nw
                      p_a24Ms
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Mr
                      (g_a24Mr, gpart_a24Nw) = Genome.Split.split gpart_a24Nv
                      p_a24Mq = double g_a24Mp
                      (g_a24Mp, gpart_a24Nv) = Genome.Split.split gpart_a24Nu
                      p_a24Mo = Functions.belowten' g_a24Mn
                      (g_a24Mn, gpart_a24Nu) = Genome.Split.split gpart_a24Nt
                      p_a24Mm = double g_a24Ml
                      (g_a24Ml, gpart_a24Nt) = Genome.Split.split gpart_a24Ns
                      p_a24Mk = Functions.belowten' g_a24Mj
                      (g_a24Mj, gpart_a24Ns) = Genome.Split.split gpart_a24Nr
                      p_a24Mi = double g_a24Mh
                      (g_a24Mh, gpart_a24Nr) = Genome.Split.split gpart_a24Nq
                      p_a24Mg = double g_a24Mf
                      (g_a24Mf, gpart_a24Nq) = Genome.Split.split gpart_a24Np
                      p_a24Me = Functions.belowten' g_a24Md
                      (g_a24Md, gpart_a24Np) = Genome.Split.split gpart_a24No
                      p_a24Mc = double g_a24Mb
                      (g_a24Mb, gpart_a24No) = Genome.Split.split gpart_a24Nn
                      p_a24Ma
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24M9
                      (g_a24M9, gpart_a24Nn) = Genome.Split.split gpart_a24Nm
                      p_a24M8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24M7
                      (g_a24M7, gpart_a24Nm) = Genome.Split.split gpart_a24Nl
                      p_a24M6 = Functions.belowten' g_a24M5
                      (g_a24M5, gpart_a24Nl) = Genome.Split.split gpart_a24Nk
                      p_a24M4 = double g_a24M3
                      (g_a24M3, gpart_a24Nk) = Genome.Split.split gpart_a24Nj
                      p_a24M2 = double g_a24M1
                      (g_a24M1, gpart_a24Nj) = Genome.Split.split gpart_a24Ni
                      p_a24M0 = double g_a24LZ
                      (g_a24LZ, gpart_a24Ni) = Genome.Split.split gpart_a24Nh
                      p_a24LY = double g_a24LX
                      (g_a24LX, gpart_a24Nh) = Genome.Split.split gpart_a24Ng
                      p_a24LW = double g_a24LV
                      (g_a24LV, gpart_a24Ng) = Genome.Split.split gpart_a24Nf
                      p_a24LU = double g_a24LT
                      (g_a24LT, gpart_a24Nf) = Genome.Split.split genome_a24Nd
                    in  \ x_a24NU
                          -> let
                               c_PTB_a24NY
                                 = ((Data.Fixed.Vector.toVector x_a24NU) Data.Vector.Unboxed.! 0)
                               c_RESTc_a24NV
                                 = ((Data.Fixed.Vector.toVector x_a24NU) Data.Vector.Unboxed.! 3)
                               c_MiRs_a24NW
                                 = ((Data.Fixed.Vector.toVector x_a24NU) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24O2
                                 = ((Data.Fixed.Vector.toVector x_a24NU) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a24Of
                                 = ((Data.Fixed.Vector.toVector x_a24NU) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24M2
                                     / (1
                                        + (((c_RESTc_a24NV / p_a24M4) ** p_a24M6)
                                           + ((c_MiRs_a24NW / p_a24Mc) ** p_a24Me))))
                                    + (negate (p_a24N4 * c_PTB_a24NY))),
                                   ((p_a24Mg
                                     / (1
                                        + (((c_MiRs_a24NW / p_a24Mi) ** p_a24Mk)
                                           + ((c_PTB_a24NY / p_a24Mm) ** p_a24Mo))))
                                    + (negate (p_a24N6 * c_NPTB_a24O2))),
                                   ((p_a24Mq
                                     * (p_a24MA
                                        / ((1 + p_a24MA) + ((c_RESTc_a24NV / p_a24Mw) ** p_a24My))))
                                    + (negate (p_a24N8 * c_MiRs_a24NW))),
                                   ((p_a24MC
                                     * ((p_a24MQ + ((c_PTB_a24NY / p_a24ME) ** p_a24MG))
                                        / (((1 + p_a24MQ) + ((c_PTB_a24NY / p_a24ME) ** p_a24MG))
                                           + (((p_a24LU / p_a24MI) ** p_a24MK)
                                              + ((c_MiRs_a24NW / p_a24MM) ** p_a24MO)))))
                                    + (negate (p_a24Na * c_RESTc_a24NV))),
                                   ((p_a24MS
                                     * ((p_a24N2 + ((c_MiRs_a24NW / p_a24MU) ** p_a24MW))
                                        / (((1 + p_a24N2) + ((c_MiRs_a24NW / p_a24MU) ** p_a24MW))
                                           + ((c_RESTc_a24NV / p_a24MY) ** p_a24N0))))
                                    + (negate (p_a24Nc * c_EndoNeuroTFs_a24Of)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504793",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504794",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504795",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504796",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504797",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504798",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504799",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504800",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504801",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504802",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504803",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504804",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504805",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504806",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504807",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504808",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504809",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504810",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504811",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504812",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504813",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504814",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504815",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504816",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504817",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504818",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504819",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504820",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504821",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504822",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504823",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504824",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504825",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504826",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504827",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504828",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504829",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504830",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504831",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504832",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504833",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504834",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504835",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504836",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504837",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504838",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504839",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504840",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504841",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504842",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504843",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504844",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504845",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504846",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504847",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504848",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504849",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504850",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504851",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504852",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504853",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504854",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504855",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504856",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504858",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504860",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504862",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504864",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504866",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504868",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Nd
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24OU
                            p_a24Nc = double g_a24Nb
                            (g_a24Nb, gpart_a24OU) = Genome.Split.split gpart_a24OT
                            p_a24Na = double g_a24N9
                            (g_a24N9, gpart_a24OT) = Genome.Split.split gpart_a24OS
                            p_a24N8 = double g_a24N7
                            (g_a24N7, gpart_a24OS) = Genome.Split.split gpart_a24OR
                            p_a24N6 = double g_a24N5
                            (g_a24N5, gpart_a24OR) = Genome.Split.split gpart_a24OQ
                            p_a24N4 = double g_a24N3
                            (g_a24N3, gpart_a24OQ) = Genome.Split.split gpart_a24OP
                            p_a24N2 = double g_a24N1
                            (g_a24N1, gpart_a24OP) = Genome.Split.split gpart_a24OO
                            p_a24N0 = Functions.belowten' g_a24MZ
                            (g_a24MZ, gpart_a24OO) = Genome.Split.split gpart_a24ON
                            p_a24MY = double g_a24MX
                            (g_a24MX, gpart_a24ON) = Genome.Split.split gpart_a24OM
                            p_a24MW = Functions.belowten' g_a24MV
                            (g_a24MV, gpart_a24OM) = Genome.Split.split gpart_a24OL
                            p_a24MU = double g_a24MT
                            (g_a24MT, gpart_a24OL) = Genome.Split.split gpart_a24OK
                            p_a24MS = double g_a24MR
                            (g_a24MR, gpart_a24OK) = Genome.Split.split gpart_a24OJ
                            p_a24MQ = double g_a24MP
                            (g_a24MP, gpart_a24OJ) = Genome.Split.split gpart_a24OI
                            p_a24MO = Functions.belowten' g_a24MN
                            (g_a24MN, gpart_a24OI) = Genome.Split.split gpart_a24OH
                            p_a24MM = double g_a24ML
                            (g_a24ML, gpart_a24OH) = Genome.Split.split gpart_a24OG
                            p_a24MK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MJ
                            (g_a24MJ, gpart_a24OG) = Genome.Split.split gpart_a24OF
                            p_a24MI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MH
                            (g_a24MH, gpart_a24OF) = Genome.Split.split gpart_a24OE
                            p_a24MG = Functions.belowten' g_a24MF
                            (g_a24MF, gpart_a24OE) = Genome.Split.split gpart_a24OD
                            p_a24ME = double g_a24MD
                            (g_a24MD, gpart_a24OD) = Genome.Split.split gpart_a24OC
                            p_a24MC = double g_a24MB
                            (g_a24MB, gpart_a24OC) = Genome.Split.split gpart_a24OB
                            p_a24MA = double g_a24Mz
                            (g_a24Mz, gpart_a24OB) = Genome.Split.split gpart_a24OA
                            p_a24My = Functions.belowten' g_a24Mx
                            (g_a24Mx, gpart_a24OA) = Genome.Split.split gpart_a24Oz
                            p_a24Mw = double g_a24Mv
                            (g_a24Mv, gpart_a24Oz) = Genome.Split.split gpart_a24Oy
                            p_a24Mu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Mt
                            (g_a24Mt, gpart_a24Oy) = Genome.Split.split gpart_a24Ox
                            p_a24Ms
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Mr
                            (g_a24Mr, gpart_a24Ox) = Genome.Split.split gpart_a24Ow
                            p_a24Mq = double g_a24Mp
                            (g_a24Mp, gpart_a24Ow) = Genome.Split.split gpart_a24Ov
                            p_a24Mo = Functions.belowten' g_a24Mn
                            (g_a24Mn, gpart_a24Ov) = Genome.Split.split gpart_a24Ou
                            p_a24Mm = double g_a24Ml
                            (g_a24Ml, gpart_a24Ou) = Genome.Split.split gpart_a24Ot
                            p_a24Mk = Functions.belowten' g_a24Mj
                            (g_a24Mj, gpart_a24Ot) = Genome.Split.split gpart_a24Os
                            p_a24Mi = double g_a24Mh
                            (g_a24Mh, gpart_a24Os) = Genome.Split.split gpart_a24Or
                            p_a24Mg = double g_a24Mf
                            (g_a24Mf, gpart_a24Or) = Genome.Split.split gpart_a24Oq
                            p_a24Me = Functions.belowten' g_a24Md
                            (g_a24Md, gpart_a24Oq) = Genome.Split.split gpart_a24Op
                            p_a24Mc = double g_a24Mb
                            (g_a24Mb, gpart_a24Op) = Genome.Split.split gpart_a24Oo
                            p_a24Ma
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24M9
                            (g_a24M9, gpart_a24Oo) = Genome.Split.split gpart_a24On
                            p_a24M8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24M7
                            (g_a24M7, gpart_a24On) = Genome.Split.split gpart_a24Om
                            p_a24M6 = Functions.belowten' g_a24M5
                            (g_a24M5, gpart_a24Om) = Genome.Split.split gpart_a24Ol
                            p_a24M4 = double g_a24M3
                            (g_a24M3, gpart_a24Ol) = Genome.Split.split gpart_a24Ok
                            p_a24M2 = double g_a24M1
                            (g_a24M1, gpart_a24Ok) = Genome.Split.split gpart_a24Oj
                            p_a24M0 = double g_a24LZ
                            (g_a24LZ, gpart_a24Oj) = Genome.Split.split gpart_a24Oi
                            p_a24LY = double g_a24LX
                            (g_a24LX, gpart_a24Oi) = Genome.Split.split gpart_a24Oh
                            p_a24LW = double g_a24LV
                            (g_a24LV, gpart_a24Oh) = Genome.Split.split gpart_a24Og
                            p_a24LU = double g_a24LT
                            (g_a24LT, gpart_a24Og) = Genome.Split.split genome_a24Nd
                          in
                            \ desc_a24Ne
                              -> case desc_a24Ne of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24LU)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24LW)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24LY)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M0)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M2)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M4)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M6)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M8)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ma)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mc)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Me)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mg)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mi)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mk)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mm)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mo)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mq)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ms)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mu)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mw)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24My)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MA)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MC)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ME)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MG)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MI)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MK)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MM)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MO)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MQ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MS)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MU)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MW)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MY)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N0)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N2)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N4)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N6)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N8)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Na)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Nc)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24Ro
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24S4
                      p_a24Rn = double g_a24Rm
                      (g_a24Rm, gpart_a24S4) = Genome.Split.split gpart_a24S3
                      p_a24Rl = double g_a24Rk
                      (g_a24Rk, gpart_a24S3) = Genome.Split.split gpart_a24S2
                      p_a24Rj = double g_a24Ri
                      (g_a24Ri, gpart_a24S2) = Genome.Split.split gpart_a24S1
                      p_a24Rh = double g_a24Rg
                      (g_a24Rg, gpart_a24S1) = Genome.Split.split gpart_a24S0
                      p_a24Rf = double g_a24Re
                      (g_a24Re, gpart_a24S0) = Genome.Split.split gpart_a24RZ
                      p_a24Rd = double g_a24Rc
                      (g_a24Rc, gpart_a24RZ) = Genome.Split.split gpart_a24RY
                      p_a24Rb = Functions.belowten' g_a24Ra
                      (g_a24Ra, gpart_a24RY) = Genome.Split.split gpart_a24RX
                      p_a24R9 = double g_a24R8
                      (g_a24R8, gpart_a24RX) = Genome.Split.split gpart_a24RW
                      p_a24R7 = Functions.belowten' g_a24R6
                      (g_a24R6, gpart_a24RW) = Genome.Split.split gpart_a24RV
                      p_a24R5 = double g_a24R4
                      (g_a24R4, gpart_a24RV) = Genome.Split.split gpart_a24RU
                      p_a24R3 = double g_a24R2
                      (g_a24R2, gpart_a24RU) = Genome.Split.split gpart_a24RT
                      p_a24R1 = double g_a24R0
                      (g_a24R0, gpart_a24RT) = Genome.Split.split gpart_a24RS
                      p_a24QZ = Functions.belowten' g_a24QY
                      (g_a24QY, gpart_a24RS) = Genome.Split.split gpart_a24RR
                      p_a24QX = double g_a24QW
                      (g_a24QW, gpart_a24RR) = Genome.Split.split gpart_a24RQ
                      p_a24QV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24QU
                      (g_a24QU, gpart_a24RQ) = Genome.Split.split gpart_a24RP
                      p_a24QT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24QS
                      (g_a24QS, gpart_a24RP) = Genome.Split.split gpart_a24RO
                      p_a24QR = Functions.belowten' g_a24QQ
                      (g_a24QQ, gpart_a24RO) = Genome.Split.split gpart_a24RN
                      p_a24QP = double g_a24QO
                      (g_a24QO, gpart_a24RN) = Genome.Split.split gpart_a24RM
                      p_a24QN = double g_a24QM
                      (g_a24QM, gpart_a24RM) = Genome.Split.split gpart_a24RL
                      p_a24QL = double g_a24QK
                      (g_a24QK, gpart_a24RL) = Genome.Split.split gpart_a24RK
                      p_a24QJ = Functions.belowten' g_a24QI
                      (g_a24QI, gpart_a24RK) = Genome.Split.split gpart_a24RJ
                      p_a24QH = double g_a24QG
                      (g_a24QG, gpart_a24RJ) = Genome.Split.split gpart_a24RI
                      p_a24QF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24QE
                      (g_a24QE, gpart_a24RI) = Genome.Split.split gpart_a24RH
                      p_a24QD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24QC
                      (g_a24QC, gpart_a24RH) = Genome.Split.split gpart_a24RG
                      p_a24QB = double g_a24QA
                      (g_a24QA, gpart_a24RG) = Genome.Split.split gpart_a24RF
                      p_a24Qz = Functions.belowten' g_a24Qy
                      (g_a24Qy, gpart_a24RF) = Genome.Split.split gpart_a24RE
                      p_a24Qx = double g_a24Qw
                      (g_a24Qw, gpart_a24RE) = Genome.Split.split gpart_a24RD
                      p_a24Qv = Functions.belowten' g_a24Qu
                      (g_a24Qu, gpart_a24RD) = Genome.Split.split gpart_a24RC
                      p_a24Qt = double g_a24Qs
                      (g_a24Qs, gpart_a24RC) = Genome.Split.split gpart_a24RB
                      p_a24Qr = double g_a24Qq
                      (g_a24Qq, gpart_a24RB) = Genome.Split.split gpart_a24RA
                      p_a24Qp = Functions.belowten' g_a24Qo
                      (g_a24Qo, gpart_a24RA) = Genome.Split.split gpart_a24Rz
                      p_a24Qn = double g_a24Qm
                      (g_a24Qm, gpart_a24Rz) = Genome.Split.split gpart_a24Ry
                      p_a24Ql
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Qk
                      (g_a24Qk, gpart_a24Ry) = Genome.Split.split gpart_a24Rx
                      p_a24Qj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Qi
                      (g_a24Qi, gpart_a24Rx) = Genome.Split.split gpart_a24Rw
                      p_a24Qh = Functions.belowten' g_a24Qg
                      (g_a24Qg, gpart_a24Rw) = Genome.Split.split gpart_a24Rv
                      p_a24Qf = double g_a24Qe
                      (g_a24Qe, gpart_a24Rv) = Genome.Split.split gpart_a24Ru
                      p_a24Qd = double g_a24Qc
                      (g_a24Qc, gpart_a24Ru) = Genome.Split.split gpart_a24Rt
                      p_a24Qb = double g_a24Qa
                      (g_a24Qa, gpart_a24Rt) = Genome.Split.split gpart_a24Rs
                      p_a24Q9 = double g_a24Q8
                      (g_a24Q8, gpart_a24Rs) = Genome.Split.split gpart_a24Rr
                      p_a24Q7 = double g_a24Q6
                      (g_a24Q6, gpart_a24Rr) = Genome.Split.split gpart_a24Rq
                      p_a24Q5 = double g_a24Q4
                      (g_a24Q4, gpart_a24Rq) = Genome.Split.split genome_a24Ro
                    in  \ x_a24S5
                          -> let
                               c_PTB_a24S9
                                 = ((Data.Fixed.Vector.toVector x_a24S5) Data.Vector.Unboxed.! 0)
                               c_RESTc_a24S6
                                 = ((Data.Fixed.Vector.toVector x_a24S5) Data.Vector.Unboxed.! 3)
                               c_MiRs_a24S7
                                 = ((Data.Fixed.Vector.toVector x_a24S5) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Sd
                                 = ((Data.Fixed.Vector.toVector x_a24S5) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a24Sq
                                 = ((Data.Fixed.Vector.toVector x_a24S5) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Qd
                                     / (1
                                        + (((c_RESTc_a24S6 / p_a24Qf) ** p_a24Qh)
                                           + ((c_MiRs_a24S7 / p_a24Qn) ** p_a24Qp))))
                                    + (negate (p_a24Rf * c_PTB_a24S9))),
                                   ((p_a24Qr
                                     / (1
                                        + (((c_MiRs_a24S7 / p_a24Qt) ** p_a24Qv)
                                           + ((c_PTB_a24S9 / p_a24Qx) ** p_a24Qz))))
                                    + (negate (p_a24Rh * c_NPTB_a24Sd))),
                                   ((p_a24QB
                                     * (p_a24QL
                                        / ((1 + p_a24QL) + ((c_RESTc_a24S6 / p_a24QH) ** p_a24QJ))))
                                    + (negate (p_a24Rj * c_MiRs_a24S7))),
                                   ((p_a24QN
                                     * ((p_a24R1 + ((c_PTB_a24S9 / p_a24QP) ** p_a24QR))
                                        / (((1 + p_a24R1) + ((c_PTB_a24S9 / p_a24QP) ** p_a24QR))
                                           + ((c_MiRs_a24S7 / p_a24QX) ** p_a24QZ))))
                                    + (negate (p_a24Rl * c_RESTc_a24S6))),
                                   ((p_a24R3
                                     * ((p_a24Rd + ((c_MiRs_a24S7 / p_a24R5) ** p_a24R7))
                                        / (((1 + p_a24Rd) + ((c_MiRs_a24S7 / p_a24R5) ** p_a24R7))
                                           + ((c_RESTc_a24S6 / p_a24R9) ** p_a24Rb))))
                                    + (negate (p_a24Rn * c_EndoNeuroTFs_a24Sq)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505059",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505061",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505063",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505065",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505067",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505069",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505085",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505087",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505089",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505091",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505093",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505103",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505105",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505107",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Ro
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24T5
                            p_a24Rn = double g_a24Rm
                            (g_a24Rm, gpart_a24T5) = Genome.Split.split gpart_a24T4
                            p_a24Rl = double g_a24Rk
                            (g_a24Rk, gpart_a24T4) = Genome.Split.split gpart_a24T3
                            p_a24Rj = double g_a24Ri
                            (g_a24Ri, gpart_a24T3) = Genome.Split.split gpart_a24T2
                            p_a24Rh = double g_a24Rg
                            (g_a24Rg, gpart_a24T2) = Genome.Split.split gpart_a24T1
                            p_a24Rf = double g_a24Re
                            (g_a24Re, gpart_a24T1) = Genome.Split.split gpart_a24T0
                            p_a24Rd = double g_a24Rc
                            (g_a24Rc, gpart_a24T0) = Genome.Split.split gpart_a24SZ
                            p_a24Rb = Functions.belowten' g_a24Ra
                            (g_a24Ra, gpart_a24SZ) = Genome.Split.split gpart_a24SY
                            p_a24R9 = double g_a24R8
                            (g_a24R8, gpart_a24SY) = Genome.Split.split gpart_a24SX
                            p_a24R7 = Functions.belowten' g_a24R6
                            (g_a24R6, gpart_a24SX) = Genome.Split.split gpart_a24SW
                            p_a24R5 = double g_a24R4
                            (g_a24R4, gpart_a24SW) = Genome.Split.split gpart_a24SV
                            p_a24R3 = double g_a24R2
                            (g_a24R2, gpart_a24SV) = Genome.Split.split gpart_a24SU
                            p_a24R1 = double g_a24R0
                            (g_a24R0, gpart_a24SU) = Genome.Split.split gpart_a24ST
                            p_a24QZ = Functions.belowten' g_a24QY
                            (g_a24QY, gpart_a24ST) = Genome.Split.split gpart_a24SS
                            p_a24QX = double g_a24QW
                            (g_a24QW, gpart_a24SS) = Genome.Split.split gpart_a24SR
                            p_a24QV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24QU
                            (g_a24QU, gpart_a24SR) = Genome.Split.split gpart_a24SQ
                            p_a24QT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24QS
                            (g_a24QS, gpart_a24SQ) = Genome.Split.split gpart_a24SP
                            p_a24QR = Functions.belowten' g_a24QQ
                            (g_a24QQ, gpart_a24SP) = Genome.Split.split gpart_a24SO
                            p_a24QP = double g_a24QO
                            (g_a24QO, gpart_a24SO) = Genome.Split.split gpart_a24SN
                            p_a24QN = double g_a24QM
                            (g_a24QM, gpart_a24SN) = Genome.Split.split gpart_a24SM
                            p_a24QL = double g_a24QK
                            (g_a24QK, gpart_a24SM) = Genome.Split.split gpart_a24SL
                            p_a24QJ = Functions.belowten' g_a24QI
                            (g_a24QI, gpart_a24SL) = Genome.Split.split gpart_a24SK
                            p_a24QH = double g_a24QG
                            (g_a24QG, gpart_a24SK) = Genome.Split.split gpart_a24SJ
                            p_a24QF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24QE
                            (g_a24QE, gpart_a24SJ) = Genome.Split.split gpart_a24SI
                            p_a24QD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24QC
                            (g_a24QC, gpart_a24SI) = Genome.Split.split gpart_a24SH
                            p_a24QB = double g_a24QA
                            (g_a24QA, gpart_a24SH) = Genome.Split.split gpart_a24SG
                            p_a24Qz = Functions.belowten' g_a24Qy
                            (g_a24Qy, gpart_a24SG) = Genome.Split.split gpart_a24SF
                            p_a24Qx = double g_a24Qw
                            (g_a24Qw, gpart_a24SF) = Genome.Split.split gpart_a24SE
                            p_a24Qv = Functions.belowten' g_a24Qu
                            (g_a24Qu, gpart_a24SE) = Genome.Split.split gpart_a24SD
                            p_a24Qt = double g_a24Qs
                            (g_a24Qs, gpart_a24SD) = Genome.Split.split gpart_a24SC
                            p_a24Qr = double g_a24Qq
                            (g_a24Qq, gpart_a24SC) = Genome.Split.split gpart_a24SB
                            p_a24Qp = Functions.belowten' g_a24Qo
                            (g_a24Qo, gpart_a24SB) = Genome.Split.split gpart_a24SA
                            p_a24Qn = double g_a24Qm
                            (g_a24Qm, gpart_a24SA) = Genome.Split.split gpart_a24Sz
                            p_a24Ql
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Qk
                            (g_a24Qk, gpart_a24Sz) = Genome.Split.split gpart_a24Sy
                            p_a24Qj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Qi
                            (g_a24Qi, gpart_a24Sy) = Genome.Split.split gpart_a24Sx
                            p_a24Qh = Functions.belowten' g_a24Qg
                            (g_a24Qg, gpart_a24Sx) = Genome.Split.split gpart_a24Sw
                            p_a24Qf = double g_a24Qe
                            (g_a24Qe, gpart_a24Sw) = Genome.Split.split gpart_a24Sv
                            p_a24Qd = double g_a24Qc
                            (g_a24Qc, gpart_a24Sv) = Genome.Split.split gpart_a24Su
                            p_a24Qb = double g_a24Qa
                            (g_a24Qa, gpart_a24Su) = Genome.Split.split gpart_a24St
                            p_a24Q9 = double g_a24Q8
                            (g_a24Q8, gpart_a24St) = Genome.Split.split gpart_a24Ss
                            p_a24Q7 = double g_a24Q6
                            (g_a24Q6, gpart_a24Ss) = Genome.Split.split gpart_a24Sr
                            p_a24Q5 = double g_a24Q4
                            (g_a24Q4, gpart_a24Sr) = Genome.Split.split genome_a24Ro
                          in
                            \ desc_a24Rp
                              -> case desc_a24Rp of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Q5)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Q7)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Q9)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qb)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qd)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qf)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qh)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qj)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ql)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qn)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qp)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qr)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qt)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qv)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qx)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Qz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QB)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QD)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QF)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QH)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QJ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QL)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QN)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QP)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QR)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QT)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QV)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QX)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24QZ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24R1)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24R3)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24R5)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24R7)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24R9)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rb)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rd)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rf)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rh)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rj)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rl)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rn)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a24Vz
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Wf
                      p_a24Vy = double g_a24Vx
                      (g_a24Vx, gpart_a24Wf) = Genome.Split.split gpart_a24We
                      p_a24Vw = double g_a24Vv
                      (g_a24Vv, gpart_a24We) = Genome.Split.split gpart_a24Wd
                      p_a24Vu = double g_a24Vt
                      (g_a24Vt, gpart_a24Wd) = Genome.Split.split gpart_a24Wc
                      p_a24Vs = double g_a24Vr
                      (g_a24Vr, gpart_a24Wc) = Genome.Split.split gpart_a24Wb
                      p_a24Vq = double g_a24Vp
                      (g_a24Vp, gpart_a24Wb) = Genome.Split.split gpart_a24Wa
                      p_a24Vo = double g_a24Vn
                      (g_a24Vn, gpart_a24Wa) = Genome.Split.split gpart_a24W9
                      p_a24Vm = Functions.belowten' g_a24Vl
                      (g_a24Vl, gpart_a24W9) = Genome.Split.split gpart_a24W8
                      p_a24Vk = double g_a24Vj
                      (g_a24Vj, gpart_a24W8) = Genome.Split.split gpart_a24W7
                      p_a24Vi = Functions.belowten' g_a24Vh
                      (g_a24Vh, gpart_a24W7) = Genome.Split.split gpart_a24W6
                      p_a24Vg = double g_a24Vf
                      (g_a24Vf, gpart_a24W6) = Genome.Split.split gpart_a24W5
                      p_a24Ve = double g_a24Vd
                      (g_a24Vd, gpart_a24W5) = Genome.Split.split gpart_a24W4
                      p_a24Vc = double g_a24Vb
                      (g_a24Vb, gpart_a24W4) = Genome.Split.split gpart_a24W3
                      p_a24Va = Functions.belowten' g_a24V9
                      (g_a24V9, gpart_a24W3) = Genome.Split.split gpart_a24W2
                      p_a24V8 = double g_a24V7
                      (g_a24V7, gpart_a24W2) = Genome.Split.split gpart_a24W1
                      p_a24V6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24V5
                      (g_a24V5, gpart_a24W1) = Genome.Split.split gpart_a24W0
                      p_a24V4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24V3
                      (g_a24V3, gpart_a24W0) = Genome.Split.split gpart_a24VZ
                      p_a24V2 = Functions.belowten' g_a24V1
                      (g_a24V1, gpart_a24VZ) = Genome.Split.split gpart_a24VY
                      p_a24V0 = double g_a24UZ
                      (g_a24UZ, gpart_a24VY) = Genome.Split.split gpart_a24VX
                      p_a24UY = double g_a24UX
                      (g_a24UX, gpart_a24VX) = Genome.Split.split gpart_a24VW
                      p_a24UW = double g_a24UV
                      (g_a24UV, gpart_a24VW) = Genome.Split.split gpart_a24VV
                      p_a24UU = Functions.belowten' g_a24UT
                      (g_a24UT, gpart_a24VV) = Genome.Split.split gpart_a24VU
                      p_a24US = double g_a24UR
                      (g_a24UR, gpart_a24VU) = Genome.Split.split gpart_a24VT
                      p_a24UQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24UP
                      (g_a24UP, gpart_a24VT) = Genome.Split.split gpart_a24VS
                      p_a24UO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24UN
                      (g_a24UN, gpart_a24VS) = Genome.Split.split gpart_a24VR
                      p_a24UM = double g_a24UL
                      (g_a24UL, gpart_a24VR) = Genome.Split.split gpart_a24VQ
                      p_a24UK = Functions.belowten' g_a24UJ
                      (g_a24UJ, gpart_a24VQ) = Genome.Split.split gpart_a24VP
                      p_a24UI = double g_a24UH
                      (g_a24UH, gpart_a24VP) = Genome.Split.split gpart_a24VO
                      p_a24UG = Functions.belowten' g_a24UF
                      (g_a24UF, gpart_a24VO) = Genome.Split.split gpart_a24VN
                      p_a24UE = double g_a24UD
                      (g_a24UD, gpart_a24VN) = Genome.Split.split gpart_a24VM
                      p_a24UC = double g_a24UB
                      (g_a24UB, gpart_a24VM) = Genome.Split.split gpart_a24VL
                      p_a24UA = Functions.belowten' g_a24Uz
                      (g_a24Uz, gpart_a24VL) = Genome.Split.split gpart_a24VK
                      p_a24Uy = double g_a24Ux
                      (g_a24Ux, gpart_a24VK) = Genome.Split.split gpart_a24VJ
                      p_a24Uw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Uv
                      (g_a24Uv, gpart_a24VJ) = Genome.Split.split gpart_a24VI
                      p_a24Uu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ut
                      (g_a24Ut, gpart_a24VI) = Genome.Split.split gpart_a24VH
                      p_a24Us = Functions.belowten' g_a24Ur
                      (g_a24Ur, gpart_a24VH) = Genome.Split.split gpart_a24VG
                      p_a24Uq = double g_a24Up
                      (g_a24Up, gpart_a24VG) = Genome.Split.split gpart_a24VF
                      p_a24Uo = double g_a24Un
                      (g_a24Un, gpart_a24VF) = Genome.Split.split gpart_a24VE
                      p_a24Um = double g_a24Ul
                      (g_a24Ul, gpart_a24VE) = Genome.Split.split gpart_a24VD
                      p_a24Uk = double g_a24Uj
                      (g_a24Uj, gpart_a24VD) = Genome.Split.split gpart_a24VC
                      p_a24Ui = double g_a24Uh
                      (g_a24Uh, gpart_a24VC) = Genome.Split.split gpart_a24VB
                      p_a24Ug = double g_a24Uf
                      (g_a24Uf, gpart_a24VB) = Genome.Split.split genome_a24Vz
                    in  \ x_a24Wg
                          -> let
                               c_PTB_a24Wk
                                 = ((Data.Fixed.Vector.toVector x_a24Wg) Data.Vector.Unboxed.! 0)
                               c_RESTc_a24Wh
                                 = ((Data.Fixed.Vector.toVector x_a24Wg) Data.Vector.Unboxed.! 3)
                               c_MiRs_a24Wi
                                 = ((Data.Fixed.Vector.toVector x_a24Wg) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Wo
                                 = ((Data.Fixed.Vector.toVector x_a24Wg) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a24WB
                                 = ((Data.Fixed.Vector.toVector x_a24Wg) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Uo
                                     / (1
                                        + ((((c_RESTc_a24Wh / p_a24Uq) ** p_a24Us)
                                            + ((p_a24Ug / p_a24Uu) ** p_a24Uw))
                                           + ((c_MiRs_a24Wi / p_a24Uy) ** p_a24UA))))
                                    + (negate (p_a24Vq * c_PTB_a24Wk))),
                                   ((p_a24UC
                                     / (1
                                        + (((c_MiRs_a24Wi / p_a24UE) ** p_a24UG)
                                           + ((c_PTB_a24Wk / p_a24UI) ** p_a24UK))))
                                    + (negate (p_a24Vs * c_NPTB_a24Wo))),
                                   ((p_a24UM
                                     * (p_a24UW
                                        / ((1 + p_a24UW) + ((c_RESTc_a24Wh / p_a24US) ** p_a24UU))))
                                    + (negate (p_a24Vu * c_MiRs_a24Wi))),
                                   ((p_a24UY
                                     * ((p_a24Vc + ((c_PTB_a24Wk / p_a24V0) ** p_a24V2))
                                        / (((1 + p_a24Vc) + ((c_PTB_a24Wk / p_a24V0) ** p_a24V2))
                                           + ((c_MiRs_a24Wi / p_a24V8) ** p_a24Va))))
                                    + (negate (p_a24Vw * c_RESTc_a24Wh))),
                                   ((p_a24Ve
                                     * ((p_a24Vo + ((c_MiRs_a24Wi / p_a24Vg) ** p_a24Vi))
                                        / (((1 + p_a24Vo) + ((c_MiRs_a24Wi / p_a24Vg) ** p_a24Vi))
                                           + ((c_RESTc_a24Wh / p_a24Vk) ** p_a24Vm))))
                                    + (negate (p_a24Vy * c_EndoNeuroTFs_a24WB)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505316",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505317",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505318",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505320",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505322",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505324",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505325",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505326",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505327",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505328",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505329",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505330",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505331",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505332",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505333",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505334",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505336",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505338",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505340",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505346",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505348",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505350",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505352",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505354",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505356",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505362",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505364",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505372",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Vz
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Xg
                            p_a24Vy = double g_a24Vx
                            (g_a24Vx, gpart_a24Xg) = Genome.Split.split gpart_a24Xf
                            p_a24Vw = double g_a24Vv
                            (g_a24Vv, gpart_a24Xf) = Genome.Split.split gpart_a24Xe
                            p_a24Vu = double g_a24Vt
                            (g_a24Vt, gpart_a24Xe) = Genome.Split.split gpart_a24Xd
                            p_a24Vs = double g_a24Vr
                            (g_a24Vr, gpart_a24Xd) = Genome.Split.split gpart_a24Xc
                            p_a24Vq = double g_a24Vp
                            (g_a24Vp, gpart_a24Xc) = Genome.Split.split gpart_a24Xb
                            p_a24Vo = double g_a24Vn
                            (g_a24Vn, gpart_a24Xb) = Genome.Split.split gpart_a24Xa
                            p_a24Vm = Functions.belowten' g_a24Vl
                            (g_a24Vl, gpart_a24Xa) = Genome.Split.split gpart_a24X9
                            p_a24Vk = double g_a24Vj
                            (g_a24Vj, gpart_a24X9) = Genome.Split.split gpart_a24X8
                            p_a24Vi = Functions.belowten' g_a24Vh
                            (g_a24Vh, gpart_a24X8) = Genome.Split.split gpart_a24X7
                            p_a24Vg = double g_a24Vf
                            (g_a24Vf, gpart_a24X7) = Genome.Split.split gpart_a24X6
                            p_a24Ve = double g_a24Vd
                            (g_a24Vd, gpart_a24X6) = Genome.Split.split gpart_a24X5
                            p_a24Vc = double g_a24Vb
                            (g_a24Vb, gpart_a24X5) = Genome.Split.split gpart_a24X4
                            p_a24Va = Functions.belowten' g_a24V9
                            (g_a24V9, gpart_a24X4) = Genome.Split.split gpart_a24X3
                            p_a24V8 = double g_a24V7
                            (g_a24V7, gpart_a24X3) = Genome.Split.split gpart_a24X2
                            p_a24V6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24V5
                            (g_a24V5, gpart_a24X2) = Genome.Split.split gpart_a24X1
                            p_a24V4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24V3
                            (g_a24V3, gpart_a24X1) = Genome.Split.split gpart_a24X0
                            p_a24V2 = Functions.belowten' g_a24V1
                            (g_a24V1, gpart_a24X0) = Genome.Split.split gpart_a24WZ
                            p_a24V0 = double g_a24UZ
                            (g_a24UZ, gpart_a24WZ) = Genome.Split.split gpart_a24WY
                            p_a24UY = double g_a24UX
                            (g_a24UX, gpart_a24WY) = Genome.Split.split gpart_a24WX
                            p_a24UW = double g_a24UV
                            (g_a24UV, gpart_a24WX) = Genome.Split.split gpart_a24WW
                            p_a24UU = Functions.belowten' g_a24UT
                            (g_a24UT, gpart_a24WW) = Genome.Split.split gpart_a24WV
                            p_a24US = double g_a24UR
                            (g_a24UR, gpart_a24WV) = Genome.Split.split gpart_a24WU
                            p_a24UQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24UP
                            (g_a24UP, gpart_a24WU) = Genome.Split.split gpart_a24WT
                            p_a24UO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24UN
                            (g_a24UN, gpart_a24WT) = Genome.Split.split gpart_a24WS
                            p_a24UM = double g_a24UL
                            (g_a24UL, gpart_a24WS) = Genome.Split.split gpart_a24WR
                            p_a24UK = Functions.belowten' g_a24UJ
                            (g_a24UJ, gpart_a24WR) = Genome.Split.split gpart_a24WQ
                            p_a24UI = double g_a24UH
                            (g_a24UH, gpart_a24WQ) = Genome.Split.split gpart_a24WP
                            p_a24UG = Functions.belowten' g_a24UF
                            (g_a24UF, gpart_a24WP) = Genome.Split.split gpart_a24WO
                            p_a24UE = double g_a24UD
                            (g_a24UD, gpart_a24WO) = Genome.Split.split gpart_a24WN
                            p_a24UC = double g_a24UB
                            (g_a24UB, gpart_a24WN) = Genome.Split.split gpart_a24WM
                            p_a24UA = Functions.belowten' g_a24Uz
                            (g_a24Uz, gpart_a24WM) = Genome.Split.split gpart_a24WL
                            p_a24Uy = double g_a24Ux
                            (g_a24Ux, gpart_a24WL) = Genome.Split.split gpart_a24WK
                            p_a24Uw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Uv
                            (g_a24Uv, gpart_a24WK) = Genome.Split.split gpart_a24WJ
                            p_a24Uu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ut
                            (g_a24Ut, gpart_a24WJ) = Genome.Split.split gpart_a24WI
                            p_a24Us = Functions.belowten' g_a24Ur
                            (g_a24Ur, gpart_a24WI) = Genome.Split.split gpart_a24WH
                            p_a24Uq = double g_a24Up
                            (g_a24Up, gpart_a24WH) = Genome.Split.split gpart_a24WG
                            p_a24Uo = double g_a24Un
                            (g_a24Un, gpart_a24WG) = Genome.Split.split gpart_a24WF
                            p_a24Um = double g_a24Ul
                            (g_a24Ul, gpart_a24WF) = Genome.Split.split gpart_a24WE
                            p_a24Uk = double g_a24Uj
                            (g_a24Uj, gpart_a24WE) = Genome.Split.split gpart_a24WD
                            p_a24Ui = double g_a24Uh
                            (g_a24Uh, gpart_a24WD) = Genome.Split.split gpart_a24WC
                            p_a24Ug = double g_a24Uf
                            (g_a24Uf, gpart_a24WC) = Genome.Split.split genome_a24Vz
                          in
                            \ desc_a24VA
                              -> case desc_a24VA of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ug)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ui)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Uk)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Um)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Uo)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Uq)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Us)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Uu)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Uw)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Uy)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UA)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UC)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UE)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UG)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UI)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UK)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UM)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UO)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UQ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24US)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UU)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UW)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24UY)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24V0)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24V2)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24V4)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24V6)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24V8)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Va)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vc)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ve)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vg)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vi)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vk)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vm)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vo)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vq)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vs)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vu)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vw)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vy)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asUg
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUW
                      p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                      (g_asUe, gpart_asUW) = Genome.Split.split gpart_asUV
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asUV) = Genome.Split.split gpart_asUU
                      p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                      (g_asUa, gpart_asUU) = Genome.Split.split gpart_asUT
                      p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                      (g_asU8, gpart_asUT) = Genome.Split.split gpart_asUS
                      p_asU7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU6
                      (g_asU6, gpart_asUS) = Genome.Split.split gpart_asUR
                      p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                      (g_asU4, gpart_asUR) = Genome.Split.split gpart_asUQ
                      p_asU3 = Functions.belowten' g_asU2
                      (g_asU2, gpart_asUQ) = Genome.Split.split gpart_asUP
                      p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                      (g_asU0, gpart_asUP) = Genome.Split.split gpart_asUO
                      p_asTZ = Functions.belowten' g_asTY
                      (g_asTY, gpart_asUO) = Genome.Split.split gpart_asUN
                      p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                      (g_asTW, gpart_asUN) = Genome.Split.split gpart_asUM
                      p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                      (g_asTU, gpart_asUM) = Genome.Split.split gpart_asUL
                      p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                      (g_asTS, gpart_asUL) = Genome.Split.split gpart_asUK
                      p_asTR = Functions.belowten' g_asTQ
                      (g_asTQ, gpart_asUK) = Genome.Split.split gpart_asUJ
                      p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                      (g_asTO, gpart_asUJ) = Genome.Split.split gpart_asUI
                      p_asTN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTM
                      (g_asTM, gpart_asUI) = Genome.Split.split gpart_asUH
                      p_asTL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTK
                      (g_asTK, gpart_asUH) = Genome.Split.split gpart_asUG
                      p_asTJ = Functions.belowten' g_asTI
                      (g_asTI, gpart_asUG) = Genome.Split.split gpart_asUF
                      p_asTH = code-0.1.0.0:Genome.FixedList.Functions.double g_asTG
                      (g_asTG, gpart_asUF) = Genome.Split.split gpart_asUE
                      p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                      (g_asTE, gpart_asUE) = Genome.Split.split gpart_asUD
                      p_asTD = code-0.1.0.0:Genome.FixedList.Functions.double g_asTC
                      (g_asTC, gpart_asUD) = Genome.Split.split gpart_asUC
                      p_asTB = Functions.belowten' g_asTA
                      (g_asTA, gpart_asUC) = Genome.Split.split gpart_asUB
                      p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                      (g_asTy, gpart_asUB) = Genome.Split.split gpart_asUA
                      p_asTx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTw
                      (g_asTw, gpart_asUA) = Genome.Split.split gpart_asUz
                      p_asTv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTu
                      (g_asTu, gpart_asUz) = Genome.Split.split gpart_asUy
                      p_asTt = code-0.1.0.0:Genome.FixedList.Functions.double g_asTs
                      (g_asTs, gpart_asUy) = Genome.Split.split gpart_asUx
                      p_asTr = Functions.belowten' g_asTq
                      (g_asTq, gpart_asUx) = Genome.Split.split gpart_asUw
                      p_asTp = code-0.1.0.0:Genome.FixedList.Functions.double g_asTo
                      (g_asTo, gpart_asUw) = Genome.Split.split gpart_asUv
                      p_asTn = Functions.belowten' g_asTm
                      (g_asTm, gpart_asUv) = Genome.Split.split gpart_asUu
                      p_asTl = code-0.1.0.0:Genome.FixedList.Functions.double g_asTk
                      (g_asTk, gpart_asUu) = Genome.Split.split gpart_asUt
                      p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                      (g_asTi, gpart_asUt) = Genome.Split.split gpart_asUs
                      p_asTh = Functions.belowten' g_asTg
                      (g_asTg, gpart_asUs) = Genome.Split.split gpart_asUr
                      p_asTf = code-0.1.0.0:Genome.FixedList.Functions.double g_asTe
                      (g_asTe, gpart_asUr) = Genome.Split.split gpart_asUq
                      p_asTd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTc
                      (g_asTc, gpart_asUq) = Genome.Split.split gpart_asUp
                      p_asTb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTa
                      (g_asTa, gpart_asUp) = Genome.Split.split gpart_asUo
                      p_asT9 = Functions.belowten' g_asT8
                      (g_asT8, gpart_asUo) = Genome.Split.split gpart_asUn
                      p_asT7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT6
                      (g_asT6, gpart_asUn) = Genome.Split.split gpart_asUm
                      p_asT5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT4
                      (g_asT4, gpart_asUm) = Genome.Split.split gpart_asUl
                      p_asT3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT2
                      (g_asT2, gpart_asUl) = Genome.Split.split gpart_asUk
                      p_asT1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT0
                      (g_asT0, gpart_asUk) = Genome.Split.split gpart_asUj
                      p_asSZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSY
                      (g_asSY, gpart_asUj) = Genome.Split.split gpart_asUi
                      p_asSX = code-0.1.0.0:Genome.FixedList.Functions.double g_asSW
                      (g_asSW, gpart_asUi) = Genome.Split.split genome_asUg
                    in
                      [Reaction
                         (\ x_asUX
                            -> let
                                 c_RESTc_asUY = ((toVector x_asUX) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asUZ = ((toVector x_asUX) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asT5
                                  / (1
                                     + (((c_RESTc_asUY / p_asT7) ** p_asT9)
                                        + ((c_MiRs_asUZ / p_asTf) ** p_asTh)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asV0
                            -> let
                                 c_MiRs_asV1 = ((toVector x_asV0) Data.Vector.Unboxed.! 2)
                                 c_PTB_asV2 = ((toVector x_asV0) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTj
                                  / (1
                                     + (((c_MiRs_asV1 / p_asTl) ** p_asTn)
                                        + ((c_PTB_asV2 / p_asTp) ** p_asTr)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asV3
                            -> let c_RESTc_asV4 = ((toVector x_asV3) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asTt
                                  * ((p_asTD + ((p_asT1 / p_asTv) ** p_asTx))
                                     / (((1 + p_asTD) + ((p_asT1 / p_asTv) ** p_asTx))
                                        + ((c_RESTc_asV4 / p_asTz) ** p_asTB)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asV5
                            -> let
                                 c_MiRs_asV8 = ((toVector x_asV5) Data.Vector.Unboxed.! 2)
                                 c_PTB_asV6 = ((toVector x_asV5) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTF
                                  * ((p_asTT + ((c_PTB_asV6 / p_asTH) ** p_asTJ))
                                     / (((1 + p_asTT) + ((c_PTB_asV6 / p_asTH) ** p_asTJ))
                                        + (((p_asSX / p_asTL) ** p_asTN)
                                           + ((c_MiRs_asV8 / p_asTP) ** p_asTR))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asV9
                            -> let
                                 c_RESTc_asVc = ((toVector x_asV9) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asVa = ((toVector x_asV9) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asTV
                                  * ((p_asU5 + ((c_MiRs_asVa / p_asTX) ** p_asTZ))
                                     / (((1 + p_asU5) + ((c_MiRs_asVa / p_asTX) ** p_asTZ))
                                        + ((c_RESTc_asVc / p_asU1) ** p_asU3)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asVd
                            -> let c_PTB_asVe = ((toVector x_asVd) Data.Vector.Unboxed.! 0)
                               in (p_asU7 * c_PTB_asVe))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVf
                            -> let c_NPTB_asVg = ((toVector x_asVf) Data.Vector.Unboxed.! 1)
                               in (p_asU9 * c_NPTB_asVg))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asVh
                            -> let c_MiRs_asVi = ((toVector x_asVh) Data.Vector.Unboxed.! 2)
                               in (p_asUb * c_MiRs_asVi))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asVj
                            -> let c_RESTc_asVk = ((toVector x_asVj) Data.Vector.Unboxed.! 3)
                               in (p_asUd * c_RESTc_asVk))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asVl
                            -> let
                                 c_EndoNeuroTFs_asVm = ((toVector x_asVl) Data.Vector.Unboxed.! 4)
                               in (p_asUf * c_EndoNeuroTFs_asVm))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120839",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120841",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120843",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120845",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120847",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120865",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120867",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120879",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120881",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120883",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asUg
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asW6
                            p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                            (g_asUe, gpart_asW6) = Genome.Split.split gpart_asW5
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asW5) = Genome.Split.split gpart_asW4
                            p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                            (g_asUa, gpart_asW4) = Genome.Split.split gpart_asW3
                            p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                            (g_asU8, gpart_asW3) = Genome.Split.split gpart_asW2
                            p_asU7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU6
                            (g_asU6, gpart_asW2) = Genome.Split.split gpart_asW1
                            p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                            (g_asU4, gpart_asW1) = Genome.Split.split gpart_asW0
                            p_asU3 = Functions.belowten' g_asU2
                            (g_asU2, gpart_asW0) = Genome.Split.split gpart_asVZ
                            p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                            (g_asU0, gpart_asVZ) = Genome.Split.split gpart_asVY
                            p_asTZ = Functions.belowten' g_asTY
                            (g_asTY, gpart_asVY) = Genome.Split.split gpart_asVX
                            p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                            (g_asTW, gpart_asVX) = Genome.Split.split gpart_asVW
                            p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                            (g_asTU, gpart_asVW) = Genome.Split.split gpart_asVV
                            p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                            (g_asTS, gpart_asVV) = Genome.Split.split gpart_asVU
                            p_asTR = Functions.belowten' g_asTQ
                            (g_asTQ, gpart_asVU) = Genome.Split.split gpart_asVT
                            p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                            (g_asTO, gpart_asVT) = Genome.Split.split gpart_asVS
                            p_asTN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTM
                            (g_asTM, gpart_asVS) = Genome.Split.split gpart_asVR
                            p_asTL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTK
                            (g_asTK, gpart_asVR) = Genome.Split.split gpart_asVQ
                            p_asTJ = Functions.belowten' g_asTI
                            (g_asTI, gpart_asVQ) = Genome.Split.split gpart_asVP
                            p_asTH = code-0.1.0.0:Genome.FixedList.Functions.double g_asTG
                            (g_asTG, gpart_asVP) = Genome.Split.split gpart_asVO
                            p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                            (g_asTE, gpart_asVO) = Genome.Split.split gpart_asVN
                            p_asTD = code-0.1.0.0:Genome.FixedList.Functions.double g_asTC
                            (g_asTC, gpart_asVN) = Genome.Split.split gpart_asVM
                            p_asTB = Functions.belowten' g_asTA
                            (g_asTA, gpart_asVM) = Genome.Split.split gpart_asVL
                            p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                            (g_asTy, gpart_asVL) = Genome.Split.split gpart_asVK
                            p_asTx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTw
                            (g_asTw, gpart_asVK) = Genome.Split.split gpart_asVJ
                            p_asTv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTu
                            (g_asTu, gpart_asVJ) = Genome.Split.split gpart_asVI
                            p_asTt = code-0.1.0.0:Genome.FixedList.Functions.double g_asTs
                            (g_asTs, gpart_asVI) = Genome.Split.split gpart_asVH
                            p_asTr = Functions.belowten' g_asTq
                            (g_asTq, gpart_asVH) = Genome.Split.split gpart_asVG
                            p_asTp = code-0.1.0.0:Genome.FixedList.Functions.double g_asTo
                            (g_asTo, gpart_asVG) = Genome.Split.split gpart_asVF
                            p_asTn = Functions.belowten' g_asTm
                            (g_asTm, gpart_asVF) = Genome.Split.split gpart_asVE
                            p_asTl = code-0.1.0.0:Genome.FixedList.Functions.double g_asTk
                            (g_asTk, gpart_asVE) = Genome.Split.split gpart_asVD
                            p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                            (g_asTi, gpart_asVD) = Genome.Split.split gpart_asVC
                            p_asTh = Functions.belowten' g_asTg
                            (g_asTg, gpart_asVC) = Genome.Split.split gpart_asVB
                            p_asTf = code-0.1.0.0:Genome.FixedList.Functions.double g_asTe
                            (g_asTe, gpart_asVB) = Genome.Split.split gpart_asVA
                            p_asTd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTc
                            (g_asTc, gpart_asVA) = Genome.Split.split gpart_asVz
                            p_asTb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTa
                            (g_asTa, gpart_asVz) = Genome.Split.split gpart_asVy
                            p_asT9 = Functions.belowten' g_asT8
                            (g_asT8, gpart_asVy) = Genome.Split.split gpart_asVx
                            p_asT7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT6
                            (g_asT6, gpart_asVx) = Genome.Split.split gpart_asVw
                            p_asT5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT4
                            (g_asT4, gpart_asVw) = Genome.Split.split gpart_asVv
                            p_asT3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT2
                            (g_asT2, gpart_asVv) = Genome.Split.split gpart_asVu
                            p_asT1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT0
                            (g_asT0, gpart_asVu) = Genome.Split.split gpart_asVt
                            p_asSZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSY
                            (g_asSY, gpart_asVt) = Genome.Split.split gpart_asVs
                            p_asSX = code-0.1.0.0:Genome.FixedList.Functions.double g_asSW
                            (g_asSW, gpart_asVs) = Genome.Split.split genome_asUg
                          in
                            \ desc_asUh
                              -> case desc_asUh of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSX)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSZ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT1)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT3)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT5)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT7)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT9)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTb)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTd)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTf)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTh)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTj)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTl)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTn)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTp)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTr)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTt)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTv)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTx)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTz)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTB)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTD)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTF)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTH)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTJ)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTL)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTN)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTP)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTR)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTT)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTV)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTX)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTZ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU1)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU3)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU5)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asY7
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYN
                      p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                      (g_asY5, gpart_asYN) = Genome.Split.split gpart_asYM
                      p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                      (g_asY3, gpart_asYM) = Genome.Split.split gpart_asYL
                      p_asY2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY1
                      (g_asY1, gpart_asYL) = Genome.Split.split gpart_asYK
                      p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                      (g_asXZ, gpart_asYK) = Genome.Split.split gpart_asYJ
                      p_asXY = code-0.1.0.0:Genome.FixedList.Functions.double g_asXX
                      (g_asXX, gpart_asYJ) = Genome.Split.split gpart_asYI
                      p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                      (g_asXV, gpart_asYI) = Genome.Split.split gpart_asYH
                      p_asXU = Functions.belowten' g_asXT
                      (g_asXT, gpart_asYH) = Genome.Split.split gpart_asYG
                      p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                      (g_asXR, gpart_asYG) = Genome.Split.split gpart_asYF
                      p_asXQ = Functions.belowten' g_asXP
                      (g_asXP, gpart_asYF) = Genome.Split.split gpart_asYE
                      p_asXO = code-0.1.0.0:Genome.FixedList.Functions.double g_asXN
                      (g_asXN, gpart_asYE) = Genome.Split.split gpart_asYD
                      p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                      (g_asXL, gpart_asYD) = Genome.Split.split gpart_asYC
                      p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                      (g_asXJ, gpart_asYC) = Genome.Split.split gpart_asYB
                      p_asXI = Functions.belowten' g_asXH
                      (g_asXH, gpart_asYB) = Genome.Split.split gpart_asYA
                      p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                      (g_asXF, gpart_asYA) = Genome.Split.split gpart_asYz
                      p_asXE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXD
                      (g_asXD, gpart_asYz) = Genome.Split.split gpart_asYy
                      p_asXC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXB
                      (g_asXB, gpart_asYy) = Genome.Split.split gpart_asYx
                      p_asXA = Functions.belowten' g_asXz
                      (g_asXz, gpart_asYx) = Genome.Split.split gpart_asYw
                      p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                      (g_asXx, gpart_asYw) = Genome.Split.split gpart_asYv
                      p_asXw = code-0.1.0.0:Genome.FixedList.Functions.double g_asXv
                      (g_asXv, gpart_asYv) = Genome.Split.split gpart_asYu
                      p_asXu = code-0.1.0.0:Genome.FixedList.Functions.double g_asXt
                      (g_asXt, gpart_asYu) = Genome.Split.split gpart_asYt
                      p_asXs = Functions.belowten' g_asXr
                      (g_asXr, gpart_asYt) = Genome.Split.split gpart_asYs
                      p_asXq = code-0.1.0.0:Genome.FixedList.Functions.double g_asXp
                      (g_asXp, gpart_asYs) = Genome.Split.split gpart_asYr
                      p_asXo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXn
                      (g_asXn, gpart_asYr) = Genome.Split.split gpart_asYq
                      p_asXm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXl
                      (g_asXl, gpart_asYq) = Genome.Split.split gpart_asYp
                      p_asXk = code-0.1.0.0:Genome.FixedList.Functions.double g_asXj
                      (g_asXj, gpart_asYp) = Genome.Split.split gpart_asYo
                      p_asXi = Functions.belowten' g_asXh
                      (g_asXh, gpart_asYo) = Genome.Split.split gpart_asYn
                      p_asXg = code-0.1.0.0:Genome.FixedList.Functions.double g_asXf
                      (g_asXf, gpart_asYn) = Genome.Split.split gpart_asYm
                      p_asXe = Functions.belowten' g_asXd
                      (g_asXd, gpart_asYm) = Genome.Split.split gpart_asYl
                      p_asXc = code-0.1.0.0:Genome.FixedList.Functions.double g_asXb
                      (g_asXb, gpart_asYl) = Genome.Split.split gpart_asYk
                      p_asXa = code-0.1.0.0:Genome.FixedList.Functions.double g_asX9
                      (g_asX9, gpart_asYk) = Genome.Split.split gpart_asYj
                      p_asX8 = Functions.belowten' g_asX7
                      (g_asX7, gpart_asYj) = Genome.Split.split gpart_asYi
                      p_asX6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX5
                      (g_asX5, gpart_asYi) = Genome.Split.split gpart_asYh
                      p_asX4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX3
                      (g_asX3, gpart_asYh) = Genome.Split.split gpart_asYg
                      p_asX2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX1
                      (g_asX1, gpart_asYg) = Genome.Split.split gpart_asYf
                      p_asX0 = Functions.belowten' g_asWZ
                      (g_asWZ, gpart_asYf) = Genome.Split.split gpart_asYe
                      p_asWY = code-0.1.0.0:Genome.FixedList.Functions.double g_asWX
                      (g_asWX, gpart_asYe) = Genome.Split.split gpart_asYd
                      p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                      (g_asWV, gpart_asYd) = Genome.Split.split gpart_asYc
                      p_asWU = code-0.1.0.0:Genome.FixedList.Functions.double g_asWT
                      (g_asWT, gpart_asYc) = Genome.Split.split gpart_asYb
                      p_asWS = code-0.1.0.0:Genome.FixedList.Functions.double g_asWR
                      (g_asWR, gpart_asYb) = Genome.Split.split gpart_asYa
                      p_asWQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWP
                      (g_asWP, gpart_asYa) = Genome.Split.split gpart_asY9
                      p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                      (g_asWN, gpart_asY9) = Genome.Split.split genome_asY7
                    in
                      [Reaction
                         (\ x_asYO
                            -> let
                                 c_RESTc_asYP = ((toVector x_asYO) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asYQ = ((toVector x_asYO) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asWW
                                  / (1
                                     + (((c_RESTc_asYP / p_asWY) ** p_asX0)
                                        + ((c_MiRs_asYQ / p_asX6) ** p_asX8)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYR
                            -> let
                                 c_MiRs_asYS = ((toVector x_asYR) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYT = ((toVector x_asYR) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXa
                                  / (1
                                     + (((c_MiRs_asYS / p_asXc) ** p_asXe)
                                        + ((c_PTB_asYT / p_asXg) ** p_asXi)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asYU
                            -> let c_RESTc_asYV = ((toVector x_asYU) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asXk
                                  * (p_asXu
                                     / ((1 + p_asXu) + ((c_RESTc_asYV / p_asXq) ** p_asXs)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asYW
                            -> let
                                 c_MiRs_asYZ = ((toVector x_asYW) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYX = ((toVector x_asYW) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXw
                                  * ((p_asXK + ((c_PTB_asYX / p_asXy) ** p_asXA))
                                     / (((1 + p_asXK) + ((c_PTB_asYX / p_asXy) ** p_asXA))
                                        + (((p_asWO / p_asXC) ** p_asXE)
                                           + ((c_MiRs_asYZ / p_asXG) ** p_asXI))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZ0
                            -> let
                                 c_RESTc_asZ3 = ((toVector x_asZ0) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asZ1 = ((toVector x_asZ0) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asXM
                                  * ((p_asXW + ((c_MiRs_asZ1 / p_asXO) ** p_asXQ))
                                     / (((1 + p_asXW) + ((c_MiRs_asZ1 / p_asXO) ** p_asXQ))
                                        + ((c_RESTc_asZ3 / p_asXS) ** p_asXU)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZ4
                            -> let c_PTB_asZ5 = ((toVector x_asZ4) Data.Vector.Unboxed.! 0)
                               in (p_asXY * c_PTB_asZ5))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZ6
                            -> let c_NPTB_asZ7 = ((toVector x_asZ6) Data.Vector.Unboxed.! 1)
                               in (p_asY0 * c_NPTB_asZ7))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZ8
                            -> let c_MiRs_asZ9 = ((toVector x_asZ8) Data.Vector.Unboxed.! 2)
                               in (p_asY2 * c_MiRs_asZ9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZa
                            -> let c_RESTc_asZb = ((toVector x_asZa) Data.Vector.Unboxed.! 3)
                               in (p_asY4 * c_RESTc_asZb))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asZc
                            -> let
                                 c_EndoNeuroTFs_asZd = ((toVector x_asZc) Data.Vector.Unboxed.! 4)
                               in (p_asY6 * c_EndoNeuroTFs_asZd))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121069",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121070",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121071",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121072",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121073",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121074",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121075",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121076",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121077",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121078",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121079",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121080",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121081",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121082",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121083",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121084",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121085",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121086",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121087",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121088",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121089",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121090",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121091",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121092",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121093",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121094",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121095",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121096",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121097",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121098",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121099",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121100",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121101",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121102",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121103",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121104",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121105",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121106",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121107",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121108",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121110",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121120",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121122",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121124",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121126",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121128",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121132",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121138",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121140",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121148",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asY7
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZS
                            p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                            (g_asY5, gpart_asZS) = Genome.Split.split gpart_asZR
                            p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                            (g_asY3, gpart_asZR) = Genome.Split.split gpart_asZQ
                            p_asY2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY1
                            (g_asY1, gpart_asZQ) = Genome.Split.split gpart_asZP
                            p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                            (g_asXZ, gpart_asZP) = Genome.Split.split gpart_asZO
                            p_asXY = code-0.1.0.0:Genome.FixedList.Functions.double g_asXX
                            (g_asXX, gpart_asZO) = Genome.Split.split gpart_asZN
                            p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                            (g_asXV, gpart_asZN) = Genome.Split.split gpart_asZM
                            p_asXU = Functions.belowten' g_asXT
                            (g_asXT, gpart_asZM) = Genome.Split.split gpart_asZL
                            p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                            (g_asXR, gpart_asZL) = Genome.Split.split gpart_asZK
                            p_asXQ = Functions.belowten' g_asXP
                            (g_asXP, gpart_asZK) = Genome.Split.split gpart_asZJ
                            p_asXO = code-0.1.0.0:Genome.FixedList.Functions.double g_asXN
                            (g_asXN, gpart_asZJ) = Genome.Split.split gpart_asZI
                            p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                            (g_asXL, gpart_asZI) = Genome.Split.split gpart_asZH
                            p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                            (g_asXJ, gpart_asZH) = Genome.Split.split gpart_asZG
                            p_asXI = Functions.belowten' g_asXH
                            (g_asXH, gpart_asZG) = Genome.Split.split gpart_asZF
                            p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                            (g_asXF, gpart_asZF) = Genome.Split.split gpart_asZE
                            p_asXE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXD
                            (g_asXD, gpart_asZE) = Genome.Split.split gpart_asZD
                            p_asXC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXB
                            (g_asXB, gpart_asZD) = Genome.Split.split gpart_asZC
                            p_asXA = Functions.belowten' g_asXz
                            (g_asXz, gpart_asZC) = Genome.Split.split gpart_asZB
                            p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                            (g_asXx, gpart_asZB) = Genome.Split.split gpart_asZA
                            p_asXw = code-0.1.0.0:Genome.FixedList.Functions.double g_asXv
                            (g_asXv, gpart_asZA) = Genome.Split.split gpart_asZz
                            p_asXu = code-0.1.0.0:Genome.FixedList.Functions.double g_asXt
                            (g_asXt, gpart_asZz) = Genome.Split.split gpart_asZy
                            p_asXs = Functions.belowten' g_asXr
                            (g_asXr, gpart_asZy) = Genome.Split.split gpart_asZx
                            p_asXq = code-0.1.0.0:Genome.FixedList.Functions.double g_asXp
                            (g_asXp, gpart_asZx) = Genome.Split.split gpart_asZw
                            p_asXo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXn
                            (g_asXn, gpart_asZw) = Genome.Split.split gpart_asZv
                            p_asXm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXl
                            (g_asXl, gpart_asZv) = Genome.Split.split gpart_asZu
                            p_asXk = code-0.1.0.0:Genome.FixedList.Functions.double g_asXj
                            (g_asXj, gpart_asZu) = Genome.Split.split gpart_asZt
                            p_asXi = Functions.belowten' g_asXh
                            (g_asXh, gpart_asZt) = Genome.Split.split gpart_asZs
                            p_asXg = code-0.1.0.0:Genome.FixedList.Functions.double g_asXf
                            (g_asXf, gpart_asZs) = Genome.Split.split gpart_asZr
                            p_asXe = Functions.belowten' g_asXd
                            (g_asXd, gpart_asZr) = Genome.Split.split gpart_asZq
                            p_asXc = code-0.1.0.0:Genome.FixedList.Functions.double g_asXb
                            (g_asXb, gpart_asZq) = Genome.Split.split gpart_asZp
                            p_asXa = code-0.1.0.0:Genome.FixedList.Functions.double g_asX9
                            (g_asX9, gpart_asZp) = Genome.Split.split gpart_asZo
                            p_asX8 = Functions.belowten' g_asX7
                            (g_asX7, gpart_asZo) = Genome.Split.split gpart_asZn
                            p_asX6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX5
                            (g_asX5, gpart_asZn) = Genome.Split.split gpart_asZm
                            p_asX4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX3
                            (g_asX3, gpart_asZm) = Genome.Split.split gpart_asZl
                            p_asX2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX1
                            (g_asX1, gpart_asZl) = Genome.Split.split gpart_asZk
                            p_asX0 = Functions.belowten' g_asWZ
                            (g_asWZ, gpart_asZk) = Genome.Split.split gpart_asZj
                            p_asWY = code-0.1.0.0:Genome.FixedList.Functions.double g_asWX
                            (g_asWX, gpart_asZj) = Genome.Split.split gpart_asZi
                            p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                            (g_asWV, gpart_asZi) = Genome.Split.split gpart_asZh
                            p_asWU = code-0.1.0.0:Genome.FixedList.Functions.double g_asWT
                            (g_asWT, gpart_asZh) = Genome.Split.split gpart_asZg
                            p_asWS = code-0.1.0.0:Genome.FixedList.Functions.double g_asWR
                            (g_asWR, gpart_asZg) = Genome.Split.split gpart_asZf
                            p_asWQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWP
                            (g_asWP, gpart_asZf) = Genome.Split.split gpart_asZe
                            p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                            (g_asWN, gpart_asZe) = Genome.Split.split genome_asY7
                          in
                            \ desc_asY8
                              -> case desc_asY8 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWO)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWQ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWS)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWU)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWW)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWY)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX0)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX2)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX4)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX6)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX8)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXa)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXc)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXe)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXg)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXi)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXk)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXm)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXo)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXq)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXs)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXu)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXw)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXy)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXA)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXC)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXE)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXG)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXI)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXK)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXM)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXO)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXQ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXS)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXU)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXW)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXY)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY0)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY2)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY4)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY6)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at1T
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2z
                      p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                      (g_at1R, gpart_at2z) = Genome.Split.split gpart_at2y
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at2y) = Genome.Split.split gpart_at2x
                      p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                      (g_at1N, gpart_at2x) = Genome.Split.split gpart_at2w
                      p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                      (g_at1L, gpart_at2w) = Genome.Split.split gpart_at2v
                      p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                      (g_at1J, gpart_at2v) = Genome.Split.split gpart_at2u
                      p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                      (g_at1H, gpart_at2u) = Genome.Split.split gpart_at2t
                      p_at1G = Functions.belowten' g_at1F
                      (g_at1F, gpart_at2t) = Genome.Split.split gpart_at2s
                      p_at1E = code-0.1.0.0:Genome.FixedList.Functions.double g_at1D
                      (g_at1D, gpart_at2s) = Genome.Split.split gpart_at2r
                      p_at1C = Functions.belowten' g_at1B
                      (g_at1B, gpart_at2r) = Genome.Split.split gpart_at2q
                      p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                      (g_at1z, gpart_at2q) = Genome.Split.split gpart_at2p
                      p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                      (g_at1x, gpart_at2p) = Genome.Split.split gpart_at2o
                      p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                      (g_at1v, gpart_at2o) = Genome.Split.split gpart_at2n
                      p_at1u = Functions.belowten' g_at1t
                      (g_at1t, gpart_at2n) = Genome.Split.split gpart_at2m
                      p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                      (g_at1r, gpart_at2m) = Genome.Split.split gpart_at2l
                      p_at1q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1p
                      (g_at1p, gpart_at2l) = Genome.Split.split gpart_at2k
                      p_at1o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1n
                      (g_at1n, gpart_at2k) = Genome.Split.split gpart_at2j
                      p_at1m = Functions.belowten' g_at1l
                      (g_at1l, gpart_at2j) = Genome.Split.split gpart_at2i
                      p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                      (g_at1j, gpart_at2i) = Genome.Split.split gpart_at2h
                      p_at1i = code-0.1.0.0:Genome.FixedList.Functions.double g_at1h
                      (g_at1h, gpart_at2h) = Genome.Split.split gpart_at2g
                      p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                      (g_at1f, gpart_at2g) = Genome.Split.split gpart_at2f
                      p_at1e = Functions.belowten' g_at1d
                      (g_at1d, gpart_at2f) = Genome.Split.split gpart_at2e
                      p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                      (g_at1b, gpart_at2e) = Genome.Split.split gpart_at2d
                      p_at1a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at19
                      (g_at19, gpart_at2d) = Genome.Split.split gpart_at2c
                      p_at18
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at17
                      (g_at17, gpart_at2c) = Genome.Split.split gpart_at2b
                      p_at16 = code-0.1.0.0:Genome.FixedList.Functions.double g_at15
                      (g_at15, gpart_at2b) = Genome.Split.split gpart_at2a
                      p_at14 = Functions.belowten' g_at13
                      (g_at13, gpart_at2a) = Genome.Split.split gpart_at29
                      p_at12 = code-0.1.0.0:Genome.FixedList.Functions.double g_at11
                      (g_at11, gpart_at29) = Genome.Split.split gpart_at28
                      p_at10 = Functions.belowten' g_at0Z
                      (g_at0Z, gpart_at28) = Genome.Split.split gpart_at27
                      p_at0Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0X
                      (g_at0X, gpart_at27) = Genome.Split.split gpart_at26
                      p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                      (g_at0V, gpart_at26) = Genome.Split.split gpart_at25
                      p_at0U = Functions.belowten' g_at0T
                      (g_at0T, gpart_at25) = Genome.Split.split gpart_at24
                      p_at0S = code-0.1.0.0:Genome.FixedList.Functions.double g_at0R
                      (g_at0R, gpart_at24) = Genome.Split.split gpart_at23
                      p_at0Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0P
                      (g_at0P, gpart_at23) = Genome.Split.split gpart_at22
                      p_at0O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0N
                      (g_at0N, gpart_at22) = Genome.Split.split gpart_at21
                      p_at0M = Functions.belowten' g_at0L
                      (g_at0L, gpart_at21) = Genome.Split.split gpart_at20
                      p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                      (g_at0J, gpart_at20) = Genome.Split.split gpart_at1Z
                      p_at0I = code-0.1.0.0:Genome.FixedList.Functions.double g_at0H
                      (g_at0H, gpart_at1Z) = Genome.Split.split gpart_at1Y
                      p_at0G = code-0.1.0.0:Genome.FixedList.Functions.double g_at0F
                      (g_at0F, gpart_at1Y) = Genome.Split.split gpart_at1X
                      p_at0E = code-0.1.0.0:Genome.FixedList.Functions.double g_at0D
                      (g_at0D, gpart_at1X) = Genome.Split.split gpart_at1W
                      p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                      (g_at0B, gpart_at1W) = Genome.Split.split gpart_at1V
                      p_at0A = code-0.1.0.0:Genome.FixedList.Functions.double g_at0z
                      (g_at0z, gpart_at1V) = Genome.Split.split genome_at1T
                    in
                      [Reaction
                         (\ x_at2A
                            -> let
                                 c_RESTc_at2B = ((toVector x_at2A) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at2C = ((toVector x_at2A) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at0I
                                  / (1
                                     + (((c_RESTc_at2B / p_at0K) ** p_at0M)
                                        + ((c_MiRs_at2C / p_at0S) ** p_at0U)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2D
                            -> let
                                 c_MiRs_at2E = ((toVector x_at2D) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2F = ((toVector x_at2D) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0W
                                  / (1
                                     + (((c_MiRs_at2E / p_at0Y) ** p_at10)
                                        + ((c_PTB_at2F / p_at12) ** p_at14)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at2G
                            -> let c_RESTc_at2H = ((toVector x_at2G) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at16
                                  * (p_at1g
                                     / ((1 + p_at1g) + ((c_RESTc_at2H / p_at1c) ** p_at1e)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at2I
                            -> let
                                 c_MiRs_at2L = ((toVector x_at2I) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2J = ((toVector x_at2I) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1i
                                  * ((p_at1w + ((c_PTB_at2J / p_at1k) ** p_at1m))
                                     / (((1 + p_at1w) + ((c_PTB_at2J / p_at1k) ** p_at1m))
                                        + ((c_MiRs_at2L / p_at1s) ** p_at1u)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2M
                            -> let
                                 c_RESTc_at2P = ((toVector x_at2M) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at2N = ((toVector x_at2M) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at1y
                                  * ((p_at1I + ((c_MiRs_at2N / p_at1A) ** p_at1C))
                                     / (((1 + p_at1I) + ((c_MiRs_at2N / p_at1A) ** p_at1C))
                                        + ((c_RESTc_at2P / p_at1E) ** p_at1G)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at2Q
                            -> let c_PTB_at2R = ((toVector x_at2Q) Data.Vector.Unboxed.! 0)
                               in (p_at1K * c_PTB_at2R))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2S
                            -> let c_NPTB_at2T = ((toVector x_at2S) Data.Vector.Unboxed.! 1)
                               in (p_at1M * c_NPTB_at2T))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at2U
                            -> let c_MiRs_at2V = ((toVector x_at2U) Data.Vector.Unboxed.! 2)
                               in (p_at1O * c_MiRs_at2V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at2W
                            -> let c_RESTc_at2X = ((toVector x_at2W) Data.Vector.Unboxed.! 3)
                               in (p_at1Q * c_RESTc_at2X))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at2Y
                            -> let
                                 c_EndoNeuroTFs_at2Z = ((toVector x_at2Y) Data.Vector.Unboxed.! 4)
                               in (p_at1S * c_EndoNeuroTFs_at2Z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121316",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121317",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121318",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121320",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121322",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121324",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121325",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121326",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121327",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121328",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121329",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121330",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121331",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121332",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121333",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121334",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121336",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121338",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121340",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121346",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121348",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121350",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121352",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121354",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121356",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121364",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at1T
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3E
                            p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                            (g_at1R, gpart_at3E) = Genome.Split.split gpart_at3D
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at3D) = Genome.Split.split gpart_at3C
                            p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                            (g_at1N, gpart_at3C) = Genome.Split.split gpart_at3B
                            p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                            (g_at1L, gpart_at3B) = Genome.Split.split gpart_at3A
                            p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                            (g_at1J, gpart_at3A) = Genome.Split.split gpart_at3z
                            p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                            (g_at1H, gpart_at3z) = Genome.Split.split gpart_at3y
                            p_at1G = Functions.belowten' g_at1F
                            (g_at1F, gpart_at3y) = Genome.Split.split gpart_at3x
                            p_at1E = code-0.1.0.0:Genome.FixedList.Functions.double g_at1D
                            (g_at1D, gpart_at3x) = Genome.Split.split gpart_at3w
                            p_at1C = Functions.belowten' g_at1B
                            (g_at1B, gpart_at3w) = Genome.Split.split gpart_at3v
                            p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                            (g_at1z, gpart_at3v) = Genome.Split.split gpart_at3u
                            p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                            (g_at1x, gpart_at3u) = Genome.Split.split gpart_at3t
                            p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                            (g_at1v, gpart_at3t) = Genome.Split.split gpart_at3s
                            p_at1u = Functions.belowten' g_at1t
                            (g_at1t, gpart_at3s) = Genome.Split.split gpart_at3r
                            p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                            (g_at1r, gpart_at3r) = Genome.Split.split gpart_at3q
                            p_at1q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1p
                            (g_at1p, gpart_at3q) = Genome.Split.split gpart_at3p
                            p_at1o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1n
                            (g_at1n, gpart_at3p) = Genome.Split.split gpart_at3o
                            p_at1m = Functions.belowten' g_at1l
                            (g_at1l, gpart_at3o) = Genome.Split.split gpart_at3n
                            p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                            (g_at1j, gpart_at3n) = Genome.Split.split gpart_at3m
                            p_at1i = code-0.1.0.0:Genome.FixedList.Functions.double g_at1h
                            (g_at1h, gpart_at3m) = Genome.Split.split gpart_at3l
                            p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                            (g_at1f, gpart_at3l) = Genome.Split.split gpart_at3k
                            p_at1e = Functions.belowten' g_at1d
                            (g_at1d, gpart_at3k) = Genome.Split.split gpart_at3j
                            p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                            (g_at1b, gpart_at3j) = Genome.Split.split gpart_at3i
                            p_at1a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at19
                            (g_at19, gpart_at3i) = Genome.Split.split gpart_at3h
                            p_at18
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at17
                            (g_at17, gpart_at3h) = Genome.Split.split gpart_at3g
                            p_at16 = code-0.1.0.0:Genome.FixedList.Functions.double g_at15
                            (g_at15, gpart_at3g) = Genome.Split.split gpart_at3f
                            p_at14 = Functions.belowten' g_at13
                            (g_at13, gpart_at3f) = Genome.Split.split gpart_at3e
                            p_at12 = code-0.1.0.0:Genome.FixedList.Functions.double g_at11
                            (g_at11, gpart_at3e) = Genome.Split.split gpart_at3d
                            p_at10 = Functions.belowten' g_at0Z
                            (g_at0Z, gpart_at3d) = Genome.Split.split gpart_at3c
                            p_at0Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0X
                            (g_at0X, gpart_at3c) = Genome.Split.split gpart_at3b
                            p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                            (g_at0V, gpart_at3b) = Genome.Split.split gpart_at3a
                            p_at0U = Functions.belowten' g_at0T
                            (g_at0T, gpart_at3a) = Genome.Split.split gpart_at39
                            p_at0S = code-0.1.0.0:Genome.FixedList.Functions.double g_at0R
                            (g_at0R, gpart_at39) = Genome.Split.split gpart_at38
                            p_at0Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0P
                            (g_at0P, gpart_at38) = Genome.Split.split gpart_at37
                            p_at0O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0N
                            (g_at0N, gpart_at37) = Genome.Split.split gpart_at36
                            p_at0M = Functions.belowten' g_at0L
                            (g_at0L, gpart_at36) = Genome.Split.split gpart_at35
                            p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                            (g_at0J, gpart_at35) = Genome.Split.split gpart_at34
                            p_at0I = code-0.1.0.0:Genome.FixedList.Functions.double g_at0H
                            (g_at0H, gpart_at34) = Genome.Split.split gpart_at33
                            p_at0G = code-0.1.0.0:Genome.FixedList.Functions.double g_at0F
                            (g_at0F, gpart_at33) = Genome.Split.split gpart_at32
                            p_at0E = code-0.1.0.0:Genome.FixedList.Functions.double g_at0D
                            (g_at0D, gpart_at32) = Genome.Split.split gpart_at31
                            p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                            (g_at0B, gpart_at31) = Genome.Split.split gpart_at30
                            p_at0A = code-0.1.0.0:Genome.FixedList.Functions.double g_at0z
                            (g_at0z, gpart_at30) = Genome.Split.split genome_at1T
                          in
                            \ desc_at1U
                              -> case desc_at1U of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0A)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0C)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0E)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0G)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0I)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0K)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0M)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0O)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Q)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0S)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0U)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at10)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at12)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at14)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at16)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at18)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1a)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1c)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1e)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1g)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1i)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1k)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1m)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1o)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1q)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1s)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1u)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1w)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1y)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at5F
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6l
                      p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                      (g_at5D, gpart_at6l) = Genome.Split.split gpart_at6k
                      p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                      (g_at5B, gpart_at6k) = Genome.Split.split gpart_at6j
                      p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                      (g_at5z, gpart_at6j) = Genome.Split.split gpart_at6i
                      p_at5y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5x
                      (g_at5x, gpart_at6i) = Genome.Split.split gpart_at6h
                      p_at5w = code-0.1.0.0:Genome.FixedList.Functions.double g_at5v
                      (g_at5v, gpart_at6h) = Genome.Split.split gpart_at6g
                      p_at5u = code-0.1.0.0:Genome.FixedList.Functions.double g_at5t
                      (g_at5t, gpart_at6g) = Genome.Split.split gpart_at6f
                      p_at5s = Functions.belowten' g_at5r
                      (g_at5r, gpart_at6f) = Genome.Split.split gpart_at6e
                      p_at5q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5p
                      (g_at5p, gpart_at6e) = Genome.Split.split gpart_at6d
                      p_at5o = Functions.belowten' g_at5n
                      (g_at5n, gpart_at6d) = Genome.Split.split gpart_at6c
                      p_at5m = code-0.1.0.0:Genome.FixedList.Functions.double g_at5l
                      (g_at5l, gpart_at6c) = Genome.Split.split gpart_at6b
                      p_at5k = code-0.1.0.0:Genome.FixedList.Functions.double g_at5j
                      (g_at5j, gpart_at6b) = Genome.Split.split gpart_at6a
                      p_at5i = code-0.1.0.0:Genome.FixedList.Functions.double g_at5h
                      (g_at5h, gpart_at6a) = Genome.Split.split gpart_at69
                      p_at5g = Functions.belowten' g_at5f
                      (g_at5f, gpart_at69) = Genome.Split.split gpart_at68
                      p_at5e = code-0.1.0.0:Genome.FixedList.Functions.double g_at5d
                      (g_at5d, gpart_at68) = Genome.Split.split gpart_at67
                      p_at5c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5b
                      (g_at5b, gpart_at67) = Genome.Split.split gpart_at66
                      p_at5a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at59
                      (g_at59, gpart_at66) = Genome.Split.split gpart_at65
                      p_at58 = Functions.belowten' g_at57
                      (g_at57, gpart_at65) = Genome.Split.split gpart_at64
                      p_at56 = code-0.1.0.0:Genome.FixedList.Functions.double g_at55
                      (g_at55, gpart_at64) = Genome.Split.split gpart_at63
                      p_at54 = code-0.1.0.0:Genome.FixedList.Functions.double g_at53
                      (g_at53, gpart_at63) = Genome.Split.split gpart_at62
                      p_at52 = code-0.1.0.0:Genome.FixedList.Functions.double g_at51
                      (g_at51, gpart_at62) = Genome.Split.split gpart_at61
                      p_at50 = Functions.belowten' g_at4Z
                      (g_at4Z, gpart_at61) = Genome.Split.split gpart_at60
                      p_at4Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4X
                      (g_at4X, gpart_at60) = Genome.Split.split gpart_at5Z
                      p_at4W
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4V
                      (g_at4V, gpart_at5Z) = Genome.Split.split gpart_at5Y
                      p_at4U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4T
                      (g_at4T, gpart_at5Y) = Genome.Split.split gpart_at5X
                      p_at4S = code-0.1.0.0:Genome.FixedList.Functions.double g_at4R
                      (g_at4R, gpart_at5X) = Genome.Split.split gpart_at5W
                      p_at4Q = Functions.belowten' g_at4P
                      (g_at4P, gpart_at5W) = Genome.Split.split gpart_at5V
                      p_at4O = code-0.1.0.0:Genome.FixedList.Functions.double g_at4N
                      (g_at4N, gpart_at5V) = Genome.Split.split gpart_at5U
                      p_at4M = Functions.belowten' g_at4L
                      (g_at4L, gpart_at5U) = Genome.Split.split gpart_at5T
                      p_at4K = code-0.1.0.0:Genome.FixedList.Functions.double g_at4J
                      (g_at4J, gpart_at5T) = Genome.Split.split gpart_at5S
                      p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                      (g_at4H, gpart_at5S) = Genome.Split.split gpart_at5R
                      p_at4G = Functions.belowten' g_at4F
                      (g_at4F, gpart_at5R) = Genome.Split.split gpart_at5Q
                      p_at4E = code-0.1.0.0:Genome.FixedList.Functions.double g_at4D
                      (g_at4D, gpart_at5Q) = Genome.Split.split gpart_at5P
                      p_at4C
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4B
                      (g_at4B, gpart_at5P) = Genome.Split.split gpart_at5O
                      p_at4A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4z
                      (g_at4z, gpart_at5O) = Genome.Split.split gpart_at5N
                      p_at4y = Functions.belowten' g_at4x
                      (g_at4x, gpart_at5N) = Genome.Split.split gpart_at5M
                      p_at4w = code-0.1.0.0:Genome.FixedList.Functions.double g_at4v
                      (g_at4v, gpart_at5M) = Genome.Split.split gpart_at5L
                      p_at4u = code-0.1.0.0:Genome.FixedList.Functions.double g_at4t
                      (g_at4t, gpart_at5L) = Genome.Split.split gpart_at5K
                      p_at4s = code-0.1.0.0:Genome.FixedList.Functions.double g_at4r
                      (g_at4r, gpart_at5K) = Genome.Split.split gpart_at5J
                      p_at4q = code-0.1.0.0:Genome.FixedList.Functions.double g_at4p
                      (g_at4p, gpart_at5J) = Genome.Split.split gpart_at5I
                      p_at4o = code-0.1.0.0:Genome.FixedList.Functions.double g_at4n
                      (g_at4n, gpart_at5I) = Genome.Split.split gpart_at5H
                      p_at4m = code-0.1.0.0:Genome.FixedList.Functions.double g_at4l
                      (g_at4l, gpart_at5H) = Genome.Split.split genome_at5F
                    in
                      [Reaction
                         (\ x_at6m
                            -> let
                                 c_RESTc_at6n = ((toVector x_at6m) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at6o = ((toVector x_at6m) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4u
                                  / (1
                                     + ((((c_RESTc_at6n / p_at4w) ** p_at4y)
                                         + ((p_at4m / p_at4A) ** p_at4C))
                                        + ((c_MiRs_at6o / p_at4E) ** p_at4G)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6p
                            -> let
                                 c_MiRs_at6q = ((toVector x_at6p) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6r = ((toVector x_at6p) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4I
                                  / (1
                                     + (((c_MiRs_at6q / p_at4K) ** p_at4M)
                                        + ((c_PTB_at6r / p_at4O) ** p_at4Q)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at6s
                            -> let c_RESTc_at6t = ((toVector x_at6s) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at4S
                                  * (p_at52
                                     / ((1 + p_at52) + ((c_RESTc_at6t / p_at4Y) ** p_at50)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at6u
                            -> let
                                 c_MiRs_at6x = ((toVector x_at6u) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6v = ((toVector x_at6u) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at54
                                  * ((p_at5i + ((c_PTB_at6v / p_at56) ** p_at58))
                                     / (((1 + p_at5i) + ((c_PTB_at6v / p_at56) ** p_at58))
                                        + ((c_MiRs_at6x / p_at5e) ** p_at5g)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6y
                            -> let
                                 c_RESTc_at6B = ((toVector x_at6y) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at6z = ((toVector x_at6y) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5k
                                  * ((p_at5u + ((c_MiRs_at6z / p_at5m) ** p_at5o))
                                     / (((1 + p_at5u) + ((c_MiRs_at6z / p_at5m) ** p_at5o))
                                        + ((c_RESTc_at6B / p_at5q) ** p_at5s)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at6C
                            -> let c_PTB_at6D = ((toVector x_at6C) Data.Vector.Unboxed.! 0)
                               in (p_at5w * c_PTB_at6D))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6E
                            -> let c_NPTB_at6F = ((toVector x_at6E) Data.Vector.Unboxed.! 1)
                               in (p_at5y * c_NPTB_at6F))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at6G
                            -> let c_MiRs_at6H = ((toVector x_at6G) Data.Vector.Unboxed.! 2)
                               in (p_at5A * c_MiRs_at6H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at6I
                            -> let c_RESTc_at6J = ((toVector x_at6I) Data.Vector.Unboxed.! 3)
                               in (p_at5C * c_RESTc_at6J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at6K
                            -> let
                                 c_EndoNeuroTFs_at6L = ((toVector x_at6K) Data.Vector.Unboxed.! 4)
                               in (p_at5E * c_EndoNeuroTFs_at6L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121538",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121544",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121548",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121550",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121552",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121554",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121568",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121572",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121574",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121575",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121576",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121577",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121578",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121579",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121580",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121581",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121582",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121583",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121584",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121586",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121588",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121590",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121592",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121593",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121594",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121595",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121596",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121597",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121598",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121599",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121600",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121601",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121602",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121603",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121604",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121605",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121606",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121607",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121608",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121609",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121610",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121611",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121612",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at5F
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7q
                            p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                            (g_at5D, gpart_at7q) = Genome.Split.split gpart_at7p
                            p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                            (g_at5B, gpart_at7p) = Genome.Split.split gpart_at7o
                            p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                            (g_at5z, gpart_at7o) = Genome.Split.split gpart_at7n
                            p_at5y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5x
                            (g_at5x, gpart_at7n) = Genome.Split.split gpart_at7m
                            p_at5w = code-0.1.0.0:Genome.FixedList.Functions.double g_at5v
                            (g_at5v, gpart_at7m) = Genome.Split.split gpart_at7l
                            p_at5u = code-0.1.0.0:Genome.FixedList.Functions.double g_at5t
                            (g_at5t, gpart_at7l) = Genome.Split.split gpart_at7k
                            p_at5s = Functions.belowten' g_at5r
                            (g_at5r, gpart_at7k) = Genome.Split.split gpart_at7j
                            p_at5q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5p
                            (g_at5p, gpart_at7j) = Genome.Split.split gpart_at7i
                            p_at5o = Functions.belowten' g_at5n
                            (g_at5n, gpart_at7i) = Genome.Split.split gpart_at7h
                            p_at5m = code-0.1.0.0:Genome.FixedList.Functions.double g_at5l
                            (g_at5l, gpart_at7h) = Genome.Split.split gpart_at7g
                            p_at5k = code-0.1.0.0:Genome.FixedList.Functions.double g_at5j
                            (g_at5j, gpart_at7g) = Genome.Split.split gpart_at7f
                            p_at5i = code-0.1.0.0:Genome.FixedList.Functions.double g_at5h
                            (g_at5h, gpart_at7f) = Genome.Split.split gpart_at7e
                            p_at5g = Functions.belowten' g_at5f
                            (g_at5f, gpart_at7e) = Genome.Split.split gpart_at7d
                            p_at5e = code-0.1.0.0:Genome.FixedList.Functions.double g_at5d
                            (g_at5d, gpart_at7d) = Genome.Split.split gpart_at7c
                            p_at5c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5b
                            (g_at5b, gpart_at7c) = Genome.Split.split gpart_at7b
                            p_at5a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at59
                            (g_at59, gpart_at7b) = Genome.Split.split gpart_at7a
                            p_at58 = Functions.belowten' g_at57
                            (g_at57, gpart_at7a) = Genome.Split.split gpart_at79
                            p_at56 = code-0.1.0.0:Genome.FixedList.Functions.double g_at55
                            (g_at55, gpart_at79) = Genome.Split.split gpart_at78
                            p_at54 = code-0.1.0.0:Genome.FixedList.Functions.double g_at53
                            (g_at53, gpart_at78) = Genome.Split.split gpart_at77
                            p_at52 = code-0.1.0.0:Genome.FixedList.Functions.double g_at51
                            (g_at51, gpart_at77) = Genome.Split.split gpart_at76
                            p_at50 = Functions.belowten' g_at4Z
                            (g_at4Z, gpart_at76) = Genome.Split.split gpart_at75
                            p_at4Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4X
                            (g_at4X, gpart_at75) = Genome.Split.split gpart_at74
                            p_at4W
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4V
                            (g_at4V, gpart_at74) = Genome.Split.split gpart_at73
                            p_at4U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4T
                            (g_at4T, gpart_at73) = Genome.Split.split gpart_at72
                            p_at4S = code-0.1.0.0:Genome.FixedList.Functions.double g_at4R
                            (g_at4R, gpart_at72) = Genome.Split.split gpart_at71
                            p_at4Q = Functions.belowten' g_at4P
                            (g_at4P, gpart_at71) = Genome.Split.split gpart_at70
                            p_at4O = code-0.1.0.0:Genome.FixedList.Functions.double g_at4N
                            (g_at4N, gpart_at70) = Genome.Split.split gpart_at6Z
                            p_at4M = Functions.belowten' g_at4L
                            (g_at4L, gpart_at6Z) = Genome.Split.split gpart_at6Y
                            p_at4K = code-0.1.0.0:Genome.FixedList.Functions.double g_at4J
                            (g_at4J, gpart_at6Y) = Genome.Split.split gpart_at6X
                            p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                            (g_at4H, gpart_at6X) = Genome.Split.split gpart_at6W
                            p_at4G = Functions.belowten' g_at4F
                            (g_at4F, gpart_at6W) = Genome.Split.split gpart_at6V
                            p_at4E = code-0.1.0.0:Genome.FixedList.Functions.double g_at4D
                            (g_at4D, gpart_at6V) = Genome.Split.split gpart_at6U
                            p_at4C
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4B
                            (g_at4B, gpart_at6U) = Genome.Split.split gpart_at6T
                            p_at4A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4z
                            (g_at4z, gpart_at6T) = Genome.Split.split gpart_at6S
                            p_at4y = Functions.belowten' g_at4x
                            (g_at4x, gpart_at6S) = Genome.Split.split gpart_at6R
                            p_at4w = code-0.1.0.0:Genome.FixedList.Functions.double g_at4v
                            (g_at4v, gpart_at6R) = Genome.Split.split gpart_at6Q
                            p_at4u = code-0.1.0.0:Genome.FixedList.Functions.double g_at4t
                            (g_at4t, gpart_at6Q) = Genome.Split.split gpart_at6P
                            p_at4s = code-0.1.0.0:Genome.FixedList.Functions.double g_at4r
                            (g_at4r, gpart_at6P) = Genome.Split.split gpart_at6O
                            p_at4q = code-0.1.0.0:Genome.FixedList.Functions.double g_at4p
                            (g_at4p, gpart_at6O) = Genome.Split.split gpart_at6N
                            p_at4o = code-0.1.0.0:Genome.FixedList.Functions.double g_at4n
                            (g_at4n, gpart_at6N) = Genome.Split.split gpart_at6M
                            p_at4m = code-0.1.0.0:Genome.FixedList.Functions.double g_at4l
                            (g_at4l, gpart_at6M) = Genome.Split.split genome_at5F
                          in
                            \ desc_at5G
                              -> case desc_at5G of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4m)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4o)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4q)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4s)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4u)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4w)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4y)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4A)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4C)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4E)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4G)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4I)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4K)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4M)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4O)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Q)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4S)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4U)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4W)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Y)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at50)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at52)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at54)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at56)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at58)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5a)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5c)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5e)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5g)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5i)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5k)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5m)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5o)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5q)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5s)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5u)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5w)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5y)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5A)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5C)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5E)
                                   _ -> Nothing }}
