src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a26tu
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26ub
                      p_a26tt = double g_a26ts
                      (g_a26ts, gpart_a26ub) = Genome.Split.split gpart_a26ua
                      p_a26tr = double g_a26tq
                      (g_a26tq, gpart_a26ua) = Genome.Split.split gpart_a26u9
                      p_a26tp = double g_a26to
                      (g_a26to, gpart_a26u9) = Genome.Split.split gpart_a26u8
                      p_a26tn = double g_a26tm
                      (g_a26tm, gpart_a26u8) = Genome.Split.split gpart_a26u7
                      p_a26tl = double g_a26tk
                      (g_a26tk, gpart_a26u7) = Genome.Split.split gpart_a26u6
                      p_a26tj = Functions.belowten' g_a26ti
                      (g_a26ti, gpart_a26u6) = Genome.Split.split gpart_a26u5
                      p_a26th = double g_a26tg
                      (g_a26tg, gpart_a26u5) = Genome.Split.split gpart_a26u4
                      p_a26tf = double g_a26te
                      (g_a26te, gpart_a26u4) = Genome.Split.split gpart_a26u3
                      p_a26td = double g_a26tc
                      (g_a26tc, gpart_a26u3) = Genome.Split.split gpart_a26u2
                      p_a26tb = Functions.belowten' g_a26ta
                      (g_a26ta, gpart_a26u2) = Genome.Split.split gpart_a26u1
                      p_a26t9 = double g_a26t8
                      (g_a26t8, gpart_a26u1) = Genome.Split.split gpart_a26u0
                      p_a26t7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26t6
                      (g_a26t6, gpart_a26u0) = Genome.Split.split gpart_a26tZ
                      p_a26t5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26t4
                      (g_a26t4, gpart_a26tZ) = Genome.Split.split gpart_a26tY
                      p_a26t3 = Functions.belowten' g_a26t2
                      (g_a26t2, gpart_a26tY) = Genome.Split.split gpart_a26tX
                      p_a26t1 = double g_a26t0
                      (g_a26t0, gpart_a26tX) = Genome.Split.split gpart_a26tW
                      p_a26sZ = double g_a26sY
                      (g_a26sY, gpart_a26tW) = Genome.Split.split gpart_a26tV
                      p_a26sX = double g_a26sW
                      (g_a26sW, gpart_a26tV) = Genome.Split.split gpart_a26tU
                      p_a26sV = Functions.belowten' g_a26sU
                      (g_a26sU, gpart_a26tU) = Genome.Split.split gpart_a26tT
                      p_a26sT = double g_a26sS
                      (g_a26sS, gpart_a26tT) = Genome.Split.split gpart_a26tS
                      p_a26sR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26sQ
                      (g_a26sQ, gpart_a26tS) = Genome.Split.split gpart_a26tR
                      p_a26sP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26sO
                      (g_a26sO, gpart_a26tR) = Genome.Split.split gpart_a26tQ
                      p_a26sN = double g_a26sM
                      (g_a26sM, gpart_a26tQ) = Genome.Split.split gpart_a26tP
                      p_a26sL = double g_a26sK
                      (g_a26sK, gpart_a26tP) = Genome.Split.split gpart_a26tO
                      p_a26sJ = Functions.belowten' g_a26sI
                      (g_a26sI, gpart_a26tO) = Genome.Split.split gpart_a26tN
                      p_a26sH = double g_a26sG
                      (g_a26sG, gpart_a26tN) = Genome.Split.split gpart_a26tM
                      p_a26sF = Functions.belowten' g_a26sE
                      (g_a26sE, gpart_a26tM) = Genome.Split.split gpart_a26tL
                      p_a26sD = double g_a26sC
                      (g_a26sC, gpart_a26tL) = Genome.Split.split gpart_a26tK
                      p_a26sB = Functions.belowten' g_a26sA
                      (g_a26sA, gpart_a26tK) = Genome.Split.split gpart_a26tJ
                      p_a26sz = double g_a26sy
                      (g_a26sy, gpart_a26tJ) = Genome.Split.split gpart_a26tI
                      p_a26sx = double g_a26sw
                      (g_a26sw, gpart_a26tI) = Genome.Split.split gpart_a26tH
                      p_a26sv = double g_a26su
                      (g_a26su, gpart_a26tH) = Genome.Split.split gpart_a26tG
                      p_a26st = Functions.belowten' g_a26ss
                      (g_a26ss, gpart_a26tG) = Genome.Split.split gpart_a26tF
                      p_a26sr = double g_a26sq
                      (g_a26sq, gpart_a26tF) = Genome.Split.split gpart_a26tE
                      p_a26sp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26so
                      (g_a26so, gpart_a26tE) = Genome.Split.split gpart_a26tD
                      p_a26sn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26sm
                      (g_a26sm, gpart_a26tD) = Genome.Split.split gpart_a26tC
                      p_a26sl = Functions.belowten' g_a26sk
                      (g_a26sk, gpart_a26tC) = Genome.Split.split gpart_a26tB
                      p_a26sj = double g_a26si
                      (g_a26si, gpart_a26tB) = Genome.Split.split gpart_a26tA
                      p_a26sh = double g_a26sg
                      (g_a26sg, gpart_a26tA) = Genome.Split.split gpart_a26tz
                      p_a26sf = double g_a26se
                      (g_a26se, gpart_a26tz) = Genome.Split.split gpart_a26ty
                      p_a26sd = double g_a26sc
                      (g_a26sc, gpart_a26ty) = Genome.Split.split gpart_a26tx
                      p_a26sb = double g_a26sa
                      (g_a26sa, gpart_a26tx) = Genome.Split.split gpart_a26tw
                      p_a26s9 = double g_a26s8
                      (g_a26s8, gpart_a26tw) = Genome.Split.split genome_a26tu
                    in  \ x_a26uc
                          -> let
                               c_PTB_a26uh
                                 = ((Data.Fixed.Vector.toVector x_a26uc) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26uf
                                 = ((Data.Fixed.Vector.toVector x_a26uc) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26ud
                                 = ((Data.Fixed.Vector.toVector x_a26uc) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26ui
                                 = ((Data.Fixed.Vector.toVector x_a26uc) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26uy
                                 = ((Data.Fixed.Vector.toVector x_a26uc) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26sh
                                     * ((p_a26sv + ((c_NPTB_a26ud / p_a26sj) ** p_a26sl))
                                        / (((1 + p_a26sv) + ((c_NPTB_a26ud / p_a26sj) ** p_a26sl))
                                           + ((c_MiRs_a26uf / p_a26sr) ** p_a26st))))
                                    + (negate (p_a26tl * c_PTB_a26uh))),
                                   ((p_a26sx
                                     * ((p_a26sL + ((c_RESTc_a26ui / p_a26sz) ** p_a26sB))
                                        / (((1 + p_a26sL) + ((c_RESTc_a26ui / p_a26sz) ** p_a26sB))
                                           + (((c_MiRs_a26uf / p_a26sD) ** p_a26sF)
                                              + ((c_PTB_a26uh / p_a26sH) ** p_a26sJ)))))
                                    + (negate (p_a26tn * c_NPTB_a26ud))),
                                   ((p_a26sN
                                     * ((p_a26sX + ((p_a26sd / p_a26sP) ** p_a26sR))
                                        / (((1 + p_a26sX) + ((p_a26sd / p_a26sP) ** p_a26sR))
                                           + ((c_RESTc_a26ui / p_a26sT) ** p_a26sV))))
                                    + (negate (p_a26tp * c_MiRs_a26uf))),
                                   ((p_a26sZ
                                     * ((p_a26td + ((c_PTB_a26uh / p_a26t1) ** p_a26t3))
                                        / (((1 + p_a26td) + ((c_PTB_a26uh / p_a26t1) ** p_a26t3))
                                           + (((p_a26s9 / p_a26t5) ** p_a26t7)
                                              + ((c_MiRs_a26uf / p_a26t9) ** p_a26tb)))))
                                    + (negate (p_a26tr * c_RESTc_a26ui))),
                                   ((p_a26tf / (1 + ((c_RESTc_a26ui / p_a26th) ** p_a26tj)))
                                    + (negate (p_a26tt * c_EndoNeuroTFs_a26uy)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511265",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511267",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511271",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511273",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511275",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511299",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511301",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511309",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511311",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511313",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511315",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511317",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511319",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511321",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511323",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511326",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511327",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511329",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511331",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511333",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511334",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511335",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511336",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511337",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511339",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26tu
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26ve
                            p_a26tt = double g_a26ts
                            (g_a26ts, gpart_a26ve) = Genome.Split.split gpart_a26vd
                            p_a26tr = double g_a26tq
                            (g_a26tq, gpart_a26vd) = Genome.Split.split gpart_a26vc
                            p_a26tp = double g_a26to
                            (g_a26to, gpart_a26vc) = Genome.Split.split gpart_a26vb
                            p_a26tn = double g_a26tm
                            (g_a26tm, gpart_a26vb) = Genome.Split.split gpart_a26va
                            p_a26tl = double g_a26tk
                            (g_a26tk, gpart_a26va) = Genome.Split.split gpart_a26v9
                            p_a26tj = Functions.belowten' g_a26ti
                            (g_a26ti, gpart_a26v9) = Genome.Split.split gpart_a26v8
                            p_a26th = double g_a26tg
                            (g_a26tg, gpart_a26v8) = Genome.Split.split gpart_a26v7
                            p_a26tf = double g_a26te
                            (g_a26te, gpart_a26v7) = Genome.Split.split gpart_a26v6
                            p_a26td = double g_a26tc
                            (g_a26tc, gpart_a26v6) = Genome.Split.split gpart_a26v5
                            p_a26tb = Functions.belowten' g_a26ta
                            (g_a26ta, gpart_a26v5) = Genome.Split.split gpart_a26v4
                            p_a26t9 = double g_a26t8
                            (g_a26t8, gpart_a26v4) = Genome.Split.split gpart_a26v3
                            p_a26t7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26t6
                            (g_a26t6, gpart_a26v3) = Genome.Split.split gpart_a26v2
                            p_a26t5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26t4
                            (g_a26t4, gpart_a26v2) = Genome.Split.split gpart_a26v1
                            p_a26t3 = Functions.belowten' g_a26t2
                            (g_a26t2, gpart_a26v1) = Genome.Split.split gpart_a26v0
                            p_a26t1 = double g_a26t0
                            (g_a26t0, gpart_a26v0) = Genome.Split.split gpart_a26uZ
                            p_a26sZ = double g_a26sY
                            (g_a26sY, gpart_a26uZ) = Genome.Split.split gpart_a26uY
                            p_a26sX = double g_a26sW
                            (g_a26sW, gpart_a26uY) = Genome.Split.split gpart_a26uX
                            p_a26sV = Functions.belowten' g_a26sU
                            (g_a26sU, gpart_a26uX) = Genome.Split.split gpart_a26uW
                            p_a26sT = double g_a26sS
                            (g_a26sS, gpart_a26uW) = Genome.Split.split gpart_a26uV
                            p_a26sR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26sQ
                            (g_a26sQ, gpart_a26uV) = Genome.Split.split gpart_a26uU
                            p_a26sP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26sO
                            (g_a26sO, gpart_a26uU) = Genome.Split.split gpart_a26uT
                            p_a26sN = double g_a26sM
                            (g_a26sM, gpart_a26uT) = Genome.Split.split gpart_a26uS
                            p_a26sL = double g_a26sK
                            (g_a26sK, gpart_a26uS) = Genome.Split.split gpart_a26uR
                            p_a26sJ = Functions.belowten' g_a26sI
                            (g_a26sI, gpart_a26uR) = Genome.Split.split gpart_a26uQ
                            p_a26sH = double g_a26sG
                            (g_a26sG, gpart_a26uQ) = Genome.Split.split gpart_a26uP
                            p_a26sF = Functions.belowten' g_a26sE
                            (g_a26sE, gpart_a26uP) = Genome.Split.split gpart_a26uO
                            p_a26sD = double g_a26sC
                            (g_a26sC, gpart_a26uO) = Genome.Split.split gpart_a26uN
                            p_a26sB = Functions.belowten' g_a26sA
                            (g_a26sA, gpart_a26uN) = Genome.Split.split gpart_a26uM
                            p_a26sz = double g_a26sy
                            (g_a26sy, gpart_a26uM) = Genome.Split.split gpart_a26uL
                            p_a26sx = double g_a26sw
                            (g_a26sw, gpart_a26uL) = Genome.Split.split gpart_a26uK
                            p_a26sv = double g_a26su
                            (g_a26su, gpart_a26uK) = Genome.Split.split gpart_a26uJ
                            p_a26st = Functions.belowten' g_a26ss
                            (g_a26ss, gpart_a26uJ) = Genome.Split.split gpart_a26uI
                            p_a26sr = double g_a26sq
                            (g_a26sq, gpart_a26uI) = Genome.Split.split gpart_a26uH
                            p_a26sp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26so
                            (g_a26so, gpart_a26uH) = Genome.Split.split gpart_a26uG
                            p_a26sn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26sm
                            (g_a26sm, gpart_a26uG) = Genome.Split.split gpart_a26uF
                            p_a26sl = Functions.belowten' g_a26sk
                            (g_a26sk, gpart_a26uF) = Genome.Split.split gpart_a26uE
                            p_a26sj = double g_a26si
                            (g_a26si, gpart_a26uE) = Genome.Split.split gpart_a26uD
                            p_a26sh = double g_a26sg
                            (g_a26sg, gpart_a26uD) = Genome.Split.split gpart_a26uC
                            p_a26sf = double g_a26se
                            (g_a26se, gpart_a26uC) = Genome.Split.split gpart_a26uB
                            p_a26sd = double g_a26sc
                            (g_a26sc, gpart_a26uB) = Genome.Split.split gpart_a26uA
                            p_a26sb = double g_a26sa
                            (g_a26sa, gpart_a26uA) = Genome.Split.split gpart_a26uz
                            p_a26s9 = double g_a26s8
                            (g_a26s8, gpart_a26uz) = Genome.Split.split genome_a26tu
                          in
                            \ desc_a26tv
                              -> case desc_a26tv of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26s9)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sb)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sd)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sf)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sh)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sj)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sl)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sn)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sp)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sr)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26st)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sv)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sx)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sz)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sB)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sD)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sF)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sH)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sJ)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sL)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sN)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sP)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sR)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sT)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sV)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sX)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26sZ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26t1)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26t3)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26t5)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26t7)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26t9)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26tb)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26td)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26tf)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26th)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26tj)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26tl)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26tn)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26tp)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26tr)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26tt)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a26xK
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26yr
                      p_a26xJ = double g_a26xI
                      (g_a26xI, gpart_a26yr) = Genome.Split.split gpart_a26yq
                      p_a26xH = double g_a26xG
                      (g_a26xG, gpart_a26yq) = Genome.Split.split gpart_a26yp
                      p_a26xF = double g_a26xE
                      (g_a26xE, gpart_a26yp) = Genome.Split.split gpart_a26yo
                      p_a26xD = double g_a26xC
                      (g_a26xC, gpart_a26yo) = Genome.Split.split gpart_a26yn
                      p_a26xB = double g_a26xA
                      (g_a26xA, gpart_a26yn) = Genome.Split.split gpart_a26ym
                      p_a26xz = Functions.belowten' g_a26xy
                      (g_a26xy, gpart_a26ym) = Genome.Split.split gpart_a26yl
                      p_a26xx = double g_a26xw
                      (g_a26xw, gpart_a26yl) = Genome.Split.split gpart_a26yk
                      p_a26xv = double g_a26xu
                      (g_a26xu, gpart_a26yk) = Genome.Split.split gpart_a26yj
                      p_a26xt = double g_a26xs
                      (g_a26xs, gpart_a26yj) = Genome.Split.split gpart_a26yi
                      p_a26xr = Functions.belowten' g_a26xq
                      (g_a26xq, gpart_a26yi) = Genome.Split.split gpart_a26yh
                      p_a26xp = double g_a26xo
                      (g_a26xo, gpart_a26yh) = Genome.Split.split gpart_a26yg
                      p_a26xn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26xm
                      (g_a26xm, gpart_a26yg) = Genome.Split.split gpart_a26yf
                      p_a26xl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26xk
                      (g_a26xk, gpart_a26yf) = Genome.Split.split gpart_a26ye
                      p_a26xj = Functions.belowten' g_a26xi
                      (g_a26xi, gpart_a26ye) = Genome.Split.split gpart_a26yd
                      p_a26xh = double g_a26xg
                      (g_a26xg, gpart_a26yd) = Genome.Split.split gpart_a26yc
                      p_a26xf = double g_a26xe
                      (g_a26xe, gpart_a26yc) = Genome.Split.split gpart_a26yb
                      p_a26xd = double g_a26xc
                      (g_a26xc, gpart_a26yb) = Genome.Split.split gpart_a26ya
                      p_a26xb = Functions.belowten' g_a26xa
                      (g_a26xa, gpart_a26ya) = Genome.Split.split gpart_a26y9
                      p_a26x9 = double g_a26x8
                      (g_a26x8, gpart_a26y9) = Genome.Split.split gpart_a26y8
                      p_a26x7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26x6
                      (g_a26x6, gpart_a26y8) = Genome.Split.split gpart_a26y7
                      p_a26x5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26x4
                      (g_a26x4, gpart_a26y7) = Genome.Split.split gpart_a26y6
                      p_a26x3 = double g_a26x2
                      (g_a26x2, gpart_a26y6) = Genome.Split.split gpart_a26y5
                      p_a26x1 = double g_a26x0
                      (g_a26x0, gpart_a26y5) = Genome.Split.split gpart_a26y4
                      p_a26wZ = Functions.belowten' g_a26wY
                      (g_a26wY, gpart_a26y4) = Genome.Split.split gpart_a26y3
                      p_a26wX = double g_a26wW
                      (g_a26wW, gpart_a26y3) = Genome.Split.split gpart_a26y2
                      p_a26wV = Functions.belowten' g_a26wU
                      (g_a26wU, gpart_a26y2) = Genome.Split.split gpart_a26y1
                      p_a26wT = double g_a26wS
                      (g_a26wS, gpart_a26y1) = Genome.Split.split gpart_a26y0
                      p_a26wR = Functions.belowten' g_a26wQ
                      (g_a26wQ, gpart_a26y0) = Genome.Split.split gpart_a26xZ
                      p_a26wP = double g_a26wO
                      (g_a26wO, gpart_a26xZ) = Genome.Split.split gpart_a26xY
                      p_a26wN = double g_a26wM
                      (g_a26wM, gpart_a26xY) = Genome.Split.split gpart_a26xX
                      p_a26wL = double g_a26wK
                      (g_a26wK, gpart_a26xX) = Genome.Split.split gpart_a26xW
                      p_a26wJ = Functions.belowten' g_a26wI
                      (g_a26wI, gpart_a26xW) = Genome.Split.split gpart_a26xV
                      p_a26wH = double g_a26wG
                      (g_a26wG, gpart_a26xV) = Genome.Split.split gpart_a26xU
                      p_a26wF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26wE
                      (g_a26wE, gpart_a26xU) = Genome.Split.split gpart_a26xT
                      p_a26wD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26wC
                      (g_a26wC, gpart_a26xT) = Genome.Split.split gpart_a26xS
                      p_a26wB = Functions.belowten' g_a26wA
                      (g_a26wA, gpart_a26xS) = Genome.Split.split gpart_a26xR
                      p_a26wz = double g_a26wy
                      (g_a26wy, gpart_a26xR) = Genome.Split.split gpart_a26xQ
                      p_a26wx = double g_a26ww
                      (g_a26ww, gpart_a26xQ) = Genome.Split.split gpart_a26xP
                      p_a26wv = double g_a26wu
                      (g_a26wu, gpart_a26xP) = Genome.Split.split gpart_a26xO
                      p_a26wt = double g_a26ws
                      (g_a26ws, gpart_a26xO) = Genome.Split.split gpart_a26xN
                      p_a26wr = double g_a26wq
                      (g_a26wq, gpart_a26xN) = Genome.Split.split gpart_a26xM
                      p_a26wp = double g_a26wo
                      (g_a26wo, gpart_a26xM) = Genome.Split.split genome_a26xK
                    in  \ x_a26ys
                          -> let
                               c_PTB_a26yx
                                 = ((Data.Fixed.Vector.toVector x_a26ys) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26yv
                                 = ((Data.Fixed.Vector.toVector x_a26ys) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26yt
                                 = ((Data.Fixed.Vector.toVector x_a26ys) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26yy
                                 = ((Data.Fixed.Vector.toVector x_a26ys) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26yO
                                 = ((Data.Fixed.Vector.toVector x_a26ys) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26wx
                                     * ((p_a26wL + ((c_NPTB_a26yt / p_a26wz) ** p_a26wB))
                                        / (((1 + p_a26wL) + ((c_NPTB_a26yt / p_a26wz) ** p_a26wB))
                                           + ((c_MiRs_a26yv / p_a26wH) ** p_a26wJ))))
                                    + (negate (p_a26xB * c_PTB_a26yx))),
                                   ((p_a26wN
                                     * ((p_a26x1 + ((c_RESTc_a26yy / p_a26wP) ** p_a26wR))
                                        / (((1 + p_a26x1) + ((c_RESTc_a26yy / p_a26wP) ** p_a26wR))
                                           + (((c_MiRs_a26yv / p_a26wT) ** p_a26wV)
                                              + ((c_PTB_a26yx / p_a26wX) ** p_a26wZ)))))
                                    + (negate (p_a26xD * c_NPTB_a26yt))),
                                   ((p_a26x3
                                     * (p_a26xd
                                        / ((1 + p_a26xd) + ((c_RESTc_a26yy / p_a26x9) ** p_a26xb))))
                                    + (negate (p_a26xF * c_MiRs_a26yv))),
                                   ((p_a26xf
                                     * ((p_a26xt + ((c_PTB_a26yx / p_a26xh) ** p_a26xj))
                                        / (((1 + p_a26xt) + ((c_PTB_a26yx / p_a26xh) ** p_a26xj))
                                           + (((p_a26wp / p_a26xl) ** p_a26xn)
                                              + ((c_MiRs_a26yv / p_a26xp) ** p_a26xr)))))
                                    + (negate (p_a26xH * c_RESTc_a26yy))),
                                   ((p_a26xv / (1 + ((c_RESTc_a26yy / p_a26xx) ** p_a26xz)))
                                    + (negate (p_a26xJ * c_EndoNeuroTFs_a26yO)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511535",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511537",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511563",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511565",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511579",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511581",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511583",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511599",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26xK
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26zu
                            p_a26xJ = double g_a26xI
                            (g_a26xI, gpart_a26zu) = Genome.Split.split gpart_a26zt
                            p_a26xH = double g_a26xG
                            (g_a26xG, gpart_a26zt) = Genome.Split.split gpart_a26zs
                            p_a26xF = double g_a26xE
                            (g_a26xE, gpart_a26zs) = Genome.Split.split gpart_a26zr
                            p_a26xD = double g_a26xC
                            (g_a26xC, gpart_a26zr) = Genome.Split.split gpart_a26zq
                            p_a26xB = double g_a26xA
                            (g_a26xA, gpart_a26zq) = Genome.Split.split gpart_a26zp
                            p_a26xz = Functions.belowten' g_a26xy
                            (g_a26xy, gpart_a26zp) = Genome.Split.split gpart_a26zo
                            p_a26xx = double g_a26xw
                            (g_a26xw, gpart_a26zo) = Genome.Split.split gpart_a26zn
                            p_a26xv = double g_a26xu
                            (g_a26xu, gpart_a26zn) = Genome.Split.split gpart_a26zm
                            p_a26xt = double g_a26xs
                            (g_a26xs, gpart_a26zm) = Genome.Split.split gpart_a26zl
                            p_a26xr = Functions.belowten' g_a26xq
                            (g_a26xq, gpart_a26zl) = Genome.Split.split gpart_a26zk
                            p_a26xp = double g_a26xo
                            (g_a26xo, gpart_a26zk) = Genome.Split.split gpart_a26zj
                            p_a26xn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26xm
                            (g_a26xm, gpart_a26zj) = Genome.Split.split gpart_a26zi
                            p_a26xl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26xk
                            (g_a26xk, gpart_a26zi) = Genome.Split.split gpart_a26zh
                            p_a26xj = Functions.belowten' g_a26xi
                            (g_a26xi, gpart_a26zh) = Genome.Split.split gpart_a26zg
                            p_a26xh = double g_a26xg
                            (g_a26xg, gpart_a26zg) = Genome.Split.split gpart_a26zf
                            p_a26xf = double g_a26xe
                            (g_a26xe, gpart_a26zf) = Genome.Split.split gpart_a26ze
                            p_a26xd = double g_a26xc
                            (g_a26xc, gpart_a26ze) = Genome.Split.split gpart_a26zd
                            p_a26xb = Functions.belowten' g_a26xa
                            (g_a26xa, gpart_a26zd) = Genome.Split.split gpart_a26zc
                            p_a26x9 = double g_a26x8
                            (g_a26x8, gpart_a26zc) = Genome.Split.split gpart_a26zb
                            p_a26x7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26x6
                            (g_a26x6, gpart_a26zb) = Genome.Split.split gpart_a26za
                            p_a26x5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26x4
                            (g_a26x4, gpart_a26za) = Genome.Split.split gpart_a26z9
                            p_a26x3 = double g_a26x2
                            (g_a26x2, gpart_a26z9) = Genome.Split.split gpart_a26z8
                            p_a26x1 = double g_a26x0
                            (g_a26x0, gpart_a26z8) = Genome.Split.split gpart_a26z7
                            p_a26wZ = Functions.belowten' g_a26wY
                            (g_a26wY, gpart_a26z7) = Genome.Split.split gpart_a26z6
                            p_a26wX = double g_a26wW
                            (g_a26wW, gpart_a26z6) = Genome.Split.split gpart_a26z5
                            p_a26wV = Functions.belowten' g_a26wU
                            (g_a26wU, gpart_a26z5) = Genome.Split.split gpart_a26z4
                            p_a26wT = double g_a26wS
                            (g_a26wS, gpart_a26z4) = Genome.Split.split gpart_a26z3
                            p_a26wR = Functions.belowten' g_a26wQ
                            (g_a26wQ, gpart_a26z3) = Genome.Split.split gpart_a26z2
                            p_a26wP = double g_a26wO
                            (g_a26wO, gpart_a26z2) = Genome.Split.split gpart_a26z1
                            p_a26wN = double g_a26wM
                            (g_a26wM, gpart_a26z1) = Genome.Split.split gpart_a26z0
                            p_a26wL = double g_a26wK
                            (g_a26wK, gpart_a26z0) = Genome.Split.split gpart_a26yZ
                            p_a26wJ = Functions.belowten' g_a26wI
                            (g_a26wI, gpart_a26yZ) = Genome.Split.split gpart_a26yY
                            p_a26wH = double g_a26wG
                            (g_a26wG, gpart_a26yY) = Genome.Split.split gpart_a26yX
                            p_a26wF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26wE
                            (g_a26wE, gpart_a26yX) = Genome.Split.split gpart_a26yW
                            p_a26wD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26wC
                            (g_a26wC, gpart_a26yW) = Genome.Split.split gpart_a26yV
                            p_a26wB = Functions.belowten' g_a26wA
                            (g_a26wA, gpart_a26yV) = Genome.Split.split gpart_a26yU
                            p_a26wz = double g_a26wy
                            (g_a26wy, gpart_a26yU) = Genome.Split.split gpart_a26yT
                            p_a26wx = double g_a26ww
                            (g_a26ww, gpart_a26yT) = Genome.Split.split gpart_a26yS
                            p_a26wv = double g_a26wu
                            (g_a26wu, gpart_a26yS) = Genome.Split.split gpart_a26yR
                            p_a26wt = double g_a26ws
                            (g_a26ws, gpart_a26yR) = Genome.Split.split gpart_a26yQ
                            p_a26wr = double g_a26wq
                            (g_a26wq, gpart_a26yQ) = Genome.Split.split gpart_a26yP
                            p_a26wp = double g_a26wo
                            (g_a26wo, gpart_a26yP) = Genome.Split.split genome_a26xK
                          in
                            \ desc_a26xL
                              -> case desc_a26xL of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wp)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wr)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wt)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wv)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wx)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wz)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wB)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wD)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wF)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wH)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wJ)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wL)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wN)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wP)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wR)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wT)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wV)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wX)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26wZ)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26x1)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26x3)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26x5)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26x7)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26x9)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xb)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xd)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xf)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xh)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xj)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xl)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xn)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xp)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xr)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xt)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xv)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xx)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xz)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xB)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xD)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xF)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xH)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26xJ)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a26C0
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26CH
                      p_a26BZ = double g_a26BY
                      (g_a26BY, gpart_a26CH) = Genome.Split.split gpart_a26CG
                      p_a26BX = double g_a26BW
                      (g_a26BW, gpart_a26CG) = Genome.Split.split gpart_a26CF
                      p_a26BV = double g_a26BU
                      (g_a26BU, gpart_a26CF) = Genome.Split.split gpart_a26CE
                      p_a26BT = double g_a26BS
                      (g_a26BS, gpart_a26CE) = Genome.Split.split gpart_a26CD
                      p_a26BR = double g_a26BQ
                      (g_a26BQ, gpart_a26CD) = Genome.Split.split gpart_a26CC
                      p_a26BP = Functions.belowten' g_a26BO
                      (g_a26BO, gpart_a26CC) = Genome.Split.split gpart_a26CB
                      p_a26BN = double g_a26BM
                      (g_a26BM, gpart_a26CB) = Genome.Split.split gpart_a26CA
                      p_a26BL = double g_a26BK
                      (g_a26BK, gpart_a26CA) = Genome.Split.split gpart_a26Cz
                      p_a26BJ = double g_a26BI
                      (g_a26BI, gpart_a26Cz) = Genome.Split.split gpart_a26Cy
                      p_a26BH = Functions.belowten' g_a26BG
                      (g_a26BG, gpart_a26Cy) = Genome.Split.split gpart_a26Cx
                      p_a26BF = double g_a26BE
                      (g_a26BE, gpart_a26Cx) = Genome.Split.split gpart_a26Cw
                      p_a26BD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BC
                      (g_a26BC, gpart_a26Cw) = Genome.Split.split gpart_a26Cv
                      p_a26BB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BA
                      (g_a26BA, gpart_a26Cv) = Genome.Split.split gpart_a26Cu
                      p_a26Bz = Functions.belowten' g_a26By
                      (g_a26By, gpart_a26Cu) = Genome.Split.split gpart_a26Ct
                      p_a26Bx = double g_a26Bw
                      (g_a26Bw, gpart_a26Ct) = Genome.Split.split gpart_a26Cs
                      p_a26Bv = double g_a26Bu
                      (g_a26Bu, gpart_a26Cs) = Genome.Split.split gpart_a26Cr
                      p_a26Bt = double g_a26Bs
                      (g_a26Bs, gpart_a26Cr) = Genome.Split.split gpart_a26Cq
                      p_a26Br = Functions.belowten' g_a26Bq
                      (g_a26Bq, gpart_a26Cq) = Genome.Split.split gpart_a26Cp
                      p_a26Bp = double g_a26Bo
                      (g_a26Bo, gpart_a26Cp) = Genome.Split.split gpart_a26Co
                      p_a26Bn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Bm
                      (g_a26Bm, gpart_a26Co) = Genome.Split.split gpart_a26Cn
                      p_a26Bl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Bk
                      (g_a26Bk, gpart_a26Cn) = Genome.Split.split gpart_a26Cm
                      p_a26Bj = double g_a26Bi
                      (g_a26Bi, gpart_a26Cm) = Genome.Split.split gpart_a26Cl
                      p_a26Bh = double g_a26Bg
                      (g_a26Bg, gpart_a26Cl) = Genome.Split.split gpart_a26Ck
                      p_a26Bf = Functions.belowten' g_a26Be
                      (g_a26Be, gpart_a26Ck) = Genome.Split.split gpart_a26Cj
                      p_a26Bd = double g_a26Bc
                      (g_a26Bc, gpart_a26Cj) = Genome.Split.split gpart_a26Ci
                      p_a26Bb = Functions.belowten' g_a26Ba
                      (g_a26Ba, gpart_a26Ci) = Genome.Split.split gpart_a26Ch
                      p_a26B9 = double g_a26B8
                      (g_a26B8, gpart_a26Ch) = Genome.Split.split gpart_a26Cg
                      p_a26B7 = Functions.belowten' g_a26B6
                      (g_a26B6, gpart_a26Cg) = Genome.Split.split gpart_a26Cf
                      p_a26B5 = double g_a26B4
                      (g_a26B4, gpart_a26Cf) = Genome.Split.split gpart_a26Ce
                      p_a26B3 = double g_a26B2
                      (g_a26B2, gpart_a26Ce) = Genome.Split.split gpart_a26Cd
                      p_a26B1 = double g_a26B0
                      (g_a26B0, gpart_a26Cd) = Genome.Split.split gpart_a26Cc
                      p_a26AZ = Functions.belowten' g_a26AY
                      (g_a26AY, gpart_a26Cc) = Genome.Split.split gpart_a26Cb
                      p_a26AX = double g_a26AW
                      (g_a26AW, gpart_a26Cb) = Genome.Split.split gpart_a26Ca
                      p_a26AV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26AU
                      (g_a26AU, gpart_a26Ca) = Genome.Split.split gpart_a26C9
                      p_a26AT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26AS
                      (g_a26AS, gpart_a26C9) = Genome.Split.split gpart_a26C8
                      p_a26AR = Functions.belowten' g_a26AQ
                      (g_a26AQ, gpart_a26C8) = Genome.Split.split gpart_a26C7
                      p_a26AP = double g_a26AO
                      (g_a26AO, gpart_a26C7) = Genome.Split.split gpart_a26C6
                      p_a26AN = double g_a26AM
                      (g_a26AM, gpart_a26C6) = Genome.Split.split gpart_a26C5
                      p_a26AL = double g_a26AK
                      (g_a26AK, gpart_a26C5) = Genome.Split.split gpart_a26C4
                      p_a26AJ = double g_a26AI
                      (g_a26AI, gpart_a26C4) = Genome.Split.split gpart_a26C3
                      p_a26AH = double g_a26AG
                      (g_a26AG, gpart_a26C3) = Genome.Split.split gpart_a26C2
                      p_a26AF = double g_a26AE
                      (g_a26AE, gpart_a26C2) = Genome.Split.split genome_a26C0
                    in  \ x_a26CI
                          -> let
                               c_PTB_a26CN
                                 = ((Data.Fixed.Vector.toVector x_a26CI) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26CL
                                 = ((Data.Fixed.Vector.toVector x_a26CI) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26CJ
                                 = ((Data.Fixed.Vector.toVector x_a26CI) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26CO
                                 = ((Data.Fixed.Vector.toVector x_a26CI) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26D4
                                 = ((Data.Fixed.Vector.toVector x_a26CI) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26AN
                                     * ((p_a26B1 + ((c_NPTB_a26CJ / p_a26AP) ** p_a26AR))
                                        / (((1 + p_a26B1) + ((c_NPTB_a26CJ / p_a26AP) ** p_a26AR))
                                           + ((c_MiRs_a26CL / p_a26AX) ** p_a26AZ))))
                                    + (negate (p_a26BR * c_PTB_a26CN))),
                                   ((p_a26B3
                                     * ((p_a26Bh + ((c_RESTc_a26CO / p_a26B5) ** p_a26B7))
                                        / (((1 + p_a26Bh) + ((c_RESTc_a26CO / p_a26B5) ** p_a26B7))
                                           + (((c_MiRs_a26CL / p_a26B9) ** p_a26Bb)
                                              + ((c_PTB_a26CN / p_a26Bd) ** p_a26Bf)))))
                                    + (negate (p_a26BT * c_NPTB_a26CJ))),
                                   ((p_a26Bj
                                     * (p_a26Bt
                                        / ((1 + p_a26Bt) + ((c_RESTc_a26CO / p_a26Bp) ** p_a26Br))))
                                    + (negate (p_a26BV * c_MiRs_a26CL))),
                                   ((p_a26Bv
                                     * ((p_a26BJ + ((c_PTB_a26CN / p_a26Bx) ** p_a26Bz))
                                        / (((1 + p_a26BJ) + ((c_PTB_a26CN / p_a26Bx) ** p_a26Bz))
                                           + ((c_MiRs_a26CL / p_a26BF) ** p_a26BH))))
                                    + (negate (p_a26BX * c_RESTc_a26CO))),
                                   ((p_a26BL / (1 + ((c_RESTc_a26CO / p_a26BN) ** p_a26BP)))
                                    + (negate (p_a26BZ * c_EndoNeuroTFs_a26D4)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511784",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511785",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511787",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511795",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511798",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511799",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511800",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511801",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511802",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511803",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511805",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511807",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511809",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511811",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511817",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511819",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511821",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511823",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511827",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511829",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511839",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511841",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511843",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511845",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511847",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511865",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26C0
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26DK
                            p_a26BZ = double g_a26BY
                            (g_a26BY, gpart_a26DK) = Genome.Split.split gpart_a26DJ
                            p_a26BX = double g_a26BW
                            (g_a26BW, gpart_a26DJ) = Genome.Split.split gpart_a26DI
                            p_a26BV = double g_a26BU
                            (g_a26BU, gpart_a26DI) = Genome.Split.split gpart_a26DH
                            p_a26BT = double g_a26BS
                            (g_a26BS, gpart_a26DH) = Genome.Split.split gpart_a26DG
                            p_a26BR = double g_a26BQ
                            (g_a26BQ, gpart_a26DG) = Genome.Split.split gpart_a26DF
                            p_a26BP = Functions.belowten' g_a26BO
                            (g_a26BO, gpart_a26DF) = Genome.Split.split gpart_a26DE
                            p_a26BN = double g_a26BM
                            (g_a26BM, gpart_a26DE) = Genome.Split.split gpart_a26DD
                            p_a26BL = double g_a26BK
                            (g_a26BK, gpart_a26DD) = Genome.Split.split gpart_a26DC
                            p_a26BJ = double g_a26BI
                            (g_a26BI, gpart_a26DC) = Genome.Split.split gpart_a26DB
                            p_a26BH = Functions.belowten' g_a26BG
                            (g_a26BG, gpart_a26DB) = Genome.Split.split gpart_a26DA
                            p_a26BF = double g_a26BE
                            (g_a26BE, gpart_a26DA) = Genome.Split.split gpart_a26Dz
                            p_a26BD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BC
                            (g_a26BC, gpart_a26Dz) = Genome.Split.split gpart_a26Dy
                            p_a26BB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BA
                            (g_a26BA, gpart_a26Dy) = Genome.Split.split gpart_a26Dx
                            p_a26Bz = Functions.belowten' g_a26By
                            (g_a26By, gpart_a26Dx) = Genome.Split.split gpart_a26Dw
                            p_a26Bx = double g_a26Bw
                            (g_a26Bw, gpart_a26Dw) = Genome.Split.split gpart_a26Dv
                            p_a26Bv = double g_a26Bu
                            (g_a26Bu, gpart_a26Dv) = Genome.Split.split gpart_a26Du
                            p_a26Bt = double g_a26Bs
                            (g_a26Bs, gpart_a26Du) = Genome.Split.split gpart_a26Dt
                            p_a26Br = Functions.belowten' g_a26Bq
                            (g_a26Bq, gpart_a26Dt) = Genome.Split.split gpart_a26Ds
                            p_a26Bp = double g_a26Bo
                            (g_a26Bo, gpart_a26Ds) = Genome.Split.split gpart_a26Dr
                            p_a26Bn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Bm
                            (g_a26Bm, gpart_a26Dr) = Genome.Split.split gpart_a26Dq
                            p_a26Bl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Bk
                            (g_a26Bk, gpart_a26Dq) = Genome.Split.split gpart_a26Dp
                            p_a26Bj = double g_a26Bi
                            (g_a26Bi, gpart_a26Dp) = Genome.Split.split gpart_a26Do
                            p_a26Bh = double g_a26Bg
                            (g_a26Bg, gpart_a26Do) = Genome.Split.split gpart_a26Dn
                            p_a26Bf = Functions.belowten' g_a26Be
                            (g_a26Be, gpart_a26Dn) = Genome.Split.split gpart_a26Dm
                            p_a26Bd = double g_a26Bc
                            (g_a26Bc, gpart_a26Dm) = Genome.Split.split gpart_a26Dl
                            p_a26Bb = Functions.belowten' g_a26Ba
                            (g_a26Ba, gpart_a26Dl) = Genome.Split.split gpart_a26Dk
                            p_a26B9 = double g_a26B8
                            (g_a26B8, gpart_a26Dk) = Genome.Split.split gpart_a26Dj
                            p_a26B7 = Functions.belowten' g_a26B6
                            (g_a26B6, gpart_a26Dj) = Genome.Split.split gpart_a26Di
                            p_a26B5 = double g_a26B4
                            (g_a26B4, gpart_a26Di) = Genome.Split.split gpart_a26Dh
                            p_a26B3 = double g_a26B2
                            (g_a26B2, gpart_a26Dh) = Genome.Split.split gpart_a26Dg
                            p_a26B1 = double g_a26B0
                            (g_a26B0, gpart_a26Dg) = Genome.Split.split gpart_a26Df
                            p_a26AZ = Functions.belowten' g_a26AY
                            (g_a26AY, gpart_a26Df) = Genome.Split.split gpart_a26De
                            p_a26AX = double g_a26AW
                            (g_a26AW, gpart_a26De) = Genome.Split.split gpart_a26Dd
                            p_a26AV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26AU
                            (g_a26AU, gpart_a26Dd) = Genome.Split.split gpart_a26Dc
                            p_a26AT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26AS
                            (g_a26AS, gpart_a26Dc) = Genome.Split.split gpart_a26Db
                            p_a26AR = Functions.belowten' g_a26AQ
                            (g_a26AQ, gpart_a26Db) = Genome.Split.split gpart_a26Da
                            p_a26AP = double g_a26AO
                            (g_a26AO, gpart_a26Da) = Genome.Split.split gpart_a26D9
                            p_a26AN = double g_a26AM
                            (g_a26AM, gpart_a26D9) = Genome.Split.split gpart_a26D8
                            p_a26AL = double g_a26AK
                            (g_a26AK, gpart_a26D8) = Genome.Split.split gpart_a26D7
                            p_a26AJ = double g_a26AI
                            (g_a26AI, gpart_a26D7) = Genome.Split.split gpart_a26D6
                            p_a26AH = double g_a26AG
                            (g_a26AG, gpart_a26D6) = Genome.Split.split gpart_a26D5
                            p_a26AF = double g_a26AE
                            (g_a26AE, gpart_a26D5) = Genome.Split.split genome_a26C0
                          in
                            \ desc_a26C1
                              -> case desc_a26C1 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AF)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AH)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AJ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AL)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AN)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AP)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AR)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AT)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AV)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AX)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AZ)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26B1)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26B3)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26B5)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26B7)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26B9)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bb)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bd)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bf)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bh)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bj)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bl)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bn)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bp)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Br)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bt)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bv)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bx)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bz)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BB)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BD)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BF)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BH)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BJ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BL)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BN)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BP)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BR)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BT)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BV)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BX)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BZ)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a26Gg
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26GX
                      p_a26Gf = double g_a26Ge
                      (g_a26Ge, gpart_a26GX) = Genome.Split.split gpart_a26GW
                      p_a26Gd = double g_a26Gc
                      (g_a26Gc, gpart_a26GW) = Genome.Split.split gpart_a26GV
                      p_a26Gb = double g_a26Ga
                      (g_a26Ga, gpart_a26GV) = Genome.Split.split gpart_a26GU
                      p_a26G9 = double g_a26G8
                      (g_a26G8, gpart_a26GU) = Genome.Split.split gpart_a26GT
                      p_a26G7 = double g_a26G6
                      (g_a26G6, gpart_a26GT) = Genome.Split.split gpart_a26GS
                      p_a26G5 = Functions.belowten' g_a26G4
                      (g_a26G4, gpart_a26GS) = Genome.Split.split gpart_a26GR
                      p_a26G3 = double g_a26G2
                      (g_a26G2, gpart_a26GR) = Genome.Split.split gpart_a26GQ
                      p_a26G1 = double g_a26G0
                      (g_a26G0, gpart_a26GQ) = Genome.Split.split gpart_a26GP
                      p_a26FZ = double g_a26FY
                      (g_a26FY, gpart_a26GP) = Genome.Split.split gpart_a26GO
                      p_a26FX = Functions.belowten' g_a26FW
                      (g_a26FW, gpart_a26GO) = Genome.Split.split gpart_a26GN
                      p_a26FV = double g_a26FU
                      (g_a26FU, gpart_a26GN) = Genome.Split.split gpart_a26GM
                      p_a26FT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FS
                      (g_a26FS, gpart_a26GM) = Genome.Split.split gpart_a26GL
                      p_a26FR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FQ
                      (g_a26FQ, gpart_a26GL) = Genome.Split.split gpart_a26GK
                      p_a26FP = Functions.belowten' g_a26FO
                      (g_a26FO, gpart_a26GK) = Genome.Split.split gpart_a26GJ
                      p_a26FN = double g_a26FM
                      (g_a26FM, gpart_a26GJ) = Genome.Split.split gpart_a26GI
                      p_a26FL = double g_a26FK
                      (g_a26FK, gpart_a26GI) = Genome.Split.split gpart_a26GH
                      p_a26FJ = double g_a26FI
                      (g_a26FI, gpart_a26GH) = Genome.Split.split gpart_a26GG
                      p_a26FH = Functions.belowten' g_a26FG
                      (g_a26FG, gpart_a26GG) = Genome.Split.split gpart_a26GF
                      p_a26FF = double g_a26FE
                      (g_a26FE, gpart_a26GF) = Genome.Split.split gpart_a26GE
                      p_a26FD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FC
                      (g_a26FC, gpart_a26GE) = Genome.Split.split gpart_a26GD
                      p_a26FB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FA
                      (g_a26FA, gpart_a26GD) = Genome.Split.split gpart_a26GC
                      p_a26Fz = double g_a26Fy
                      (g_a26Fy, gpart_a26GC) = Genome.Split.split gpart_a26GB
                      p_a26Fx = double g_a26Fw
                      (g_a26Fw, gpart_a26GB) = Genome.Split.split gpart_a26GA
                      p_a26Fv = Functions.belowten' g_a26Fu
                      (g_a26Fu, gpart_a26GA) = Genome.Split.split gpart_a26Gz
                      p_a26Ft = double g_a26Fs
                      (g_a26Fs, gpart_a26Gz) = Genome.Split.split gpart_a26Gy
                      p_a26Fr = Functions.belowten' g_a26Fq
                      (g_a26Fq, gpart_a26Gy) = Genome.Split.split gpart_a26Gx
                      p_a26Fp = double g_a26Fo
                      (g_a26Fo, gpart_a26Gx) = Genome.Split.split gpart_a26Gw
                      p_a26Fn = Functions.belowten' g_a26Fm
                      (g_a26Fm, gpart_a26Gw) = Genome.Split.split gpart_a26Gv
                      p_a26Fl = double g_a26Fk
                      (g_a26Fk, gpart_a26Gv) = Genome.Split.split gpart_a26Gu
                      p_a26Fj = double g_a26Fi
                      (g_a26Fi, gpart_a26Gu) = Genome.Split.split gpart_a26Gt
                      p_a26Fh = double g_a26Fg
                      (g_a26Fg, gpart_a26Gt) = Genome.Split.split gpart_a26Gs
                      p_a26Ff = Functions.belowten' g_a26Fe
                      (g_a26Fe, gpart_a26Gs) = Genome.Split.split gpart_a26Gr
                      p_a26Fd = double g_a26Fc
                      (g_a26Fc, gpart_a26Gr) = Genome.Split.split gpart_a26Gq
                      p_a26Fb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Fa
                      (g_a26Fa, gpart_a26Gq) = Genome.Split.split gpart_a26Gp
                      p_a26F9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26F8
                      (g_a26F8, gpart_a26Gp) = Genome.Split.split gpart_a26Go
                      p_a26F7 = Functions.belowten' g_a26F6
                      (g_a26F6, gpart_a26Go) = Genome.Split.split gpart_a26Gn
                      p_a26F5 = double g_a26F4
                      (g_a26F4, gpart_a26Gn) = Genome.Split.split gpart_a26Gm
                      p_a26F3 = double g_a26F2
                      (g_a26F2, gpart_a26Gm) = Genome.Split.split gpart_a26Gl
                      p_a26F1 = double g_a26F0
                      (g_a26F0, gpart_a26Gl) = Genome.Split.split gpart_a26Gk
                      p_a26EZ = double g_a26EY
                      (g_a26EY, gpart_a26Gk) = Genome.Split.split gpart_a26Gj
                      p_a26EX = double g_a26EW
                      (g_a26EW, gpart_a26Gj) = Genome.Split.split gpart_a26Gi
                      p_a26EV = double g_a26EU
                      (g_a26EU, gpart_a26Gi) = Genome.Split.split genome_a26Gg
                    in  \ x_a26GY
                          -> let
                               c_PTB_a26H3
                                 = ((Data.Fixed.Vector.toVector x_a26GY) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26H1
                                 = ((Data.Fixed.Vector.toVector x_a26GY) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26GZ
                                 = ((Data.Fixed.Vector.toVector x_a26GY) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26H4
                                 = ((Data.Fixed.Vector.toVector x_a26GY) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26Hk
                                 = ((Data.Fixed.Vector.toVector x_a26GY) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26F3
                                     * ((p_a26Fh + ((c_NPTB_a26GZ / p_a26F5) ** p_a26F7))
                                        / (((1 + p_a26Fh) + ((c_NPTB_a26GZ / p_a26F5) ** p_a26F7))
                                           + (((p_a26EV / p_a26F9) ** p_a26Fb)
                                              + ((c_MiRs_a26H1 / p_a26Fd) ** p_a26Ff)))))
                                    + (negate (p_a26G7 * c_PTB_a26H3))),
                                   ((p_a26Fj
                                     * ((p_a26Fx + ((c_RESTc_a26H4 / p_a26Fl) ** p_a26Fn))
                                        / (((1 + p_a26Fx) + ((c_RESTc_a26H4 / p_a26Fl) ** p_a26Fn))
                                           + (((c_MiRs_a26H1 / p_a26Fp) ** p_a26Fr)
                                              + ((c_PTB_a26H3 / p_a26Ft) ** p_a26Fv)))))
                                    + (negate (p_a26G9 * c_NPTB_a26GZ))),
                                   ((p_a26Fz
                                     * (p_a26FJ
                                        / ((1 + p_a26FJ) + ((c_RESTc_a26H4 / p_a26FF) ** p_a26FH))))
                                    + (negate (p_a26Gb * c_MiRs_a26H1))),
                                   ((p_a26FL
                                     * ((p_a26FZ + ((c_PTB_a26H3 / p_a26FN) ** p_a26FP))
                                        / (((1 + p_a26FZ) + ((c_PTB_a26H3 / p_a26FN) ** p_a26FP))
                                           + ((c_MiRs_a26H1 / p_a26FV) ** p_a26FX))))
                                    + (negate (p_a26Gd * c_RESTc_a26H4))),
                                   ((p_a26G1 / (1 + ((c_RESTc_a26H4 / p_a26G3) ** p_a26G5)))
                                    + (negate (p_a26Gf * c_EndoNeuroTFs_a26Hk)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512048",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512049",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512050",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512051",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512059",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512061",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512063",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512065",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512067",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512069",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512085",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512087",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512091",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512093",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512107",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512109",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26Gg
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26I0
                            p_a26Gf = double g_a26Ge
                            (g_a26Ge, gpart_a26I0) = Genome.Split.split gpart_a26HZ
                            p_a26Gd = double g_a26Gc
                            (g_a26Gc, gpart_a26HZ) = Genome.Split.split gpart_a26HY
                            p_a26Gb = double g_a26Ga
                            (g_a26Ga, gpart_a26HY) = Genome.Split.split gpart_a26HX
                            p_a26G9 = double g_a26G8
                            (g_a26G8, gpart_a26HX) = Genome.Split.split gpart_a26HW
                            p_a26G7 = double g_a26G6
                            (g_a26G6, gpart_a26HW) = Genome.Split.split gpart_a26HV
                            p_a26G5 = Functions.belowten' g_a26G4
                            (g_a26G4, gpart_a26HV) = Genome.Split.split gpart_a26HU
                            p_a26G3 = double g_a26G2
                            (g_a26G2, gpart_a26HU) = Genome.Split.split gpart_a26HT
                            p_a26G1 = double g_a26G0
                            (g_a26G0, gpart_a26HT) = Genome.Split.split gpart_a26HS
                            p_a26FZ = double g_a26FY
                            (g_a26FY, gpart_a26HS) = Genome.Split.split gpart_a26HR
                            p_a26FX = Functions.belowten' g_a26FW
                            (g_a26FW, gpart_a26HR) = Genome.Split.split gpart_a26HQ
                            p_a26FV = double g_a26FU
                            (g_a26FU, gpart_a26HQ) = Genome.Split.split gpart_a26HP
                            p_a26FT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FS
                            (g_a26FS, gpart_a26HP) = Genome.Split.split gpart_a26HO
                            p_a26FR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FQ
                            (g_a26FQ, gpart_a26HO) = Genome.Split.split gpart_a26HN
                            p_a26FP = Functions.belowten' g_a26FO
                            (g_a26FO, gpart_a26HN) = Genome.Split.split gpart_a26HM
                            p_a26FN = double g_a26FM
                            (g_a26FM, gpart_a26HM) = Genome.Split.split gpart_a26HL
                            p_a26FL = double g_a26FK
                            (g_a26FK, gpart_a26HL) = Genome.Split.split gpart_a26HK
                            p_a26FJ = double g_a26FI
                            (g_a26FI, gpart_a26HK) = Genome.Split.split gpart_a26HJ
                            p_a26FH = Functions.belowten' g_a26FG
                            (g_a26FG, gpart_a26HJ) = Genome.Split.split gpart_a26HI
                            p_a26FF = double g_a26FE
                            (g_a26FE, gpart_a26HI) = Genome.Split.split gpart_a26HH
                            p_a26FD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FC
                            (g_a26FC, gpart_a26HH) = Genome.Split.split gpart_a26HG
                            p_a26FB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FA
                            (g_a26FA, gpart_a26HG) = Genome.Split.split gpart_a26HF
                            p_a26Fz = double g_a26Fy
                            (g_a26Fy, gpart_a26HF) = Genome.Split.split gpart_a26HE
                            p_a26Fx = double g_a26Fw
                            (g_a26Fw, gpart_a26HE) = Genome.Split.split gpart_a26HD
                            p_a26Fv = Functions.belowten' g_a26Fu
                            (g_a26Fu, gpart_a26HD) = Genome.Split.split gpart_a26HC
                            p_a26Ft = double g_a26Fs
                            (g_a26Fs, gpart_a26HC) = Genome.Split.split gpart_a26HB
                            p_a26Fr = Functions.belowten' g_a26Fq
                            (g_a26Fq, gpart_a26HB) = Genome.Split.split gpart_a26HA
                            p_a26Fp = double g_a26Fo
                            (g_a26Fo, gpart_a26HA) = Genome.Split.split gpart_a26Hz
                            p_a26Fn = Functions.belowten' g_a26Fm
                            (g_a26Fm, gpart_a26Hz) = Genome.Split.split gpart_a26Hy
                            p_a26Fl = double g_a26Fk
                            (g_a26Fk, gpart_a26Hy) = Genome.Split.split gpart_a26Hx
                            p_a26Fj = double g_a26Fi
                            (g_a26Fi, gpart_a26Hx) = Genome.Split.split gpart_a26Hw
                            p_a26Fh = double g_a26Fg
                            (g_a26Fg, gpart_a26Hw) = Genome.Split.split gpart_a26Hv
                            p_a26Ff = Functions.belowten' g_a26Fe
                            (g_a26Fe, gpart_a26Hv) = Genome.Split.split gpart_a26Hu
                            p_a26Fd = double g_a26Fc
                            (g_a26Fc, gpart_a26Hu) = Genome.Split.split gpart_a26Ht
                            p_a26Fb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Fa
                            (g_a26Fa, gpart_a26Ht) = Genome.Split.split gpart_a26Hs
                            p_a26F9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26F8
                            (g_a26F8, gpart_a26Hs) = Genome.Split.split gpart_a26Hr
                            p_a26F7 = Functions.belowten' g_a26F6
                            (g_a26F6, gpart_a26Hr) = Genome.Split.split gpart_a26Hq
                            p_a26F5 = double g_a26F4
                            (g_a26F4, gpart_a26Hq) = Genome.Split.split gpart_a26Hp
                            p_a26F3 = double g_a26F2
                            (g_a26F2, gpart_a26Hp) = Genome.Split.split gpart_a26Ho
                            p_a26F1 = double g_a26F0
                            (g_a26F0, gpart_a26Ho) = Genome.Split.split gpart_a26Hn
                            p_a26EZ = double g_a26EY
                            (g_a26EY, gpart_a26Hn) = Genome.Split.split gpart_a26Hm
                            p_a26EX = double g_a26EW
                            (g_a26EW, gpart_a26Hm) = Genome.Split.split gpart_a26Hl
                            p_a26EV = double g_a26EU
                            (g_a26EU, gpart_a26Hl) = Genome.Split.split genome_a26Gg
                          in
                            \ desc_a26Gh
                              -> case desc_a26Gh of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EV)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EX)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EZ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F1)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F3)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F5)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F7)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F9)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fb)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fd)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ff)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fh)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fj)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fl)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fn)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fp)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fr)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ft)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fv)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fx)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fz)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FB)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FD)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FF)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FH)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FJ)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FL)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FN)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FP)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FR)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FT)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FV)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FX)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FZ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G1)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G3)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G5)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G7)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G9)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gb)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gd)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gf)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asV8
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVP
                      p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                      (g_asV6, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                      (g_asV4, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                      (g_asV2, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                      (g_asV0, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                      (g_asUY, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUX = Functions.belowten' g_asUW
                      (g_asUW, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                      (g_asUU, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                      (g_asUS, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                      (g_asUQ, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUP = Functions.belowten' g_asUO
                      (g_asUO, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                      (g_asUM, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUK
                      (g_asUK, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUI
                      (g_asUI, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUH = Functions.belowten' g_asUG
                      (g_asUG, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUF = code-0.1.0.0:Genome.FixedList.Functions.double g_asUE
                      (g_asUE, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                      (g_asUC, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                      (g_asUA, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUz = Functions.belowten' g_asUy
                      (g_asUy, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                      (g_asUw, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUu
                      (g_asUu, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asUt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUs
                      (g_asUs, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                      (g_asUq, gpart_asVu) = Genome.Split.split gpart_asVt
                      p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                      (g_asUo, gpart_asVt) = Genome.Split.split gpart_asVs
                      p_asUn = Functions.belowten' g_asUm
                      (g_asUm, gpart_asVs) = Genome.Split.split gpart_asVr
                      p_asUl = code-0.1.0.0:Genome.FixedList.Functions.double g_asUk
                      (g_asUk, gpart_asVr) = Genome.Split.split gpart_asVq
                      p_asUj = Functions.belowten' g_asUi
                      (g_asUi, gpart_asVq) = Genome.Split.split gpart_asVp
                      p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                      (g_asUg, gpart_asVp) = Genome.Split.split gpart_asVo
                      p_asUf = Functions.belowten' g_asUe
                      (g_asUe, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                      (g_asUa, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                      (g_asU8, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asU7 = Functions.belowten' g_asU6
                      (g_asU6, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                      (g_asU4, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asU3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU2
                      (g_asU2, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asU1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU0
                      (g_asU0, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asTZ = Functions.belowten' g_asTY
                      (g_asTY, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                      (g_asTW, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                      (g_asTU, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                      (g_asTS, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                      (g_asTQ, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                      (g_asTO, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                      (g_asTM, gpart_asVa) = Genome.Split.split genome_asV8
                    in
                      [Reaction
                         (\ x_asVQ
                            -> let
                                 c_MiRs_asVT = ((toVector x_asVQ) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asVR = ((toVector x_asVQ) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asTV
                                  * ((p_asU9 + ((c_NPTB_asVR / p_asTX) ** p_asTZ))
                                     / (((1 + p_asU9) + ((c_NPTB_asVR / p_asTX) ** p_asTZ))
                                        + ((c_MiRs_asVT / p_asU5) ** p_asU7)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVU
                            -> let
                                 c_PTB_asVY = ((toVector x_asVU) Data.Vector.Unboxed.! 0)
                                 c_MiRs_asVX = ((toVector x_asVU) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asVV = ((toVector x_asVU) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUb
                                  * ((p_asUp + ((c_RESTc_asVV / p_asUd) ** p_asUf))
                                     / (((1 + p_asUp) + ((c_RESTc_asVV / p_asUd) ** p_asUf))
                                        + (((c_MiRs_asVX / p_asUh) ** p_asUj)
                                           + ((c_PTB_asVY / p_asUl) ** p_asUn))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVZ
                            -> let c_RESTc_asW0 = ((toVector x_asVZ) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUr
                                  * ((p_asUB + ((p_asTR / p_asUt) ** p_asUv))
                                     / (((1 + p_asUB) + ((p_asTR / p_asUt) ** p_asUv))
                                        + ((c_RESTc_asW0 / p_asUx) ** p_asUz)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asW1
                            -> let
                                 c_MiRs_asW4 = ((toVector x_asW1) Data.Vector.Unboxed.! 2)
                                 c_PTB_asW2 = ((toVector x_asW1) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUD
                                  * ((p_asUR + ((c_PTB_asW2 / p_asUF) ** p_asUH))
                                     / (((1 + p_asUR) + ((c_PTB_asW2 / p_asUF) ** p_asUH))
                                        + (((p_asTN / p_asUJ) ** p_asUL)
                                           + ((c_MiRs_asW4 / p_asUN) ** p_asUP))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asW5
                            -> let c_RESTc_asW6 = ((toVector x_asW5) Data.Vector.Unboxed.! 3)
                               in (p_asUT / (1 + ((c_RESTc_asW6 / p_asUV) ** p_asUX))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asW7
                            -> let c_PTB_asW8 = ((toVector x_asW7) Data.Vector.Unboxed.! 0)
                               in (p_asUZ * c_PTB_asW8))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asW9
                            -> let c_NPTB_asWa = ((toVector x_asW9) Data.Vector.Unboxed.! 1)
                               in (p_asV1 * c_NPTB_asWa))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWb
                            -> let c_MiRs_asWc = ((toVector x_asWb) Data.Vector.Unboxed.! 2)
                               in (p_asV3 * c_MiRs_asWc))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWd
                            -> let c_RESTc_asWe = ((toVector x_asWd) Data.Vector.Unboxed.! 3)
                               in (p_asV5 * c_RESTc_asWe))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWf
                            -> let
                                 c_EndoNeuroTFs_asWg = ((toVector x_asWf) Data.Vector.Unboxed.! 4)
                               in (p_asV7 * c_EndoNeuroTFs_asWg))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120897",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120899",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120939",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120941",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120943",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120957",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asV8
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asX1
                            p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                            (g_asV6, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                            (g_asV4, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                            (g_asV2, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                            (g_asV0, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                            (g_asUY, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asUX = Functions.belowten' g_asUW
                            (g_asUW, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                            (g_asUU, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                            (g_asUS, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                            (g_asUQ, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUP = Functions.belowten' g_asUO
                            (g_asUO, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                            (g_asUM, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUK
                            (g_asUK, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUI
                            (g_asUI, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUH = Functions.belowten' g_asUG
                            (g_asUG, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUF = code-0.1.0.0:Genome.FixedList.Functions.double g_asUE
                            (g_asUE, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                            (g_asUC, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                            (g_asUA, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUz = Functions.belowten' g_asUy
                            (g_asUy, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                            (g_asUw, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUu
                            (g_asUu, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUs
                            (g_asUs, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                            (g_asUq, gpart_asWG) = Genome.Split.split gpart_asWF
                            p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                            (g_asUo, gpart_asWF) = Genome.Split.split gpart_asWE
                            p_asUn = Functions.belowten' g_asUm
                            (g_asUm, gpart_asWE) = Genome.Split.split gpart_asWD
                            p_asUl = code-0.1.0.0:Genome.FixedList.Functions.double g_asUk
                            (g_asUk, gpart_asWD) = Genome.Split.split gpart_asWC
                            p_asUj = Functions.belowten' g_asUi
                            (g_asUi, gpart_asWC) = Genome.Split.split gpart_asWB
                            p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                            (g_asUg, gpart_asWB) = Genome.Split.split gpart_asWA
                            p_asUf = Functions.belowten' g_asUe
                            (g_asUe, gpart_asWA) = Genome.Split.split gpart_asWz
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWz) = Genome.Split.split gpart_asWy
                            p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                            (g_asUa, gpart_asWy) = Genome.Split.split gpart_asWx
                            p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                            (g_asU8, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asU7 = Functions.belowten' g_asU6
                            (g_asU6, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                            (g_asU4, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asU3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU2
                            (g_asU2, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asU1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU0
                            (g_asU0, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asTZ = Functions.belowten' g_asTY
                            (g_asTY, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                            (g_asTW, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                            (g_asTU, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                            (g_asTS, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                            (g_asTQ, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                            (g_asTO, gpart_asWn) = Genome.Split.split gpart_asWm
                            p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                            (g_asTM, gpart_asWm) = Genome.Split.split genome_asV8
                          in
                            \ desc_asV9
                              -> case desc_asV9 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTN)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTP)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTR)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTT)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTV)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTX)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTZ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU1)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU3)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU5)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUH)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUJ)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUL)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUN)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUP)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUR)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUT)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUV)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUX)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUZ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV1)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV5)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV7)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZ4
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZL
                      p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                      (g_asZ2, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                      (g_asZ0, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                      (g_asYY, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                      (g_asYW, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                      (g_asYU, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYT = Functions.belowten' g_asYS
                      (g_asYS, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                      (g_asYQ, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYP = code-0.1.0.0:Genome.FixedList.Functions.double g_asYO
                      (g_asYO, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                      (g_asYM, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYL = Functions.belowten' g_asYK
                      (g_asYK, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                      (g_asYI, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYG
                      (g_asYG, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYE
                      (g_asYE, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYD = Functions.belowten' g_asYC
                      (g_asYC, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                      (g_asYA, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYz = code-0.1.0.0:Genome.FixedList.Functions.double g_asYy
                      (g_asYy, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                      (g_asYw, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYv = Functions.belowten' g_asYu
                      (g_asYu, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                      (g_asYs, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYq
                      (g_asYq, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asYp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYo
                      (g_asYo, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                      (g_asYm, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                      (g_asYk, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asYj = Functions.belowten' g_asYi
                      (g_asYi, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                      (g_asYg, gpart_asZn) = Genome.Split.split gpart_asZm
                      p_asYf = Functions.belowten' g_asYe
                      (g_asYe, gpart_asZm) = Genome.Split.split gpart_asZl
                      p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                      (g_asYc, gpart_asZl) = Genome.Split.split gpart_asZk
                      p_asYb = Functions.belowten' g_asYa
                      (g_asYa, gpart_asZk) = Genome.Split.split gpart_asZj
                      p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                      (g_asY8, gpart_asZj) = Genome.Split.split gpart_asZi
                      p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                      (g_asY6, gpart_asZi) = Genome.Split.split gpart_asZh
                      p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                      (g_asY4, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asY3 = Functions.belowten' g_asY2
                      (g_asY2, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                      (g_asY0, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asXZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXY
                      (g_asXY, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asXX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXW
                      (g_asXW, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asXV = Functions.belowten' g_asXU
                      (g_asXU, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                      (g_asXS, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asXR = code-0.1.0.0:Genome.FixedList.Functions.double g_asXQ
                      (g_asXQ, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                      (g_asXO, gpart_asZ9) = Genome.Split.split gpart_asZ8
                      p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                      (g_asXM, gpart_asZ8) = Genome.Split.split gpart_asZ7
                      p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                      (g_asXK, gpart_asZ7) = Genome.Split.split gpart_asZ6
                      p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                      (g_asXI, gpart_asZ6) = Genome.Split.split genome_asZ4
                    in
                      [Reaction
                         (\ x_asZM
                            -> let
                                 c_MiRs_asZP = ((toVector x_asZM) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asZN = ((toVector x_asZM) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asXR
                                  * ((p_asY5 + ((c_NPTB_asZN / p_asXT) ** p_asXV))
                                     / (((1 + p_asY5) + ((c_NPTB_asZN / p_asXT) ** p_asXV))
                                        + ((c_MiRs_asZP / p_asY1) ** p_asY3)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZQ
                            -> let
                                 c_PTB_asZU = ((toVector x_asZQ) Data.Vector.Unboxed.! 0)
                                 c_MiRs_asZT = ((toVector x_asZQ) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asZR = ((toVector x_asZQ) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asY7
                                  * ((p_asYl + ((c_RESTc_asZR / p_asY9) ** p_asYb))
                                     / (((1 + p_asYl) + ((c_RESTc_asZR / p_asY9) ** p_asYb))
                                        + (((c_MiRs_asZT / p_asYd) ** p_asYf)
                                           + ((c_PTB_asZU / p_asYh) ** p_asYj))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZV
                            -> let c_RESTc_asZW = ((toVector x_asZV) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYn
                                  * (p_asYx
                                     / ((1 + p_asYx) + ((c_RESTc_asZW / p_asYt) ** p_asYv)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZX
                            -> let
                                 c_MiRs_at00 = ((toVector x_asZX) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZY = ((toVector x_asZX) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYz
                                  * ((p_asYN + ((c_PTB_asZY / p_asYB) ** p_asYD))
                                     / (((1 + p_asYN) + ((c_PTB_asZY / p_asYB) ** p_asYD))
                                        + (((p_asXJ / p_asYF) ** p_asYH)
                                           + ((c_MiRs_at00 / p_asYJ) ** p_asYL))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at01
                            -> let c_RESTc_at02 = ((toVector x_at01) Data.Vector.Unboxed.! 3)
                               in (p_asYP / (1 + ((c_RESTc_at02 / p_asYR) ** p_asYT))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at03
                            -> let c_PTB_at04 = ((toVector x_at03) Data.Vector.Unboxed.! 0)
                               in (p_asYV * c_PTB_at04))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at05
                            -> let c_NPTB_at06 = ((toVector x_at05) Data.Vector.Unboxed.! 1)
                               in (p_asYX * c_NPTB_at06))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at07
                            -> let c_MiRs_at08 = ((toVector x_at07) Data.Vector.Unboxed.! 2)
                               in (p_asYZ * c_MiRs_at08))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at09
                            -> let c_RESTc_at0a = ((toVector x_at09) Data.Vector.Unboxed.! 3)
                               in (p_asZ1 * c_RESTc_at0a))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0b
                            -> let
                                 c_EndoNeuroTFs_at0c = ((toVector x_at0b) Data.Vector.Unboxed.! 4)
                               in (p_asZ3 * c_EndoNeuroTFs_at0c))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121141",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121143",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121185",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121187",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZ4
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0S
                            p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                            (g_asZ2, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                            (g_asZ0, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                            (g_asYY, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                            (g_asYW, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                            (g_asYU, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asYT = Functions.belowten' g_asYS
                            (g_asYS, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                            (g_asYQ, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYP = code-0.1.0.0:Genome.FixedList.Functions.double g_asYO
                            (g_asYO, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                            (g_asYM, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYL = Functions.belowten' g_asYK
                            (g_asYK, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                            (g_asYI, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYG
                            (g_asYG, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYE
                            (g_asYE, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYD = Functions.belowten' g_asYC
                            (g_asYC, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                            (g_asYA, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYz = code-0.1.0.0:Genome.FixedList.Functions.double g_asYy
                            (g_asYy, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                            (g_asYw, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYv = Functions.belowten' g_asYu
                            (g_asYu, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                            (g_asYs, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYq
                            (g_asYq, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYo
                            (g_asYo, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                            (g_asYm, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                            (g_asYk, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asYj = Functions.belowten' g_asYi
                            (g_asYi, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                            (g_asYg, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asYf = Functions.belowten' g_asYe
                            (g_asYe, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                            (g_asYc, gpart_at0s) = Genome.Split.split gpart_at0r
                            p_asYb = Functions.belowten' g_asYa
                            (g_asYa, gpart_at0r) = Genome.Split.split gpart_at0q
                            p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                            (g_asY8, gpart_at0q) = Genome.Split.split gpart_at0p
                            p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                            (g_asY6, gpart_at0p) = Genome.Split.split gpart_at0o
                            p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                            (g_asY4, gpart_at0o) = Genome.Split.split gpart_at0n
                            p_asY3 = Functions.belowten' g_asY2
                            (g_asY2, gpart_at0n) = Genome.Split.split gpart_at0m
                            p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                            (g_asY0, gpart_at0m) = Genome.Split.split gpart_at0l
                            p_asXZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXY
                            (g_asXY, gpart_at0l) = Genome.Split.split gpart_at0k
                            p_asXX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXW
                            (g_asXW, gpart_at0k) = Genome.Split.split gpart_at0j
                            p_asXV = Functions.belowten' g_asXU
                            (g_asXU, gpart_at0j) = Genome.Split.split gpart_at0i
                            p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                            (g_asXS, gpart_at0i) = Genome.Split.split gpart_at0h
                            p_asXR = code-0.1.0.0:Genome.FixedList.Functions.double g_asXQ
                            (g_asXQ, gpart_at0h) = Genome.Split.split gpart_at0g
                            p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                            (g_asXO, gpart_at0g) = Genome.Split.split gpart_at0f
                            p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                            (g_asXM, gpart_at0f) = Genome.Split.split gpart_at0e
                            p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                            (g_asXK, gpart_at0e) = Genome.Split.split gpart_at0d
                            p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                            (g_asXI, gpart_at0d) = Genome.Split.split genome_asZ4
                          in
                            \ desc_asZ5
                              -> case desc_asZ5 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXP)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXR)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXT)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXV)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXX)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXZ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY1)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYz)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYB)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYF)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYH)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYJ)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYL)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYN)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYP)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYR)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYT)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYV)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYX)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYZ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ1)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ3)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at2V
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3C
                      p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                      (g_at2T, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                      (g_at2R, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                      (g_at2P, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                      (g_at2N, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                      (g_at2L, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2K = Functions.belowten' g_at2J
                      (g_at2J, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                      (g_at2H, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                      (g_at2F, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                      (g_at2D, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2C = Functions.belowten' g_at2B
                      (g_at2B, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                      (g_at2z, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2x
                      (g_at2x, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2w
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2v
                      (g_at2v, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2u = Functions.belowten' g_at2t
                      (g_at2t, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                      (g_at2r, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                      (g_at2p, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                      (g_at2n, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2m = Functions.belowten' g_at2l
                      (g_at2l, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                      (g_at2j, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at2i
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2h
                      (g_at2h, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at2g
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2f
                      (g_at2f, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                      (g_at2d, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                      (g_at2b, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at2a = Functions.belowten' g_at29
                      (g_at29, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                      (g_at27, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at26 = Functions.belowten' g_at25
                      (g_at25, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                      (g_at23, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at22 = Functions.belowten' g_at21
                      (g_at21, gpart_at3b) = Genome.Split.split gpart_at3a
                      p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                      (g_at1Z, gpart_at3a) = Genome.Split.split gpart_at39
                      p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                      (g_at1X, gpart_at39) = Genome.Split.split gpart_at38
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at38) = Genome.Split.split gpart_at37
                      p_at1U = Functions.belowten' g_at1T
                      (g_at1T, gpart_at37) = Genome.Split.split gpart_at36
                      p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                      (g_at1R, gpart_at36) = Genome.Split.split gpart_at35
                      p_at1Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1P
                      (g_at1P, gpart_at35) = Genome.Split.split gpart_at34
                      p_at1O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1N
                      (g_at1N, gpart_at34) = Genome.Split.split gpart_at33
                      p_at1M = Functions.belowten' g_at1L
                      (g_at1L, gpart_at33) = Genome.Split.split gpart_at32
                      p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                      (g_at1J, gpart_at32) = Genome.Split.split gpart_at31
                      p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                      (g_at1H, gpart_at31) = Genome.Split.split gpart_at30
                      p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                      (g_at1F, gpart_at30) = Genome.Split.split gpart_at2Z
                      p_at1E = code-0.1.0.0:Genome.FixedList.Functions.double g_at1D
                      (g_at1D, gpart_at2Z) = Genome.Split.split gpart_at2Y
                      p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                      (g_at1B, gpart_at2Y) = Genome.Split.split gpart_at2X
                      p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                      (g_at1z, gpart_at2X) = Genome.Split.split genome_at2V
                    in
                      [Reaction
                         (\ x_at3D
                            -> let
                                 c_MiRs_at3G = ((toVector x_at3D) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at3E = ((toVector x_at3D) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at1I
                                  * ((p_at1W + ((c_NPTB_at3E / p_at1K) ** p_at1M))
                                     / (((1 + p_at1W) + ((c_NPTB_at3E / p_at1K) ** p_at1M))
                                        + ((c_MiRs_at3G / p_at1S) ** p_at1U)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3H
                            -> let
                                 c_PTB_at3L = ((toVector x_at3H) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at3K = ((toVector x_at3H) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at3I = ((toVector x_at3H) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at1Y
                                  * ((p_at2c + ((c_RESTc_at3I / p_at20) ** p_at22))
                                     / (((1 + p_at2c) + ((c_RESTc_at3I / p_at20) ** p_at22))
                                        + (((c_MiRs_at3K / p_at24) ** p_at26)
                                           + ((c_PTB_at3L / p_at28) ** p_at2a))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3M
                            -> let c_RESTc_at3N = ((toVector x_at3M) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2e
                                  * (p_at2o
                                     / ((1 + p_at2o) + ((c_RESTc_at3N / p_at2k) ** p_at2m)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3O
                            -> let
                                 c_MiRs_at3R = ((toVector x_at3O) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3P = ((toVector x_at3O) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2q
                                  * ((p_at2E + ((c_PTB_at3P / p_at2s) ** p_at2u))
                                     / (((1 + p_at2E) + ((c_PTB_at3P / p_at2s) ** p_at2u))
                                        + ((c_MiRs_at3R / p_at2A) ** p_at2C)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3S
                            -> let c_RESTc_at3T = ((toVector x_at3S) Data.Vector.Unboxed.! 3)
                               in (p_at2G / (1 + ((c_RESTc_at3T / p_at2I) ** p_at2K))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at3U
                            -> let c_PTB_at3V = ((toVector x_at3U) Data.Vector.Unboxed.! 0)
                               in (p_at2M * c_PTB_at3V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3W
                            -> let c_NPTB_at3X = ((toVector x_at3W) Data.Vector.Unboxed.! 1)
                               in (p_at2O * c_NPTB_at3X))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at3Y
                            -> let c_MiRs_at3Z = ((toVector x_at3Y) Data.Vector.Unboxed.! 2)
                               in (p_at2Q * c_MiRs_at3Z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at40
                            -> let c_RESTc_at41 = ((toVector x_at40) Data.Vector.Unboxed.! 3)
                               in (p_at2S * c_RESTc_at41))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at42
                            -> let
                                 c_EndoNeuroTFs_at43 = ((toVector x_at42) Data.Vector.Unboxed.! 4)
                               in (p_at2U * c_EndoNeuroTFs_at43))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121424",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121426",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2V
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4J
                            p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                            (g_at2T, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                            (g_at2R, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                            (g_at2P, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                            (g_at2N, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                            (g_at2L, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2K = Functions.belowten' g_at2J
                            (g_at2J, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                            (g_at2H, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                            (g_at2F, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                            (g_at2D, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2C = Functions.belowten' g_at2B
                            (g_at2B, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                            (g_at2z, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2x
                            (g_at2x, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2w
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2v
                            (g_at2v, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2u = Functions.belowten' g_at2t
                            (g_at2t, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                            (g_at2r, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                            (g_at2p, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                            (g_at2n, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at2m = Functions.belowten' g_at2l
                            (g_at2l, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                            (g_at2j, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at2i
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2h
                            (g_at2h, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at2g
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2f
                            (g_at2f, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                            (g_at2d, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                            (g_at2b, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at2a = Functions.belowten' g_at29
                            (g_at29, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                            (g_at27, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at26 = Functions.belowten' g_at25
                            (g_at25, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                            (g_at23, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at22 = Functions.belowten' g_at21
                            (g_at21, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                            (g_at1Z, gpart_at4h) = Genome.Split.split gpart_at4g
                            p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                            (g_at1X, gpart_at4g) = Genome.Split.split gpart_at4f
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at4f) = Genome.Split.split gpart_at4e
                            p_at1U = Functions.belowten' g_at1T
                            (g_at1T, gpart_at4e) = Genome.Split.split gpart_at4d
                            p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                            (g_at1R, gpart_at4d) = Genome.Split.split gpart_at4c
                            p_at1Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1P
                            (g_at1P, gpart_at4c) = Genome.Split.split gpart_at4b
                            p_at1O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1N
                            (g_at1N, gpart_at4b) = Genome.Split.split gpart_at4a
                            p_at1M = Functions.belowten' g_at1L
                            (g_at1L, gpart_at4a) = Genome.Split.split gpart_at49
                            p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                            (g_at1J, gpart_at49) = Genome.Split.split gpart_at48
                            p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                            (g_at1H, gpart_at48) = Genome.Split.split gpart_at47
                            p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                            (g_at1F, gpart_at47) = Genome.Split.split gpart_at46
                            p_at1E = code-0.1.0.0:Genome.FixedList.Functions.double g_at1D
                            (g_at1D, gpart_at46) = Genome.Split.split gpart_at45
                            p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                            (g_at1B, gpart_at45) = Genome.Split.split gpart_at44
                            p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                            (g_at1z, gpart_at44) = Genome.Split.split genome_at2V
                          in
                            \ desc_at2W
                              -> case desc_at2W of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2u)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2w)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2y)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2A)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2C)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2E)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2G)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2M)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2O)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Q)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2S)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2U)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at6M
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7t
                      p_at6L = code-0.1.0.0:Genome.FixedList.Functions.double g_at6K
                      (g_at6K, gpart_at7t) = Genome.Split.split gpart_at7s
                      p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                      (g_at6I, gpart_at7s) = Genome.Split.split gpart_at7r
                      p_at6H = code-0.1.0.0:Genome.FixedList.Functions.double g_at6G
                      (g_at6G, gpart_at7r) = Genome.Split.split gpart_at7q
                      p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                      (g_at6E, gpart_at7q) = Genome.Split.split gpart_at7p
                      p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                      (g_at6C, gpart_at7p) = Genome.Split.split gpart_at7o
                      p_at6B = Functions.belowten' g_at6A
                      (g_at6A, gpart_at7o) = Genome.Split.split gpart_at7n
                      p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                      (g_at6y, gpart_at7n) = Genome.Split.split gpart_at7m
                      p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                      (g_at6w, gpart_at7m) = Genome.Split.split gpart_at7l
                      p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                      (g_at6u, gpart_at7l) = Genome.Split.split gpart_at7k
                      p_at6t = Functions.belowten' g_at6s
                      (g_at6s, gpart_at7k) = Genome.Split.split gpart_at7j
                      p_at6r = code-0.1.0.0:Genome.FixedList.Functions.double g_at6q
                      (g_at6q, gpart_at7j) = Genome.Split.split gpart_at7i
                      p_at6p
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6o
                      (g_at6o, gpart_at7i) = Genome.Split.split gpart_at7h
                      p_at6n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6m
                      (g_at6m, gpart_at7h) = Genome.Split.split gpart_at7g
                      p_at6l = Functions.belowten' g_at6k
                      (g_at6k, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                      (g_at6i, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                      (g_at6g, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                      (g_at6e, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at6d = Functions.belowten' g_at6c
                      (g_at6c, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at6b = code-0.1.0.0:Genome.FixedList.Functions.double g_at6a
                      (g_at6a, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at69
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at68
                      (g_at68, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at67
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at66
                      (g_at66, gpart_at79) = Genome.Split.split gpart_at78
                      p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                      (g_at64, gpart_at78) = Genome.Split.split gpart_at77
                      p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                      (g_at62, gpart_at77) = Genome.Split.split gpart_at76
                      p_at61 = Functions.belowten' g_at60
                      (g_at60, gpart_at76) = Genome.Split.split gpart_at75
                      p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                      (g_at5Y, gpart_at75) = Genome.Split.split gpart_at74
                      p_at5X = Functions.belowten' g_at5W
                      (g_at5W, gpart_at74) = Genome.Split.split gpart_at73
                      p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                      (g_at5U, gpart_at73) = Genome.Split.split gpart_at72
                      p_at5T = Functions.belowten' g_at5S
                      (g_at5S, gpart_at72) = Genome.Split.split gpart_at71
                      p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                      (g_at5Q, gpart_at71) = Genome.Split.split gpart_at70
                      p_at5P = code-0.1.0.0:Genome.FixedList.Functions.double g_at5O
                      (g_at5O, gpart_at70) = Genome.Split.split gpart_at6Z
                      p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                      (g_at5M, gpart_at6Z) = Genome.Split.split gpart_at6Y
                      p_at5L = Functions.belowten' g_at5K
                      (g_at5K, gpart_at6Y) = Genome.Split.split gpart_at6X
                      p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                      (g_at5I, gpart_at6X) = Genome.Split.split gpart_at6W
                      p_at5H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5G
                      (g_at5G, gpart_at6W) = Genome.Split.split gpart_at6V
                      p_at5F
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5E
                      (g_at5E, gpart_at6V) = Genome.Split.split gpart_at6U
                      p_at5D = Functions.belowten' g_at5C
                      (g_at5C, gpart_at6U) = Genome.Split.split gpart_at6T
                      p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                      (g_at5A, gpart_at6T) = Genome.Split.split gpart_at6S
                      p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                      (g_at5y, gpart_at6S) = Genome.Split.split gpart_at6R
                      p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                      (g_at5w, gpart_at6R) = Genome.Split.split gpart_at6Q
                      p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                      (g_at5u, gpart_at6Q) = Genome.Split.split gpart_at6P
                      p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                      (g_at5s, gpart_at6P) = Genome.Split.split gpart_at6O
                      p_at5r = code-0.1.0.0:Genome.FixedList.Functions.double g_at5q
                      (g_at5q, gpart_at6O) = Genome.Split.split genome_at6M
                    in
                      [Reaction
                         (\ x_at7u
                            -> let
                                 c_MiRs_at7x = ((toVector x_at7u) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at7v = ((toVector x_at7u) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at5z
                                  * ((p_at5N + ((c_NPTB_at7v / p_at5B) ** p_at5D))
                                     / (((1 + p_at5N) + ((c_NPTB_at7v / p_at5B) ** p_at5D))
                                        + (((p_at5r / p_at5F) ** p_at5H)
                                           + ((c_MiRs_at7x / p_at5J) ** p_at5L))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7y
                            -> let
                                 c_PTB_at7C = ((toVector x_at7y) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at7B = ((toVector x_at7y) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at7z = ((toVector x_at7y) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at5P
                                  * ((p_at63 + ((c_RESTc_at7z / p_at5R) ** p_at5T))
                                     / (((1 + p_at63) + ((c_RESTc_at7z / p_at5R) ** p_at5T))
                                        + (((c_MiRs_at7B / p_at5V) ** p_at5X)
                                           + ((c_PTB_at7C / p_at5Z) ** p_at61))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7D
                            -> let c_RESTc_at7E = ((toVector x_at7D) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at65
                                  * (p_at6f
                                     / ((1 + p_at6f) + ((c_RESTc_at7E / p_at6b) ** p_at6d)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7F
                            -> let
                                 c_MiRs_at7I = ((toVector x_at7F) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7G = ((toVector x_at7F) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6h
                                  * ((p_at6v + ((c_PTB_at7G / p_at6j) ** p_at6l))
                                     / (((1 + p_at6v) + ((c_PTB_at7G / p_at6j) ** p_at6l))
                                        + ((c_MiRs_at7I / p_at6r) ** p_at6t)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7J
                            -> let c_RESTc_at7K = ((toVector x_at7J) Data.Vector.Unboxed.! 3)
                               in (p_at6x / (1 + ((c_RESTc_at7K / p_at6z) ** p_at6B))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at7L
                            -> let c_PTB_at7M = ((toVector x_at7L) Data.Vector.Unboxed.! 0)
                               in (p_at6D * c_PTB_at7M))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7N
                            -> let c_NPTB_at7O = ((toVector x_at7N) Data.Vector.Unboxed.! 1)
                               in (p_at6F * c_NPTB_at7O))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at7P
                            -> let c_MiRs_at7Q = ((toVector x_at7P) Data.Vector.Unboxed.! 2)
                               in (p_at6H * c_MiRs_at7Q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at7R
                            -> let c_RESTc_at7S = ((toVector x_at7R) Data.Vector.Unboxed.! 3)
                               in (p_at6J * c_RESTc_at7S))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at7T
                            -> let
                                 c_EndoNeuroTFs_at7U = ((toVector x_at7T) Data.Vector.Unboxed.! 4)
                               in (p_at6L * c_EndoNeuroTFs_at7U))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121647",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121649",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121651",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121663",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121665",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6M
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8A
                            p_at6L = code-0.1.0.0:Genome.FixedList.Functions.double g_at6K
                            (g_at6K, gpart_at8A) = Genome.Split.split gpart_at8z
                            p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                            (g_at6I, gpart_at8z) = Genome.Split.split gpart_at8y
                            p_at6H = code-0.1.0.0:Genome.FixedList.Functions.double g_at6G
                            (g_at6G, gpart_at8y) = Genome.Split.split gpart_at8x
                            p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                            (g_at6E, gpart_at8x) = Genome.Split.split gpart_at8w
                            p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                            (g_at6C, gpart_at8w) = Genome.Split.split gpart_at8v
                            p_at6B = Functions.belowten' g_at6A
                            (g_at6A, gpart_at8v) = Genome.Split.split gpart_at8u
                            p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                            (g_at6y, gpart_at8u) = Genome.Split.split gpart_at8t
                            p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                            (g_at6w, gpart_at8t) = Genome.Split.split gpart_at8s
                            p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                            (g_at6u, gpart_at8s) = Genome.Split.split gpart_at8r
                            p_at6t = Functions.belowten' g_at6s
                            (g_at6s, gpart_at8r) = Genome.Split.split gpart_at8q
                            p_at6r = code-0.1.0.0:Genome.FixedList.Functions.double g_at6q
                            (g_at6q, gpart_at8q) = Genome.Split.split gpart_at8p
                            p_at6p
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6o
                            (g_at6o, gpart_at8p) = Genome.Split.split gpart_at8o
                            p_at6n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6m
                            (g_at6m, gpart_at8o) = Genome.Split.split gpart_at8n
                            p_at6l = Functions.belowten' g_at6k
                            (g_at6k, gpart_at8n) = Genome.Split.split gpart_at8m
                            p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                            (g_at6i, gpart_at8m) = Genome.Split.split gpart_at8l
                            p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                            (g_at6g, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                            (g_at6e, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at6d = Functions.belowten' g_at6c
                            (g_at6c, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at6b = code-0.1.0.0:Genome.FixedList.Functions.double g_at6a
                            (g_at6a, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at69
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at68
                            (g_at68, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at67
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at66
                            (g_at66, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                            (g_at64, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                            (g_at62, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at61 = Functions.belowten' g_at60
                            (g_at60, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                            (g_at5Y, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at5X = Functions.belowten' g_at5W
                            (g_at5W, gpart_at8b) = Genome.Split.split gpart_at8a
                            p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                            (g_at5U, gpart_at8a) = Genome.Split.split gpart_at89
                            p_at5T = Functions.belowten' g_at5S
                            (g_at5S, gpart_at89) = Genome.Split.split gpart_at88
                            p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                            (g_at5Q, gpart_at88) = Genome.Split.split gpart_at87
                            p_at5P = code-0.1.0.0:Genome.FixedList.Functions.double g_at5O
                            (g_at5O, gpart_at87) = Genome.Split.split gpart_at86
                            p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                            (g_at5M, gpart_at86) = Genome.Split.split gpart_at85
                            p_at5L = Functions.belowten' g_at5K
                            (g_at5K, gpart_at85) = Genome.Split.split gpart_at84
                            p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                            (g_at5I, gpart_at84) = Genome.Split.split gpart_at83
                            p_at5H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5G
                            (g_at5G, gpart_at83) = Genome.Split.split gpart_at82
                            p_at5F
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5E
                            (g_at5E, gpart_at82) = Genome.Split.split gpart_at81
                            p_at5D = Functions.belowten' g_at5C
                            (g_at5C, gpart_at81) = Genome.Split.split gpart_at80
                            p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                            (g_at5A, gpart_at80) = Genome.Split.split gpart_at7Z
                            p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                            (g_at5y, gpart_at7Z) = Genome.Split.split gpart_at7Y
                            p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                            (g_at5w, gpart_at7Y) = Genome.Split.split gpart_at7X
                            p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                            (g_at5u, gpart_at7X) = Genome.Split.split gpart_at7W
                            p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                            (g_at5s, gpart_at7W) = Genome.Split.split gpart_at7V
                            p_at5r = code-0.1.0.0:Genome.FixedList.Functions.double g_at5q
                            (g_at5q, gpart_at7V) = Genome.Split.split genome_at6M
                          in
                            \ desc_at6N
                              -> case desc_at6N of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5r)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5t)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5v)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5x)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5z)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5B)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5J)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5L)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5N)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5P)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5R)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5T)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5V)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5X)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Z)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at61)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at63)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at65)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at67)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at69)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6b)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6d)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6f)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6h)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6j)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6l)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6n)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6p)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6r)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6t)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6v)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6x)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6z)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6B)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6D)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6F)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6H)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6J)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6L)
                                   _ -> Nothing }}
