src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24Kw
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Lc
                      p_a24Kv = double g_a24Ku
                      (g_a24Ku, gpart_a24Lc) = Genome.Split.split gpart_a24Lb
                      p_a24Kt = double g_a24Ks
                      (g_a24Ks, gpart_a24Lb) = Genome.Split.split gpart_a24La
                      p_a24Kr = double g_a24Kq
                      (g_a24Kq, gpart_a24La) = Genome.Split.split gpart_a24L9
                      p_a24Kp = double g_a24Ko
                      (g_a24Ko, gpart_a24L9) = Genome.Split.split gpart_a24L8
                      p_a24Kn = double g_a24Km
                      (g_a24Km, gpart_a24L8) = Genome.Split.split gpart_a24L7
                      p_a24Kl = double g_a24Kk
                      (g_a24Kk, gpart_a24L7) = Genome.Split.split gpart_a24L6
                      p_a24Kj = Functions.belowten' g_a24Ki
                      (g_a24Ki, gpart_a24L6) = Genome.Split.split gpart_a24L5
                      p_a24Kh = double g_a24Kg
                      (g_a24Kg, gpart_a24L5) = Genome.Split.split gpart_a24L4
                      p_a24Kf = Functions.belowten' g_a24Ke
                      (g_a24Ke, gpart_a24L4) = Genome.Split.split gpart_a24L3
                      p_a24Kd = double g_a24Kc
                      (g_a24Kc, gpart_a24L3) = Genome.Split.split gpart_a24L2
                      p_a24Kb = double g_a24Ka
                      (g_a24Ka, gpart_a24L2) = Genome.Split.split gpart_a24L1
                      p_a24K9 = double g_a24K8
                      (g_a24K8, gpart_a24L1) = Genome.Split.split gpart_a24L0
                      p_a24K7 = Functions.belowten' g_a24K6
                      (g_a24K6, gpart_a24L0) = Genome.Split.split gpart_a24KZ
                      p_a24K5 = double g_a24K4
                      (g_a24K4, gpart_a24KZ) = Genome.Split.split gpart_a24KY
                      p_a24K3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24K2
                      (g_a24K2, gpart_a24KY) = Genome.Split.split gpart_a24KX
                      p_a24K1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24K0
                      (g_a24K0, gpart_a24KX) = Genome.Split.split gpart_a24KW
                      p_a24JZ = Functions.belowten' g_a24JY
                      (g_a24JY, gpart_a24KW) = Genome.Split.split gpart_a24KV
                      p_a24JX = double g_a24JW
                      (g_a24JW, gpart_a24KV) = Genome.Split.split gpart_a24KU
                      p_a24JV = double g_a24JU
                      (g_a24JU, gpart_a24KU) = Genome.Split.split gpart_a24KT
                      p_a24JT = double g_a24JS
                      (g_a24JS, gpart_a24KT) = Genome.Split.split gpart_a24KS
                      p_a24JR = Functions.belowten' g_a24JQ
                      (g_a24JQ, gpart_a24KS) = Genome.Split.split gpart_a24KR
                      p_a24JP = double g_a24JO
                      (g_a24JO, gpart_a24KR) = Genome.Split.split gpart_a24KQ
                      p_a24JN = Functions.belowten' g_a24JM
                      (g_a24JM, gpart_a24KQ) = Genome.Split.split gpart_a24KP
                      p_a24JL = double g_a24JK
                      (g_a24JK, gpart_a24KP) = Genome.Split.split gpart_a24KO
                      p_a24JJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JI
                      (g_a24JI, gpart_a24KO) = Genome.Split.split gpart_a24KN
                      p_a24JH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JG
                      (g_a24JG, gpart_a24KN) = Genome.Split.split gpart_a24KM
                      p_a24JF = double g_a24JE
                      (g_a24JE, gpart_a24KM) = Genome.Split.split gpart_a24KL
                      p_a24JD = Functions.belowten' g_a24JC
                      (g_a24JC, gpart_a24KL) = Genome.Split.split gpart_a24KK
                      p_a24JB = double g_a24JA
                      (g_a24JA, gpart_a24KK) = Genome.Split.split gpart_a24KJ
                      p_a24Jz = Functions.belowten' g_a24Jy
                      (g_a24Jy, gpart_a24KJ) = Genome.Split.split gpart_a24KI
                      p_a24Jx = double g_a24Jw
                      (g_a24Jw, gpart_a24KI) = Genome.Split.split gpart_a24KH
                      p_a24Jv = double g_a24Ju
                      (g_a24Ju, gpart_a24KH) = Genome.Split.split gpart_a24KG
                      p_a24Jt = Functions.belowten' g_a24Js
                      (g_a24Js, gpart_a24KG) = Genome.Split.split gpart_a24KF
                      p_a24Jr = double g_a24Jq
                      (g_a24Jq, gpart_a24KF) = Genome.Split.split gpart_a24KE
                      p_a24Jp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Jo
                      (g_a24Jo, gpart_a24KE) = Genome.Split.split gpart_a24KD
                      p_a24Jn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Jm
                      (g_a24Jm, gpart_a24KD) = Genome.Split.split gpart_a24KC
                      p_a24Jl = double g_a24Jk
                      (g_a24Jk, gpart_a24KC) = Genome.Split.split gpart_a24KB
                      p_a24Jj = double g_a24Ji
                      (g_a24Ji, gpart_a24KB) = Genome.Split.split gpart_a24KA
                      p_a24Jh = double g_a24Jg
                      (g_a24Jg, gpart_a24KA) = Genome.Split.split gpart_a24Kz
                      p_a24Jf = double g_a24Je
                      (g_a24Je, gpart_a24Kz) = Genome.Split.split gpart_a24Ky
                      p_a24Jd = double g_a24Jc
                      (g_a24Jc, gpart_a24Ky) = Genome.Split.split genome_a24Kw
                    in  \ x_a24Ld
                          -> let
                               c_PTB_a24Lg
                                 = ((Data.Fixed.Vector.toVector x_a24Ld) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Le
                                 = ((Data.Fixed.Vector.toVector x_a24Ld) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Lk
                                 = ((Data.Fixed.Vector.toVector x_a24Ld) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Lm
                                 = ((Data.Fixed.Vector.toVector x_a24Ld) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Ly
                                 = ((Data.Fixed.Vector.toVector x_a24Ld) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Jl / (1 + ((c_MiRs_a24Le / p_a24Jr) ** p_a24Jt)))
                                    + (negate (p_a24Kn * c_PTB_a24Lg))),
                                   ((p_a24Jv
                                     / (1
                                        + (((c_MiRs_a24Le / p_a24Jx) ** p_a24Jz)
                                           + ((c_PTB_a24Lg / p_a24JB) ** p_a24JD))))
                                    + (negate (p_a24Kp * c_NPTB_a24Lk))),
                                   ((p_a24JF
                                     * ((p_a24JT + ((p_a24Jh / p_a24JH) ** p_a24JJ))
                                        / (((1 + p_a24JT) + ((p_a24Jh / p_a24JH) ** p_a24JJ))
                                           + (((c_PTB_a24Lg / p_a24JL) ** p_a24JN)
                                              + ((c_RESTc_a24Lm / p_a24JP) ** p_a24JR)))))
                                    + (negate (p_a24Kr * c_MiRs_a24Le))),
                                   ((p_a24JV
                                     * ((p_a24K9 + ((c_PTB_a24Lg / p_a24JX) ** p_a24JZ))
                                        / (((1 + p_a24K9) + ((c_PTB_a24Lg / p_a24JX) ** p_a24JZ))
                                           + (((p_a24Jd / p_a24K1) ** p_a24K3)
                                              + ((c_MiRs_a24Le / p_a24K5) ** p_a24K7)))))
                                    + (negate (p_a24Kt * c_RESTc_a24Lm))),
                                   ((p_a24Kb
                                     * ((p_a24Kl + ((c_MiRs_a24Le / p_a24Kd) ** p_a24Kf))
                                        / (((1 + p_a24Kl) + ((c_MiRs_a24Le / p_a24Kd) ** p_a24Kf))
                                           + ((c_RESTc_a24Lm / p_a24Kh) ** p_a24Kj))))
                                    + (negate (p_a24Kv * c_EndoNeuroTFs_a24Ly)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504637",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504639",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504647",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504649",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504651",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504657",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504659",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504677",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504679",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Kw
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Md
                            p_a24Kv = double g_a24Ku
                            (g_a24Ku, gpart_a24Md) = Genome.Split.split gpart_a24Mc
                            p_a24Kt = double g_a24Ks
                            (g_a24Ks, gpart_a24Mc) = Genome.Split.split gpart_a24Mb
                            p_a24Kr = double g_a24Kq
                            (g_a24Kq, gpart_a24Mb) = Genome.Split.split gpart_a24Ma
                            p_a24Kp = double g_a24Ko
                            (g_a24Ko, gpart_a24Ma) = Genome.Split.split gpart_a24M9
                            p_a24Kn = double g_a24Km
                            (g_a24Km, gpart_a24M9) = Genome.Split.split gpart_a24M8
                            p_a24Kl = double g_a24Kk
                            (g_a24Kk, gpart_a24M8) = Genome.Split.split gpart_a24M7
                            p_a24Kj = Functions.belowten' g_a24Ki
                            (g_a24Ki, gpart_a24M7) = Genome.Split.split gpart_a24M6
                            p_a24Kh = double g_a24Kg
                            (g_a24Kg, gpart_a24M6) = Genome.Split.split gpart_a24M5
                            p_a24Kf = Functions.belowten' g_a24Ke
                            (g_a24Ke, gpart_a24M5) = Genome.Split.split gpart_a24M4
                            p_a24Kd = double g_a24Kc
                            (g_a24Kc, gpart_a24M4) = Genome.Split.split gpart_a24M3
                            p_a24Kb = double g_a24Ka
                            (g_a24Ka, gpart_a24M3) = Genome.Split.split gpart_a24M2
                            p_a24K9 = double g_a24K8
                            (g_a24K8, gpart_a24M2) = Genome.Split.split gpart_a24M1
                            p_a24K7 = Functions.belowten' g_a24K6
                            (g_a24K6, gpart_a24M1) = Genome.Split.split gpart_a24M0
                            p_a24K5 = double g_a24K4
                            (g_a24K4, gpart_a24M0) = Genome.Split.split gpart_a24LZ
                            p_a24K3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24K2
                            (g_a24K2, gpart_a24LZ) = Genome.Split.split gpart_a24LY
                            p_a24K1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24K0
                            (g_a24K0, gpart_a24LY) = Genome.Split.split gpart_a24LX
                            p_a24JZ = Functions.belowten' g_a24JY
                            (g_a24JY, gpart_a24LX) = Genome.Split.split gpart_a24LW
                            p_a24JX = double g_a24JW
                            (g_a24JW, gpart_a24LW) = Genome.Split.split gpart_a24LV
                            p_a24JV = double g_a24JU
                            (g_a24JU, gpart_a24LV) = Genome.Split.split gpart_a24LU
                            p_a24JT = double g_a24JS
                            (g_a24JS, gpart_a24LU) = Genome.Split.split gpart_a24LT
                            p_a24JR = Functions.belowten' g_a24JQ
                            (g_a24JQ, gpart_a24LT) = Genome.Split.split gpart_a24LS
                            p_a24JP = double g_a24JO
                            (g_a24JO, gpart_a24LS) = Genome.Split.split gpart_a24LR
                            p_a24JN = Functions.belowten' g_a24JM
                            (g_a24JM, gpart_a24LR) = Genome.Split.split gpart_a24LQ
                            p_a24JL = double g_a24JK
                            (g_a24JK, gpart_a24LQ) = Genome.Split.split gpart_a24LP
                            p_a24JJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JI
                            (g_a24JI, gpart_a24LP) = Genome.Split.split gpart_a24LO
                            p_a24JH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JG
                            (g_a24JG, gpart_a24LO) = Genome.Split.split gpart_a24LN
                            p_a24JF = double g_a24JE
                            (g_a24JE, gpart_a24LN) = Genome.Split.split gpart_a24LM
                            p_a24JD = Functions.belowten' g_a24JC
                            (g_a24JC, gpart_a24LM) = Genome.Split.split gpart_a24LL
                            p_a24JB = double g_a24JA
                            (g_a24JA, gpart_a24LL) = Genome.Split.split gpart_a24LK
                            p_a24Jz = Functions.belowten' g_a24Jy
                            (g_a24Jy, gpart_a24LK) = Genome.Split.split gpart_a24LJ
                            p_a24Jx = double g_a24Jw
                            (g_a24Jw, gpart_a24LJ) = Genome.Split.split gpart_a24LI
                            p_a24Jv = double g_a24Ju
                            (g_a24Ju, gpart_a24LI) = Genome.Split.split gpart_a24LH
                            p_a24Jt = Functions.belowten' g_a24Js
                            (g_a24Js, gpart_a24LH) = Genome.Split.split gpart_a24LG
                            p_a24Jr = double g_a24Jq
                            (g_a24Jq, gpart_a24LG) = Genome.Split.split gpart_a24LF
                            p_a24Jp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Jo
                            (g_a24Jo, gpart_a24LF) = Genome.Split.split gpart_a24LE
                            p_a24Jn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Jm
                            (g_a24Jm, gpart_a24LE) = Genome.Split.split gpart_a24LD
                            p_a24Jl = double g_a24Jk
                            (g_a24Jk, gpart_a24LD) = Genome.Split.split gpart_a24LC
                            p_a24Jj = double g_a24Ji
                            (g_a24Ji, gpart_a24LC) = Genome.Split.split gpart_a24LB
                            p_a24Jh = double g_a24Jg
                            (g_a24Jg, gpart_a24LB) = Genome.Split.split gpart_a24LA
                            p_a24Jf = double g_a24Je
                            (g_a24Je, gpart_a24LA) = Genome.Split.split gpart_a24Lz
                            p_a24Jd = double g_a24Jc
                            (g_a24Jc, gpart_a24Lz) = Genome.Split.split genome_a24Kw
                          in
                            \ desc_a24Kx
                              -> case desc_a24Kx of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jd)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jf)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jh)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jj)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jl)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jn)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jp)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jr)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jt)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jv)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jx)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jz)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JB)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JD)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JF)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JH)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JJ)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JL)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JN)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JP)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JR)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JT)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JV)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JX)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JZ)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K1)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K3)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K5)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K7)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K9)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kb)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kd)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kf)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kh)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kj)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kl)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kn)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kp)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kr)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kt)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kv)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24OH
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Pn
                      p_a24OG = double g_a24OF
                      (g_a24OF, gpart_a24Pn) = Genome.Split.split gpart_a24Pm
                      p_a24OE = double g_a24OD
                      (g_a24OD, gpart_a24Pm) = Genome.Split.split gpart_a24Pl
                      p_a24OC = double g_a24OB
                      (g_a24OB, gpart_a24Pl) = Genome.Split.split gpart_a24Pk
                      p_a24OA = double g_a24Oz
                      (g_a24Oz, gpart_a24Pk) = Genome.Split.split gpart_a24Pj
                      p_a24Oy = double g_a24Ox
                      (g_a24Ox, gpart_a24Pj) = Genome.Split.split gpart_a24Pi
                      p_a24Ow = double g_a24Ov
                      (g_a24Ov, gpart_a24Pi) = Genome.Split.split gpart_a24Ph
                      p_a24Ou = Functions.belowten' g_a24Ot
                      (g_a24Ot, gpart_a24Ph) = Genome.Split.split gpart_a24Pg
                      p_a24Os = double g_a24Or
                      (g_a24Or, gpart_a24Pg) = Genome.Split.split gpart_a24Pf
                      p_a24Oq = Functions.belowten' g_a24Op
                      (g_a24Op, gpart_a24Pf) = Genome.Split.split gpart_a24Pe
                      p_a24Oo = double g_a24On
                      (g_a24On, gpart_a24Pe) = Genome.Split.split gpart_a24Pd
                      p_a24Om = double g_a24Ol
                      (g_a24Ol, gpart_a24Pd) = Genome.Split.split gpart_a24Pc
                      p_a24Ok = double g_a24Oj
                      (g_a24Oj, gpart_a24Pc) = Genome.Split.split gpart_a24Pb
                      p_a24Oi = Functions.belowten' g_a24Oh
                      (g_a24Oh, gpart_a24Pb) = Genome.Split.split gpart_a24Pa
                      p_a24Og = double g_a24Of
                      (g_a24Of, gpart_a24Pa) = Genome.Split.split gpart_a24P9
                      p_a24Oe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Od
                      (g_a24Od, gpart_a24P9) = Genome.Split.split gpart_a24P8
                      p_a24Oc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ob
                      (g_a24Ob, gpart_a24P8) = Genome.Split.split gpart_a24P7
                      p_a24Oa = Functions.belowten' g_a24O9
                      (g_a24O9, gpart_a24P7) = Genome.Split.split gpart_a24P6
                      p_a24O8 = double g_a24O7
                      (g_a24O7, gpart_a24P6) = Genome.Split.split gpart_a24P5
                      p_a24O6 = double g_a24O5
                      (g_a24O5, gpart_a24P5) = Genome.Split.split gpart_a24P4
                      p_a24O4 = double g_a24O3
                      (g_a24O3, gpart_a24P4) = Genome.Split.split gpart_a24P3
                      p_a24O2 = Functions.belowten' g_a24O1
                      (g_a24O1, gpart_a24P3) = Genome.Split.split gpart_a24P2
                      p_a24O0 = double g_a24NZ
                      (g_a24NZ, gpart_a24P2) = Genome.Split.split gpart_a24P1
                      p_a24NY = Functions.belowten' g_a24NX
                      (g_a24NX, gpart_a24P1) = Genome.Split.split gpart_a24P0
                      p_a24NW = double g_a24NV
                      (g_a24NV, gpart_a24P0) = Genome.Split.split gpart_a24OZ
                      p_a24NU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NT
                      (g_a24NT, gpart_a24OZ) = Genome.Split.split gpart_a24OY
                      p_a24NS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NR
                      (g_a24NR, gpart_a24OY) = Genome.Split.split gpart_a24OX
                      p_a24NQ = double g_a24NP
                      (g_a24NP, gpart_a24OX) = Genome.Split.split gpart_a24OW
                      p_a24NO = Functions.belowten' g_a24NN
                      (g_a24NN, gpart_a24OW) = Genome.Split.split gpart_a24OV
                      p_a24NM = double g_a24NL
                      (g_a24NL, gpart_a24OV) = Genome.Split.split gpart_a24OU
                      p_a24NK = Functions.belowten' g_a24NJ
                      (g_a24NJ, gpart_a24OU) = Genome.Split.split gpart_a24OT
                      p_a24NI = double g_a24NH
                      (g_a24NH, gpart_a24OT) = Genome.Split.split gpart_a24OS
                      p_a24NG = double g_a24NF
                      (g_a24NF, gpart_a24OS) = Genome.Split.split gpart_a24OR
                      p_a24NE = Functions.belowten' g_a24ND
                      (g_a24ND, gpart_a24OR) = Genome.Split.split gpart_a24OQ
                      p_a24NC = double g_a24NB
                      (g_a24NB, gpart_a24OQ) = Genome.Split.split gpart_a24OP
                      p_a24NA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Nz
                      (g_a24Nz, gpart_a24OP) = Genome.Split.split gpart_a24OO
                      p_a24Ny
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Nx
                      (g_a24Nx, gpart_a24OO) = Genome.Split.split gpart_a24ON
                      p_a24Nw = double g_a24Nv
                      (g_a24Nv, gpart_a24ON) = Genome.Split.split gpart_a24OM
                      p_a24Nu = double g_a24Nt
                      (g_a24Nt, gpart_a24OM) = Genome.Split.split gpart_a24OL
                      p_a24Ns = double g_a24Nr
                      (g_a24Nr, gpart_a24OL) = Genome.Split.split gpart_a24OK
                      p_a24Nq = double g_a24Np
                      (g_a24Np, gpart_a24OK) = Genome.Split.split gpart_a24OJ
                      p_a24No = double g_a24Nn
                      (g_a24Nn, gpart_a24OJ) = Genome.Split.split genome_a24OH
                    in  \ x_a24Po
                          -> let
                               c_PTB_a24Pr
                                 = ((Data.Fixed.Vector.toVector x_a24Po) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Pp
                                 = ((Data.Fixed.Vector.toVector x_a24Po) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Pv
                                 = ((Data.Fixed.Vector.toVector x_a24Po) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Px
                                 = ((Data.Fixed.Vector.toVector x_a24Po) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24PJ
                                 = ((Data.Fixed.Vector.toVector x_a24Po) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Nw / (1 + ((c_MiRs_a24Pp / p_a24NC) ** p_a24NE)))
                                    + (negate (p_a24Oy * c_PTB_a24Pr))),
                                   ((p_a24NG
                                     / (1
                                        + (((c_MiRs_a24Pp / p_a24NI) ** p_a24NK)
                                           + ((c_PTB_a24Pr / p_a24NM) ** p_a24NO))))
                                    + (negate (p_a24OA * c_NPTB_a24Pv))),
                                   ((p_a24NQ
                                     * (p_a24O4
                                        / ((1 + p_a24O4)
                                           + (((c_PTB_a24Pr / p_a24NW) ** p_a24NY)
                                              + ((c_RESTc_a24Px / p_a24O0) ** p_a24O2)))))
                                    + (negate (p_a24OC * c_MiRs_a24Pp))),
                                   ((p_a24O6
                                     * ((p_a24Ok + ((c_PTB_a24Pr / p_a24O8) ** p_a24Oa))
                                        / (((1 + p_a24Ok) + ((c_PTB_a24Pr / p_a24O8) ** p_a24Oa))
                                           + (((p_a24No / p_a24Oc) ** p_a24Oe)
                                              + ((c_MiRs_a24Pp / p_a24Og) ** p_a24Oi)))))
                                    + (negate (p_a24OE * c_RESTc_a24Px))),
                                   ((p_a24Om
                                     * ((p_a24Ow + ((c_MiRs_a24Pp / p_a24Oo) ** p_a24Oq))
                                        / (((1 + p_a24Ow) + ((c_MiRs_a24Pp / p_a24Oo) ** p_a24Oq))
                                           + ((c_RESTc_a24Px / p_a24Os) ** p_a24Ou))))
                                    + (negate (p_a24OG * c_EndoNeuroTFs_a24PJ)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504896",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504898",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504916",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504918",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504936",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504938",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24OH
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Qo
                            p_a24OG = double g_a24OF
                            (g_a24OF, gpart_a24Qo) = Genome.Split.split gpart_a24Qn
                            p_a24OE = double g_a24OD
                            (g_a24OD, gpart_a24Qn) = Genome.Split.split gpart_a24Qm
                            p_a24OC = double g_a24OB
                            (g_a24OB, gpart_a24Qm) = Genome.Split.split gpart_a24Ql
                            p_a24OA = double g_a24Oz
                            (g_a24Oz, gpart_a24Ql) = Genome.Split.split gpart_a24Qk
                            p_a24Oy = double g_a24Ox
                            (g_a24Ox, gpart_a24Qk) = Genome.Split.split gpart_a24Qj
                            p_a24Ow = double g_a24Ov
                            (g_a24Ov, gpart_a24Qj) = Genome.Split.split gpart_a24Qi
                            p_a24Ou = Functions.belowten' g_a24Ot
                            (g_a24Ot, gpart_a24Qi) = Genome.Split.split gpart_a24Qh
                            p_a24Os = double g_a24Or
                            (g_a24Or, gpart_a24Qh) = Genome.Split.split gpart_a24Qg
                            p_a24Oq = Functions.belowten' g_a24Op
                            (g_a24Op, gpart_a24Qg) = Genome.Split.split gpart_a24Qf
                            p_a24Oo = double g_a24On
                            (g_a24On, gpart_a24Qf) = Genome.Split.split gpart_a24Qe
                            p_a24Om = double g_a24Ol
                            (g_a24Ol, gpart_a24Qe) = Genome.Split.split gpart_a24Qd
                            p_a24Ok = double g_a24Oj
                            (g_a24Oj, gpart_a24Qd) = Genome.Split.split gpart_a24Qc
                            p_a24Oi = Functions.belowten' g_a24Oh
                            (g_a24Oh, gpart_a24Qc) = Genome.Split.split gpart_a24Qb
                            p_a24Og = double g_a24Of
                            (g_a24Of, gpart_a24Qb) = Genome.Split.split gpart_a24Qa
                            p_a24Oe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Od
                            (g_a24Od, gpart_a24Qa) = Genome.Split.split gpart_a24Q9
                            p_a24Oc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ob
                            (g_a24Ob, gpart_a24Q9) = Genome.Split.split gpart_a24Q8
                            p_a24Oa = Functions.belowten' g_a24O9
                            (g_a24O9, gpart_a24Q8) = Genome.Split.split gpart_a24Q7
                            p_a24O8 = double g_a24O7
                            (g_a24O7, gpart_a24Q7) = Genome.Split.split gpart_a24Q6
                            p_a24O6 = double g_a24O5
                            (g_a24O5, gpart_a24Q6) = Genome.Split.split gpart_a24Q5
                            p_a24O4 = double g_a24O3
                            (g_a24O3, gpart_a24Q5) = Genome.Split.split gpart_a24Q4
                            p_a24O2 = Functions.belowten' g_a24O1
                            (g_a24O1, gpart_a24Q4) = Genome.Split.split gpart_a24Q3
                            p_a24O0 = double g_a24NZ
                            (g_a24NZ, gpart_a24Q3) = Genome.Split.split gpart_a24Q2
                            p_a24NY = Functions.belowten' g_a24NX
                            (g_a24NX, gpart_a24Q2) = Genome.Split.split gpart_a24Q1
                            p_a24NW = double g_a24NV
                            (g_a24NV, gpart_a24Q1) = Genome.Split.split gpart_a24Q0
                            p_a24NU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NT
                            (g_a24NT, gpart_a24Q0) = Genome.Split.split gpart_a24PZ
                            p_a24NS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NR
                            (g_a24NR, gpart_a24PZ) = Genome.Split.split gpart_a24PY
                            p_a24NQ = double g_a24NP
                            (g_a24NP, gpart_a24PY) = Genome.Split.split gpart_a24PX
                            p_a24NO = Functions.belowten' g_a24NN
                            (g_a24NN, gpart_a24PX) = Genome.Split.split gpart_a24PW
                            p_a24NM = double g_a24NL
                            (g_a24NL, gpart_a24PW) = Genome.Split.split gpart_a24PV
                            p_a24NK = Functions.belowten' g_a24NJ
                            (g_a24NJ, gpart_a24PV) = Genome.Split.split gpart_a24PU
                            p_a24NI = double g_a24NH
                            (g_a24NH, gpart_a24PU) = Genome.Split.split gpart_a24PT
                            p_a24NG = double g_a24NF
                            (g_a24NF, gpart_a24PT) = Genome.Split.split gpart_a24PS
                            p_a24NE = Functions.belowten' g_a24ND
                            (g_a24ND, gpart_a24PS) = Genome.Split.split gpart_a24PR
                            p_a24NC = double g_a24NB
                            (g_a24NB, gpart_a24PR) = Genome.Split.split gpart_a24PQ
                            p_a24NA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Nz
                            (g_a24Nz, gpart_a24PQ) = Genome.Split.split gpart_a24PP
                            p_a24Ny
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Nx
                            (g_a24Nx, gpart_a24PP) = Genome.Split.split gpart_a24PO
                            p_a24Nw = double g_a24Nv
                            (g_a24Nv, gpart_a24PO) = Genome.Split.split gpart_a24PN
                            p_a24Nu = double g_a24Nt
                            (g_a24Nt, gpart_a24PN) = Genome.Split.split gpart_a24PM
                            p_a24Ns = double g_a24Nr
                            (g_a24Nr, gpart_a24PM) = Genome.Split.split gpart_a24PL
                            p_a24Nq = double g_a24Np
                            (g_a24Np, gpart_a24PL) = Genome.Split.split gpart_a24PK
                            p_a24No = double g_a24Nn
                            (g_a24Nn, gpart_a24PK) = Genome.Split.split genome_a24OH
                          in
                            \ desc_a24OI
                              -> case desc_a24OI of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24No)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Nq)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ns)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Nu)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Nw)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ny)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NA)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NC)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NE)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NG)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NI)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NK)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NM)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NO)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NQ)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NS)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NU)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NW)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NY)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O0)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O2)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O4)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O6)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O8)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oa)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oc)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oe)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Og)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oi)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ok)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Om)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oo)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oq)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Os)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ou)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ow)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oy)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OA)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OC)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OE)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OG)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24SS
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Ty
                      p_a24SR = double g_a24SQ
                      (g_a24SQ, gpart_a24Ty) = Genome.Split.split gpart_a24Tx
                      p_a24SP = double g_a24SO
                      (g_a24SO, gpart_a24Tx) = Genome.Split.split gpart_a24Tw
                      p_a24SN = double g_a24SM
                      (g_a24SM, gpart_a24Tw) = Genome.Split.split gpart_a24Tv
                      p_a24SL = double g_a24SK
                      (g_a24SK, gpart_a24Tv) = Genome.Split.split gpart_a24Tu
                      p_a24SJ = double g_a24SI
                      (g_a24SI, gpart_a24Tu) = Genome.Split.split gpart_a24Tt
                      p_a24SH = double g_a24SG
                      (g_a24SG, gpart_a24Tt) = Genome.Split.split gpart_a24Ts
                      p_a24SF = Functions.belowten' g_a24SE
                      (g_a24SE, gpart_a24Ts) = Genome.Split.split gpart_a24Tr
                      p_a24SD = double g_a24SC
                      (g_a24SC, gpart_a24Tr) = Genome.Split.split gpart_a24Tq
                      p_a24SB = Functions.belowten' g_a24SA
                      (g_a24SA, gpart_a24Tq) = Genome.Split.split gpart_a24Tp
                      p_a24Sz = double g_a24Sy
                      (g_a24Sy, gpart_a24Tp) = Genome.Split.split gpart_a24To
                      p_a24Sx = double g_a24Sw
                      (g_a24Sw, gpart_a24To) = Genome.Split.split gpart_a24Tn
                      p_a24Sv = double g_a24Su
                      (g_a24Su, gpart_a24Tn) = Genome.Split.split gpart_a24Tm
                      p_a24St = Functions.belowten' g_a24Ss
                      (g_a24Ss, gpart_a24Tm) = Genome.Split.split gpart_a24Tl
                      p_a24Sr = double g_a24Sq
                      (g_a24Sq, gpart_a24Tl) = Genome.Split.split gpart_a24Tk
                      p_a24Sp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24So
                      (g_a24So, gpart_a24Tk) = Genome.Split.split gpart_a24Tj
                      p_a24Sn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sm
                      (g_a24Sm, gpart_a24Tj) = Genome.Split.split gpart_a24Ti
                      p_a24Sl = Functions.belowten' g_a24Sk
                      (g_a24Sk, gpart_a24Ti) = Genome.Split.split gpart_a24Th
                      p_a24Sj = double g_a24Si
                      (g_a24Si, gpart_a24Th) = Genome.Split.split gpart_a24Tg
                      p_a24Sh = double g_a24Sg
                      (g_a24Sg, gpart_a24Tg) = Genome.Split.split gpart_a24Tf
                      p_a24Sf = double g_a24Se
                      (g_a24Se, gpart_a24Tf) = Genome.Split.split gpart_a24Te
                      p_a24Sd = Functions.belowten' g_a24Sc
                      (g_a24Sc, gpart_a24Te) = Genome.Split.split gpart_a24Td
                      p_a24Sb = double g_a24Sa
                      (g_a24Sa, gpart_a24Td) = Genome.Split.split gpart_a24Tc
                      p_a24S9 = Functions.belowten' g_a24S8
                      (g_a24S8, gpart_a24Tc) = Genome.Split.split gpart_a24Tb
                      p_a24S7 = double g_a24S6
                      (g_a24S6, gpart_a24Tb) = Genome.Split.split gpart_a24Ta
                      p_a24S5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S4
                      (g_a24S4, gpart_a24Ta) = Genome.Split.split gpart_a24T9
                      p_a24S3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S2
                      (g_a24S2, gpart_a24T9) = Genome.Split.split gpart_a24T8
                      p_a24S1 = double g_a24S0
                      (g_a24S0, gpart_a24T8) = Genome.Split.split gpart_a24T7
                      p_a24RZ = Functions.belowten' g_a24RY
                      (g_a24RY, gpart_a24T7) = Genome.Split.split gpart_a24T6
                      p_a24RX = double g_a24RW
                      (g_a24RW, gpart_a24T6) = Genome.Split.split gpart_a24T5
                      p_a24RV = Functions.belowten' g_a24RU
                      (g_a24RU, gpart_a24T5) = Genome.Split.split gpart_a24T4
                      p_a24RT = double g_a24RS
                      (g_a24RS, gpart_a24T4) = Genome.Split.split gpart_a24T3
                      p_a24RR = double g_a24RQ
                      (g_a24RQ, gpart_a24T3) = Genome.Split.split gpart_a24T2
                      p_a24RP = Functions.belowten' g_a24RO
                      (g_a24RO, gpart_a24T2) = Genome.Split.split gpart_a24T1
                      p_a24RN = double g_a24RM
                      (g_a24RM, gpart_a24T1) = Genome.Split.split gpart_a24T0
                      p_a24RL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RK
                      (g_a24RK, gpart_a24T0) = Genome.Split.split gpart_a24SZ
                      p_a24RJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RI
                      (g_a24RI, gpart_a24SZ) = Genome.Split.split gpart_a24SY
                      p_a24RH = double g_a24RG
                      (g_a24RG, gpart_a24SY) = Genome.Split.split gpart_a24SX
                      p_a24RF = double g_a24RE
                      (g_a24RE, gpart_a24SX) = Genome.Split.split gpart_a24SW
                      p_a24RD = double g_a24RC
                      (g_a24RC, gpart_a24SW) = Genome.Split.split gpart_a24SV
                      p_a24RB = double g_a24RA
                      (g_a24RA, gpart_a24SV) = Genome.Split.split gpart_a24SU
                      p_a24Rz = double g_a24Ry
                      (g_a24Ry, gpart_a24SU) = Genome.Split.split genome_a24SS
                    in  \ x_a24Tz
                          -> let
                               c_PTB_a24TC
                                 = ((Data.Fixed.Vector.toVector x_a24Tz) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24TA
                                 = ((Data.Fixed.Vector.toVector x_a24Tz) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24TG
                                 = ((Data.Fixed.Vector.toVector x_a24Tz) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24TI
                                 = ((Data.Fixed.Vector.toVector x_a24Tz) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24TU
                                 = ((Data.Fixed.Vector.toVector x_a24Tz) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24RH / (1 + ((c_MiRs_a24TA / p_a24RN) ** p_a24RP)))
                                    + (negate (p_a24SJ * c_PTB_a24TC))),
                                   ((p_a24RR
                                     / (1
                                        + (((c_MiRs_a24TA / p_a24RT) ** p_a24RV)
                                           + ((c_PTB_a24TC / p_a24RX) ** p_a24RZ))))
                                    + (negate (p_a24SL * c_NPTB_a24TG))),
                                   ((p_a24S1
                                     * (p_a24Sf
                                        / ((1 + p_a24Sf)
                                           + (((c_PTB_a24TC / p_a24S7) ** p_a24S9)
                                              + ((c_RESTc_a24TI / p_a24Sb) ** p_a24Sd)))))
                                    + (negate (p_a24SN * c_MiRs_a24TA))),
                                   ((p_a24Sh
                                     * ((p_a24Sv + ((c_PTB_a24TC / p_a24Sj) ** p_a24Sl))
                                        / (((1 + p_a24Sv) + ((c_PTB_a24TC / p_a24Sj) ** p_a24Sl))
                                           + ((c_MiRs_a24TA / p_a24Sr) ** p_a24St))))
                                    + (negate (p_a24SP * c_RESTc_a24TI))),
                                   ((p_a24Sx
                                     * ((p_a24SH + ((c_MiRs_a24TA / p_a24Sz) ** p_a24SB))
                                        / (((1 + p_a24SH) + ((c_MiRs_a24TA / p_a24Sz) ** p_a24SB))
                                           + ((c_RESTc_a24TI / p_a24SD) ** p_a24SF))))
                                    + (negate (p_a24SR * c_EndoNeuroTFs_a24TU)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505155",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505157",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505175",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505177",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505195",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505197",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24SS
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Uz
                            p_a24SR = double g_a24SQ
                            (g_a24SQ, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                            p_a24SP = double g_a24SO
                            (g_a24SO, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                            p_a24SN = double g_a24SM
                            (g_a24SM, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                            p_a24SL = double g_a24SK
                            (g_a24SK, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                            p_a24SJ = double g_a24SI
                            (g_a24SI, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                            p_a24SH = double g_a24SG
                            (g_a24SG, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                            p_a24SF = Functions.belowten' g_a24SE
                            (g_a24SE, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                            p_a24SD = double g_a24SC
                            (g_a24SC, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                            p_a24SB = Functions.belowten' g_a24SA
                            (g_a24SA, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                            p_a24Sz = double g_a24Sy
                            (g_a24Sy, gpart_a24Uq) = Genome.Split.split gpart_a24Up
                            p_a24Sx = double g_a24Sw
                            (g_a24Sw, gpart_a24Up) = Genome.Split.split gpart_a24Uo
                            p_a24Sv = double g_a24Su
                            (g_a24Su, gpart_a24Uo) = Genome.Split.split gpart_a24Un
                            p_a24St = Functions.belowten' g_a24Ss
                            (g_a24Ss, gpart_a24Un) = Genome.Split.split gpart_a24Um
                            p_a24Sr = double g_a24Sq
                            (g_a24Sq, gpart_a24Um) = Genome.Split.split gpart_a24Ul
                            p_a24Sp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24So
                            (g_a24So, gpart_a24Ul) = Genome.Split.split gpart_a24Uk
                            p_a24Sn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sm
                            (g_a24Sm, gpart_a24Uk) = Genome.Split.split gpart_a24Uj
                            p_a24Sl = Functions.belowten' g_a24Sk
                            (g_a24Sk, gpart_a24Uj) = Genome.Split.split gpart_a24Ui
                            p_a24Sj = double g_a24Si
                            (g_a24Si, gpart_a24Ui) = Genome.Split.split gpart_a24Uh
                            p_a24Sh = double g_a24Sg
                            (g_a24Sg, gpart_a24Uh) = Genome.Split.split gpart_a24Ug
                            p_a24Sf = double g_a24Se
                            (g_a24Se, gpart_a24Ug) = Genome.Split.split gpart_a24Uf
                            p_a24Sd = Functions.belowten' g_a24Sc
                            (g_a24Sc, gpart_a24Uf) = Genome.Split.split gpart_a24Ue
                            p_a24Sb = double g_a24Sa
                            (g_a24Sa, gpart_a24Ue) = Genome.Split.split gpart_a24Ud
                            p_a24S9 = Functions.belowten' g_a24S8
                            (g_a24S8, gpart_a24Ud) = Genome.Split.split gpart_a24Uc
                            p_a24S7 = double g_a24S6
                            (g_a24S6, gpart_a24Uc) = Genome.Split.split gpart_a24Ub
                            p_a24S5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S4
                            (g_a24S4, gpart_a24Ub) = Genome.Split.split gpart_a24Ua
                            p_a24S3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S2
                            (g_a24S2, gpart_a24Ua) = Genome.Split.split gpart_a24U9
                            p_a24S1 = double g_a24S0
                            (g_a24S0, gpart_a24U9) = Genome.Split.split gpart_a24U8
                            p_a24RZ = Functions.belowten' g_a24RY
                            (g_a24RY, gpart_a24U8) = Genome.Split.split gpart_a24U7
                            p_a24RX = double g_a24RW
                            (g_a24RW, gpart_a24U7) = Genome.Split.split gpart_a24U6
                            p_a24RV = Functions.belowten' g_a24RU
                            (g_a24RU, gpart_a24U6) = Genome.Split.split gpart_a24U5
                            p_a24RT = double g_a24RS
                            (g_a24RS, gpart_a24U5) = Genome.Split.split gpart_a24U4
                            p_a24RR = double g_a24RQ
                            (g_a24RQ, gpart_a24U4) = Genome.Split.split gpart_a24U3
                            p_a24RP = Functions.belowten' g_a24RO
                            (g_a24RO, gpart_a24U3) = Genome.Split.split gpart_a24U2
                            p_a24RN = double g_a24RM
                            (g_a24RM, gpart_a24U2) = Genome.Split.split gpart_a24U1
                            p_a24RL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RK
                            (g_a24RK, gpart_a24U1) = Genome.Split.split gpart_a24U0
                            p_a24RJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RI
                            (g_a24RI, gpart_a24U0) = Genome.Split.split gpart_a24TZ
                            p_a24RH = double g_a24RG
                            (g_a24RG, gpart_a24TZ) = Genome.Split.split gpart_a24TY
                            p_a24RF = double g_a24RE
                            (g_a24RE, gpart_a24TY) = Genome.Split.split gpart_a24TX
                            p_a24RD = double g_a24RC
                            (g_a24RC, gpart_a24TX) = Genome.Split.split gpart_a24TW
                            p_a24RB = double g_a24RA
                            (g_a24RA, gpart_a24TW) = Genome.Split.split gpart_a24TV
                            p_a24Rz = double g_a24Ry
                            (g_a24Ry, gpart_a24TV) = Genome.Split.split genome_a24SS
                          in
                            \ desc_a24ST
                              -> case desc_a24ST of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rz)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RB)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RD)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RF)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RH)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RJ)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RL)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RN)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RP)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RR)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RT)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RV)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RX)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RZ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S1)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S3)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S5)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S7)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S9)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sb)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sd)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sf)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sh)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sj)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sl)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sn)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sp)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sr)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24St)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sv)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sx)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sz)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SB)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SD)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SF)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SH)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SJ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SL)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SN)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SP)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SR)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a24X3
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24XJ
                      p_a24X2 = double g_a24X1
                      (g_a24X1, gpart_a24XJ) = Genome.Split.split gpart_a24XI
                      p_a24X0 = double g_a24WZ
                      (g_a24WZ, gpart_a24XI) = Genome.Split.split gpart_a24XH
                      p_a24WY = double g_a24WX
                      (g_a24WX, gpart_a24XH) = Genome.Split.split gpart_a24XG
                      p_a24WW = double g_a24WV
                      (g_a24WV, gpart_a24XG) = Genome.Split.split gpart_a24XF
                      p_a24WU = double g_a24WT
                      (g_a24WT, gpart_a24XF) = Genome.Split.split gpart_a24XE
                      p_a24WS = double g_a24WR
                      (g_a24WR, gpart_a24XE) = Genome.Split.split gpart_a24XD
                      p_a24WQ = Functions.belowten' g_a24WP
                      (g_a24WP, gpart_a24XD) = Genome.Split.split gpart_a24XC
                      p_a24WO = double g_a24WN
                      (g_a24WN, gpart_a24XC) = Genome.Split.split gpart_a24XB
                      p_a24WM = Functions.belowten' g_a24WL
                      (g_a24WL, gpart_a24XB) = Genome.Split.split gpart_a24XA
                      p_a24WK = double g_a24WJ
                      (g_a24WJ, gpart_a24XA) = Genome.Split.split gpart_a24Xz
                      p_a24WI = double g_a24WH
                      (g_a24WH, gpart_a24Xz) = Genome.Split.split gpart_a24Xy
                      p_a24WG = double g_a24WF
                      (g_a24WF, gpart_a24Xy) = Genome.Split.split gpart_a24Xx
                      p_a24WE = Functions.belowten' g_a24WD
                      (g_a24WD, gpart_a24Xx) = Genome.Split.split gpart_a24Xw
                      p_a24WC = double g_a24WB
                      (g_a24WB, gpart_a24Xw) = Genome.Split.split gpart_a24Xv
                      p_a24WA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wz
                      (g_a24Wz, gpart_a24Xv) = Genome.Split.split gpart_a24Xu
                      p_a24Wy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wx
                      (g_a24Wx, gpart_a24Xu) = Genome.Split.split gpart_a24Xt
                      p_a24Ww = Functions.belowten' g_a24Wv
                      (g_a24Wv, gpart_a24Xt) = Genome.Split.split gpart_a24Xs
                      p_a24Wu = double g_a24Wt
                      (g_a24Wt, gpart_a24Xs) = Genome.Split.split gpart_a24Xr
                      p_a24Ws = double g_a24Wr
                      (g_a24Wr, gpart_a24Xr) = Genome.Split.split gpart_a24Xq
                      p_a24Wq = double g_a24Wp
                      (g_a24Wp, gpart_a24Xq) = Genome.Split.split gpart_a24Xp
                      p_a24Wo = Functions.belowten' g_a24Wn
                      (g_a24Wn, gpart_a24Xp) = Genome.Split.split gpart_a24Xo
                      p_a24Wm = double g_a24Wl
                      (g_a24Wl, gpart_a24Xo) = Genome.Split.split gpart_a24Xn
                      p_a24Wk = Functions.belowten' g_a24Wj
                      (g_a24Wj, gpart_a24Xn) = Genome.Split.split gpart_a24Xm
                      p_a24Wi = double g_a24Wh
                      (g_a24Wh, gpart_a24Xm) = Genome.Split.split gpart_a24Xl
                      p_a24Wg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wf
                      (g_a24Wf, gpart_a24Xl) = Genome.Split.split gpart_a24Xk
                      p_a24We
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wd
                      (g_a24Wd, gpart_a24Xk) = Genome.Split.split gpart_a24Xj
                      p_a24Wc = double g_a24Wb
                      (g_a24Wb, gpart_a24Xj) = Genome.Split.split gpart_a24Xi
                      p_a24Wa = Functions.belowten' g_a24W9
                      (g_a24W9, gpart_a24Xi) = Genome.Split.split gpart_a24Xh
                      p_a24W8 = double g_a24W7
                      (g_a24W7, gpart_a24Xh) = Genome.Split.split gpart_a24Xg
                      p_a24W6 = Functions.belowten' g_a24W5
                      (g_a24W5, gpart_a24Xg) = Genome.Split.split gpart_a24Xf
                      p_a24W4 = double g_a24W3
                      (g_a24W3, gpart_a24Xf) = Genome.Split.split gpart_a24Xe
                      p_a24W2 = double g_a24W1
                      (g_a24W1, gpart_a24Xe) = Genome.Split.split gpart_a24Xd
                      p_a24W0 = Functions.belowten' g_a24VZ
                      (g_a24VZ, gpart_a24Xd) = Genome.Split.split gpart_a24Xc
                      p_a24VY = double g_a24VX
                      (g_a24VX, gpart_a24Xc) = Genome.Split.split gpart_a24Xb
                      p_a24VW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VV
                      (g_a24VV, gpart_a24Xb) = Genome.Split.split gpart_a24Xa
                      p_a24VU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VT
                      (g_a24VT, gpart_a24Xa) = Genome.Split.split gpart_a24X9
                      p_a24VS = double g_a24VR
                      (g_a24VR, gpart_a24X9) = Genome.Split.split gpart_a24X8
                      p_a24VQ = double g_a24VP
                      (g_a24VP, gpart_a24X8) = Genome.Split.split gpart_a24X7
                      p_a24VO = double g_a24VN
                      (g_a24VN, gpart_a24X7) = Genome.Split.split gpart_a24X6
                      p_a24VM = double g_a24VL
                      (g_a24VL, gpart_a24X6) = Genome.Split.split gpart_a24X5
                      p_a24VK = double g_a24VJ
                      (g_a24VJ, gpart_a24X5) = Genome.Split.split genome_a24X3
                    in  \ x_a24XK
                          -> let
                               c_PTB_a24XN
                                 = ((Data.Fixed.Vector.toVector x_a24XK) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24XL
                                 = ((Data.Fixed.Vector.toVector x_a24XK) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24XR
                                 = ((Data.Fixed.Vector.toVector x_a24XK) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24XT
                                 = ((Data.Fixed.Vector.toVector x_a24XK) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Y5
                                 = ((Data.Fixed.Vector.toVector x_a24XK) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24VS
                                     / (1
                                        + (((p_a24VK / p_a24VU) ** p_a24VW)
                                           + ((c_MiRs_a24XL / p_a24VY) ** p_a24W0))))
                                    + (negate (p_a24WU * c_PTB_a24XN))),
                                   ((p_a24W2
                                     / (1
                                        + (((c_MiRs_a24XL / p_a24W4) ** p_a24W6)
                                           + ((c_PTB_a24XN / p_a24W8) ** p_a24Wa))))
                                    + (negate (p_a24WW * c_NPTB_a24XR))),
                                   ((p_a24Wc
                                     * (p_a24Wq
                                        / ((1 + p_a24Wq)
                                           + (((c_PTB_a24XN / p_a24Wi) ** p_a24Wk)
                                              + ((c_RESTc_a24XT / p_a24Wm) ** p_a24Wo)))))
                                    + (negate (p_a24WY * c_MiRs_a24XL))),
                                   ((p_a24Ws
                                     * ((p_a24WG + ((c_PTB_a24XN / p_a24Wu) ** p_a24Ww))
                                        / (((1 + p_a24WG) + ((c_PTB_a24XN / p_a24Wu) ** p_a24Ww))
                                           + ((c_MiRs_a24XL / p_a24WC) ** p_a24WE))))
                                    + (negate (p_a24X0 * c_RESTc_a24XT))),
                                   ((p_a24WI
                                     * ((p_a24WS + ((c_MiRs_a24XL / p_a24WK) ** p_a24WM))
                                        / (((1 + p_a24WS) + ((c_MiRs_a24XL / p_a24WK) ** p_a24WM))
                                           + ((c_RESTc_a24XT / p_a24WO) ** p_a24WQ))))
                                    + (negate (p_a24X2 * c_EndoNeuroTFs_a24Y5)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505414",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505416",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505434",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505436",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505454",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505456",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24X3
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24YK
                            p_a24X2 = double g_a24X1
                            (g_a24X1, gpart_a24YK) = Genome.Split.split gpart_a24YJ
                            p_a24X0 = double g_a24WZ
                            (g_a24WZ, gpart_a24YJ) = Genome.Split.split gpart_a24YI
                            p_a24WY = double g_a24WX
                            (g_a24WX, gpart_a24YI) = Genome.Split.split gpart_a24YH
                            p_a24WW = double g_a24WV
                            (g_a24WV, gpart_a24YH) = Genome.Split.split gpart_a24YG
                            p_a24WU = double g_a24WT
                            (g_a24WT, gpart_a24YG) = Genome.Split.split gpart_a24YF
                            p_a24WS = double g_a24WR
                            (g_a24WR, gpart_a24YF) = Genome.Split.split gpart_a24YE
                            p_a24WQ = Functions.belowten' g_a24WP
                            (g_a24WP, gpart_a24YE) = Genome.Split.split gpart_a24YD
                            p_a24WO = double g_a24WN
                            (g_a24WN, gpart_a24YD) = Genome.Split.split gpart_a24YC
                            p_a24WM = Functions.belowten' g_a24WL
                            (g_a24WL, gpart_a24YC) = Genome.Split.split gpart_a24YB
                            p_a24WK = double g_a24WJ
                            (g_a24WJ, gpart_a24YB) = Genome.Split.split gpart_a24YA
                            p_a24WI = double g_a24WH
                            (g_a24WH, gpart_a24YA) = Genome.Split.split gpart_a24Yz
                            p_a24WG = double g_a24WF
                            (g_a24WF, gpart_a24Yz) = Genome.Split.split gpart_a24Yy
                            p_a24WE = Functions.belowten' g_a24WD
                            (g_a24WD, gpart_a24Yy) = Genome.Split.split gpart_a24Yx
                            p_a24WC = double g_a24WB
                            (g_a24WB, gpart_a24Yx) = Genome.Split.split gpart_a24Yw
                            p_a24WA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wz
                            (g_a24Wz, gpart_a24Yw) = Genome.Split.split gpart_a24Yv
                            p_a24Wy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wx
                            (g_a24Wx, gpart_a24Yv) = Genome.Split.split gpart_a24Yu
                            p_a24Ww = Functions.belowten' g_a24Wv
                            (g_a24Wv, gpart_a24Yu) = Genome.Split.split gpart_a24Yt
                            p_a24Wu = double g_a24Wt
                            (g_a24Wt, gpart_a24Yt) = Genome.Split.split gpart_a24Ys
                            p_a24Ws = double g_a24Wr
                            (g_a24Wr, gpart_a24Ys) = Genome.Split.split gpart_a24Yr
                            p_a24Wq = double g_a24Wp
                            (g_a24Wp, gpart_a24Yr) = Genome.Split.split gpart_a24Yq
                            p_a24Wo = Functions.belowten' g_a24Wn
                            (g_a24Wn, gpart_a24Yq) = Genome.Split.split gpart_a24Yp
                            p_a24Wm = double g_a24Wl
                            (g_a24Wl, gpart_a24Yp) = Genome.Split.split gpart_a24Yo
                            p_a24Wk = Functions.belowten' g_a24Wj
                            (g_a24Wj, gpart_a24Yo) = Genome.Split.split gpart_a24Yn
                            p_a24Wi = double g_a24Wh
                            (g_a24Wh, gpart_a24Yn) = Genome.Split.split gpart_a24Ym
                            p_a24Wg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wf
                            (g_a24Wf, gpart_a24Ym) = Genome.Split.split gpart_a24Yl
                            p_a24We
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wd
                            (g_a24Wd, gpart_a24Yl) = Genome.Split.split gpart_a24Yk
                            p_a24Wc = double g_a24Wb
                            (g_a24Wb, gpart_a24Yk) = Genome.Split.split gpart_a24Yj
                            p_a24Wa = Functions.belowten' g_a24W9
                            (g_a24W9, gpart_a24Yj) = Genome.Split.split gpart_a24Yi
                            p_a24W8 = double g_a24W7
                            (g_a24W7, gpart_a24Yi) = Genome.Split.split gpart_a24Yh
                            p_a24W6 = Functions.belowten' g_a24W5
                            (g_a24W5, gpart_a24Yh) = Genome.Split.split gpart_a24Yg
                            p_a24W4 = double g_a24W3
                            (g_a24W3, gpart_a24Yg) = Genome.Split.split gpart_a24Yf
                            p_a24W2 = double g_a24W1
                            (g_a24W1, gpart_a24Yf) = Genome.Split.split gpart_a24Ye
                            p_a24W0 = Functions.belowten' g_a24VZ
                            (g_a24VZ, gpart_a24Ye) = Genome.Split.split gpart_a24Yd
                            p_a24VY = double g_a24VX
                            (g_a24VX, gpart_a24Yd) = Genome.Split.split gpart_a24Yc
                            p_a24VW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VV
                            (g_a24VV, gpart_a24Yc) = Genome.Split.split gpart_a24Yb
                            p_a24VU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VT
                            (g_a24VT, gpart_a24Yb) = Genome.Split.split gpart_a24Ya
                            p_a24VS = double g_a24VR
                            (g_a24VR, gpart_a24Ya) = Genome.Split.split gpart_a24Y9
                            p_a24VQ = double g_a24VP
                            (g_a24VP, gpart_a24Y9) = Genome.Split.split gpart_a24Y8
                            p_a24VO = double g_a24VN
                            (g_a24VN, gpart_a24Y8) = Genome.Split.split gpart_a24Y7
                            p_a24VM = double g_a24VL
                            (g_a24VL, gpart_a24Y7) = Genome.Split.split gpart_a24Y6
                            p_a24VK = double g_a24VJ
                            (g_a24VJ, gpart_a24Y6) = Genome.Split.split genome_a24X3
                          in
                            \ desc_a24X4
                              -> case desc_a24X4 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VK)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VM)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VO)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VQ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VS)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VU)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VW)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VY)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W0)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W2)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W4)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W6)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W8)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wa)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wc)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24We)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wg)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wi)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wk)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wm)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wo)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wq)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ws)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wu)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ww)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wy)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WA)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WC)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WE)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WG)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WI)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WK)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WM)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WO)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WQ)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WS)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WU)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WW)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WY)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X0)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X2)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asV4
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVK
                      p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                      (g_asV2, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                      (g_asV0, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                      (g_asUY, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUX = code-0.1.0.0:Genome.FixedList.Functions.double g_asUW
                      (g_asUW, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                      (g_asUU, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                      (g_asUS, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUR = Functions.belowten' g_asUQ
                      (g_asUQ, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUP = code-0.1.0.0:Genome.FixedList.Functions.double g_asUO
                      (g_asUO, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUN = Functions.belowten' g_asUM
                      (g_asUM, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUL = code-0.1.0.0:Genome.FixedList.Functions.double g_asUK
                      (g_asUK, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUI
                      (g_asUI, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUH = code-0.1.0.0:Genome.FixedList.Functions.double g_asUG
                      (g_asUG, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUF = Functions.belowten' g_asUE
                      (g_asUE, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                      (g_asUC, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUA
                      (g_asUA, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asUz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUy
                      (g_asUy, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asUx = Functions.belowten' g_asUw
                      (g_asUw, gpart_asVu) = Genome.Split.split gpart_asVt
                      p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                      (g_asUu, gpart_asVt) = Genome.Split.split gpart_asVs
                      p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                      (g_asUs, gpart_asVs) = Genome.Split.split gpart_asVr
                      p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                      (g_asUq, gpart_asVr) = Genome.Split.split gpart_asVq
                      p_asUp = Functions.belowten' g_asUo
                      (g_asUo, gpart_asVq) = Genome.Split.split gpart_asVp
                      p_asUn = code-0.1.0.0:Genome.FixedList.Functions.double g_asUm
                      (g_asUm, gpart_asVp) = Genome.Split.split gpart_asVo
                      p_asUl = Functions.belowten' g_asUk
                      (g_asUk, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asUj = code-0.1.0.0:Genome.FixedList.Functions.double g_asUi
                      (g_asUi, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asUh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUg
                      (g_asUg, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asUf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUe
                      (g_asUe, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asUb = Functions.belowten' g_asUa
                      (g_asUa, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                      (g_asU8, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asU7 = Functions.belowten' g_asU6
                      (g_asU6, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                      (g_asU4, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asU3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU2
                      (g_asU2, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asU1 = Functions.belowten' g_asU0
                      (g_asU0, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asTZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTY
                      (g_asTY, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asTX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTW
                      (g_asTW, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asTV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTU
                      (g_asTU, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                      (g_asTS, gpart_asVa) = Genome.Split.split gpart_asV9
                      p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                      (g_asTQ, gpart_asV9) = Genome.Split.split gpart_asV8
                      p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                      (g_asTO, gpart_asV8) = Genome.Split.split gpart_asV7
                      p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                      (g_asTM, gpart_asV7) = Genome.Split.split gpart_asV6
                      p_asTL = code-0.1.0.0:Genome.FixedList.Functions.double g_asTK
                      (g_asTK, gpart_asV6) = Genome.Split.split genome_asV4
                    in
                      [Reaction
                         (\ x_asVL
                            -> let c_MiRs_asVM = ((toVector x_asVL) Data.Vector.Unboxed.! 2)
                               in (p_asTT / (1 + ((c_MiRs_asVM / p_asTZ) ** p_asU1))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVN
                            -> let
                                 c_MiRs_asVO = ((toVector x_asVN) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVP = ((toVector x_asVN) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asU3
                                  / (1
                                     + (((c_MiRs_asVO / p_asU5) ** p_asU7)
                                        + ((c_PTB_asVP / p_asU9) ** p_asUb)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVQ
                            -> let
                                 c_RESTc_asVS = ((toVector x_asVQ) Data.Vector.Unboxed.! 3)
                                 c_PTB_asVR = ((toVector x_asVQ) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUd
                                  * ((p_asUr + ((p_asTP / p_asUf) ** p_asUh))
                                     / (((1 + p_asUr) + ((p_asTP / p_asUf) ** p_asUh))
                                        + (((c_PTB_asVR / p_asUj) ** p_asUl)
                                           + ((c_RESTc_asVS / p_asUn) ** p_asUp))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVT
                            -> let
                                 c_MiRs_asVW = ((toVector x_asVT) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVU = ((toVector x_asVT) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUt
                                  * ((p_asUH + ((c_PTB_asVU / p_asUv) ** p_asUx))
                                     / (((1 + p_asUH) + ((c_PTB_asVU / p_asUv) ** p_asUx))
                                        + (((p_asTL / p_asUz) ** p_asUB)
                                           + ((c_MiRs_asVW / p_asUD) ** p_asUF))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asVX
                            -> let
                                 c_RESTc_asW0 = ((toVector x_asVX) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asVY = ((toVector x_asVX) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asUJ
                                  * ((p_asUT + ((c_MiRs_asVY / p_asUL) ** p_asUN))
                                     / (((1 + p_asUT) + ((c_MiRs_asVY / p_asUL) ** p_asUN))
                                        + ((c_RESTc_asW0 / p_asUP) ** p_asUR)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asW1
                            -> let c_PTB_asW2 = ((toVector x_asW1) Data.Vector.Unboxed.! 0)
                               in (p_asUV * c_PTB_asW2))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asW3
                            -> let c_NPTB_asW4 = ((toVector x_asW3) Data.Vector.Unboxed.! 1)
                               in (p_asUX * c_NPTB_asW4))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asW5
                            -> let c_MiRs_asW6 = ((toVector x_asW5) Data.Vector.Unboxed.! 2)
                               in (p_asUZ * c_MiRs_asW6))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asW7
                            -> let c_RESTc_asW8 = ((toVector x_asW7) Data.Vector.Unboxed.! 3)
                               in (p_asV1 * c_RESTc_asW8))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asW9
                            -> let
                                 c_EndoNeuroTFs_asWa = ((toVector x_asW9) Data.Vector.Unboxed.! 4)
                               in (p_asV3 * c_EndoNeuroTFs_asWa))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120881",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120891",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120893",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120939",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120941",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120957",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asV4
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWU
                            p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                            (g_asV2, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                            (g_asV0, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                            (g_asUY, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUX = code-0.1.0.0:Genome.FixedList.Functions.double g_asUW
                            (g_asUW, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                            (g_asUU, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                            (g_asUS, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUR = Functions.belowten' g_asUQ
                            (g_asUQ, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUP = code-0.1.0.0:Genome.FixedList.Functions.double g_asUO
                            (g_asUO, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUN = Functions.belowten' g_asUM
                            (g_asUM, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUL = code-0.1.0.0:Genome.FixedList.Functions.double g_asUK
                            (g_asUK, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUI
                            (g_asUI, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUH = code-0.1.0.0:Genome.FixedList.Functions.double g_asUG
                            (g_asUG, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUF = Functions.belowten' g_asUE
                            (g_asUE, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                            (g_asUC, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUA
                            (g_asUA, gpart_asWG) = Genome.Split.split gpart_asWF
                            p_asUz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUy
                            (g_asUy, gpart_asWF) = Genome.Split.split gpart_asWE
                            p_asUx = Functions.belowten' g_asUw
                            (g_asUw, gpart_asWE) = Genome.Split.split gpart_asWD
                            p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                            (g_asUu, gpart_asWD) = Genome.Split.split gpart_asWC
                            p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                            (g_asUs, gpart_asWC) = Genome.Split.split gpart_asWB
                            p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                            (g_asUq, gpart_asWB) = Genome.Split.split gpart_asWA
                            p_asUp = Functions.belowten' g_asUo
                            (g_asUo, gpart_asWA) = Genome.Split.split gpart_asWz
                            p_asUn = code-0.1.0.0:Genome.FixedList.Functions.double g_asUm
                            (g_asUm, gpart_asWz) = Genome.Split.split gpart_asWy
                            p_asUl = Functions.belowten' g_asUk
                            (g_asUk, gpart_asWy) = Genome.Split.split gpart_asWx
                            p_asUj = code-0.1.0.0:Genome.FixedList.Functions.double g_asUi
                            (g_asUi, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asUh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUg
                            (g_asUg, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asUf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUe
                            (g_asUe, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asUb = Functions.belowten' g_asUa
                            (g_asUa, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                            (g_asU8, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asU7 = Functions.belowten' g_asU6
                            (g_asU6, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                            (g_asU4, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asU3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU2
                            (g_asU2, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asU1 = Functions.belowten' g_asU0
                            (g_asU0, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asTZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTY
                            (g_asTY, gpart_asWn) = Genome.Split.split gpart_asWm
                            p_asTX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTW
                            (g_asTW, gpart_asWm) = Genome.Split.split gpart_asWl
                            p_asTV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTU
                            (g_asTU, gpart_asWl) = Genome.Split.split gpart_asWk
                            p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                            (g_asTS, gpart_asWk) = Genome.Split.split gpart_asWj
                            p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                            (g_asTQ, gpart_asWj) = Genome.Split.split gpart_asWi
                            p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                            (g_asTO, gpart_asWi) = Genome.Split.split gpart_asWh
                            p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                            (g_asTM, gpart_asWh) = Genome.Split.split gpart_asWg
                            p_asTL = code-0.1.0.0:Genome.FixedList.Functions.double g_asTK
                            (g_asTK, gpart_asWg) = Genome.Split.split genome_asV4
                          in
                            \ desc_asV5
                              -> case desc_asV5 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTL)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTN)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTP)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTR)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTT)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTV)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTX)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTZ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU1)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU3)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU5)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUH)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUJ)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUL)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUN)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUP)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUR)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUT)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUV)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUX)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUZ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV1)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYV
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZB
                      p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                      (g_asYT, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                      (g_asYR, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                      (g_asYP, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                      (g_asYN, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                      (g_asYL, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                      (g_asYJ, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYI = Functions.belowten' g_asYH
                      (g_asYH, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                      (g_asYF, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYE = Functions.belowten' g_asYD
                      (g_asYD, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                      (g_asYB, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asYA = code-0.1.0.0:Genome.FixedList.Functions.double g_asYz
                      (g_asYz, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                      (g_asYx, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asYw = Functions.belowten' g_asYv
                      (g_asYv, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                      (g_asYt, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asYs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYr
                      (g_asYr, gpart_asZn) = Genome.Split.split gpart_asZm
                      p_asYq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYp
                      (g_asYp, gpart_asZm) = Genome.Split.split gpart_asZl
                      p_asYo = Functions.belowten' g_asYn
                      (g_asYn, gpart_asZl) = Genome.Split.split gpart_asZk
                      p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                      (g_asYl, gpart_asZk) = Genome.Split.split gpart_asZj
                      p_asYk = code-0.1.0.0:Genome.FixedList.Functions.double g_asYj
                      (g_asYj, gpart_asZj) = Genome.Split.split gpart_asZi
                      p_asYi = code-0.1.0.0:Genome.FixedList.Functions.double g_asYh
                      (g_asYh, gpart_asZi) = Genome.Split.split gpart_asZh
                      p_asYg = Functions.belowten' g_asYf
                      (g_asYf, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                      (g_asYd, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asYc = Functions.belowten' g_asYb
                      (g_asYb, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                      (g_asY9, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asY8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY7
                      (g_asY7, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asY6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY5
                      (g_asY5, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                      (g_asY3, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asY2 = Functions.belowten' g_asY1
                      (g_asY1, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                      (g_asXZ, gpart_asZ9) = Genome.Split.split gpart_asZ8
                      p_asXY = Functions.belowten' g_asXX
                      (g_asXX, gpart_asZ8) = Genome.Split.split gpart_asZ7
                      p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                      (g_asXV, gpart_asZ7) = Genome.Split.split gpart_asZ6
                      p_asXU = code-0.1.0.0:Genome.FixedList.Functions.double g_asXT
                      (g_asXT, gpart_asZ6) = Genome.Split.split gpart_asZ5
                      p_asXS = Functions.belowten' g_asXR
                      (g_asXR, gpart_asZ5) = Genome.Split.split gpart_asZ4
                      p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                      (g_asXP, gpart_asZ4) = Genome.Split.split gpart_asZ3
                      p_asXO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXN
                      (g_asXN, gpart_asZ3) = Genome.Split.split gpart_asZ2
                      p_asXM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXL
                      (g_asXL, gpart_asZ2) = Genome.Split.split gpart_asZ1
                      p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                      (g_asXJ, gpart_asZ1) = Genome.Split.split gpart_asZ0
                      p_asXI = code-0.1.0.0:Genome.FixedList.Functions.double g_asXH
                      (g_asXH, gpart_asZ0) = Genome.Split.split gpart_asYZ
                      p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                      (g_asXF, gpart_asYZ) = Genome.Split.split gpart_asYY
                      p_asXE = code-0.1.0.0:Genome.FixedList.Functions.double g_asXD
                      (g_asXD, gpart_asYY) = Genome.Split.split gpart_asYX
                      p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                      (g_asXB, gpart_asYX) = Genome.Split.split genome_asYV
                    in
                      [Reaction
                         (\ x_asZC
                            -> let c_MiRs_asZD = ((toVector x_asZC) Data.Vector.Unboxed.! 2)
                               in (p_asXK / (1 + ((c_MiRs_asZD / p_asXQ) ** p_asXS))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZE
                            -> let
                                 c_MiRs_asZF = ((toVector x_asZE) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZG = ((toVector x_asZE) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXU
                                  / (1
                                     + (((c_MiRs_asZF / p_asXW) ** p_asXY)
                                        + ((c_PTB_asZG / p_asY0) ** p_asY2)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZH
                            -> let
                                 c_RESTc_asZJ = ((toVector x_asZH) Data.Vector.Unboxed.! 3)
                                 c_PTB_asZI = ((toVector x_asZH) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asY4
                                  * (p_asYi
                                     / ((1 + p_asYi)
                                        + (((c_PTB_asZI / p_asYa) ** p_asYc)
                                           + ((c_RESTc_asZJ / p_asYe) ** p_asYg))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZK
                            -> let
                                 c_MiRs_asZN = ((toVector x_asZK) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZL = ((toVector x_asZK) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYk
                                  * ((p_asYy + ((c_PTB_asZL / p_asYm) ** p_asYo))
                                     / (((1 + p_asYy) + ((c_PTB_asZL / p_asYm) ** p_asYo))
                                        + (((p_asXC / p_asYq) ** p_asYs)
                                           + ((c_MiRs_asZN / p_asYu) ** p_asYw))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZO
                            -> let
                                 c_RESTc_asZR = ((toVector x_asZO) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asZP = ((toVector x_asZO) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asYA
                                  * ((p_asYK + ((c_MiRs_asZP / p_asYC) ** p_asYE))
                                     / (((1 + p_asYK) + ((c_MiRs_asZP / p_asYC) ** p_asYE))
                                        + ((c_RESTc_asZR / p_asYG) ** p_asYI)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZS
                            -> let c_PTB_asZT = ((toVector x_asZS) Data.Vector.Unboxed.! 0)
                               in (p_asYM * c_PTB_asZT))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZU
                            -> let c_NPTB_asZV = ((toVector x_asZU) Data.Vector.Unboxed.! 1)
                               in (p_asYO * c_NPTB_asZV))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZW
                            -> let c_MiRs_asZX = ((toVector x_asZW) Data.Vector.Unboxed.! 2)
                               in (p_asYQ * c_MiRs_asZX))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZY
                            -> let c_RESTc_asZZ = ((toVector x_asZY) Data.Vector.Unboxed.! 3)
                               in (p_asYS * c_RESTc_asZZ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at00
                            -> let
                                 c_EndoNeuroTFs_at01 = ((toVector x_at00) Data.Vector.Unboxed.! 4)
                               in (p_asYU * c_EndoNeuroTFs_at01))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121122",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121124",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121126",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121128",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121130",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121132",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121138",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121140",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121148",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121150",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121152",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121170",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121172",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121178",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121180",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121198",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121200",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYV
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0G
                            p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                            (g_asYT, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                            (g_asYR, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                            (g_asYP, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                            (g_asYN, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                            (g_asYL, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                            (g_asYJ, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYI = Functions.belowten' g_asYH
                            (g_asYH, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                            (g_asYF, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYE = Functions.belowten' g_asYD
                            (g_asYD, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                            (g_asYB, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asYA = code-0.1.0.0:Genome.FixedList.Functions.double g_asYz
                            (g_asYz, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                            (g_asYx, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asYw = Functions.belowten' g_asYv
                            (g_asYv, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                            (g_asYt, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asYs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYr
                            (g_asYr, gpart_at0s) = Genome.Split.split gpart_at0r
                            p_asYq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYp
                            (g_asYp, gpart_at0r) = Genome.Split.split gpart_at0q
                            p_asYo = Functions.belowten' g_asYn
                            (g_asYn, gpart_at0q) = Genome.Split.split gpart_at0p
                            p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                            (g_asYl, gpart_at0p) = Genome.Split.split gpart_at0o
                            p_asYk = code-0.1.0.0:Genome.FixedList.Functions.double g_asYj
                            (g_asYj, gpart_at0o) = Genome.Split.split gpart_at0n
                            p_asYi = code-0.1.0.0:Genome.FixedList.Functions.double g_asYh
                            (g_asYh, gpart_at0n) = Genome.Split.split gpart_at0m
                            p_asYg = Functions.belowten' g_asYf
                            (g_asYf, gpart_at0m) = Genome.Split.split gpart_at0l
                            p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                            (g_asYd, gpart_at0l) = Genome.Split.split gpart_at0k
                            p_asYc = Functions.belowten' g_asYb
                            (g_asYb, gpart_at0k) = Genome.Split.split gpart_at0j
                            p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                            (g_asY9, gpart_at0j) = Genome.Split.split gpart_at0i
                            p_asY8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY7
                            (g_asY7, gpart_at0i) = Genome.Split.split gpart_at0h
                            p_asY6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY5
                            (g_asY5, gpart_at0h) = Genome.Split.split gpart_at0g
                            p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                            (g_asY3, gpart_at0g) = Genome.Split.split gpart_at0f
                            p_asY2 = Functions.belowten' g_asY1
                            (g_asY1, gpart_at0f) = Genome.Split.split gpart_at0e
                            p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                            (g_asXZ, gpart_at0e) = Genome.Split.split gpart_at0d
                            p_asXY = Functions.belowten' g_asXX
                            (g_asXX, gpart_at0d) = Genome.Split.split gpart_at0c
                            p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                            (g_asXV, gpart_at0c) = Genome.Split.split gpart_at0b
                            p_asXU = code-0.1.0.0:Genome.FixedList.Functions.double g_asXT
                            (g_asXT, gpart_at0b) = Genome.Split.split gpart_at0a
                            p_asXS = Functions.belowten' g_asXR
                            (g_asXR, gpart_at0a) = Genome.Split.split gpart_at09
                            p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                            (g_asXP, gpart_at09) = Genome.Split.split gpart_at08
                            p_asXO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXN
                            (g_asXN, gpart_at08) = Genome.Split.split gpart_at07
                            p_asXM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXL
                            (g_asXL, gpart_at07) = Genome.Split.split gpart_at06
                            p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                            (g_asXJ, gpart_at06) = Genome.Split.split gpart_at05
                            p_asXI = code-0.1.0.0:Genome.FixedList.Functions.double g_asXH
                            (g_asXH, gpart_at05) = Genome.Split.split gpart_at04
                            p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                            (g_asXF, gpart_at04) = Genome.Split.split gpart_at03
                            p_asXE = code-0.1.0.0:Genome.FixedList.Functions.double g_asXD
                            (g_asXD, gpart_at03) = Genome.Split.split gpart_at02
                            p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                            (g_asXB, gpart_at02) = Genome.Split.split genome_asYV
                          in
                            \ desc_asYW
                              -> case desc_asYW of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXC)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXE)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXG)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXI)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXK)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXM)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXO)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXQ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXS)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXU)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXW)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXY)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY0)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY2)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY4)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY6)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY8)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYa)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYc)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYe)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYg)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYi)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYk)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYm)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYo)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYq)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYs)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYu)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYw)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYy)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYA)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYM)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYO)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYQ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYS)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYU)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at2H
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3n
                      p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                      (g_at2F, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                      (g_at2D, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                      (g_at2B, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                      (g_at2z, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                      (g_at2x, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                      (g_at2v, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at2u = Functions.belowten' g_at2t
                      (g_at2t, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                      (g_at2r, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at2q = Functions.belowten' g_at2p
                      (g_at2p, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                      (g_at2n, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at2m = code-0.1.0.0:Genome.FixedList.Functions.double g_at2l
                      (g_at2l, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                      (g_at2j, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at2i = Functions.belowten' g_at2h
                      (g_at2h, gpart_at3b) = Genome.Split.split gpart_at3a
                      p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                      (g_at2f, gpart_at3a) = Genome.Split.split gpart_at39
                      p_at2e
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2d
                      (g_at2d, gpart_at39) = Genome.Split.split gpart_at38
                      p_at2c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2b
                      (g_at2b, gpart_at38) = Genome.Split.split gpart_at37
                      p_at2a = Functions.belowten' g_at29
                      (g_at29, gpart_at37) = Genome.Split.split gpart_at36
                      p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                      (g_at27, gpart_at36) = Genome.Split.split gpart_at35
                      p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                      (g_at25, gpart_at35) = Genome.Split.split gpart_at34
                      p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                      (g_at23, gpart_at34) = Genome.Split.split gpart_at33
                      p_at22 = Functions.belowten' g_at21
                      (g_at21, gpart_at33) = Genome.Split.split gpart_at32
                      p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                      (g_at1Z, gpart_at32) = Genome.Split.split gpart_at31
                      p_at1Y = Functions.belowten' g_at1X
                      (g_at1X, gpart_at31) = Genome.Split.split gpart_at30
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at30) = Genome.Split.split gpart_at2Z
                      p_at1U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1T
                      (g_at1T, gpart_at2Z) = Genome.Split.split gpart_at2Y
                      p_at1S
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1R
                      (g_at1R, gpart_at2Y) = Genome.Split.split gpart_at2X
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at2X) = Genome.Split.split gpart_at2W
                      p_at1O = Functions.belowten' g_at1N
                      (g_at1N, gpart_at2W) = Genome.Split.split gpart_at2V
                      p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                      (g_at1L, gpart_at2V) = Genome.Split.split gpart_at2U
                      p_at1K = Functions.belowten' g_at1J
                      (g_at1J, gpart_at2U) = Genome.Split.split gpart_at2T
                      p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                      (g_at1H, gpart_at2T) = Genome.Split.split gpart_at2S
                      p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                      (g_at1F, gpart_at2S) = Genome.Split.split gpart_at2R
                      p_at1E = Functions.belowten' g_at1D
                      (g_at1D, gpart_at2R) = Genome.Split.split gpart_at2Q
                      p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                      (g_at1B, gpart_at2Q) = Genome.Split.split gpart_at2P
                      p_at1A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1z
                      (g_at1z, gpart_at2P) = Genome.Split.split gpart_at2O
                      p_at1y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1x
                      (g_at1x, gpart_at2O) = Genome.Split.split gpart_at2N
                      p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                      (g_at1v, gpart_at2N) = Genome.Split.split gpart_at2M
                      p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                      (g_at1t, gpart_at2M) = Genome.Split.split gpart_at2L
                      p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                      (g_at1r, gpart_at2L) = Genome.Split.split gpart_at2K
                      p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                      (g_at1p, gpart_at2K) = Genome.Split.split gpart_at2J
                      p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                      (g_at1n, gpart_at2J) = Genome.Split.split genome_at2H
                    in
                      [Reaction
                         (\ x_at3o
                            -> let c_MiRs_at3p = ((toVector x_at3o) Data.Vector.Unboxed.! 2)
                               in (p_at1w / (1 + ((c_MiRs_at3p / p_at1C) ** p_at1E))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3q
                            -> let
                                 c_MiRs_at3r = ((toVector x_at3q) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3s = ((toVector x_at3q) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1G
                                  / (1
                                     + (((c_MiRs_at3r / p_at1I) ** p_at1K)
                                        + ((c_PTB_at3s / p_at1M) ** p_at1O)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3t
                            -> let
                                 c_RESTc_at3v = ((toVector x_at3t) Data.Vector.Unboxed.! 3)
                                 c_PTB_at3u = ((toVector x_at3t) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1Q
                                  * (p_at24
                                     / ((1 + p_at24)
                                        + (((c_PTB_at3u / p_at1W) ** p_at1Y)
                                           + ((c_RESTc_at3v / p_at20) ** p_at22))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3w
                            -> let
                                 c_MiRs_at3z = ((toVector x_at3w) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3x = ((toVector x_at3w) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at26
                                  * ((p_at2k + ((c_PTB_at3x / p_at28) ** p_at2a))
                                     / (((1 + p_at2k) + ((c_PTB_at3x / p_at28) ** p_at2a))
                                        + ((c_MiRs_at3z / p_at2g) ** p_at2i)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3A
                            -> let
                                 c_RESTc_at3D = ((toVector x_at3A) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at3B = ((toVector x_at3A) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2m
                                  * ((p_at2w + ((c_MiRs_at3B / p_at2o) ** p_at2q))
                                     / (((1 + p_at2w) + ((c_MiRs_at3B / p_at2o) ** p_at2q))
                                        + ((c_RESTc_at3D / p_at2s) ** p_at2u)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at3E
                            -> let c_PTB_at3F = ((toVector x_at3E) Data.Vector.Unboxed.! 0)
                               in (p_at2y * c_PTB_at3F))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3G
                            -> let c_NPTB_at3H = ((toVector x_at3G) Data.Vector.Unboxed.! 1)
                               in (p_at2A * c_NPTB_at3H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at3I
                            -> let c_MiRs_at3J = ((toVector x_at3I) Data.Vector.Unboxed.! 2)
                               in (p_at2C * c_MiRs_at3J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at3K
                            -> let c_RESTc_at3L = ((toVector x_at3K) Data.Vector.Unboxed.! 3)
                               in (p_at2E * c_RESTc_at3L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at3M
                            -> let
                                 c_EndoNeuroTFs_at3N = ((toVector x_at3M) Data.Vector.Unboxed.! 4)
                               in (p_at2G * c_EndoNeuroTFs_at3N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121354",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121356",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121364",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2H
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4s
                            p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                            (g_at2F, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                            (g_at2D, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                            (g_at2B, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                            (g_at2z, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                            (g_at2x, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                            (g_at2v, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at2u = Functions.belowten' g_at2t
                            (g_at2t, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                            (g_at2r, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at2q = Functions.belowten' g_at2p
                            (g_at2p, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                            (g_at2n, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at2m = code-0.1.0.0:Genome.FixedList.Functions.double g_at2l
                            (g_at2l, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                            (g_at2j, gpart_at4h) = Genome.Split.split gpart_at4g
                            p_at2i = Functions.belowten' g_at2h
                            (g_at2h, gpart_at4g) = Genome.Split.split gpart_at4f
                            p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                            (g_at2f, gpart_at4f) = Genome.Split.split gpart_at4e
                            p_at2e
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2d
                            (g_at2d, gpart_at4e) = Genome.Split.split gpart_at4d
                            p_at2c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2b
                            (g_at2b, gpart_at4d) = Genome.Split.split gpart_at4c
                            p_at2a = Functions.belowten' g_at29
                            (g_at29, gpart_at4c) = Genome.Split.split gpart_at4b
                            p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                            (g_at27, gpart_at4b) = Genome.Split.split gpart_at4a
                            p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                            (g_at25, gpart_at4a) = Genome.Split.split gpart_at49
                            p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                            (g_at23, gpart_at49) = Genome.Split.split gpart_at48
                            p_at22 = Functions.belowten' g_at21
                            (g_at21, gpart_at48) = Genome.Split.split gpart_at47
                            p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                            (g_at1Z, gpart_at47) = Genome.Split.split gpart_at46
                            p_at1Y = Functions.belowten' g_at1X
                            (g_at1X, gpart_at46) = Genome.Split.split gpart_at45
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at45) = Genome.Split.split gpart_at44
                            p_at1U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1T
                            (g_at1T, gpart_at44) = Genome.Split.split gpart_at43
                            p_at1S
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1R
                            (g_at1R, gpart_at43) = Genome.Split.split gpart_at42
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at42) = Genome.Split.split gpart_at41
                            p_at1O = Functions.belowten' g_at1N
                            (g_at1N, gpart_at41) = Genome.Split.split gpart_at40
                            p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                            (g_at1L, gpart_at40) = Genome.Split.split gpart_at3Z
                            p_at1K = Functions.belowten' g_at1J
                            (g_at1J, gpart_at3Z) = Genome.Split.split gpart_at3Y
                            p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                            (g_at1H, gpart_at3Y) = Genome.Split.split gpart_at3X
                            p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                            (g_at1F, gpart_at3X) = Genome.Split.split gpart_at3W
                            p_at1E = Functions.belowten' g_at1D
                            (g_at1D, gpart_at3W) = Genome.Split.split gpart_at3V
                            p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                            (g_at1B, gpart_at3V) = Genome.Split.split gpart_at3U
                            p_at1A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1z
                            (g_at1z, gpart_at3U) = Genome.Split.split gpart_at3T
                            p_at1y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1x
                            (g_at1x, gpart_at3T) = Genome.Split.split gpart_at3S
                            p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                            (g_at1v, gpart_at3S) = Genome.Split.split gpart_at3R
                            p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                            (g_at1t, gpart_at3R) = Genome.Split.split gpart_at3Q
                            p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                            (g_at1r, gpart_at3Q) = Genome.Split.split gpart_at3P
                            p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                            (g_at1p, gpart_at3P) = Genome.Split.split gpart_at3O
                            p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                            (g_at1n, gpart_at3O) = Genome.Split.split genome_at2H
                          in
                            \ desc_at2I
                              -> case desc_at2I of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1o)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1q)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1s)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1u)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1w)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1y)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2u)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2w)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2y)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2A)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2C)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2E)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2G)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at6t
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at79
                      p_at6s = code-0.1.0.0:Genome.FixedList.Functions.double g_at6r
                      (g_at6r, gpart_at79) = Genome.Split.split gpart_at78
                      p_at6q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6p
                      (g_at6p, gpart_at78) = Genome.Split.split gpart_at77
                      p_at6o = code-0.1.0.0:Genome.FixedList.Functions.double g_at6n
                      (g_at6n, gpart_at77) = Genome.Split.split gpart_at76
                      p_at6m = code-0.1.0.0:Genome.FixedList.Functions.double g_at6l
                      (g_at6l, gpart_at76) = Genome.Split.split gpart_at75
                      p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                      (g_at6j, gpart_at75) = Genome.Split.split gpart_at74
                      p_at6i = code-0.1.0.0:Genome.FixedList.Functions.double g_at6h
                      (g_at6h, gpart_at74) = Genome.Split.split gpart_at73
                      p_at6g = Functions.belowten' g_at6f
                      (g_at6f, gpart_at73) = Genome.Split.split gpart_at72
                      p_at6e = code-0.1.0.0:Genome.FixedList.Functions.double g_at6d
                      (g_at6d, gpart_at72) = Genome.Split.split gpart_at71
                      p_at6c = Functions.belowten' g_at6b
                      (g_at6b, gpart_at71) = Genome.Split.split gpart_at70
                      p_at6a = code-0.1.0.0:Genome.FixedList.Functions.double g_at69
                      (g_at69, gpart_at70) = Genome.Split.split gpart_at6Z
                      p_at68 = code-0.1.0.0:Genome.FixedList.Functions.double g_at67
                      (g_at67, gpart_at6Z) = Genome.Split.split gpart_at6Y
                      p_at66 = code-0.1.0.0:Genome.FixedList.Functions.double g_at65
                      (g_at65, gpart_at6Y) = Genome.Split.split gpart_at6X
                      p_at64 = Functions.belowten' g_at63
                      (g_at63, gpart_at6X) = Genome.Split.split gpart_at6W
                      p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                      (g_at61, gpart_at6W) = Genome.Split.split gpart_at6V
                      p_at60
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5Z
                      (g_at5Z, gpart_at6V) = Genome.Split.split gpart_at6U
                      p_at5Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5X
                      (g_at5X, gpart_at6U) = Genome.Split.split gpart_at6T
                      p_at5W = Functions.belowten' g_at5V
                      (g_at5V, gpart_at6T) = Genome.Split.split gpart_at6S
                      p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                      (g_at5T, gpart_at6S) = Genome.Split.split gpart_at6R
                      p_at5S = code-0.1.0.0:Genome.FixedList.Functions.double g_at5R
                      (g_at5R, gpart_at6R) = Genome.Split.split gpart_at6Q
                      p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                      (g_at5P, gpart_at6Q) = Genome.Split.split gpart_at6P
                      p_at5O = Functions.belowten' g_at5N
                      (g_at5N, gpart_at6P) = Genome.Split.split gpart_at6O
                      p_at5M = code-0.1.0.0:Genome.FixedList.Functions.double g_at5L
                      (g_at5L, gpart_at6O) = Genome.Split.split gpart_at6N
                      p_at5K = Functions.belowten' g_at5J
                      (g_at5J, gpart_at6N) = Genome.Split.split gpart_at6M
                      p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                      (g_at5H, gpart_at6M) = Genome.Split.split gpart_at6L
                      p_at5G
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5F
                      (g_at5F, gpart_at6L) = Genome.Split.split gpart_at6K
                      p_at5E
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5D
                      (g_at5D, gpart_at6K) = Genome.Split.split gpart_at6J
                      p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                      (g_at5B, gpart_at6J) = Genome.Split.split gpart_at6I
                      p_at5A = Functions.belowten' g_at5z
                      (g_at5z, gpart_at6I) = Genome.Split.split gpart_at6H
                      p_at5y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5x
                      (g_at5x, gpart_at6H) = Genome.Split.split gpart_at6G
                      p_at5w = Functions.belowten' g_at5v
                      (g_at5v, gpart_at6G) = Genome.Split.split gpart_at6F
                      p_at5u = code-0.1.0.0:Genome.FixedList.Functions.double g_at5t
                      (g_at5t, gpart_at6F) = Genome.Split.split gpart_at6E
                      p_at5s = code-0.1.0.0:Genome.FixedList.Functions.double g_at5r
                      (g_at5r, gpart_at6E) = Genome.Split.split gpart_at6D
                      p_at5q = Functions.belowten' g_at5p
                      (g_at5p, gpart_at6D) = Genome.Split.split gpart_at6C
                      p_at5o = code-0.1.0.0:Genome.FixedList.Functions.double g_at5n
                      (g_at5n, gpart_at6C) = Genome.Split.split gpart_at6B
                      p_at5m
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5l
                      (g_at5l, gpart_at6B) = Genome.Split.split gpart_at6A
                      p_at5k
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5j
                      (g_at5j, gpart_at6A) = Genome.Split.split gpart_at6z
                      p_at5i = code-0.1.0.0:Genome.FixedList.Functions.double g_at5h
                      (g_at5h, gpart_at6z) = Genome.Split.split gpart_at6y
                      p_at5g = code-0.1.0.0:Genome.FixedList.Functions.double g_at5f
                      (g_at5f, gpart_at6y) = Genome.Split.split gpart_at6x
                      p_at5e = code-0.1.0.0:Genome.FixedList.Functions.double g_at5d
                      (g_at5d, gpart_at6x) = Genome.Split.split gpart_at6w
                      p_at5c = code-0.1.0.0:Genome.FixedList.Functions.double g_at5b
                      (g_at5b, gpart_at6w) = Genome.Split.split gpart_at6v
                      p_at5a = code-0.1.0.0:Genome.FixedList.Functions.double g_at59
                      (g_at59, gpart_at6v) = Genome.Split.split genome_at6t
                    in
                      [Reaction
                         (\ x_at7a
                            -> let c_MiRs_at7b = ((toVector x_at7a) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5i
                                  / (1
                                     + (((p_at5a / p_at5k) ** p_at5m)
                                        + ((c_MiRs_at7b / p_at5o) ** p_at5q)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7c
                            -> let
                                 c_MiRs_at7d = ((toVector x_at7c) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7e = ((toVector x_at7c) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5s
                                  / (1
                                     + (((c_MiRs_at7d / p_at5u) ** p_at5w)
                                        + ((c_PTB_at7e / p_at5y) ** p_at5A)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7f
                            -> let
                                 c_RESTc_at7h = ((toVector x_at7f) Data.Vector.Unboxed.! 3)
                                 c_PTB_at7g = ((toVector x_at7f) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5C
                                  * (p_at5Q
                                     / ((1 + p_at5Q)
                                        + (((c_PTB_at7g / p_at5I) ** p_at5K)
                                           + ((c_RESTc_at7h / p_at5M) ** p_at5O))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7i
                            -> let
                                 c_MiRs_at7l = ((toVector x_at7i) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7j = ((toVector x_at7i) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5S
                                  * ((p_at66 + ((c_PTB_at7j / p_at5U) ** p_at5W))
                                     / (((1 + p_at66) + ((c_PTB_at7j / p_at5U) ** p_at5W))
                                        + ((c_MiRs_at7l / p_at62) ** p_at64)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7m
                            -> let
                                 c_RESTc_at7p = ((toVector x_at7m) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at7n = ((toVector x_at7m) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at68
                                  * ((p_at6i + ((c_MiRs_at7n / p_at6a) ** p_at6c))
                                     / (((1 + p_at6i) + ((c_MiRs_at7n / p_at6a) ** p_at6c))
                                        + ((c_RESTc_at7p / p_at6e) ** p_at6g)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at7q
                            -> let c_PTB_at7r = ((toVector x_at7q) Data.Vector.Unboxed.! 0)
                               in (p_at6k * c_PTB_at7r))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7s
                            -> let c_NPTB_at7t = ((toVector x_at7s) Data.Vector.Unboxed.! 1)
                               in (p_at6m * c_NPTB_at7t))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at7u
                            -> let c_MiRs_at7v = ((toVector x_at7u) Data.Vector.Unboxed.! 2)
                               in (p_at6o * c_MiRs_at7v))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at7w
                            -> let c_RESTc_at7x = ((toVector x_at7w) Data.Vector.Unboxed.! 3)
                               in (p_at6q * c_RESTc_at7x))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at7y
                            -> let
                                 c_EndoNeuroTFs_at7z = ((toVector x_at7y) Data.Vector.Unboxed.! 4)
                               in (p_at6s * c_EndoNeuroTFs_at7z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121588",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121590",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121592",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121593",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121594",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121595",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121596",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121597",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121598",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121599",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121600",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121601",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121602",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121603",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121604",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121605",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121606",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121607",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121608",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121609",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121610",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121611",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121612",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121618",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121620",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121624",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121626",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121628",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121631",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121632",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121633",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121634",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121635",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121636",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121638",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121640",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121642",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121644",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121648",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121650",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121652",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121654",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121656",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121658",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121660",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121662",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121663",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121664",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121665",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121666",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121668",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6t
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8e
                            p_at6s = code-0.1.0.0:Genome.FixedList.Functions.double g_at6r
                            (g_at6r, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at6q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6p
                            (g_at6p, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at6o = code-0.1.0.0:Genome.FixedList.Functions.double g_at6n
                            (g_at6n, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at6m = code-0.1.0.0:Genome.FixedList.Functions.double g_at6l
                            (g_at6l, gpart_at8b) = Genome.Split.split gpart_at8a
                            p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                            (g_at6j, gpart_at8a) = Genome.Split.split gpart_at89
                            p_at6i = code-0.1.0.0:Genome.FixedList.Functions.double g_at6h
                            (g_at6h, gpart_at89) = Genome.Split.split gpart_at88
                            p_at6g = Functions.belowten' g_at6f
                            (g_at6f, gpart_at88) = Genome.Split.split gpart_at87
                            p_at6e = code-0.1.0.0:Genome.FixedList.Functions.double g_at6d
                            (g_at6d, gpart_at87) = Genome.Split.split gpart_at86
                            p_at6c = Functions.belowten' g_at6b
                            (g_at6b, gpart_at86) = Genome.Split.split gpart_at85
                            p_at6a = code-0.1.0.0:Genome.FixedList.Functions.double g_at69
                            (g_at69, gpart_at85) = Genome.Split.split gpart_at84
                            p_at68 = code-0.1.0.0:Genome.FixedList.Functions.double g_at67
                            (g_at67, gpart_at84) = Genome.Split.split gpart_at83
                            p_at66 = code-0.1.0.0:Genome.FixedList.Functions.double g_at65
                            (g_at65, gpart_at83) = Genome.Split.split gpart_at82
                            p_at64 = Functions.belowten' g_at63
                            (g_at63, gpart_at82) = Genome.Split.split gpart_at81
                            p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                            (g_at61, gpart_at81) = Genome.Split.split gpart_at80
                            p_at60
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5Z
                            (g_at5Z, gpart_at80) = Genome.Split.split gpart_at7Z
                            p_at5Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5X
                            (g_at5X, gpart_at7Z) = Genome.Split.split gpart_at7Y
                            p_at5W = Functions.belowten' g_at5V
                            (g_at5V, gpart_at7Y) = Genome.Split.split gpart_at7X
                            p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                            (g_at5T, gpart_at7X) = Genome.Split.split gpart_at7W
                            p_at5S = code-0.1.0.0:Genome.FixedList.Functions.double g_at5R
                            (g_at5R, gpart_at7W) = Genome.Split.split gpart_at7V
                            p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                            (g_at5P, gpart_at7V) = Genome.Split.split gpart_at7U
                            p_at5O = Functions.belowten' g_at5N
                            (g_at5N, gpart_at7U) = Genome.Split.split gpart_at7T
                            p_at5M = code-0.1.0.0:Genome.FixedList.Functions.double g_at5L
                            (g_at5L, gpart_at7T) = Genome.Split.split gpart_at7S
                            p_at5K = Functions.belowten' g_at5J
                            (g_at5J, gpart_at7S) = Genome.Split.split gpart_at7R
                            p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                            (g_at5H, gpart_at7R) = Genome.Split.split gpart_at7Q
                            p_at5G
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5F
                            (g_at5F, gpart_at7Q) = Genome.Split.split gpart_at7P
                            p_at5E
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5D
                            (g_at5D, gpart_at7P) = Genome.Split.split gpart_at7O
                            p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                            (g_at5B, gpart_at7O) = Genome.Split.split gpart_at7N
                            p_at5A = Functions.belowten' g_at5z
                            (g_at5z, gpart_at7N) = Genome.Split.split gpart_at7M
                            p_at5y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5x
                            (g_at5x, gpart_at7M) = Genome.Split.split gpart_at7L
                            p_at5w = Functions.belowten' g_at5v
                            (g_at5v, gpart_at7L) = Genome.Split.split gpart_at7K
                            p_at5u = code-0.1.0.0:Genome.FixedList.Functions.double g_at5t
                            (g_at5t, gpart_at7K) = Genome.Split.split gpart_at7J
                            p_at5s = code-0.1.0.0:Genome.FixedList.Functions.double g_at5r
                            (g_at5r, gpart_at7J) = Genome.Split.split gpart_at7I
                            p_at5q = Functions.belowten' g_at5p
                            (g_at5p, gpart_at7I) = Genome.Split.split gpart_at7H
                            p_at5o = code-0.1.0.0:Genome.FixedList.Functions.double g_at5n
                            (g_at5n, gpart_at7H) = Genome.Split.split gpart_at7G
                            p_at5m
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5l
                            (g_at5l, gpart_at7G) = Genome.Split.split gpart_at7F
                            p_at5k
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5j
                            (g_at5j, gpart_at7F) = Genome.Split.split gpart_at7E
                            p_at5i = code-0.1.0.0:Genome.FixedList.Functions.double g_at5h
                            (g_at5h, gpart_at7E) = Genome.Split.split gpart_at7D
                            p_at5g = code-0.1.0.0:Genome.FixedList.Functions.double g_at5f
                            (g_at5f, gpart_at7D) = Genome.Split.split gpart_at7C
                            p_at5e = code-0.1.0.0:Genome.FixedList.Functions.double g_at5d
                            (g_at5d, gpart_at7C) = Genome.Split.split gpart_at7B
                            p_at5c = code-0.1.0.0:Genome.FixedList.Functions.double g_at5b
                            (g_at5b, gpart_at7B) = Genome.Split.split gpart_at7A
                            p_at5a = code-0.1.0.0:Genome.FixedList.Functions.double g_at59
                            (g_at59, gpart_at7A) = Genome.Split.split genome_at6t
                          in
                            \ desc_at6u
                              -> case desc_at6u of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5a)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5c)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5e)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5g)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5i)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5k)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5m)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5o)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5q)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5s)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5u)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5w)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5y)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5A)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5C)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5E)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5G)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5I)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5K)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5M)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5O)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Q)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5S)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5U)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5W)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Y)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at60)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at62)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at64)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at66)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at68)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6a)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6c)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6e)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6g)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6i)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6k)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6m)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6o)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6q)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6s)
                                   _ -> Nothing }}
