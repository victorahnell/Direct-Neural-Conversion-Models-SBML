src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a2aiB
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ajk
                      p_a2aiA = double g_a2aiz
                      (g_a2aiz, gpart_a2ajk) = Genome.Split.split gpart_a2ajj
                      p_a2aiy = double g_a2aix
                      (g_a2aix, gpart_a2ajj) = Genome.Split.split gpart_a2aji
                      p_a2aiw = double g_a2aiv
                      (g_a2aiv, gpart_a2aji) = Genome.Split.split gpart_a2ajh
                      p_a2aiu = double g_a2ait
                      (g_a2ait, gpart_a2ajh) = Genome.Split.split gpart_a2ajg
                      p_a2ais = double g_a2air
                      (g_a2air, gpart_a2ajg) = Genome.Split.split gpart_a2ajf
                      p_a2aiq = double g_a2aip
                      (g_a2aip, gpart_a2ajf) = Genome.Split.split gpart_a2aje
                      p_a2aio = Functions.belowten' g_a2ain
                      (g_a2ain, gpart_a2aje) = Genome.Split.split gpart_a2ajd
                      p_a2aim = double g_a2ail
                      (g_a2ail, gpart_a2ajd) = Genome.Split.split gpart_a2ajc
                      p_a2aik = Functions.belowten' g_a2aij
                      (g_a2aij, gpart_a2ajc) = Genome.Split.split gpart_a2ajb
                      p_a2aii = double g_a2aih
                      (g_a2aih, gpart_a2ajb) = Genome.Split.split gpart_a2aja
                      p_a2aig = double g_a2aif
                      (g_a2aif, gpart_a2aja) = Genome.Split.split gpart_a2aj9
                      p_a2aie = double g_a2aid
                      (g_a2aid, gpart_a2aj9) = Genome.Split.split gpart_a2aj8
                      p_a2aic = Functions.belowten' g_a2aib
                      (g_a2aib, gpart_a2aj8) = Genome.Split.split gpart_a2aj7
                      p_a2aia = double g_a2ai9
                      (g_a2ai9, gpart_a2aj7) = Genome.Split.split gpart_a2aj6
                      p_a2ai8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ai7
                      (g_a2ai7, gpart_a2aj6) = Genome.Split.split gpart_a2aj5
                      p_a2ai6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ai5
                      (g_a2ai5, gpart_a2aj5) = Genome.Split.split gpart_a2aj4
                      p_a2ai4 = Functions.belowten' g_a2ai3
                      (g_a2ai3, gpart_a2aj4) = Genome.Split.split gpart_a2aj3
                      p_a2ai2 = double g_a2ai1
                      (g_a2ai1, gpart_a2aj3) = Genome.Split.split gpart_a2aj2
                      p_a2ai0 = Functions.belowten' g_a2ahZ
                      (g_a2ahZ, gpart_a2aj2) = Genome.Split.split gpart_a2aj1
                      p_a2ahY = double g_a2ahX
                      (g_a2ahX, gpart_a2aj1) = Genome.Split.split gpart_a2aj0
                      p_a2ahW = double g_a2ahV
                      (g_a2ahV, gpart_a2aj0) = Genome.Split.split gpart_a2aiZ
                      p_a2ahU = double g_a2ahT
                      (g_a2ahT, gpart_a2aiZ) = Genome.Split.split gpart_a2aiY
                      p_a2ahS = Functions.belowten' g_a2ahR
                      (g_a2ahR, gpart_a2aiY) = Genome.Split.split gpart_a2aiX
                      p_a2ahQ = double g_a2ahP
                      (g_a2ahP, gpart_a2aiX) = Genome.Split.split gpart_a2aiW
                      p_a2ahO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ahN
                      (g_a2ahN, gpart_a2aiW) = Genome.Split.split gpart_a2aiV
                      p_a2ahM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ahL
                      (g_a2ahL, gpart_a2aiV) = Genome.Split.split gpart_a2aiU
                      p_a2ahK = double g_a2ahJ
                      (g_a2ahJ, gpart_a2aiU) = Genome.Split.split gpart_a2aiT
                      p_a2ahI = Functions.belowten' g_a2ahH
                      (g_a2ahH, gpart_a2aiT) = Genome.Split.split gpart_a2aiS
                      p_a2ahG = double g_a2ahF
                      (g_a2ahF, gpart_a2aiS) = Genome.Split.split gpart_a2aiR
                      p_a2ahE = Functions.belowten' g_a2ahD
                      (g_a2ahD, gpart_a2aiR) = Genome.Split.split gpart_a2aiQ
                      p_a2ahC = double g_a2ahB
                      (g_a2ahB, gpart_a2aiQ) = Genome.Split.split gpart_a2aiP
                      p_a2ahA = double g_a2ahz
                      (g_a2ahz, gpart_a2aiP) = Genome.Split.split gpart_a2aiO
                      p_a2ahy = double g_a2ahx
                      (g_a2ahx, gpart_a2aiO) = Genome.Split.split gpart_a2aiN
                      p_a2ahw = Functions.belowten' g_a2ahv
                      (g_a2ahv, gpart_a2aiN) = Genome.Split.split gpart_a2aiM
                      p_a2ahu = double g_a2aht
                      (g_a2aht, gpart_a2aiM) = Genome.Split.split gpart_a2aiL
                      p_a2ahs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ahr
                      (g_a2ahr, gpart_a2aiL) = Genome.Split.split gpart_a2aiK
                      p_a2ahq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ahp
                      (g_a2ahp, gpart_a2aiK) = Genome.Split.split gpart_a2aiJ
                      p_a2aho = Functions.belowten' g_a2ahn
                      (g_a2ahn, gpart_a2aiJ) = Genome.Split.split gpart_a2aiI
                      p_a2ahm = double g_a2ahl
                      (g_a2ahl, gpart_a2aiI) = Genome.Split.split gpart_a2aiH
                      p_a2ahk = double g_a2ahj
                      (g_a2ahj, gpart_a2aiH) = Genome.Split.split gpart_a2aiG
                      p_a2ahi = double g_a2ahh
                      (g_a2ahh, gpart_a2aiG) = Genome.Split.split gpart_a2aiF
                      p_a2ahg = double g_a2ahf
                      (g_a2ahf, gpart_a2aiF) = Genome.Split.split gpart_a2aiE
                      p_a2ahe = double g_a2ahd
                      (g_a2ahd, gpart_a2aiE) = Genome.Split.split gpart_a2aiD
                      p_a2ahc = double g_a2ahb
                      (g_a2ahb, gpart_a2aiD) = Genome.Split.split genome_a2aiB
                    in  \ x_a2ajl
                          -> let
                               c_PTB_a2ajq
                                 = ((Data.Fixed.Vector.toVector x_a2ajl) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2ajo
                                 = ((Data.Fixed.Vector.toVector x_a2ajl) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2ajm
                                 = ((Data.Fixed.Vector.toVector x_a2ajl) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2ajv
                                 = ((Data.Fixed.Vector.toVector x_a2ajl) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2ajJ
                                 = ((Data.Fixed.Vector.toVector x_a2ajl) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2ahk
                                     * ((p_a2ahy + ((c_NPTB_a2ajm / p_a2ahm) ** p_a2aho))
                                        / (((1 + p_a2ahy) + ((c_NPTB_a2ajm / p_a2ahm) ** p_a2aho))
                                           + ((c_MiRs_a2ajo / p_a2ahu) ** p_a2ahw))))
                                    + (negate (p_a2ais * c_PTB_a2ajq))),
                                   ((p_a2ahA
                                     / (1
                                        + (((c_MiRs_a2ajo / p_a2ahC) ** p_a2ahE)
                                           + ((c_PTB_a2ajq / p_a2ahG) ** p_a2ahI))))
                                    + (negate (p_a2aiu * c_NPTB_a2ajm))),
                                   ((p_a2ahK
                                     * ((p_a2ahU + ((p_a2ahg / p_a2ahM) ** p_a2ahO))
                                        / (((1 + p_a2ahU) + ((p_a2ahg / p_a2ahM) ** p_a2ahO))
                                           + ((c_RESTc_a2ajv / p_a2ahQ) ** p_a2ahS))))
                                    + (negate (p_a2aiw * c_MiRs_a2ajo))),
                                   ((p_a2ahW
                                     * ((p_a2aie
                                         + (((c_NPTB_a2ajm / p_a2ahY) ** p_a2ai0)
                                            + ((c_PTB_a2ajq / p_a2ai2) ** p_a2ai4)))
                                        / (((1 + p_a2aie)
                                            + (((c_NPTB_a2ajm / p_a2ahY) ** p_a2ai0)
                                               + ((c_PTB_a2ajq / p_a2ai2) ** p_a2ai4)))
                                           + (((p_a2ahc / p_a2ai6) ** p_a2ai8)
                                              + ((c_MiRs_a2ajo / p_a2aia) ** p_a2aic)))))
                                    + (negate (p_a2aiy * c_RESTc_a2ajv))),
                                   ((p_a2aig
                                     * ((p_a2aiq + ((c_MiRs_a2ajo / p_a2aii) ** p_a2aik))
                                        / (((1 + p_a2aiq) + ((c_MiRs_a2ajo / p_a2aii) ** p_a2aik))
                                           + ((c_RESTc_a2ajv / p_a2aim) ** p_a2aio))))
                                    + (negate (p_a2aiA * c_EndoNeuroTFs_a2ajJ)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525968",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525970",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525990",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525992",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526010",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526012",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526020",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526022",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526028",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526036",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526038",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526040",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2aiB
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2akr
                            p_a2aiA = double g_a2aiz
                            (g_a2aiz, gpart_a2akr) = Genome.Split.split gpart_a2akq
                            p_a2aiy = double g_a2aix
                            (g_a2aix, gpart_a2akq) = Genome.Split.split gpart_a2akp
                            p_a2aiw = double g_a2aiv
                            (g_a2aiv, gpart_a2akp) = Genome.Split.split gpart_a2ako
                            p_a2aiu = double g_a2ait
                            (g_a2ait, gpart_a2ako) = Genome.Split.split gpart_a2akn
                            p_a2ais = double g_a2air
                            (g_a2air, gpart_a2akn) = Genome.Split.split gpart_a2akm
                            p_a2aiq = double g_a2aip
                            (g_a2aip, gpart_a2akm) = Genome.Split.split gpart_a2akl
                            p_a2aio = Functions.belowten' g_a2ain
                            (g_a2ain, gpart_a2akl) = Genome.Split.split gpart_a2akk
                            p_a2aim = double g_a2ail
                            (g_a2ail, gpart_a2akk) = Genome.Split.split gpart_a2akj
                            p_a2aik = Functions.belowten' g_a2aij
                            (g_a2aij, gpart_a2akj) = Genome.Split.split gpart_a2aki
                            p_a2aii = double g_a2aih
                            (g_a2aih, gpart_a2aki) = Genome.Split.split gpart_a2akh
                            p_a2aig = double g_a2aif
                            (g_a2aif, gpart_a2akh) = Genome.Split.split gpart_a2akg
                            p_a2aie = double g_a2aid
                            (g_a2aid, gpart_a2akg) = Genome.Split.split gpart_a2akf
                            p_a2aic = Functions.belowten' g_a2aib
                            (g_a2aib, gpart_a2akf) = Genome.Split.split gpart_a2ake
                            p_a2aia = double g_a2ai9
                            (g_a2ai9, gpart_a2ake) = Genome.Split.split gpart_a2akd
                            p_a2ai8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ai7
                            (g_a2ai7, gpart_a2akd) = Genome.Split.split gpart_a2akc
                            p_a2ai6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ai5
                            (g_a2ai5, gpart_a2akc) = Genome.Split.split gpart_a2akb
                            p_a2ai4 = Functions.belowten' g_a2ai3
                            (g_a2ai3, gpart_a2akb) = Genome.Split.split gpart_a2aka
                            p_a2ai2 = double g_a2ai1
                            (g_a2ai1, gpart_a2aka) = Genome.Split.split gpart_a2ak9
                            p_a2ai0 = Functions.belowten' g_a2ahZ
                            (g_a2ahZ, gpart_a2ak9) = Genome.Split.split gpart_a2ak8
                            p_a2ahY = double g_a2ahX
                            (g_a2ahX, gpart_a2ak8) = Genome.Split.split gpart_a2ak7
                            p_a2ahW = double g_a2ahV
                            (g_a2ahV, gpart_a2ak7) = Genome.Split.split gpart_a2ak6
                            p_a2ahU = double g_a2ahT
                            (g_a2ahT, gpart_a2ak6) = Genome.Split.split gpart_a2ak5
                            p_a2ahS = Functions.belowten' g_a2ahR
                            (g_a2ahR, gpart_a2ak5) = Genome.Split.split gpart_a2ak4
                            p_a2ahQ = double g_a2ahP
                            (g_a2ahP, gpart_a2ak4) = Genome.Split.split gpart_a2ak3
                            p_a2ahO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ahN
                            (g_a2ahN, gpart_a2ak3) = Genome.Split.split gpart_a2ak2
                            p_a2ahM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ahL
                            (g_a2ahL, gpart_a2ak2) = Genome.Split.split gpart_a2ak1
                            p_a2ahK = double g_a2ahJ
                            (g_a2ahJ, gpart_a2ak1) = Genome.Split.split gpart_a2ak0
                            p_a2ahI = Functions.belowten' g_a2ahH
                            (g_a2ahH, gpart_a2ak0) = Genome.Split.split gpart_a2ajZ
                            p_a2ahG = double g_a2ahF
                            (g_a2ahF, gpart_a2ajZ) = Genome.Split.split gpart_a2ajY
                            p_a2ahE = Functions.belowten' g_a2ahD
                            (g_a2ahD, gpart_a2ajY) = Genome.Split.split gpart_a2ajX
                            p_a2ahC = double g_a2ahB
                            (g_a2ahB, gpart_a2ajX) = Genome.Split.split gpart_a2ajW
                            p_a2ahA = double g_a2ahz
                            (g_a2ahz, gpart_a2ajW) = Genome.Split.split gpart_a2ajV
                            p_a2ahy = double g_a2ahx
                            (g_a2ahx, gpart_a2ajV) = Genome.Split.split gpart_a2ajU
                            p_a2ahw = Functions.belowten' g_a2ahv
                            (g_a2ahv, gpart_a2ajU) = Genome.Split.split gpart_a2ajT
                            p_a2ahu = double g_a2aht
                            (g_a2aht, gpart_a2ajT) = Genome.Split.split gpart_a2ajS
                            p_a2ahs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ahr
                            (g_a2ahr, gpart_a2ajS) = Genome.Split.split gpart_a2ajR
                            p_a2ahq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ahp
                            (g_a2ahp, gpart_a2ajR) = Genome.Split.split gpart_a2ajQ
                            p_a2aho = Functions.belowten' g_a2ahn
                            (g_a2ahn, gpart_a2ajQ) = Genome.Split.split gpart_a2ajP
                            p_a2ahm = double g_a2ahl
                            (g_a2ahl, gpart_a2ajP) = Genome.Split.split gpart_a2ajO
                            p_a2ahk = double g_a2ahj
                            (g_a2ahj, gpart_a2ajO) = Genome.Split.split gpart_a2ajN
                            p_a2ahi = double g_a2ahh
                            (g_a2ahh, gpart_a2ajN) = Genome.Split.split gpart_a2ajM
                            p_a2ahg = double g_a2ahf
                            (g_a2ahf, gpart_a2ajM) = Genome.Split.split gpart_a2ajL
                            p_a2ahe = double g_a2ahd
                            (g_a2ahd, gpart_a2ajL) = Genome.Split.split gpart_a2ajK
                            p_a2ahc = double g_a2ahb
                            (g_a2ahb, gpart_a2ajK) = Genome.Split.split genome_a2aiB
                          in
                            \ desc_a2aiC
                              -> case desc_a2aiC of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahc)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahe)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahg)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahi)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahk)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahm)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aho)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahq)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahs)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahu)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahw)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahy)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahA)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahC)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahE)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahG)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahI)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahK)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahM)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahO)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahQ)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahS)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahU)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahW)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahY)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ai0)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ai2)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ai4)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ai6)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ai8)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aia)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aic)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aie)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aig)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aii)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aik)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aim)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aio)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aiq)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ais)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aiu)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aiw)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aiy)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aiA)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a2an1
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2anK
                      p_a2an0 = double g_a2amZ
                      (g_a2amZ, gpart_a2anK) = Genome.Split.split gpart_a2anJ
                      p_a2amY = double g_a2amX
                      (g_a2amX, gpart_a2anJ) = Genome.Split.split gpart_a2anI
                      p_a2amW = double g_a2amV
                      (g_a2amV, gpart_a2anI) = Genome.Split.split gpart_a2anH
                      p_a2amU = double g_a2amT
                      (g_a2amT, gpart_a2anH) = Genome.Split.split gpart_a2anG
                      p_a2amS = double g_a2amR
                      (g_a2amR, gpart_a2anG) = Genome.Split.split gpart_a2anF
                      p_a2amQ = double g_a2amP
                      (g_a2amP, gpart_a2anF) = Genome.Split.split gpart_a2anE
                      p_a2amO = Functions.belowten' g_a2amN
                      (g_a2amN, gpart_a2anE) = Genome.Split.split gpart_a2anD
                      p_a2amM = double g_a2amL
                      (g_a2amL, gpart_a2anD) = Genome.Split.split gpart_a2anC
                      p_a2amK = Functions.belowten' g_a2amJ
                      (g_a2amJ, gpart_a2anC) = Genome.Split.split gpart_a2anB
                      p_a2amI = double g_a2amH
                      (g_a2amH, gpart_a2anB) = Genome.Split.split gpart_a2anA
                      p_a2amG = double g_a2amF
                      (g_a2amF, gpart_a2anA) = Genome.Split.split gpart_a2anz
                      p_a2amE = double g_a2amD
                      (g_a2amD, gpart_a2anz) = Genome.Split.split gpart_a2any
                      p_a2amC = Functions.belowten' g_a2amB
                      (g_a2amB, gpart_a2any) = Genome.Split.split gpart_a2anx
                      p_a2amA = double g_a2amz
                      (g_a2amz, gpart_a2anx) = Genome.Split.split gpart_a2anw
                      p_a2amy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2amx
                      (g_a2amx, gpart_a2anw) = Genome.Split.split gpart_a2anv
                      p_a2amw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2amv
                      (g_a2amv, gpart_a2anv) = Genome.Split.split gpart_a2anu
                      p_a2amu = Functions.belowten' g_a2amt
                      (g_a2amt, gpart_a2anu) = Genome.Split.split gpart_a2ant
                      p_a2ams = double g_a2amr
                      (g_a2amr, gpart_a2ant) = Genome.Split.split gpart_a2ans
                      p_a2amq = Functions.belowten' g_a2amp
                      (g_a2amp, gpart_a2ans) = Genome.Split.split gpart_a2anr
                      p_a2amo = double g_a2amn
                      (g_a2amn, gpart_a2anr) = Genome.Split.split gpart_a2anq
                      p_a2amm = double g_a2aml
                      (g_a2aml, gpart_a2anq) = Genome.Split.split gpart_a2anp
                      p_a2amk = double g_a2amj
                      (g_a2amj, gpart_a2anp) = Genome.Split.split gpart_a2ano
                      p_a2ami = Functions.belowten' g_a2amh
                      (g_a2amh, gpart_a2ano) = Genome.Split.split gpart_a2ann
                      p_a2amg = double g_a2amf
                      (g_a2amf, gpart_a2ann) = Genome.Split.split gpart_a2anm
                      p_a2ame
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2amd
                      (g_a2amd, gpart_a2anm) = Genome.Split.split gpart_a2anl
                      p_a2amc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2amb
                      (g_a2amb, gpart_a2anl) = Genome.Split.split gpart_a2ank
                      p_a2ama = double g_a2am9
                      (g_a2am9, gpart_a2ank) = Genome.Split.split gpart_a2anj
                      p_a2am8 = Functions.belowten' g_a2am7
                      (g_a2am7, gpart_a2anj) = Genome.Split.split gpart_a2ani
                      p_a2am6 = double g_a2am5
                      (g_a2am5, gpart_a2ani) = Genome.Split.split gpart_a2anh
                      p_a2am4 = Functions.belowten' g_a2am3
                      (g_a2am3, gpart_a2anh) = Genome.Split.split gpart_a2ang
                      p_a2am2 = double g_a2am1
                      (g_a2am1, gpart_a2ang) = Genome.Split.split gpart_a2anf
                      p_a2am0 = double g_a2alZ
                      (g_a2alZ, gpart_a2anf) = Genome.Split.split gpart_a2ane
                      p_a2alY = double g_a2alX
                      (g_a2alX, gpart_a2ane) = Genome.Split.split gpart_a2and
                      p_a2alW = Functions.belowten' g_a2alV
                      (g_a2alV, gpart_a2and) = Genome.Split.split gpart_a2anc
                      p_a2alU = double g_a2alT
                      (g_a2alT, gpart_a2anc) = Genome.Split.split gpart_a2anb
                      p_a2alS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2alR
                      (g_a2alR, gpart_a2anb) = Genome.Split.split gpart_a2ana
                      p_a2alQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2alP
                      (g_a2alP, gpart_a2ana) = Genome.Split.split gpart_a2an9
                      p_a2alO = Functions.belowten' g_a2alN
                      (g_a2alN, gpart_a2an9) = Genome.Split.split gpart_a2an8
                      p_a2alM = double g_a2alL
                      (g_a2alL, gpart_a2an8) = Genome.Split.split gpart_a2an7
                      p_a2alK = double g_a2alJ
                      (g_a2alJ, gpart_a2an7) = Genome.Split.split gpart_a2an6
                      p_a2alI = double g_a2alH
                      (g_a2alH, gpart_a2an6) = Genome.Split.split gpart_a2an5
                      p_a2alG = double g_a2alF
                      (g_a2alF, gpart_a2an5) = Genome.Split.split gpart_a2an4
                      p_a2alE = double g_a2alD
                      (g_a2alD, gpart_a2an4) = Genome.Split.split gpart_a2an3
                      p_a2alC = double g_a2alB
                      (g_a2alB, gpart_a2an3) = Genome.Split.split genome_a2an1
                    in  \ x_a2anL
                          -> let
                               c_PTB_a2anQ
                                 = ((Data.Fixed.Vector.toVector x_a2anL) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2anO
                                 = ((Data.Fixed.Vector.toVector x_a2anL) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2anM
                                 = ((Data.Fixed.Vector.toVector x_a2anL) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2anV
                                 = ((Data.Fixed.Vector.toVector x_a2anL) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2ao9
                                 = ((Data.Fixed.Vector.toVector x_a2anL) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2alK
                                     * ((p_a2alY + ((c_NPTB_a2anM / p_a2alM) ** p_a2alO))
                                        / (((1 + p_a2alY) + ((c_NPTB_a2anM / p_a2alM) ** p_a2alO))
                                           + ((c_MiRs_a2anO / p_a2alU) ** p_a2alW))))
                                    + (negate (p_a2amS * c_PTB_a2anQ))),
                                   ((p_a2am0
                                     / (1
                                        + (((c_MiRs_a2anO / p_a2am2) ** p_a2am4)
                                           + ((c_PTB_a2anQ / p_a2am6) ** p_a2am8))))
                                    + (negate (p_a2amU * c_NPTB_a2anM))),
                                   ((p_a2ama
                                     * (p_a2amk
                                        / ((1 + p_a2amk) + ((c_RESTc_a2anV / p_a2amg) ** p_a2ami))))
                                    + (negate (p_a2amW * c_MiRs_a2anO))),
                                   ((p_a2amm
                                     * ((p_a2amE
                                         + (((c_NPTB_a2anM / p_a2amo) ** p_a2amq)
                                            + ((c_PTB_a2anQ / p_a2ams) ** p_a2amu)))
                                        / (((1 + p_a2amE)
                                            + (((c_NPTB_a2anM / p_a2amo) ** p_a2amq)
                                               + ((c_PTB_a2anQ / p_a2ams) ** p_a2amu)))
                                           + (((p_a2alC / p_a2amw) ** p_a2amy)
                                              + ((c_MiRs_a2anO / p_a2amA) ** p_a2amC)))))
                                    + (negate (p_a2amY * c_RESTc_a2anV))),
                                   ((p_a2amG
                                     * ((p_a2amQ + ((c_MiRs_a2anO / p_a2amI) ** p_a2amK))
                                        / (((1 + p_a2amQ) + ((c_MiRs_a2anO / p_a2amI) ** p_a2amK))
                                           + ((c_RESTc_a2anV / p_a2amM) ** p_a2amO))))
                                    + (negate (p_a2an0 * c_EndoNeuroTFs_a2ao9)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526232",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526234",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526242",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526244",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526250",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526252",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526253",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526254",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526257",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526258",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526259",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526260",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526261",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526262",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526263",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526264",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526265",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526266",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526268",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526270",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526272",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526274",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526276",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526284",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526286",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526298",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526300",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526302",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2an1
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2aoR
                            p_a2an0 = double g_a2amZ
                            (g_a2amZ, gpart_a2aoR) = Genome.Split.split gpart_a2aoQ
                            p_a2amY = double g_a2amX
                            (g_a2amX, gpart_a2aoQ) = Genome.Split.split gpart_a2aoP
                            p_a2amW = double g_a2amV
                            (g_a2amV, gpart_a2aoP) = Genome.Split.split gpart_a2aoO
                            p_a2amU = double g_a2amT
                            (g_a2amT, gpart_a2aoO) = Genome.Split.split gpart_a2aoN
                            p_a2amS = double g_a2amR
                            (g_a2amR, gpart_a2aoN) = Genome.Split.split gpart_a2aoM
                            p_a2amQ = double g_a2amP
                            (g_a2amP, gpart_a2aoM) = Genome.Split.split gpart_a2aoL
                            p_a2amO = Functions.belowten' g_a2amN
                            (g_a2amN, gpart_a2aoL) = Genome.Split.split gpart_a2aoK
                            p_a2amM = double g_a2amL
                            (g_a2amL, gpart_a2aoK) = Genome.Split.split gpart_a2aoJ
                            p_a2amK = Functions.belowten' g_a2amJ
                            (g_a2amJ, gpart_a2aoJ) = Genome.Split.split gpart_a2aoI
                            p_a2amI = double g_a2amH
                            (g_a2amH, gpart_a2aoI) = Genome.Split.split gpart_a2aoH
                            p_a2amG = double g_a2amF
                            (g_a2amF, gpart_a2aoH) = Genome.Split.split gpart_a2aoG
                            p_a2amE = double g_a2amD
                            (g_a2amD, gpart_a2aoG) = Genome.Split.split gpart_a2aoF
                            p_a2amC = Functions.belowten' g_a2amB
                            (g_a2amB, gpart_a2aoF) = Genome.Split.split gpart_a2aoE
                            p_a2amA = double g_a2amz
                            (g_a2amz, gpart_a2aoE) = Genome.Split.split gpart_a2aoD
                            p_a2amy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2amx
                            (g_a2amx, gpart_a2aoD) = Genome.Split.split gpart_a2aoC
                            p_a2amw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2amv
                            (g_a2amv, gpart_a2aoC) = Genome.Split.split gpart_a2aoB
                            p_a2amu = Functions.belowten' g_a2amt
                            (g_a2amt, gpart_a2aoB) = Genome.Split.split gpart_a2aoA
                            p_a2ams = double g_a2amr
                            (g_a2amr, gpart_a2aoA) = Genome.Split.split gpart_a2aoz
                            p_a2amq = Functions.belowten' g_a2amp
                            (g_a2amp, gpart_a2aoz) = Genome.Split.split gpart_a2aoy
                            p_a2amo = double g_a2amn
                            (g_a2amn, gpart_a2aoy) = Genome.Split.split gpart_a2aox
                            p_a2amm = double g_a2aml
                            (g_a2aml, gpart_a2aox) = Genome.Split.split gpart_a2aow
                            p_a2amk = double g_a2amj
                            (g_a2amj, gpart_a2aow) = Genome.Split.split gpart_a2aov
                            p_a2ami = Functions.belowten' g_a2amh
                            (g_a2amh, gpart_a2aov) = Genome.Split.split gpart_a2aou
                            p_a2amg = double g_a2amf
                            (g_a2amf, gpart_a2aou) = Genome.Split.split gpart_a2aot
                            p_a2ame
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2amd
                            (g_a2amd, gpart_a2aot) = Genome.Split.split gpart_a2aos
                            p_a2amc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2amb
                            (g_a2amb, gpart_a2aos) = Genome.Split.split gpart_a2aor
                            p_a2ama = double g_a2am9
                            (g_a2am9, gpart_a2aor) = Genome.Split.split gpart_a2aoq
                            p_a2am8 = Functions.belowten' g_a2am7
                            (g_a2am7, gpart_a2aoq) = Genome.Split.split gpart_a2aop
                            p_a2am6 = double g_a2am5
                            (g_a2am5, gpart_a2aop) = Genome.Split.split gpart_a2aoo
                            p_a2am4 = Functions.belowten' g_a2am3
                            (g_a2am3, gpart_a2aoo) = Genome.Split.split gpart_a2aon
                            p_a2am2 = double g_a2am1
                            (g_a2am1, gpart_a2aon) = Genome.Split.split gpart_a2aom
                            p_a2am0 = double g_a2alZ
                            (g_a2alZ, gpart_a2aom) = Genome.Split.split gpart_a2aol
                            p_a2alY = double g_a2alX
                            (g_a2alX, gpart_a2aol) = Genome.Split.split gpart_a2aok
                            p_a2alW = Functions.belowten' g_a2alV
                            (g_a2alV, gpart_a2aok) = Genome.Split.split gpart_a2aoj
                            p_a2alU = double g_a2alT
                            (g_a2alT, gpart_a2aoj) = Genome.Split.split gpart_a2aoi
                            p_a2alS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2alR
                            (g_a2alR, gpart_a2aoi) = Genome.Split.split gpart_a2aoh
                            p_a2alQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2alP
                            (g_a2alP, gpart_a2aoh) = Genome.Split.split gpart_a2aog
                            p_a2alO = Functions.belowten' g_a2alN
                            (g_a2alN, gpart_a2aog) = Genome.Split.split gpart_a2aof
                            p_a2alM = double g_a2alL
                            (g_a2alL, gpart_a2aof) = Genome.Split.split gpart_a2aoe
                            p_a2alK = double g_a2alJ
                            (g_a2alJ, gpart_a2aoe) = Genome.Split.split gpart_a2aod
                            p_a2alI = double g_a2alH
                            (g_a2alH, gpart_a2aod) = Genome.Split.split gpart_a2aoc
                            p_a2alG = double g_a2alF
                            (g_a2alF, gpart_a2aoc) = Genome.Split.split gpart_a2aob
                            p_a2alE = double g_a2alD
                            (g_a2alD, gpart_a2aob) = Genome.Split.split gpart_a2aoa
                            p_a2alC = double g_a2alB
                            (g_a2alB, gpart_a2aoa) = Genome.Split.split genome_a2an1
                          in
                            \ desc_a2an2
                              -> case desc_a2an2 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alC)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alE)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alG)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alI)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alK)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alM)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alO)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alQ)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alS)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alU)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alW)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alY)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2am0)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2am2)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2am4)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2am6)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2am8)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ama)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amc)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ame)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amg)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ami)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amk)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amm)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amo)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amq)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ams)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amu)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amw)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amy)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amA)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amC)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amE)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amG)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amI)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amK)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amM)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amO)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amQ)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amS)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amU)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amW)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2amY)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2an0)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a2arr
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2asa
                      p_a2arq = double g_a2arp
                      (g_a2arp, gpart_a2asa) = Genome.Split.split gpart_a2as9
                      p_a2aro = double g_a2arn
                      (g_a2arn, gpart_a2as9) = Genome.Split.split gpart_a2as8
                      p_a2arm = double g_a2arl
                      (g_a2arl, gpart_a2as8) = Genome.Split.split gpart_a2as7
                      p_a2ark = double g_a2arj
                      (g_a2arj, gpart_a2as7) = Genome.Split.split gpart_a2as6
                      p_a2ari = double g_a2arh
                      (g_a2arh, gpart_a2as6) = Genome.Split.split gpart_a2as5
                      p_a2arg = double g_a2arf
                      (g_a2arf, gpart_a2as5) = Genome.Split.split gpart_a2as4
                      p_a2are = Functions.belowten' g_a2ard
                      (g_a2ard, gpart_a2as4) = Genome.Split.split gpart_a2as3
                      p_a2arc = double g_a2arb
                      (g_a2arb, gpart_a2as3) = Genome.Split.split gpart_a2as2
                      p_a2ara = Functions.belowten' g_a2ar9
                      (g_a2ar9, gpart_a2as2) = Genome.Split.split gpart_a2as1
                      p_a2ar8 = double g_a2ar7
                      (g_a2ar7, gpart_a2as1) = Genome.Split.split gpart_a2as0
                      p_a2ar6 = double g_a2ar5
                      (g_a2ar5, gpart_a2as0) = Genome.Split.split gpart_a2arZ
                      p_a2ar4 = double g_a2ar3
                      (g_a2ar3, gpart_a2arZ) = Genome.Split.split gpart_a2arY
                      p_a2ar2 = Functions.belowten' g_a2ar1
                      (g_a2ar1, gpart_a2arY) = Genome.Split.split gpart_a2arX
                      p_a2ar0 = double g_a2aqZ
                      (g_a2aqZ, gpart_a2arX) = Genome.Split.split gpart_a2arW
                      p_a2aqY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqX
                      (g_a2aqX, gpart_a2arW) = Genome.Split.split gpart_a2arV
                      p_a2aqW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqV
                      (g_a2aqV, gpart_a2arV) = Genome.Split.split gpart_a2arU
                      p_a2aqU = Functions.belowten' g_a2aqT
                      (g_a2aqT, gpart_a2arU) = Genome.Split.split gpart_a2arT
                      p_a2aqS = double g_a2aqR
                      (g_a2aqR, gpart_a2arT) = Genome.Split.split gpart_a2arS
                      p_a2aqQ = Functions.belowten' g_a2aqP
                      (g_a2aqP, gpart_a2arS) = Genome.Split.split gpart_a2arR
                      p_a2aqO = double g_a2aqN
                      (g_a2aqN, gpart_a2arR) = Genome.Split.split gpart_a2arQ
                      p_a2aqM = double g_a2aqL
                      (g_a2aqL, gpart_a2arQ) = Genome.Split.split gpart_a2arP
                      p_a2aqK = double g_a2aqJ
                      (g_a2aqJ, gpart_a2arP) = Genome.Split.split gpart_a2arO
                      p_a2aqI = Functions.belowten' g_a2aqH
                      (g_a2aqH, gpart_a2arO) = Genome.Split.split gpart_a2arN
                      p_a2aqG = double g_a2aqF
                      (g_a2aqF, gpart_a2arN) = Genome.Split.split gpart_a2arM
                      p_a2aqE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqD
                      (g_a2aqD, gpart_a2arM) = Genome.Split.split gpart_a2arL
                      p_a2aqC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqB
                      (g_a2aqB, gpart_a2arL) = Genome.Split.split gpart_a2arK
                      p_a2aqA = double g_a2aqz
                      (g_a2aqz, gpart_a2arK) = Genome.Split.split gpart_a2arJ
                      p_a2aqy = Functions.belowten' g_a2aqx
                      (g_a2aqx, gpart_a2arJ) = Genome.Split.split gpart_a2arI
                      p_a2aqw = double g_a2aqv
                      (g_a2aqv, gpart_a2arI) = Genome.Split.split gpart_a2arH
                      p_a2aqu = Functions.belowten' g_a2aqt
                      (g_a2aqt, gpart_a2arH) = Genome.Split.split gpart_a2arG
                      p_a2aqs = double g_a2aqr
                      (g_a2aqr, gpart_a2arG) = Genome.Split.split gpart_a2arF
                      p_a2aqq = double g_a2aqp
                      (g_a2aqp, gpart_a2arF) = Genome.Split.split gpart_a2arE
                      p_a2aqo = double g_a2aqn
                      (g_a2aqn, gpart_a2arE) = Genome.Split.split gpart_a2arD
                      p_a2aqm = Functions.belowten' g_a2aql
                      (g_a2aql, gpart_a2arD) = Genome.Split.split gpart_a2arC
                      p_a2aqk = double g_a2aqj
                      (g_a2aqj, gpart_a2arC) = Genome.Split.split gpart_a2arB
                      p_a2aqi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqh
                      (g_a2aqh, gpart_a2arB) = Genome.Split.split gpart_a2arA
                      p_a2aqg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqf
                      (g_a2aqf, gpart_a2arA) = Genome.Split.split gpart_a2arz
                      p_a2aqe = Functions.belowten' g_a2aqd
                      (g_a2aqd, gpart_a2arz) = Genome.Split.split gpart_a2ary
                      p_a2aqc = double g_a2aqb
                      (g_a2aqb, gpart_a2ary) = Genome.Split.split gpart_a2arx
                      p_a2aqa = double g_a2aq9
                      (g_a2aq9, gpart_a2arx) = Genome.Split.split gpart_a2arw
                      p_a2aq8 = double g_a2aq7
                      (g_a2aq7, gpart_a2arw) = Genome.Split.split gpart_a2arv
                      p_a2aq6 = double g_a2aq5
                      (g_a2aq5, gpart_a2arv) = Genome.Split.split gpart_a2aru
                      p_a2aq4 = double g_a2aq3
                      (g_a2aq3, gpart_a2aru) = Genome.Split.split gpart_a2art
                      p_a2aq2 = double g_a2aq1
                      (g_a2aq1, gpart_a2art) = Genome.Split.split genome_a2arr
                    in  \ x_a2asb
                          -> let
                               c_PTB_a2asg
                                 = ((Data.Fixed.Vector.toVector x_a2asb) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2ase
                                 = ((Data.Fixed.Vector.toVector x_a2asb) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2asc
                                 = ((Data.Fixed.Vector.toVector x_a2asb) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2asl
                                 = ((Data.Fixed.Vector.toVector x_a2asb) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2asz
                                 = ((Data.Fixed.Vector.toVector x_a2asb) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2aqa
                                     * ((p_a2aqo + ((c_NPTB_a2asc / p_a2aqc) ** p_a2aqe))
                                        / (((1 + p_a2aqo) + ((c_NPTB_a2asc / p_a2aqc) ** p_a2aqe))
                                           + ((c_MiRs_a2ase / p_a2aqk) ** p_a2aqm))))
                                    + (negate (p_a2ari * c_PTB_a2asg))),
                                   ((p_a2aqq
                                     / (1
                                        + (((c_MiRs_a2ase / p_a2aqs) ** p_a2aqu)
                                           + ((c_PTB_a2asg / p_a2aqw) ** p_a2aqy))))
                                    + (negate (p_a2ark * c_NPTB_a2asc))),
                                   ((p_a2aqA
                                     * (p_a2aqK
                                        / ((1 + p_a2aqK) + ((c_RESTc_a2asl / p_a2aqG) ** p_a2aqI))))
                                    + (negate (p_a2arm * c_MiRs_a2ase))),
                                   ((p_a2aqM
                                     * ((p_a2ar4
                                         + (((c_NPTB_a2asc / p_a2aqO) ** p_a2aqQ)
                                            + ((c_PTB_a2asg / p_a2aqS) ** p_a2aqU)))
                                        / (((1 + p_a2ar4)
                                            + (((c_NPTB_a2asc / p_a2aqO) ** p_a2aqQ)
                                               + ((c_PTB_a2asg / p_a2aqS) ** p_a2aqU)))
                                           + ((c_MiRs_a2ase / p_a2ar0) ** p_a2ar2))))
                                    + (negate (p_a2aro * c_RESTc_a2asl))),
                                   ((p_a2ar6
                                     * ((p_a2arg + ((c_MiRs_a2ase / p_a2ar8) ** p_a2ara))
                                        / (((1 + p_a2arg) + ((c_MiRs_a2ase / p_a2ar8) ** p_a2ara))
                                           + ((c_RESTc_a2asl / p_a2arc) ** p_a2are))))
                                    + (negate (p_a2arq * c_EndoNeuroTFs_a2asz)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526510",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526516",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526518",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526520",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526524",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526526",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526528",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526530",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526532",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526536",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526538",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526540",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526544",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526548",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526550",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526552",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526554",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526558",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526560",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526568",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526575",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526576",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526577",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526578",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526579",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526580",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526581",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526582",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526583",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526584",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526586",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526588",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2arr
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ath
                            p_a2arq = double g_a2arp
                            (g_a2arp, gpart_a2ath) = Genome.Split.split gpart_a2atg
                            p_a2aro = double g_a2arn
                            (g_a2arn, gpart_a2atg) = Genome.Split.split gpart_a2atf
                            p_a2arm = double g_a2arl
                            (g_a2arl, gpart_a2atf) = Genome.Split.split gpart_a2ate
                            p_a2ark = double g_a2arj
                            (g_a2arj, gpart_a2ate) = Genome.Split.split gpart_a2atd
                            p_a2ari = double g_a2arh
                            (g_a2arh, gpart_a2atd) = Genome.Split.split gpart_a2atc
                            p_a2arg = double g_a2arf
                            (g_a2arf, gpart_a2atc) = Genome.Split.split gpart_a2atb
                            p_a2are = Functions.belowten' g_a2ard
                            (g_a2ard, gpart_a2atb) = Genome.Split.split gpart_a2ata
                            p_a2arc = double g_a2arb
                            (g_a2arb, gpart_a2ata) = Genome.Split.split gpart_a2at9
                            p_a2ara = Functions.belowten' g_a2ar9
                            (g_a2ar9, gpart_a2at9) = Genome.Split.split gpart_a2at8
                            p_a2ar8 = double g_a2ar7
                            (g_a2ar7, gpart_a2at8) = Genome.Split.split gpart_a2at7
                            p_a2ar6 = double g_a2ar5
                            (g_a2ar5, gpart_a2at7) = Genome.Split.split gpart_a2at6
                            p_a2ar4 = double g_a2ar3
                            (g_a2ar3, gpart_a2at6) = Genome.Split.split gpart_a2at5
                            p_a2ar2 = Functions.belowten' g_a2ar1
                            (g_a2ar1, gpart_a2at5) = Genome.Split.split gpart_a2at4
                            p_a2ar0 = double g_a2aqZ
                            (g_a2aqZ, gpart_a2at4) = Genome.Split.split gpart_a2at3
                            p_a2aqY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqX
                            (g_a2aqX, gpart_a2at3) = Genome.Split.split gpart_a2at2
                            p_a2aqW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqV
                            (g_a2aqV, gpart_a2at2) = Genome.Split.split gpart_a2at1
                            p_a2aqU = Functions.belowten' g_a2aqT
                            (g_a2aqT, gpart_a2at1) = Genome.Split.split gpart_a2at0
                            p_a2aqS = double g_a2aqR
                            (g_a2aqR, gpart_a2at0) = Genome.Split.split gpart_a2asZ
                            p_a2aqQ = Functions.belowten' g_a2aqP
                            (g_a2aqP, gpart_a2asZ) = Genome.Split.split gpart_a2asY
                            p_a2aqO = double g_a2aqN
                            (g_a2aqN, gpart_a2asY) = Genome.Split.split gpart_a2asX
                            p_a2aqM = double g_a2aqL
                            (g_a2aqL, gpart_a2asX) = Genome.Split.split gpart_a2asW
                            p_a2aqK = double g_a2aqJ
                            (g_a2aqJ, gpart_a2asW) = Genome.Split.split gpart_a2asV
                            p_a2aqI = Functions.belowten' g_a2aqH
                            (g_a2aqH, gpart_a2asV) = Genome.Split.split gpart_a2asU
                            p_a2aqG = double g_a2aqF
                            (g_a2aqF, gpart_a2asU) = Genome.Split.split gpart_a2asT
                            p_a2aqE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqD
                            (g_a2aqD, gpart_a2asT) = Genome.Split.split gpart_a2asS
                            p_a2aqC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqB
                            (g_a2aqB, gpart_a2asS) = Genome.Split.split gpart_a2asR
                            p_a2aqA = double g_a2aqz
                            (g_a2aqz, gpart_a2asR) = Genome.Split.split gpart_a2asQ
                            p_a2aqy = Functions.belowten' g_a2aqx
                            (g_a2aqx, gpart_a2asQ) = Genome.Split.split gpart_a2asP
                            p_a2aqw = double g_a2aqv
                            (g_a2aqv, gpart_a2asP) = Genome.Split.split gpart_a2asO
                            p_a2aqu = Functions.belowten' g_a2aqt
                            (g_a2aqt, gpart_a2asO) = Genome.Split.split gpart_a2asN
                            p_a2aqs = double g_a2aqr
                            (g_a2aqr, gpart_a2asN) = Genome.Split.split gpart_a2asM
                            p_a2aqq = double g_a2aqp
                            (g_a2aqp, gpart_a2asM) = Genome.Split.split gpart_a2asL
                            p_a2aqo = double g_a2aqn
                            (g_a2aqn, gpart_a2asL) = Genome.Split.split gpart_a2asK
                            p_a2aqm = Functions.belowten' g_a2aql
                            (g_a2aql, gpart_a2asK) = Genome.Split.split gpart_a2asJ
                            p_a2aqk = double g_a2aqj
                            (g_a2aqj, gpart_a2asJ) = Genome.Split.split gpart_a2asI
                            p_a2aqi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqh
                            (g_a2aqh, gpart_a2asI) = Genome.Split.split gpart_a2asH
                            p_a2aqg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aqf
                            (g_a2aqf, gpart_a2asH) = Genome.Split.split gpart_a2asG
                            p_a2aqe = Functions.belowten' g_a2aqd
                            (g_a2aqd, gpart_a2asG) = Genome.Split.split gpart_a2asF
                            p_a2aqc = double g_a2aqb
                            (g_a2aqb, gpart_a2asF) = Genome.Split.split gpart_a2asE
                            p_a2aqa = double g_a2aq9
                            (g_a2aq9, gpart_a2asE) = Genome.Split.split gpart_a2asD
                            p_a2aq8 = double g_a2aq7
                            (g_a2aq7, gpart_a2asD) = Genome.Split.split gpart_a2asC
                            p_a2aq6 = double g_a2aq5
                            (g_a2aq5, gpart_a2asC) = Genome.Split.split gpart_a2asB
                            p_a2aq4 = double g_a2aq3
                            (g_a2aq3, gpart_a2asB) = Genome.Split.split gpart_a2asA
                            p_a2aq2 = double g_a2aq1
                            (g_a2aq1, gpart_a2asA) = Genome.Split.split genome_a2arr
                          in
                            \ desc_a2ars
                              -> case desc_a2ars of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aq2)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aq4)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aq6)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aq8)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqa)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqc)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqe)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqg)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqi)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqk)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqm)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqo)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqq)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqs)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqu)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqw)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqy)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqA)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqC)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqE)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqG)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqI)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqK)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqM)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqO)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqQ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqS)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqU)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqW)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqY)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar0)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar2)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar4)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar6)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar8)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ara)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arc)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2are)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arg)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ari)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ark)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arm)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aro)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arq)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a2avR
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2awA
                      p_a2avQ = double g_a2avP
                      (g_a2avP, gpart_a2awA) = Genome.Split.split gpart_a2awz
                      p_a2avO = double g_a2avN
                      (g_a2avN, gpart_a2awz) = Genome.Split.split gpart_a2awy
                      p_a2avM = double g_a2avL
                      (g_a2avL, gpart_a2awy) = Genome.Split.split gpart_a2awx
                      p_a2avK = double g_a2avJ
                      (g_a2avJ, gpart_a2awx) = Genome.Split.split gpart_a2aww
                      p_a2avI = double g_a2avH
                      (g_a2avH, gpart_a2aww) = Genome.Split.split gpart_a2awv
                      p_a2avG = double g_a2avF
                      (g_a2avF, gpart_a2awv) = Genome.Split.split gpart_a2awu
                      p_a2avE = Functions.belowten' g_a2avD
                      (g_a2avD, gpart_a2awu) = Genome.Split.split gpart_a2awt
                      p_a2avC = double g_a2avB
                      (g_a2avB, gpart_a2awt) = Genome.Split.split gpart_a2aws
                      p_a2avA = Functions.belowten' g_a2avz
                      (g_a2avz, gpart_a2aws) = Genome.Split.split gpart_a2awr
                      p_a2avy = double g_a2avx
                      (g_a2avx, gpart_a2awr) = Genome.Split.split gpart_a2awq
                      p_a2avw = double g_a2avv
                      (g_a2avv, gpart_a2awq) = Genome.Split.split gpart_a2awp
                      p_a2avu = double g_a2avt
                      (g_a2avt, gpart_a2awp) = Genome.Split.split gpart_a2awo
                      p_a2avs = Functions.belowten' g_a2avr
                      (g_a2avr, gpart_a2awo) = Genome.Split.split gpart_a2awn
                      p_a2avq = double g_a2avp
                      (g_a2avp, gpart_a2awn) = Genome.Split.split gpart_a2awm
                      p_a2avo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avn
                      (g_a2avn, gpart_a2awm) = Genome.Split.split gpart_a2awl
                      p_a2avm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avl
                      (g_a2avl, gpart_a2awl) = Genome.Split.split gpart_a2awk
                      p_a2avk = Functions.belowten' g_a2avj
                      (g_a2avj, gpart_a2awk) = Genome.Split.split gpart_a2awj
                      p_a2avi = double g_a2avh
                      (g_a2avh, gpart_a2awj) = Genome.Split.split gpart_a2awi
                      p_a2avg = Functions.belowten' g_a2avf
                      (g_a2avf, gpart_a2awi) = Genome.Split.split gpart_a2awh
                      p_a2ave = double g_a2avd
                      (g_a2avd, gpart_a2awh) = Genome.Split.split gpart_a2awg
                      p_a2avc = double g_a2avb
                      (g_a2avb, gpart_a2awg) = Genome.Split.split gpart_a2awf
                      p_a2ava = double g_a2av9
                      (g_a2av9, gpart_a2awf) = Genome.Split.split gpart_a2awe
                      p_a2av8 = Functions.belowten' g_a2av7
                      (g_a2av7, gpart_a2awe) = Genome.Split.split gpart_a2awd
                      p_a2av6 = double g_a2av5
                      (g_a2av5, gpart_a2awd) = Genome.Split.split gpart_a2awc
                      p_a2av4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2av3
                      (g_a2av3, gpart_a2awc) = Genome.Split.split gpart_a2awb
                      p_a2av2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2av1
                      (g_a2av1, gpart_a2awb) = Genome.Split.split gpart_a2awa
                      p_a2av0 = double g_a2auZ
                      (g_a2auZ, gpart_a2awa) = Genome.Split.split gpart_a2aw9
                      p_a2auY = Functions.belowten' g_a2auX
                      (g_a2auX, gpart_a2aw9) = Genome.Split.split gpart_a2aw8
                      p_a2auW = double g_a2auV
                      (g_a2auV, gpart_a2aw8) = Genome.Split.split gpart_a2aw7
                      p_a2auU = Functions.belowten' g_a2auT
                      (g_a2auT, gpart_a2aw7) = Genome.Split.split gpart_a2aw6
                      p_a2auS = double g_a2auR
                      (g_a2auR, gpart_a2aw6) = Genome.Split.split gpart_a2aw5
                      p_a2auQ = double g_a2auP
                      (g_a2auP, gpart_a2aw5) = Genome.Split.split gpart_a2aw4
                      p_a2auO = double g_a2auN
                      (g_a2auN, gpart_a2aw4) = Genome.Split.split gpart_a2aw3
                      p_a2auM = Functions.belowten' g_a2auL
                      (g_a2auL, gpart_a2aw3) = Genome.Split.split gpart_a2aw2
                      p_a2auK = double g_a2auJ
                      (g_a2auJ, gpart_a2aw2) = Genome.Split.split gpart_a2aw1
                      p_a2auI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2auH
                      (g_a2auH, gpart_a2aw1) = Genome.Split.split gpart_a2aw0
                      p_a2auG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2auF
                      (g_a2auF, gpart_a2aw0) = Genome.Split.split gpart_a2avZ
                      p_a2auE = Functions.belowten' g_a2auD
                      (g_a2auD, gpart_a2avZ) = Genome.Split.split gpart_a2avY
                      p_a2auC = double g_a2auB
                      (g_a2auB, gpart_a2avY) = Genome.Split.split gpart_a2avX
                      p_a2auA = double g_a2auz
                      (g_a2auz, gpart_a2avX) = Genome.Split.split gpart_a2avW
                      p_a2auy = double g_a2aux
                      (g_a2aux, gpart_a2avW) = Genome.Split.split gpart_a2avV
                      p_a2auw = double g_a2auv
                      (g_a2auv, gpart_a2avV) = Genome.Split.split gpart_a2avU
                      p_a2auu = double g_a2aut
                      (g_a2aut, gpart_a2avU) = Genome.Split.split gpart_a2avT
                      p_a2aus = double g_a2aur
                      (g_a2aur, gpart_a2avT) = Genome.Split.split genome_a2avR
                    in  \ x_a2awB
                          -> let
                               c_PTB_a2awG
                                 = ((Data.Fixed.Vector.toVector x_a2awB) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2awE
                                 = ((Data.Fixed.Vector.toVector x_a2awB) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2awC
                                 = ((Data.Fixed.Vector.toVector x_a2awB) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2awL
                                 = ((Data.Fixed.Vector.toVector x_a2awB) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2awZ
                                 = ((Data.Fixed.Vector.toVector x_a2awB) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2auA
                                     * ((p_a2auO + ((c_NPTB_a2awC / p_a2auC) ** p_a2auE))
                                        / (((1 + p_a2auO) + ((c_NPTB_a2awC / p_a2auC) ** p_a2auE))
                                           + (((p_a2aus / p_a2auG) ** p_a2auI)
                                              + ((c_MiRs_a2awE / p_a2auK) ** p_a2auM)))))
                                    + (negate (p_a2avI * c_PTB_a2awG))),
                                   ((p_a2auQ
                                     / (1
                                        + (((c_MiRs_a2awE / p_a2auS) ** p_a2auU)
                                           + ((c_PTB_a2awG / p_a2auW) ** p_a2auY))))
                                    + (negate (p_a2avK * c_NPTB_a2awC))),
                                   ((p_a2av0
                                     * (p_a2ava
                                        / ((1 + p_a2ava) + ((c_RESTc_a2awL / p_a2av6) ** p_a2av8))))
                                    + (negate (p_a2avM * c_MiRs_a2awE))),
                                   ((p_a2avc
                                     * ((p_a2avu
                                         + (((c_NPTB_a2awC / p_a2ave) ** p_a2avg)
                                            + ((c_PTB_a2awG / p_a2avi) ** p_a2avk)))
                                        / (((1 + p_a2avu)
                                            + (((c_NPTB_a2awC / p_a2ave) ** p_a2avg)
                                               + ((c_PTB_a2awG / p_a2avi) ** p_a2avk)))
                                           + ((c_MiRs_a2awE / p_a2avq) ** p_a2avs))))
                                    + (negate (p_a2avO * c_RESTc_a2awL))),
                                   ((p_a2avw
                                     * ((p_a2avG + ((c_MiRs_a2awE / p_a2avy) ** p_a2avA))
                                        / (((1 + p_a2avG) + ((c_MiRs_a2awE / p_a2avy) ** p_a2avA))
                                           + ((c_RESTc_a2awL / p_a2avC) ** p_a2avE))))
                                    + (negate (p_a2avQ * c_EndoNeuroTFs_a2awZ)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526777",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526778",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526779",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526780",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526781",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526782",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526783",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526784",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526785",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526786",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526787",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526788",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526789",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526790",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526791",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526792",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526793",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526794",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526795",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526796",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526797",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526798",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526799",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526800",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526801",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526802",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526803",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526804",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526805",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526806",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526807",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526808",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526809",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526810",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526811",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526812",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526813",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526814",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526815",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526816",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526817",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526818",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526819",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526820",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526821",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526822",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526823",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526824",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526825",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526826",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526827",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526828",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526829",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526830",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526831",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526832",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526833",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526834",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526835",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526836",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526837",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526838",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526839",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526840",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526841",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526842",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526843",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526844",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526845",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526846",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526847",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526848",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526849",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526850",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526851",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526852",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526853",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526854",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526855",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526856",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526858",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526860",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526862",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2avR
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2axH
                            p_a2avQ = double g_a2avP
                            (g_a2avP, gpart_a2axH) = Genome.Split.split gpart_a2axG
                            p_a2avO = double g_a2avN
                            (g_a2avN, gpart_a2axG) = Genome.Split.split gpart_a2axF
                            p_a2avM = double g_a2avL
                            (g_a2avL, gpart_a2axF) = Genome.Split.split gpart_a2axE
                            p_a2avK = double g_a2avJ
                            (g_a2avJ, gpart_a2axE) = Genome.Split.split gpart_a2axD
                            p_a2avI = double g_a2avH
                            (g_a2avH, gpart_a2axD) = Genome.Split.split gpart_a2axC
                            p_a2avG = double g_a2avF
                            (g_a2avF, gpart_a2axC) = Genome.Split.split gpart_a2axB
                            p_a2avE = Functions.belowten' g_a2avD
                            (g_a2avD, gpart_a2axB) = Genome.Split.split gpart_a2axA
                            p_a2avC = double g_a2avB
                            (g_a2avB, gpart_a2axA) = Genome.Split.split gpart_a2axz
                            p_a2avA = Functions.belowten' g_a2avz
                            (g_a2avz, gpart_a2axz) = Genome.Split.split gpart_a2axy
                            p_a2avy = double g_a2avx
                            (g_a2avx, gpart_a2axy) = Genome.Split.split gpart_a2axx
                            p_a2avw = double g_a2avv
                            (g_a2avv, gpart_a2axx) = Genome.Split.split gpart_a2axw
                            p_a2avu = double g_a2avt
                            (g_a2avt, gpart_a2axw) = Genome.Split.split gpart_a2axv
                            p_a2avs = Functions.belowten' g_a2avr
                            (g_a2avr, gpart_a2axv) = Genome.Split.split gpart_a2axu
                            p_a2avq = double g_a2avp
                            (g_a2avp, gpart_a2axu) = Genome.Split.split gpart_a2axt
                            p_a2avo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avn
                            (g_a2avn, gpart_a2axt) = Genome.Split.split gpart_a2axs
                            p_a2avm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avl
                            (g_a2avl, gpart_a2axs) = Genome.Split.split gpart_a2axr
                            p_a2avk = Functions.belowten' g_a2avj
                            (g_a2avj, gpart_a2axr) = Genome.Split.split gpart_a2axq
                            p_a2avi = double g_a2avh
                            (g_a2avh, gpart_a2axq) = Genome.Split.split gpart_a2axp
                            p_a2avg = Functions.belowten' g_a2avf
                            (g_a2avf, gpart_a2axp) = Genome.Split.split gpart_a2axo
                            p_a2ave = double g_a2avd
                            (g_a2avd, gpart_a2axo) = Genome.Split.split gpart_a2axn
                            p_a2avc = double g_a2avb
                            (g_a2avb, gpart_a2axn) = Genome.Split.split gpart_a2axm
                            p_a2ava = double g_a2av9
                            (g_a2av9, gpart_a2axm) = Genome.Split.split gpart_a2axl
                            p_a2av8 = Functions.belowten' g_a2av7
                            (g_a2av7, gpart_a2axl) = Genome.Split.split gpart_a2axk
                            p_a2av6 = double g_a2av5
                            (g_a2av5, gpart_a2axk) = Genome.Split.split gpart_a2axj
                            p_a2av4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2av3
                            (g_a2av3, gpart_a2axj) = Genome.Split.split gpart_a2axi
                            p_a2av2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2av1
                            (g_a2av1, gpart_a2axi) = Genome.Split.split gpart_a2axh
                            p_a2av0 = double g_a2auZ
                            (g_a2auZ, gpart_a2axh) = Genome.Split.split gpart_a2axg
                            p_a2auY = Functions.belowten' g_a2auX
                            (g_a2auX, gpart_a2axg) = Genome.Split.split gpart_a2axf
                            p_a2auW = double g_a2auV
                            (g_a2auV, gpart_a2axf) = Genome.Split.split gpart_a2axe
                            p_a2auU = Functions.belowten' g_a2auT
                            (g_a2auT, gpart_a2axe) = Genome.Split.split gpart_a2axd
                            p_a2auS = double g_a2auR
                            (g_a2auR, gpart_a2axd) = Genome.Split.split gpart_a2axc
                            p_a2auQ = double g_a2auP
                            (g_a2auP, gpart_a2axc) = Genome.Split.split gpart_a2axb
                            p_a2auO = double g_a2auN
                            (g_a2auN, gpart_a2axb) = Genome.Split.split gpart_a2axa
                            p_a2auM = Functions.belowten' g_a2auL
                            (g_a2auL, gpart_a2axa) = Genome.Split.split gpart_a2ax9
                            p_a2auK = double g_a2auJ
                            (g_a2auJ, gpart_a2ax9) = Genome.Split.split gpart_a2ax8
                            p_a2auI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2auH
                            (g_a2auH, gpart_a2ax8) = Genome.Split.split gpart_a2ax7
                            p_a2auG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2auF
                            (g_a2auF, gpart_a2ax7) = Genome.Split.split gpart_a2ax6
                            p_a2auE = Functions.belowten' g_a2auD
                            (g_a2auD, gpart_a2ax6) = Genome.Split.split gpart_a2ax5
                            p_a2auC = double g_a2auB
                            (g_a2auB, gpart_a2ax5) = Genome.Split.split gpart_a2ax4
                            p_a2auA = double g_a2auz
                            (g_a2auz, gpart_a2ax4) = Genome.Split.split gpart_a2ax3
                            p_a2auy = double g_a2aux
                            (g_a2aux, gpart_a2ax3) = Genome.Split.split gpart_a2ax2
                            p_a2auw = double g_a2auv
                            (g_a2auv, gpart_a2ax2) = Genome.Split.split gpart_a2ax1
                            p_a2auu = double g_a2aut
                            (g_a2aut, gpart_a2ax1) = Genome.Split.split gpart_a2ax0
                            p_a2aus = double g_a2aur
                            (g_a2aur, gpart_a2ax0) = Genome.Split.split genome_a2avR
                          in
                            \ desc_a2avS
                              -> case desc_a2avS of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aus)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auu)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auw)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auy)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auA)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auC)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auE)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auG)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auI)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auK)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auM)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auO)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auQ)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auS)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auU)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auW)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auY)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2av0)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2av2)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2av4)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2av6)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2av8)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ava)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avc)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ave)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avg)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avi)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avk)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avm)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avo)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avq)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avs)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avu)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avw)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avy)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avA)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avC)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avE)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avG)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avI)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avK)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avM)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avO)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avQ)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asWP
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXy
                      p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                      (g_asWN, gpart_asXy) = Genome.Split.split gpart_asXx
                      p_asWM = code-0.1.0.0:Genome.FixedList.Functions.double g_asWL
                      (g_asWL, gpart_asXx) = Genome.Split.split gpart_asXw
                      p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                      (g_asWJ, gpart_asXw) = Genome.Split.split gpart_asXv
                      p_asWI = code-0.1.0.0:Genome.FixedList.Functions.double g_asWH
                      (g_asWH, gpart_asXv) = Genome.Split.split gpart_asXu
                      p_asWG = code-0.1.0.0:Genome.FixedList.Functions.double g_asWF
                      (g_asWF, gpart_asXu) = Genome.Split.split gpart_asXt
                      p_asWE = code-0.1.0.0:Genome.FixedList.Functions.double g_asWD
                      (g_asWD, gpart_asXt) = Genome.Split.split gpart_asXs
                      p_asWC = Functions.belowten' g_asWB
                      (g_asWB, gpart_asXs) = Genome.Split.split gpart_asXr
                      p_asWA = code-0.1.0.0:Genome.FixedList.Functions.double g_asWz
                      (g_asWz, gpart_asXr) = Genome.Split.split gpart_asXq
                      p_asWy = Functions.belowten' g_asWx
                      (g_asWx, gpart_asXq) = Genome.Split.split gpart_asXp
                      p_asWw = code-0.1.0.0:Genome.FixedList.Functions.double g_asWv
                      (g_asWv, gpart_asXp) = Genome.Split.split gpart_asXo
                      p_asWu = code-0.1.0.0:Genome.FixedList.Functions.double g_asWt
                      (g_asWt, gpart_asXo) = Genome.Split.split gpart_asXn
                      p_asWs = code-0.1.0.0:Genome.FixedList.Functions.double g_asWr
                      (g_asWr, gpart_asXn) = Genome.Split.split gpart_asXm
                      p_asWq = Functions.belowten' g_asWp
                      (g_asWp, gpart_asXm) = Genome.Split.split gpart_asXl
                      p_asWo = code-0.1.0.0:Genome.FixedList.Functions.double g_asWn
                      (g_asWn, gpart_asXl) = Genome.Split.split gpart_asXk
                      p_asWm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWl
                      (g_asWl, gpart_asXk) = Genome.Split.split gpart_asXj
                      p_asWk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWj
                      (g_asWj, gpart_asXj) = Genome.Split.split gpart_asXi
                      p_asWi = Functions.belowten' g_asWh
                      (g_asWh, gpart_asXi) = Genome.Split.split gpart_asXh
                      p_asWg = code-0.1.0.0:Genome.FixedList.Functions.double g_asWf
                      (g_asWf, gpart_asXh) = Genome.Split.split gpart_asXg
                      p_asWe = Functions.belowten' g_asWd
                      (g_asWd, gpart_asXg) = Genome.Split.split gpart_asXf
                      p_asWc = code-0.1.0.0:Genome.FixedList.Functions.double g_asWb
                      (g_asWb, gpart_asXf) = Genome.Split.split gpart_asXe
                      p_asWa = code-0.1.0.0:Genome.FixedList.Functions.double g_asW9
                      (g_asW9, gpart_asXe) = Genome.Split.split gpart_asXd
                      p_asW8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW7
                      (g_asW7, gpart_asXd) = Genome.Split.split gpart_asXc
                      p_asW6 = Functions.belowten' g_asW5
                      (g_asW5, gpart_asXc) = Genome.Split.split gpart_asXb
                      p_asW4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW3
                      (g_asW3, gpart_asXb) = Genome.Split.split gpart_asXa
                      p_asW2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW1
                      (g_asW1, gpart_asXa) = Genome.Split.split gpart_asX9
                      p_asW0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVZ
                      (g_asVZ, gpart_asX9) = Genome.Split.split gpart_asX8
                      p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                      (g_asVX, gpart_asX8) = Genome.Split.split gpart_asX7
                      p_asVW = Functions.belowten' g_asVV
                      (g_asVV, gpart_asX7) = Genome.Split.split gpart_asX6
                      p_asVU = code-0.1.0.0:Genome.FixedList.Functions.double g_asVT
                      (g_asVT, gpart_asX6) = Genome.Split.split gpart_asX5
                      p_asVS = Functions.belowten' g_asVR
                      (g_asVR, gpart_asX5) = Genome.Split.split gpart_asX4
                      p_asVQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVP
                      (g_asVP, gpart_asX4) = Genome.Split.split gpart_asX3
                      p_asVO = code-0.1.0.0:Genome.FixedList.Functions.double g_asVN
                      (g_asVN, gpart_asX3) = Genome.Split.split gpart_asX2
                      p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                      (g_asVL, gpart_asX2) = Genome.Split.split gpart_asX1
                      p_asVK = Functions.belowten' g_asVJ
                      (g_asVJ, gpart_asX1) = Genome.Split.split gpart_asX0
                      p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                      (g_asVH, gpart_asX0) = Genome.Split.split gpart_asWZ
                      p_asVG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVF
                      (g_asVF, gpart_asWZ) = Genome.Split.split gpart_asWY
                      p_asVE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVD
                      (g_asVD, gpart_asWY) = Genome.Split.split gpart_asWX
                      p_asVC = Functions.belowten' g_asVB
                      (g_asVB, gpart_asWX) = Genome.Split.split gpart_asWW
                      p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                      (g_asVz, gpart_asWW) = Genome.Split.split gpart_asWV
                      p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                      (g_asVx, gpart_asWV) = Genome.Split.split gpart_asWU
                      p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                      (g_asVv, gpart_asWU) = Genome.Split.split gpart_asWT
                      p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                      (g_asVt, gpart_asWT) = Genome.Split.split gpart_asWS
                      p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                      (g_asVr, gpart_asWS) = Genome.Split.split gpart_asWR
                      p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                      (g_asVp, gpart_asWR) = Genome.Split.split genome_asWP
                    in
                      [Reaction
                         (\ x_asXz
                            -> let
                                 c_MiRs_asXC = ((toVector x_asXz) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asXA = ((toVector x_asXz) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asVy
                                  * ((p_asVM + ((c_NPTB_asXA / p_asVA) ** p_asVC))
                                     / (((1 + p_asVM) + ((c_NPTB_asXA / p_asVA) ** p_asVC))
                                        + ((c_MiRs_asXC / p_asVI) ** p_asVK)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXD
                            -> let
                                 c_MiRs_asXE = ((toVector x_asXD) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXF = ((toVector x_asXD) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVO
                                  / (1
                                     + (((c_MiRs_asXE / p_asVQ) ** p_asVS)
                                        + ((c_PTB_asXF / p_asVU) ** p_asVW)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asXG
                            -> let c_RESTc_asXH = ((toVector x_asXG) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asVY
                                  * ((p_asW8 + ((p_asVu / p_asW0) ** p_asW2))
                                     / (((1 + p_asW8) + ((p_asVu / p_asW0) ** p_asW2))
                                        + ((c_RESTc_asXH / p_asW4) ** p_asW6)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asXI
                            -> let
                                 c_MiRs_asXN = ((toVector x_asXI) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXK = ((toVector x_asXI) Data.Vector.Unboxed.! 0)
                                 c_NPTB_asXJ = ((toVector x_asXI) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asWa
                                  * ((p_asWs
                                      + (((c_NPTB_asXJ / p_asWc) ** p_asWe)
                                         + ((c_PTB_asXK / p_asWg) ** p_asWi)))
                                     / (((1 + p_asWs)
                                         + (((c_NPTB_asXJ / p_asWc) ** p_asWe)
                                            + ((c_PTB_asXK / p_asWg) ** p_asWi)))
                                        + (((p_asVq / p_asWk) ** p_asWm)
                                           + ((c_MiRs_asXN / p_asWo) ** p_asWq))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asXO
                            -> let
                                 c_RESTc_asXR = ((toVector x_asXO) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asXP = ((toVector x_asXO) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asWu
                                  * ((p_asWE + ((c_MiRs_asXP / p_asWw) ** p_asWy))
                                     / (((1 + p_asWE) + ((c_MiRs_asXP / p_asWw) ** p_asWy))
                                        + ((c_RESTc_asXR / p_asWA) ** p_asWC)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asXS
                            -> let c_PTB_asXT = ((toVector x_asXS) Data.Vector.Unboxed.! 0)
                               in (p_asWG * c_PTB_asXT))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXU
                            -> let c_NPTB_asXV = ((toVector x_asXU) Data.Vector.Unboxed.! 1)
                               in (p_asWI * c_NPTB_asXV))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asXW
                            -> let c_MiRs_asXX = ((toVector x_asXW) Data.Vector.Unboxed.! 2)
                               in (p_asWK * c_MiRs_asXX))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asXY
                            -> let c_RESTc_asXZ = ((toVector x_asXY) Data.Vector.Unboxed.! 3)
                               in (p_asWM * c_RESTc_asXZ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asY0
                            -> let
                                 c_EndoNeuroTFs_asY1 = ((toVector x_asY0) Data.Vector.Unboxed.! 4)
                               in (p_asWO * c_EndoNeuroTFs_asY1))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120998",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121000",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121020",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121022",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121028",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121036",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121038",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121040",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121042",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121046",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121048",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121051",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121052",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121053",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121054",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121055",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121056",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121057",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121058",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121059",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121060",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121061",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121062",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121063",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121064",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121067",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121068",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121069",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121070",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asWP
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYO
                            p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                            (g_asWN, gpart_asYO) = Genome.Split.split gpart_asYN
                            p_asWM = code-0.1.0.0:Genome.FixedList.Functions.double g_asWL
                            (g_asWL, gpart_asYN) = Genome.Split.split gpart_asYM
                            p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                            (g_asWJ, gpart_asYM) = Genome.Split.split gpart_asYL
                            p_asWI = code-0.1.0.0:Genome.FixedList.Functions.double g_asWH
                            (g_asWH, gpart_asYL) = Genome.Split.split gpart_asYK
                            p_asWG = code-0.1.0.0:Genome.FixedList.Functions.double g_asWF
                            (g_asWF, gpart_asYK) = Genome.Split.split gpart_asYJ
                            p_asWE = code-0.1.0.0:Genome.FixedList.Functions.double g_asWD
                            (g_asWD, gpart_asYJ) = Genome.Split.split gpart_asYI
                            p_asWC = Functions.belowten' g_asWB
                            (g_asWB, gpart_asYI) = Genome.Split.split gpart_asYH
                            p_asWA = code-0.1.0.0:Genome.FixedList.Functions.double g_asWz
                            (g_asWz, gpart_asYH) = Genome.Split.split gpart_asYG
                            p_asWy = Functions.belowten' g_asWx
                            (g_asWx, gpart_asYG) = Genome.Split.split gpart_asYF
                            p_asWw = code-0.1.0.0:Genome.FixedList.Functions.double g_asWv
                            (g_asWv, gpart_asYF) = Genome.Split.split gpart_asYE
                            p_asWu = code-0.1.0.0:Genome.FixedList.Functions.double g_asWt
                            (g_asWt, gpart_asYE) = Genome.Split.split gpart_asYD
                            p_asWs = code-0.1.0.0:Genome.FixedList.Functions.double g_asWr
                            (g_asWr, gpart_asYD) = Genome.Split.split gpart_asYC
                            p_asWq = Functions.belowten' g_asWp
                            (g_asWp, gpart_asYC) = Genome.Split.split gpart_asYB
                            p_asWo = code-0.1.0.0:Genome.FixedList.Functions.double g_asWn
                            (g_asWn, gpart_asYB) = Genome.Split.split gpart_asYA
                            p_asWm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWl
                            (g_asWl, gpart_asYA) = Genome.Split.split gpart_asYz
                            p_asWk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWj
                            (g_asWj, gpart_asYz) = Genome.Split.split gpart_asYy
                            p_asWi = Functions.belowten' g_asWh
                            (g_asWh, gpart_asYy) = Genome.Split.split gpart_asYx
                            p_asWg = code-0.1.0.0:Genome.FixedList.Functions.double g_asWf
                            (g_asWf, gpart_asYx) = Genome.Split.split gpart_asYw
                            p_asWe = Functions.belowten' g_asWd
                            (g_asWd, gpart_asYw) = Genome.Split.split gpart_asYv
                            p_asWc = code-0.1.0.0:Genome.FixedList.Functions.double g_asWb
                            (g_asWb, gpart_asYv) = Genome.Split.split gpart_asYu
                            p_asWa = code-0.1.0.0:Genome.FixedList.Functions.double g_asW9
                            (g_asW9, gpart_asYu) = Genome.Split.split gpart_asYt
                            p_asW8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW7
                            (g_asW7, gpart_asYt) = Genome.Split.split gpart_asYs
                            p_asW6 = Functions.belowten' g_asW5
                            (g_asW5, gpart_asYs) = Genome.Split.split gpart_asYr
                            p_asW4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW3
                            (g_asW3, gpart_asYr) = Genome.Split.split gpart_asYq
                            p_asW2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW1
                            (g_asW1, gpart_asYq) = Genome.Split.split gpart_asYp
                            p_asW0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVZ
                            (g_asVZ, gpart_asYp) = Genome.Split.split gpart_asYo
                            p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                            (g_asVX, gpart_asYo) = Genome.Split.split gpart_asYn
                            p_asVW = Functions.belowten' g_asVV
                            (g_asVV, gpart_asYn) = Genome.Split.split gpart_asYm
                            p_asVU = code-0.1.0.0:Genome.FixedList.Functions.double g_asVT
                            (g_asVT, gpart_asYm) = Genome.Split.split gpart_asYl
                            p_asVS = Functions.belowten' g_asVR
                            (g_asVR, gpart_asYl) = Genome.Split.split gpart_asYk
                            p_asVQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVP
                            (g_asVP, gpart_asYk) = Genome.Split.split gpart_asYj
                            p_asVO = code-0.1.0.0:Genome.FixedList.Functions.double g_asVN
                            (g_asVN, gpart_asYj) = Genome.Split.split gpart_asYi
                            p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                            (g_asVL, gpart_asYi) = Genome.Split.split gpart_asYh
                            p_asVK = Functions.belowten' g_asVJ
                            (g_asVJ, gpart_asYh) = Genome.Split.split gpart_asYg
                            p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                            (g_asVH, gpart_asYg) = Genome.Split.split gpart_asYf
                            p_asVG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVF
                            (g_asVF, gpart_asYf) = Genome.Split.split gpart_asYe
                            p_asVE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVD
                            (g_asVD, gpart_asYe) = Genome.Split.split gpart_asYd
                            p_asVC = Functions.belowten' g_asVB
                            (g_asVB, gpart_asYd) = Genome.Split.split gpart_asYc
                            p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                            (g_asVz, gpart_asYc) = Genome.Split.split gpart_asYb
                            p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                            (g_asVx, gpart_asYb) = Genome.Split.split gpart_asYa
                            p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                            (g_asVv, gpart_asYa) = Genome.Split.split gpart_asY9
                            p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                            (g_asVt, gpart_asY9) = Genome.Split.split gpart_asY8
                            p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                            (g_asVr, gpart_asY8) = Genome.Split.split gpart_asY7
                            p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                            (g_asVp, gpart_asY7) = Genome.Split.split genome_asWP
                          in
                            \ desc_asWQ
                              -> case desc_asWQ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVq)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVs)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVu)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVw)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVy)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVA)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVC)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVE)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVG)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVI)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVK)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVM)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVO)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVQ)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVS)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVU)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVW)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVY)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW0)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW2)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW4)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW6)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW8)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWa)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWc)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWe)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWg)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWi)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWk)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWm)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWo)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWq)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWs)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWu)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWw)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWy)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWA)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWC)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWE)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWG)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWI)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWK)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWM)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWO)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_at0V
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1E
                      p_at0U = code-0.1.0.0:Genome.FixedList.Functions.double g_at0T
                      (g_at0T, gpart_at1E) = Genome.Split.split gpart_at1D
                      p_at0S = code-0.1.0.0:Genome.FixedList.Functions.double g_at0R
                      (g_at0R, gpart_at1D) = Genome.Split.split gpart_at1C
                      p_at0Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0P
                      (g_at0P, gpart_at1C) = Genome.Split.split gpart_at1B
                      p_at0O = code-0.1.0.0:Genome.FixedList.Functions.double g_at0N
                      (g_at0N, gpart_at1B) = Genome.Split.split gpart_at1A
                      p_at0M = code-0.1.0.0:Genome.FixedList.Functions.double g_at0L
                      (g_at0L, gpart_at1A) = Genome.Split.split gpart_at1z
                      p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                      (g_at0J, gpart_at1z) = Genome.Split.split gpart_at1y
                      p_at0I = Functions.belowten' g_at0H
                      (g_at0H, gpart_at1y) = Genome.Split.split gpart_at1x
                      p_at0G = code-0.1.0.0:Genome.FixedList.Functions.double g_at0F
                      (g_at0F, gpart_at1x) = Genome.Split.split gpart_at1w
                      p_at0E = Functions.belowten' g_at0D
                      (g_at0D, gpart_at1w) = Genome.Split.split gpart_at1v
                      p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                      (g_at0B, gpart_at1v) = Genome.Split.split gpart_at1u
                      p_at0A = code-0.1.0.0:Genome.FixedList.Functions.double g_at0z
                      (g_at0z, gpart_at1u) = Genome.Split.split gpart_at1t
                      p_at0y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0x
                      (g_at0x, gpart_at1t) = Genome.Split.split gpart_at1s
                      p_at0w = Functions.belowten' g_at0v
                      (g_at0v, gpart_at1s) = Genome.Split.split gpart_at1r
                      p_at0u = code-0.1.0.0:Genome.FixedList.Functions.double g_at0t
                      (g_at0t, gpart_at1r) = Genome.Split.split gpart_at1q
                      p_at0s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0r
                      (g_at0r, gpart_at1q) = Genome.Split.split gpart_at1p
                      p_at0q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0p
                      (g_at0p, gpart_at1p) = Genome.Split.split gpart_at1o
                      p_at0o = Functions.belowten' g_at0n
                      (g_at0n, gpart_at1o) = Genome.Split.split gpart_at1n
                      p_at0m = code-0.1.0.0:Genome.FixedList.Functions.double g_at0l
                      (g_at0l, gpart_at1n) = Genome.Split.split gpart_at1m
                      p_at0k = Functions.belowten' g_at0j
                      (g_at0j, gpart_at1m) = Genome.Split.split gpart_at1l
                      p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                      (g_at0h, gpart_at1l) = Genome.Split.split gpart_at1k
                      p_at0g = code-0.1.0.0:Genome.FixedList.Functions.double g_at0f
                      (g_at0f, gpart_at1k) = Genome.Split.split gpart_at1j
                      p_at0e = code-0.1.0.0:Genome.FixedList.Functions.double g_at0d
                      (g_at0d, gpart_at1j) = Genome.Split.split gpart_at1i
                      p_at0c = Functions.belowten' g_at0b
                      (g_at0b, gpart_at1i) = Genome.Split.split gpart_at1h
                      p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                      (g_at09, gpart_at1h) = Genome.Split.split gpart_at1g
                      p_at08
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at07
                      (g_at07, gpart_at1g) = Genome.Split.split gpart_at1f
                      p_at06
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at05
                      (g_at05, gpart_at1f) = Genome.Split.split gpart_at1e
                      p_at04 = code-0.1.0.0:Genome.FixedList.Functions.double g_at03
                      (g_at03, gpart_at1e) = Genome.Split.split gpart_at1d
                      p_at02 = Functions.belowten' g_at01
                      (g_at01, gpart_at1d) = Genome.Split.split gpart_at1c
                      p_at00 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZZ
                      (g_asZZ, gpart_at1c) = Genome.Split.split gpart_at1b
                      p_asZY = Functions.belowten' g_asZX
                      (g_asZX, gpart_at1b) = Genome.Split.split gpart_at1a
                      p_asZW = code-0.1.0.0:Genome.FixedList.Functions.double g_asZV
                      (g_asZV, gpart_at1a) = Genome.Split.split gpart_at19
                      p_asZU = code-0.1.0.0:Genome.FixedList.Functions.double g_asZT
                      (g_asZT, gpart_at19) = Genome.Split.split gpart_at18
                      p_asZS = code-0.1.0.0:Genome.FixedList.Functions.double g_asZR
                      (g_asZR, gpart_at18) = Genome.Split.split gpart_at17
                      p_asZQ = Functions.belowten' g_asZP
                      (g_asZP, gpart_at17) = Genome.Split.split gpart_at16
                      p_asZO = code-0.1.0.0:Genome.FixedList.Functions.double g_asZN
                      (g_asZN, gpart_at16) = Genome.Split.split gpart_at15
                      p_asZM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZL
                      (g_asZL, gpart_at15) = Genome.Split.split gpart_at14
                      p_asZK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZJ
                      (g_asZJ, gpart_at14) = Genome.Split.split gpart_at13
                      p_asZI = Functions.belowten' g_asZH
                      (g_asZH, gpart_at13) = Genome.Split.split gpart_at12
                      p_asZG = code-0.1.0.0:Genome.FixedList.Functions.double g_asZF
                      (g_asZF, gpart_at12) = Genome.Split.split gpart_at11
                      p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                      (g_asZD, gpart_at11) = Genome.Split.split gpart_at10
                      p_asZC = code-0.1.0.0:Genome.FixedList.Functions.double g_asZB
                      (g_asZB, gpart_at10) = Genome.Split.split gpart_at0Z
                      p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                      (g_asZz, gpart_at0Z) = Genome.Split.split gpart_at0Y
                      p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                      (g_asZx, gpart_at0Y) = Genome.Split.split gpart_at0X
                      p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                      (g_asZv, gpart_at0X) = Genome.Split.split genome_at0V
                    in
                      [Reaction
                         (\ x_at1F
                            -> let
                                 c_MiRs_at1I = ((toVector x_at1F) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at1G = ((toVector x_at1F) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asZE
                                  * ((p_asZS + ((c_NPTB_at1G / p_asZG) ** p_asZI))
                                     / (((1 + p_asZS) + ((c_NPTB_at1G / p_asZG) ** p_asZI))
                                        + ((c_MiRs_at1I / p_asZO) ** p_asZQ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1J
                            -> let
                                 c_MiRs_at1K = ((toVector x_at1J) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1L = ((toVector x_at1J) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZU
                                  / (1
                                     + (((c_MiRs_at1K / p_asZW) ** p_asZY)
                                        + ((c_PTB_at1L / p_at00) ** p_at02)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at1M
                            -> let c_RESTc_at1N = ((toVector x_at1M) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at04
                                  * (p_at0e
                                     / ((1 + p_at0e) + ((c_RESTc_at1N / p_at0a) ** p_at0c)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at1O
                            -> let
                                 c_MiRs_at1T = ((toVector x_at1O) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1Q = ((toVector x_at1O) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at1P = ((toVector x_at1O) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at0g
                                  * ((p_at0y
                                      + (((c_NPTB_at1P / p_at0i) ** p_at0k)
                                         + ((c_PTB_at1Q / p_at0m) ** p_at0o)))
                                     / (((1 + p_at0y)
                                         + (((c_NPTB_at1P / p_at0i) ** p_at0k)
                                            + ((c_PTB_at1Q / p_at0m) ** p_at0o)))
                                        + (((p_asZw / p_at0q) ** p_at0s)
                                           + ((c_MiRs_at1T / p_at0u) ** p_at0w))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at1U
                            -> let
                                 c_RESTc_at1X = ((toVector x_at1U) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at1V = ((toVector x_at1U) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at0A
                                  * ((p_at0K + ((c_MiRs_at1V / p_at0C) ** p_at0E))
                                     / (((1 + p_at0K) + ((c_MiRs_at1V / p_at0C) ** p_at0E))
                                        + ((c_RESTc_at1X / p_at0G) ** p_at0I)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at1Y
                            -> let c_PTB_at1Z = ((toVector x_at1Y) Data.Vector.Unboxed.! 0)
                               in (p_at0M * c_PTB_at1Z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at20
                            -> let c_NPTB_at21 = ((toVector x_at20) Data.Vector.Unboxed.! 1)
                               in (p_at0O * c_NPTB_at21))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at22
                            -> let c_MiRs_at23 = ((toVector x_at22) Data.Vector.Unboxed.! 2)
                               in (p_at0Q * c_MiRs_at23))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at24
                            -> let c_RESTc_at25 = ((toVector x_at24) Data.Vector.Unboxed.! 3)
                               in (p_at0S * c_RESTc_at25))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at26
                            -> let
                                 c_EndoNeuroTFs_at27 = ((toVector x_at26) Data.Vector.Unboxed.! 4)
                               in (p_at0U * c_EndoNeuroTFs_at27))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121244",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121250",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121252",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121253",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121254",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121257",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121258",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121259",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121260",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121261",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121262",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121263",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121264",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121265",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121266",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121268",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121270",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121272",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121274",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121276",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121284",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121286",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121294",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121296",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121298",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121300",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121302",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121316",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121317",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121318",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121320",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121322",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121324",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at0V
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2P
                            p_at0U = code-0.1.0.0:Genome.FixedList.Functions.double g_at0T
                            (g_at0T, gpart_at2P) = Genome.Split.split gpart_at2O
                            p_at0S = code-0.1.0.0:Genome.FixedList.Functions.double g_at0R
                            (g_at0R, gpart_at2O) = Genome.Split.split gpart_at2N
                            p_at0Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0P
                            (g_at0P, gpart_at2N) = Genome.Split.split gpart_at2M
                            p_at0O = code-0.1.0.0:Genome.FixedList.Functions.double g_at0N
                            (g_at0N, gpart_at2M) = Genome.Split.split gpart_at2L
                            p_at0M = code-0.1.0.0:Genome.FixedList.Functions.double g_at0L
                            (g_at0L, gpart_at2L) = Genome.Split.split gpart_at2K
                            p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                            (g_at0J, gpart_at2K) = Genome.Split.split gpart_at2J
                            p_at0I = Functions.belowten' g_at0H
                            (g_at0H, gpart_at2J) = Genome.Split.split gpart_at2I
                            p_at0G = code-0.1.0.0:Genome.FixedList.Functions.double g_at0F
                            (g_at0F, gpart_at2I) = Genome.Split.split gpart_at2H
                            p_at0E = Functions.belowten' g_at0D
                            (g_at0D, gpart_at2H) = Genome.Split.split gpart_at2G
                            p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                            (g_at0B, gpart_at2G) = Genome.Split.split gpart_at2F
                            p_at0A = code-0.1.0.0:Genome.FixedList.Functions.double g_at0z
                            (g_at0z, gpart_at2F) = Genome.Split.split gpart_at2E
                            p_at0y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0x
                            (g_at0x, gpart_at2E) = Genome.Split.split gpart_at2D
                            p_at0w = Functions.belowten' g_at0v
                            (g_at0v, gpart_at2D) = Genome.Split.split gpart_at2C
                            p_at0u = code-0.1.0.0:Genome.FixedList.Functions.double g_at0t
                            (g_at0t, gpart_at2C) = Genome.Split.split gpart_at2B
                            p_at0s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0r
                            (g_at0r, gpart_at2B) = Genome.Split.split gpart_at2A
                            p_at0q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0p
                            (g_at0p, gpart_at2A) = Genome.Split.split gpart_at2z
                            p_at0o = Functions.belowten' g_at0n
                            (g_at0n, gpart_at2z) = Genome.Split.split gpart_at2y
                            p_at0m = code-0.1.0.0:Genome.FixedList.Functions.double g_at0l
                            (g_at0l, gpart_at2y) = Genome.Split.split gpart_at2x
                            p_at0k = Functions.belowten' g_at0j
                            (g_at0j, gpart_at2x) = Genome.Split.split gpart_at2w
                            p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                            (g_at0h, gpart_at2w) = Genome.Split.split gpart_at2v
                            p_at0g = code-0.1.0.0:Genome.FixedList.Functions.double g_at0f
                            (g_at0f, gpart_at2v) = Genome.Split.split gpart_at2u
                            p_at0e = code-0.1.0.0:Genome.FixedList.Functions.double g_at0d
                            (g_at0d, gpart_at2u) = Genome.Split.split gpart_at2t
                            p_at0c = Functions.belowten' g_at0b
                            (g_at0b, gpart_at2t) = Genome.Split.split gpart_at2s
                            p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                            (g_at09, gpart_at2s) = Genome.Split.split gpart_at2r
                            p_at08
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at07
                            (g_at07, gpart_at2r) = Genome.Split.split gpart_at2q
                            p_at06
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at05
                            (g_at05, gpart_at2q) = Genome.Split.split gpart_at2p
                            p_at04 = code-0.1.0.0:Genome.FixedList.Functions.double g_at03
                            (g_at03, gpart_at2p) = Genome.Split.split gpart_at2o
                            p_at02 = Functions.belowten' g_at01
                            (g_at01, gpart_at2o) = Genome.Split.split gpart_at2n
                            p_at00 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZZ
                            (g_asZZ, gpart_at2n) = Genome.Split.split gpart_at2m
                            p_asZY = Functions.belowten' g_asZX
                            (g_asZX, gpart_at2m) = Genome.Split.split gpart_at2l
                            p_asZW = code-0.1.0.0:Genome.FixedList.Functions.double g_asZV
                            (g_asZV, gpart_at2l) = Genome.Split.split gpart_at2k
                            p_asZU = code-0.1.0.0:Genome.FixedList.Functions.double g_asZT
                            (g_asZT, gpart_at2k) = Genome.Split.split gpart_at2j
                            p_asZS = code-0.1.0.0:Genome.FixedList.Functions.double g_asZR
                            (g_asZR, gpart_at2j) = Genome.Split.split gpart_at2i
                            p_asZQ = Functions.belowten' g_asZP
                            (g_asZP, gpart_at2i) = Genome.Split.split gpart_at2h
                            p_asZO = code-0.1.0.0:Genome.FixedList.Functions.double g_asZN
                            (g_asZN, gpart_at2h) = Genome.Split.split gpart_at2g
                            p_asZM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZL
                            (g_asZL, gpart_at2g) = Genome.Split.split gpart_at2f
                            p_asZK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZJ
                            (g_asZJ, gpart_at2f) = Genome.Split.split gpart_at2e
                            p_asZI = Functions.belowten' g_asZH
                            (g_asZH, gpart_at2e) = Genome.Split.split gpart_at2d
                            p_asZG = code-0.1.0.0:Genome.FixedList.Functions.double g_asZF
                            (g_asZF, gpart_at2d) = Genome.Split.split gpart_at2c
                            p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                            (g_asZD, gpart_at2c) = Genome.Split.split gpart_at2b
                            p_asZC = code-0.1.0.0:Genome.FixedList.Functions.double g_asZB
                            (g_asZB, gpart_at2b) = Genome.Split.split gpart_at2a
                            p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                            (g_asZz, gpart_at2a) = Genome.Split.split gpart_at29
                            p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                            (g_asZx, gpart_at29) = Genome.Split.split gpart_at28
                            p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                            (g_asZv, gpart_at28) = Genome.Split.split genome_at0V
                          in
                            \ desc_at0W
                              -> case desc_at0W of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZw)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZy)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZA)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZC)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZE)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZG)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZI)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZK)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZM)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZO)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZQ)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZS)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZU)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZW)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZY)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at00)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at02)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at04)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at06)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at08)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0a)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0c)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0e)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0g)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0i)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0k)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0m)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0o)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0q)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0s)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0u)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0w)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0y)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0A)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0C)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0E)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0G)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0I)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0K)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0M)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0O)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Q)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0S)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0U)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at4W
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5F
                      p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                      (g_at4U, gpart_at5F) = Genome.Split.split gpart_at5E
                      p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                      (g_at4S, gpart_at5E) = Genome.Split.split gpart_at5D
                      p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                      (g_at4Q, gpart_at5D) = Genome.Split.split gpart_at5C
                      p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                      (g_at4O, gpart_at5C) = Genome.Split.split gpart_at5B
                      p_at4N = code-0.1.0.0:Genome.FixedList.Functions.double g_at4M
                      (g_at4M, gpart_at5B) = Genome.Split.split gpart_at5A
                      p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                      (g_at4K, gpart_at5A) = Genome.Split.split gpart_at5z
                      p_at4J = Functions.belowten' g_at4I
                      (g_at4I, gpart_at5z) = Genome.Split.split gpart_at5y
                      p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                      (g_at4G, gpart_at5y) = Genome.Split.split gpart_at5x
                      p_at4F = Functions.belowten' g_at4E
                      (g_at4E, gpart_at5x) = Genome.Split.split gpart_at5w
                      p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                      (g_at4C, gpart_at5w) = Genome.Split.split gpart_at5v
                      p_at4B = code-0.1.0.0:Genome.FixedList.Functions.double g_at4A
                      (g_at4A, gpart_at5v) = Genome.Split.split gpart_at5u
                      p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                      (g_at4y, gpart_at5u) = Genome.Split.split gpart_at5t
                      p_at4x = Functions.belowten' g_at4w
                      (g_at4w, gpart_at5t) = Genome.Split.split gpart_at5s
                      p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                      (g_at4u, gpart_at5s) = Genome.Split.split gpart_at5r
                      p_at4t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4s
                      (g_at4s, gpart_at5r) = Genome.Split.split gpart_at5q
                      p_at4r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4q
                      (g_at4q, gpart_at5q) = Genome.Split.split gpart_at5p
                      p_at4p = Functions.belowten' g_at4o
                      (g_at4o, gpart_at5p) = Genome.Split.split gpart_at5o
                      p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                      (g_at4m, gpart_at5o) = Genome.Split.split gpart_at5n
                      p_at4l = Functions.belowten' g_at4k
                      (g_at4k, gpart_at5n) = Genome.Split.split gpart_at5m
                      p_at4j = code-0.1.0.0:Genome.FixedList.Functions.double g_at4i
                      (g_at4i, gpart_at5m) = Genome.Split.split gpart_at5l
                      p_at4h = code-0.1.0.0:Genome.FixedList.Functions.double g_at4g
                      (g_at4g, gpart_at5l) = Genome.Split.split gpart_at5k
                      p_at4f = code-0.1.0.0:Genome.FixedList.Functions.double g_at4e
                      (g_at4e, gpart_at5k) = Genome.Split.split gpart_at5j
                      p_at4d = Functions.belowten' g_at4c
                      (g_at4c, gpart_at5j) = Genome.Split.split gpart_at5i
                      p_at4b = code-0.1.0.0:Genome.FixedList.Functions.double g_at4a
                      (g_at4a, gpart_at5i) = Genome.Split.split gpart_at5h
                      p_at49
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at48
                      (g_at48, gpart_at5h) = Genome.Split.split gpart_at5g
                      p_at47
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at46
                      (g_at46, gpart_at5g) = Genome.Split.split gpart_at5f
                      p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                      (g_at44, gpart_at5f) = Genome.Split.split gpart_at5e
                      p_at43 = Functions.belowten' g_at42
                      (g_at42, gpart_at5e) = Genome.Split.split gpart_at5d
                      p_at41 = code-0.1.0.0:Genome.FixedList.Functions.double g_at40
                      (g_at40, gpart_at5d) = Genome.Split.split gpart_at5c
                      p_at3Z = Functions.belowten' g_at3Y
                      (g_at3Y, gpart_at5c) = Genome.Split.split gpart_at5b
                      p_at3X = code-0.1.0.0:Genome.FixedList.Functions.double g_at3W
                      (g_at3W, gpart_at5b) = Genome.Split.split gpart_at5a
                      p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                      (g_at3U, gpart_at5a) = Genome.Split.split gpart_at59
                      p_at3T = code-0.1.0.0:Genome.FixedList.Functions.double g_at3S
                      (g_at3S, gpart_at59) = Genome.Split.split gpart_at58
                      p_at3R = Functions.belowten' g_at3Q
                      (g_at3Q, gpart_at58) = Genome.Split.split gpart_at57
                      p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                      (g_at3O, gpart_at57) = Genome.Split.split gpart_at56
                      p_at3N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3M
                      (g_at3M, gpart_at56) = Genome.Split.split gpart_at55
                      p_at3L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3K
                      (g_at3K, gpart_at55) = Genome.Split.split gpart_at54
                      p_at3J = Functions.belowten' g_at3I
                      (g_at3I, gpart_at54) = Genome.Split.split gpart_at53
                      p_at3H = code-0.1.0.0:Genome.FixedList.Functions.double g_at3G
                      (g_at3G, gpart_at53) = Genome.Split.split gpart_at52
                      p_at3F = code-0.1.0.0:Genome.FixedList.Functions.double g_at3E
                      (g_at3E, gpart_at52) = Genome.Split.split gpart_at51
                      p_at3D = code-0.1.0.0:Genome.FixedList.Functions.double g_at3C
                      (g_at3C, gpart_at51) = Genome.Split.split gpart_at50
                      p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                      (g_at3A, gpart_at50) = Genome.Split.split gpart_at4Z
                      p_at3z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3y
                      (g_at3y, gpart_at4Z) = Genome.Split.split gpart_at4Y
                      p_at3x = code-0.1.0.0:Genome.FixedList.Functions.double g_at3w
                      (g_at3w, gpart_at4Y) = Genome.Split.split genome_at4W
                    in
                      [Reaction
                         (\ x_at5G
                            -> let
                                 c_MiRs_at5J = ((toVector x_at5G) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at5H = ((toVector x_at5G) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at3F
                                  * ((p_at3T + ((c_NPTB_at5H / p_at3H) ** p_at3J))
                                     / (((1 + p_at3T) + ((c_NPTB_at5H / p_at3H) ** p_at3J))
                                        + ((c_MiRs_at5J / p_at3P) ** p_at3R)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5K
                            -> let
                                 c_MiRs_at5L = ((toVector x_at5K) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5M = ((toVector x_at5K) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3V
                                  / (1
                                     + (((c_MiRs_at5L / p_at3X) ** p_at3Z)
                                        + ((c_PTB_at5M / p_at41) ** p_at43)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at5N
                            -> let c_RESTc_at5O = ((toVector x_at5N) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at45
                                  * (p_at4f
                                     / ((1 + p_at4f) + ((c_RESTc_at5O / p_at4b) ** p_at4d)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at5P
                            -> let
                                 c_MiRs_at5U = ((toVector x_at5P) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5R = ((toVector x_at5P) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at5Q = ((toVector x_at5P) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at4h
                                  * ((p_at4z
                                      + (((c_NPTB_at5Q / p_at4j) ** p_at4l)
                                         + ((c_PTB_at5R / p_at4n) ** p_at4p)))
                                     / (((1 + p_at4z)
                                         + (((c_NPTB_at5Q / p_at4j) ** p_at4l)
                                            + ((c_PTB_at5R / p_at4n) ** p_at4p)))
                                        + ((c_MiRs_at5U / p_at4v) ** p_at4x)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at5V
                            -> let
                                 c_RESTc_at5Y = ((toVector x_at5V) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at5W = ((toVector x_at5V) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4B
                                  * ((p_at4L + ((c_MiRs_at5W / p_at4D) ** p_at4F))
                                     / (((1 + p_at4L) + ((c_MiRs_at5W / p_at4D) ** p_at4F))
                                        + ((c_RESTc_at5Y / p_at4H) ** p_at4J)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at5Z
                            -> let c_PTB_at60 = ((toVector x_at5Z) Data.Vector.Unboxed.! 0)
                               in (p_at4N * c_PTB_at60))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at61
                            -> let c_NPTB_at62 = ((toVector x_at61) Data.Vector.Unboxed.! 1)
                               in (p_at4P * c_NPTB_at62))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at63
                            -> let c_MiRs_at64 = ((toVector x_at63) Data.Vector.Unboxed.! 2)
                               in (p_at4R * c_MiRs_at64))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at65
                            -> let c_RESTc_at66 = ((toVector x_at65) Data.Vector.Unboxed.! 3)
                               in (p_at4T * c_RESTc_at66))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at67
                            -> let
                                 c_EndoNeuroTFs_at68 = ((toVector x_at67) Data.Vector.Unboxed.! 4)
                               in (p_at4V * c_EndoNeuroTFs_at68))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121486",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121487",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121488",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121489",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121497",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121499",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121501",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121503",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121505",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121507",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121509",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121523",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121525",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121543",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121545",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at4W
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6Q
                            p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                            (g_at4U, gpart_at6Q) = Genome.Split.split gpart_at6P
                            p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                            (g_at4S, gpart_at6P) = Genome.Split.split gpart_at6O
                            p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                            (g_at4Q, gpart_at6O) = Genome.Split.split gpart_at6N
                            p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                            (g_at4O, gpart_at6N) = Genome.Split.split gpart_at6M
                            p_at4N = code-0.1.0.0:Genome.FixedList.Functions.double g_at4M
                            (g_at4M, gpart_at6M) = Genome.Split.split gpart_at6L
                            p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                            (g_at4K, gpart_at6L) = Genome.Split.split gpart_at6K
                            p_at4J = Functions.belowten' g_at4I
                            (g_at4I, gpart_at6K) = Genome.Split.split gpart_at6J
                            p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                            (g_at4G, gpart_at6J) = Genome.Split.split gpart_at6I
                            p_at4F = Functions.belowten' g_at4E
                            (g_at4E, gpart_at6I) = Genome.Split.split gpart_at6H
                            p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                            (g_at4C, gpart_at6H) = Genome.Split.split gpart_at6G
                            p_at4B = code-0.1.0.0:Genome.FixedList.Functions.double g_at4A
                            (g_at4A, gpart_at6G) = Genome.Split.split gpart_at6F
                            p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                            (g_at4y, gpart_at6F) = Genome.Split.split gpart_at6E
                            p_at4x = Functions.belowten' g_at4w
                            (g_at4w, gpart_at6E) = Genome.Split.split gpart_at6D
                            p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                            (g_at4u, gpart_at6D) = Genome.Split.split gpart_at6C
                            p_at4t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4s
                            (g_at4s, gpart_at6C) = Genome.Split.split gpart_at6B
                            p_at4r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4q
                            (g_at4q, gpart_at6B) = Genome.Split.split gpart_at6A
                            p_at4p = Functions.belowten' g_at4o
                            (g_at4o, gpart_at6A) = Genome.Split.split gpart_at6z
                            p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                            (g_at4m, gpart_at6z) = Genome.Split.split gpart_at6y
                            p_at4l = Functions.belowten' g_at4k
                            (g_at4k, gpart_at6y) = Genome.Split.split gpart_at6x
                            p_at4j = code-0.1.0.0:Genome.FixedList.Functions.double g_at4i
                            (g_at4i, gpart_at6x) = Genome.Split.split gpart_at6w
                            p_at4h = code-0.1.0.0:Genome.FixedList.Functions.double g_at4g
                            (g_at4g, gpart_at6w) = Genome.Split.split gpart_at6v
                            p_at4f = code-0.1.0.0:Genome.FixedList.Functions.double g_at4e
                            (g_at4e, gpart_at6v) = Genome.Split.split gpart_at6u
                            p_at4d = Functions.belowten' g_at4c
                            (g_at4c, gpart_at6u) = Genome.Split.split gpart_at6t
                            p_at4b = code-0.1.0.0:Genome.FixedList.Functions.double g_at4a
                            (g_at4a, gpart_at6t) = Genome.Split.split gpart_at6s
                            p_at49
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at48
                            (g_at48, gpart_at6s) = Genome.Split.split gpart_at6r
                            p_at47
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at46
                            (g_at46, gpart_at6r) = Genome.Split.split gpart_at6q
                            p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                            (g_at44, gpart_at6q) = Genome.Split.split gpart_at6p
                            p_at43 = Functions.belowten' g_at42
                            (g_at42, gpart_at6p) = Genome.Split.split gpart_at6o
                            p_at41 = code-0.1.0.0:Genome.FixedList.Functions.double g_at40
                            (g_at40, gpart_at6o) = Genome.Split.split gpart_at6n
                            p_at3Z = Functions.belowten' g_at3Y
                            (g_at3Y, gpart_at6n) = Genome.Split.split gpart_at6m
                            p_at3X = code-0.1.0.0:Genome.FixedList.Functions.double g_at3W
                            (g_at3W, gpart_at6m) = Genome.Split.split gpart_at6l
                            p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                            (g_at3U, gpart_at6l) = Genome.Split.split gpart_at6k
                            p_at3T = code-0.1.0.0:Genome.FixedList.Functions.double g_at3S
                            (g_at3S, gpart_at6k) = Genome.Split.split gpart_at6j
                            p_at3R = Functions.belowten' g_at3Q
                            (g_at3Q, gpart_at6j) = Genome.Split.split gpart_at6i
                            p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                            (g_at3O, gpart_at6i) = Genome.Split.split gpart_at6h
                            p_at3N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3M
                            (g_at3M, gpart_at6h) = Genome.Split.split gpart_at6g
                            p_at3L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3K
                            (g_at3K, gpart_at6g) = Genome.Split.split gpart_at6f
                            p_at3J = Functions.belowten' g_at3I
                            (g_at3I, gpart_at6f) = Genome.Split.split gpart_at6e
                            p_at3H = code-0.1.0.0:Genome.FixedList.Functions.double g_at3G
                            (g_at3G, gpart_at6e) = Genome.Split.split gpart_at6d
                            p_at3F = code-0.1.0.0:Genome.FixedList.Functions.double g_at3E
                            (g_at3E, gpart_at6d) = Genome.Split.split gpart_at6c
                            p_at3D = code-0.1.0.0:Genome.FixedList.Functions.double g_at3C
                            (g_at3C, gpart_at6c) = Genome.Split.split gpart_at6b
                            p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                            (g_at3A, gpart_at6b) = Genome.Split.split gpart_at6a
                            p_at3z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3y
                            (g_at3y, gpart_at6a) = Genome.Split.split gpart_at69
                            p_at3x = code-0.1.0.0:Genome.FixedList.Functions.double g_at3w
                            (g_at3w, gpart_at69) = Genome.Split.split genome_at4W
                          in
                            \ desc_at4X
                              -> case desc_at4X of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3x)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3z)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3B)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3D)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3F)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3H)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3J)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3L)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3N)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3P)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3R)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3T)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3V)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3X)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Z)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at41)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at43)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at45)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at47)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at49)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4b)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4d)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4f)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4h)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4j)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4l)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4n)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4p)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4r)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4t)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4v)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4x)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4z)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4B)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4D)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4F)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4H)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4J)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4L)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4N)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4P)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4V)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at8X
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at9G
                      p_at8W = code-0.1.0.0:Genome.FixedList.Functions.double g_at8V
                      (g_at8V, gpart_at9G) = Genome.Split.split gpart_at9F
                      p_at8U = code-0.1.0.0:Genome.FixedList.Functions.double g_at8T
                      (g_at8T, gpart_at9F) = Genome.Split.split gpart_at9E
                      p_at8S = code-0.1.0.0:Genome.FixedList.Functions.double g_at8R
                      (g_at8R, gpart_at9E) = Genome.Split.split gpart_at9D
                      p_at8Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at8P
                      (g_at8P, gpart_at9D) = Genome.Split.split gpart_at9C
                      p_at8O = code-0.1.0.0:Genome.FixedList.Functions.double g_at8N
                      (g_at8N, gpart_at9C) = Genome.Split.split gpart_at9B
                      p_at8M = code-0.1.0.0:Genome.FixedList.Functions.double g_at8L
                      (g_at8L, gpart_at9B) = Genome.Split.split gpart_at9A
                      p_at8K = Functions.belowten' g_at8J
                      (g_at8J, gpart_at9A) = Genome.Split.split gpart_at9z
                      p_at8I = code-0.1.0.0:Genome.FixedList.Functions.double g_at8H
                      (g_at8H, gpart_at9z) = Genome.Split.split gpart_at9y
                      p_at8G = Functions.belowten' g_at8F
                      (g_at8F, gpart_at9y) = Genome.Split.split gpart_at9x
                      p_at8E = code-0.1.0.0:Genome.FixedList.Functions.double g_at8D
                      (g_at8D, gpart_at9x) = Genome.Split.split gpart_at9w
                      p_at8C = code-0.1.0.0:Genome.FixedList.Functions.double g_at8B
                      (g_at8B, gpart_at9w) = Genome.Split.split gpart_at9v
                      p_at8A = code-0.1.0.0:Genome.FixedList.Functions.double g_at8z
                      (g_at8z, gpart_at9v) = Genome.Split.split gpart_at9u
                      p_at8y = Functions.belowten' g_at8x
                      (g_at8x, gpart_at9u) = Genome.Split.split gpart_at9t
                      p_at8w = code-0.1.0.0:Genome.FixedList.Functions.double g_at8v
                      (g_at8v, gpart_at9t) = Genome.Split.split gpart_at9s
                      p_at8u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at8t
                      (g_at8t, gpart_at9s) = Genome.Split.split gpart_at9r
                      p_at8s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at8r
                      (g_at8r, gpart_at9r) = Genome.Split.split gpart_at9q
                      p_at8q = Functions.belowten' g_at8p
                      (g_at8p, gpart_at9q) = Genome.Split.split gpart_at9p
                      p_at8o = code-0.1.0.0:Genome.FixedList.Functions.double g_at8n
                      (g_at8n, gpart_at9p) = Genome.Split.split gpart_at9o
                      p_at8m = Functions.belowten' g_at8l
                      (g_at8l, gpart_at9o) = Genome.Split.split gpart_at9n
                      p_at8k = code-0.1.0.0:Genome.FixedList.Functions.double g_at8j
                      (g_at8j, gpart_at9n) = Genome.Split.split gpart_at9m
                      p_at8i = code-0.1.0.0:Genome.FixedList.Functions.double g_at8h
                      (g_at8h, gpart_at9m) = Genome.Split.split gpart_at9l
                      p_at8g = code-0.1.0.0:Genome.FixedList.Functions.double g_at8f
                      (g_at8f, gpart_at9l) = Genome.Split.split gpart_at9k
                      p_at8e = Functions.belowten' g_at8d
                      (g_at8d, gpart_at9k) = Genome.Split.split gpart_at9j
                      p_at8c = code-0.1.0.0:Genome.FixedList.Functions.double g_at8b
                      (g_at8b, gpart_at9j) = Genome.Split.split gpart_at9i
                      p_at8a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at89
                      (g_at89, gpart_at9i) = Genome.Split.split gpart_at9h
                      p_at88
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at87
                      (g_at87, gpart_at9h) = Genome.Split.split gpart_at9g
                      p_at86 = code-0.1.0.0:Genome.FixedList.Functions.double g_at85
                      (g_at85, gpart_at9g) = Genome.Split.split gpart_at9f
                      p_at84 = Functions.belowten' g_at83
                      (g_at83, gpart_at9f) = Genome.Split.split gpart_at9e
                      p_at82 = code-0.1.0.0:Genome.FixedList.Functions.double g_at81
                      (g_at81, gpart_at9e) = Genome.Split.split gpart_at9d
                      p_at80 = Functions.belowten' g_at7Z
                      (g_at7Z, gpart_at9d) = Genome.Split.split gpart_at9c
                      p_at7Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7X
                      (g_at7X, gpart_at9c) = Genome.Split.split gpart_at9b
                      p_at7W = code-0.1.0.0:Genome.FixedList.Functions.double g_at7V
                      (g_at7V, gpart_at9b) = Genome.Split.split gpart_at9a
                      p_at7U = code-0.1.0.0:Genome.FixedList.Functions.double g_at7T
                      (g_at7T, gpart_at9a) = Genome.Split.split gpart_at99
                      p_at7S = Functions.belowten' g_at7R
                      (g_at7R, gpart_at99) = Genome.Split.split gpart_at98
                      p_at7Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7P
                      (g_at7P, gpart_at98) = Genome.Split.split gpart_at97
                      p_at7O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7N
                      (g_at7N, gpart_at97) = Genome.Split.split gpart_at96
                      p_at7M
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7L
                      (g_at7L, gpart_at96) = Genome.Split.split gpart_at95
                      p_at7K = Functions.belowten' g_at7J
                      (g_at7J, gpart_at95) = Genome.Split.split gpart_at94
                      p_at7I = code-0.1.0.0:Genome.FixedList.Functions.double g_at7H
                      (g_at7H, gpart_at94) = Genome.Split.split gpart_at93
                      p_at7G = code-0.1.0.0:Genome.FixedList.Functions.double g_at7F
                      (g_at7F, gpart_at93) = Genome.Split.split gpart_at92
                      p_at7E = code-0.1.0.0:Genome.FixedList.Functions.double g_at7D
                      (g_at7D, gpart_at92) = Genome.Split.split gpart_at91
                      p_at7C = code-0.1.0.0:Genome.FixedList.Functions.double g_at7B
                      (g_at7B, gpart_at91) = Genome.Split.split gpart_at90
                      p_at7A = code-0.1.0.0:Genome.FixedList.Functions.double g_at7z
                      (g_at7z, gpart_at90) = Genome.Split.split gpart_at8Z
                      p_at7y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7x
                      (g_at7x, gpart_at8Z) = Genome.Split.split genome_at8X
                    in
                      [Reaction
                         (\ x_at9H
                            -> let
                                 c_MiRs_at9K = ((toVector x_at9H) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at9I = ((toVector x_at9H) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at7G
                                  * ((p_at7U + ((c_NPTB_at9I / p_at7I) ** p_at7K))
                                     / (((1 + p_at7U) + ((c_NPTB_at9I / p_at7I) ** p_at7K))
                                        + (((p_at7y / p_at7M) ** p_at7O)
                                           + ((c_MiRs_at9K / p_at7Q) ** p_at7S))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at9L
                            -> let
                                 c_MiRs_at9M = ((toVector x_at9L) Data.Vector.Unboxed.! 2)
                                 c_PTB_at9N = ((toVector x_at9L) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at7W
                                  / (1
                                     + (((c_MiRs_at9M / p_at7Y) ** p_at80)
                                        + ((c_PTB_at9N / p_at82) ** p_at84)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at9O
                            -> let c_RESTc_at9P = ((toVector x_at9O) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at86
                                  * (p_at8g
                                     / ((1 + p_at8g) + ((c_RESTc_at9P / p_at8c) ** p_at8e)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at9Q
                            -> let
                                 c_MiRs_at9V = ((toVector x_at9Q) Data.Vector.Unboxed.! 2)
                                 c_PTB_at9S = ((toVector x_at9Q) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at9R = ((toVector x_at9Q) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at8i
                                  * ((p_at8A
                                      + (((c_NPTB_at9R / p_at8k) ** p_at8m)
                                         + ((c_PTB_at9S / p_at8o) ** p_at8q)))
                                     / (((1 + p_at8A)
                                         + (((c_NPTB_at9R / p_at8k) ** p_at8m)
                                            + ((c_PTB_at9S / p_at8o) ** p_at8q)))
                                        + ((c_MiRs_at9V / p_at8w) ** p_at8y)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at9W
                            -> let
                                 c_RESTc_at9Z = ((toVector x_at9W) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at9X = ((toVector x_at9W) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at8C
                                  * ((p_at8M + ((c_MiRs_at9X / p_at8E) ** p_at8G))
                                     / (((1 + p_at8M) + ((c_MiRs_at9X / p_at8E) ** p_at8G))
                                        + ((c_RESTc_at9Z / p_at8I) ** p_at8K)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_ata0
                            -> let c_PTB_ata1 = ((toVector x_ata0) Data.Vector.Unboxed.! 0)
                               in (p_at8O * c_PTB_ata1))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_ata2
                            -> let c_NPTB_ata3 = ((toVector x_ata2) Data.Vector.Unboxed.! 1)
                               in (p_at8Q * c_NPTB_ata3))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_ata4
                            -> let c_MiRs_ata5 = ((toVector x_ata4) Data.Vector.Unboxed.! 2)
                               in (p_at8S * c_MiRs_ata5))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_ata6
                            -> let c_RESTc_ata7 = ((toVector x_ata6) Data.Vector.Unboxed.! 3)
                               in (p_at8U * c_RESTc_ata7))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_ata8
                            -> let
                                 c_EndoNeuroTFs_ata9 = ((toVector x_ata8) Data.Vector.Unboxed.! 4)
                               in (p_at8W * c_EndoNeuroTFs_ata9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121750",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121752",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121764",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121766",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121768",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121770",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121771",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121772",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121773",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121774",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121777",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121778",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121779",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121780",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121781",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121782",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121783",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121784",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121785",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121786",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121787",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121788",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121789",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121790",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121791",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121792",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121793",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121794",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121795",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121796",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121797",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121798",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121799",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121800",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121801",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121802",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121803",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121804",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121805",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121806",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121807",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121808",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121809",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121810",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121811",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121812",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121813",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121814",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121815",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121816",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121817",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121818",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121819",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121820",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121821",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121822",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at8X
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_ataR
                            p_at8W = code-0.1.0.0:Genome.FixedList.Functions.double g_at8V
                            (g_at8V, gpart_ataR) = Genome.Split.split gpart_ataQ
                            p_at8U = code-0.1.0.0:Genome.FixedList.Functions.double g_at8T
                            (g_at8T, gpart_ataQ) = Genome.Split.split gpart_ataP
                            p_at8S = code-0.1.0.0:Genome.FixedList.Functions.double g_at8R
                            (g_at8R, gpart_ataP) = Genome.Split.split gpart_ataO
                            p_at8Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at8P
                            (g_at8P, gpart_ataO) = Genome.Split.split gpart_ataN
                            p_at8O = code-0.1.0.0:Genome.FixedList.Functions.double g_at8N
                            (g_at8N, gpart_ataN) = Genome.Split.split gpart_ataM
                            p_at8M = code-0.1.0.0:Genome.FixedList.Functions.double g_at8L
                            (g_at8L, gpart_ataM) = Genome.Split.split gpart_ataL
                            p_at8K = Functions.belowten' g_at8J
                            (g_at8J, gpart_ataL) = Genome.Split.split gpart_ataK
                            p_at8I = code-0.1.0.0:Genome.FixedList.Functions.double g_at8H
                            (g_at8H, gpart_ataK) = Genome.Split.split gpart_ataJ
                            p_at8G = Functions.belowten' g_at8F
                            (g_at8F, gpart_ataJ) = Genome.Split.split gpart_ataI
                            p_at8E = code-0.1.0.0:Genome.FixedList.Functions.double g_at8D
                            (g_at8D, gpart_ataI) = Genome.Split.split gpart_ataH
                            p_at8C = code-0.1.0.0:Genome.FixedList.Functions.double g_at8B
                            (g_at8B, gpart_ataH) = Genome.Split.split gpart_ataG
                            p_at8A = code-0.1.0.0:Genome.FixedList.Functions.double g_at8z
                            (g_at8z, gpart_ataG) = Genome.Split.split gpart_ataF
                            p_at8y = Functions.belowten' g_at8x
                            (g_at8x, gpart_ataF) = Genome.Split.split gpart_ataE
                            p_at8w = code-0.1.0.0:Genome.FixedList.Functions.double g_at8v
                            (g_at8v, gpart_ataE) = Genome.Split.split gpart_ataD
                            p_at8u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at8t
                            (g_at8t, gpart_ataD) = Genome.Split.split gpart_ataC
                            p_at8s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at8r
                            (g_at8r, gpart_ataC) = Genome.Split.split gpart_ataB
                            p_at8q = Functions.belowten' g_at8p
                            (g_at8p, gpart_ataB) = Genome.Split.split gpart_ataA
                            p_at8o = code-0.1.0.0:Genome.FixedList.Functions.double g_at8n
                            (g_at8n, gpart_ataA) = Genome.Split.split gpart_ataz
                            p_at8m = Functions.belowten' g_at8l
                            (g_at8l, gpart_ataz) = Genome.Split.split gpart_atay
                            p_at8k = code-0.1.0.0:Genome.FixedList.Functions.double g_at8j
                            (g_at8j, gpart_atay) = Genome.Split.split gpart_atax
                            p_at8i = code-0.1.0.0:Genome.FixedList.Functions.double g_at8h
                            (g_at8h, gpart_atax) = Genome.Split.split gpart_ataw
                            p_at8g = code-0.1.0.0:Genome.FixedList.Functions.double g_at8f
                            (g_at8f, gpart_ataw) = Genome.Split.split gpart_atav
                            p_at8e = Functions.belowten' g_at8d
                            (g_at8d, gpart_atav) = Genome.Split.split gpart_atau
                            p_at8c = code-0.1.0.0:Genome.FixedList.Functions.double g_at8b
                            (g_at8b, gpart_atau) = Genome.Split.split gpart_atat
                            p_at8a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at89
                            (g_at89, gpart_atat) = Genome.Split.split gpart_atas
                            p_at88
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at87
                            (g_at87, gpart_atas) = Genome.Split.split gpart_atar
                            p_at86 = code-0.1.0.0:Genome.FixedList.Functions.double g_at85
                            (g_at85, gpart_atar) = Genome.Split.split gpart_ataq
                            p_at84 = Functions.belowten' g_at83
                            (g_at83, gpart_ataq) = Genome.Split.split gpart_atap
                            p_at82 = code-0.1.0.0:Genome.FixedList.Functions.double g_at81
                            (g_at81, gpart_atap) = Genome.Split.split gpart_atao
                            p_at80 = Functions.belowten' g_at7Z
                            (g_at7Z, gpart_atao) = Genome.Split.split gpart_atan
                            p_at7Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7X
                            (g_at7X, gpart_atan) = Genome.Split.split gpart_atam
                            p_at7W = code-0.1.0.0:Genome.FixedList.Functions.double g_at7V
                            (g_at7V, gpart_atam) = Genome.Split.split gpart_atal
                            p_at7U = code-0.1.0.0:Genome.FixedList.Functions.double g_at7T
                            (g_at7T, gpart_atal) = Genome.Split.split gpart_atak
                            p_at7S = Functions.belowten' g_at7R
                            (g_at7R, gpart_atak) = Genome.Split.split gpart_ataj
                            p_at7Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7P
                            (g_at7P, gpart_ataj) = Genome.Split.split gpart_atai
                            p_at7O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7N
                            (g_at7N, gpart_atai) = Genome.Split.split gpart_atah
                            p_at7M
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7L
                            (g_at7L, gpart_atah) = Genome.Split.split gpart_atag
                            p_at7K = Functions.belowten' g_at7J
                            (g_at7J, gpart_atag) = Genome.Split.split gpart_ataf
                            p_at7I = code-0.1.0.0:Genome.FixedList.Functions.double g_at7H
                            (g_at7H, gpart_ataf) = Genome.Split.split gpart_atae
                            p_at7G = code-0.1.0.0:Genome.FixedList.Functions.double g_at7F
                            (g_at7F, gpart_atae) = Genome.Split.split gpart_atad
                            p_at7E = code-0.1.0.0:Genome.FixedList.Functions.double g_at7D
                            (g_at7D, gpart_atad) = Genome.Split.split gpart_atac
                            p_at7C = code-0.1.0.0:Genome.FixedList.Functions.double g_at7B
                            (g_at7B, gpart_atac) = Genome.Split.split gpart_atab
                            p_at7A = code-0.1.0.0:Genome.FixedList.Functions.double g_at7z
                            (g_at7z, gpart_atab) = Genome.Split.split gpart_ataa
                            p_at7y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7x
                            (g_at7x, gpart_ataa) = Genome.Split.split genome_at8X
                          in
                            \ desc_at8Y
                              -> case desc_at8Y of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7y)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7A)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7C)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7E)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7G)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7I)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7K)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7M)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7O)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7Q)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7S)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7U)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at80)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at82)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at84)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at86)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at88)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8a)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8c)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8e)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8g)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8i)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8k)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8m)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8o)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8q)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8s)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8u)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8w)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8y)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8A)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8C)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8E)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8G)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8I)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8K)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8M)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8O)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8Q)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8S)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8U)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8W)
                                   _ -> Nothing }}
