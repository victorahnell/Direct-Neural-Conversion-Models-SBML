src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a22Pm
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a22Q1
                      p_a22Pl = double g_a22Pk
                      (g_a22Pk, gpart_a22Q1) = Genome.Split.split gpart_a22Q0
                      p_a22Pj = double g_a22Pi
                      (g_a22Pi, gpart_a22Q0) = Genome.Split.split gpart_a22PZ
                      p_a22Ph = double g_a22Pg
                      (g_a22Pg, gpart_a22PZ) = Genome.Split.split gpart_a22PY
                      p_a22Pf = double g_a22Pe
                      (g_a22Pe, gpart_a22PY) = Genome.Split.split gpart_a22PX
                      p_a22Pd = double g_a22Pc
                      (g_a22Pc, gpart_a22PX) = Genome.Split.split gpart_a22PW
                      p_a22Pb = Functions.belowten' g_a22Pa
                      (g_a22Pa, gpart_a22PW) = Genome.Split.split gpart_a22PV
                      p_a22P9 = double g_a22P8
                      (g_a22P8, gpart_a22PV) = Genome.Split.split gpart_a22PU
                      p_a22P7 = double g_a22P6
                      (g_a22P6, gpart_a22PU) = Genome.Split.split gpart_a22PT
                      p_a22P5 = double g_a22P4
                      (g_a22P4, gpart_a22PT) = Genome.Split.split gpart_a22PS
                      p_a22P3 = Functions.belowten' g_a22P2
                      (g_a22P2, gpart_a22PS) = Genome.Split.split gpart_a22PR
                      p_a22P1 = double g_a22P0
                      (g_a22P0, gpart_a22PR) = Genome.Split.split gpart_a22PQ
                      p_a22OZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22OY
                      (g_a22OY, gpart_a22PQ) = Genome.Split.split gpart_a22PP
                      p_a22OX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22OW
                      (g_a22OW, gpart_a22PP) = Genome.Split.split gpart_a22PO
                      p_a22OV = Functions.belowten' g_a22OU
                      (g_a22OU, gpart_a22PO) = Genome.Split.split gpart_a22PN
                      p_a22OT = double g_a22OS
                      (g_a22OS, gpart_a22PN) = Genome.Split.split gpart_a22PM
                      p_a22OR = double g_a22OQ
                      (g_a22OQ, gpart_a22PM) = Genome.Split.split gpart_a22PL
                      p_a22OP = double g_a22OO
                      (g_a22OO, gpart_a22PL) = Genome.Split.split gpart_a22PK
                      p_a22ON = Functions.belowten' g_a22OM
                      (g_a22OM, gpart_a22PK) = Genome.Split.split gpart_a22PJ
                      p_a22OL = double g_a22OK
                      (g_a22OK, gpart_a22PJ) = Genome.Split.split gpart_a22PI
                      p_a22OJ = Functions.belowten' g_a22OI
                      (g_a22OI, gpart_a22PI) = Genome.Split.split gpart_a22PH
                      p_a22OH = double g_a22OG
                      (g_a22OG, gpart_a22PH) = Genome.Split.split gpart_a22PG
                      p_a22OF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22OE
                      (g_a22OE, gpart_a22PG) = Genome.Split.split gpart_a22PF
                      p_a22OD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22OC
                      (g_a22OC, gpart_a22PF) = Genome.Split.split gpart_a22PE
                      p_a22OB = double g_a22OA
                      (g_a22OA, gpart_a22PE) = Genome.Split.split gpart_a22PD
                      p_a22Oz = Functions.belowten' g_a22Oy
                      (g_a22Oy, gpart_a22PD) = Genome.Split.split gpart_a22PC
                      p_a22Ox = double g_a22Ow
                      (g_a22Ow, gpart_a22PC) = Genome.Split.split gpart_a22PB
                      p_a22Ov = Functions.belowten' g_a22Ou
                      (g_a22Ou, gpart_a22PB) = Genome.Split.split gpart_a22PA
                      p_a22Ot = double g_a22Os
                      (g_a22Os, gpart_a22PA) = Genome.Split.split gpart_a22Pz
                      p_a22Or = Functions.belowten' g_a22Oq
                      (g_a22Oq, gpart_a22Pz) = Genome.Split.split gpart_a22Py
                      p_a22Op = double g_a22Oo
                      (g_a22Oo, gpart_a22Py) = Genome.Split.split gpart_a22Px
                      p_a22On = double g_a22Om
                      (g_a22Om, gpart_a22Px) = Genome.Split.split gpart_a22Pw
                      p_a22Ol = Functions.belowten' g_a22Ok
                      (g_a22Ok, gpart_a22Pw) = Genome.Split.split gpart_a22Pv
                      p_a22Oj = double g_a22Oi
                      (g_a22Oi, gpart_a22Pv) = Genome.Split.split gpart_a22Pu
                      p_a22Oh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Og
                      (g_a22Og, gpart_a22Pu) = Genome.Split.split gpart_a22Pt
                      p_a22Of
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Oe
                      (g_a22Oe, gpart_a22Pt) = Genome.Split.split gpart_a22Ps
                      p_a22Od = double g_a22Oc
                      (g_a22Oc, gpart_a22Ps) = Genome.Split.split gpart_a22Pr
                      p_a22Ob = double g_a22Oa
                      (g_a22Oa, gpart_a22Pr) = Genome.Split.split gpart_a22Pq
                      p_a22O9 = double g_a22O8
                      (g_a22O8, gpart_a22Pq) = Genome.Split.split gpart_a22Pp
                      p_a22O7 = double g_a22O6
                      (g_a22O6, gpart_a22Pp) = Genome.Split.split gpart_a22Po
                      p_a22O5 = double g_a22O4
                      (g_a22O4, gpart_a22Po) = Genome.Split.split genome_a22Pm
                    in  \ x_a22Q2
                          -> let
                               c_PTB_a22Q5
                                 = ((Data.Fixed.Vector.toVector x_a22Q2) Data.Vector.Unboxed.! 0)
                               c_MiRs_a22Q3
                                 = ((Data.Fixed.Vector.toVector x_a22Q2) Data.Vector.Unboxed.! 2)
                               c_NPTB_a22Qa
                                 = ((Data.Fixed.Vector.toVector x_a22Q2) Data.Vector.Unboxed.! 1)
                               c_RESTc_a22Q6
                                 = ((Data.Fixed.Vector.toVector x_a22Q2) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a22Qm
                                 = ((Data.Fixed.Vector.toVector x_a22Q2) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a22Od / (1 + ((c_MiRs_a22Q3 / p_a22Oj) ** p_a22Ol)))
                                    + (negate (p_a22Pd * c_PTB_a22Q5))),
                                   ((p_a22On
                                     / (1
                                        + ((((c_RESTc_a22Q6 / p_a22Op) ** p_a22Or)
                                            + ((c_MiRs_a22Q3 / p_a22Ot) ** p_a22Ov))
                                           + ((c_PTB_a22Q5 / p_a22Ox) ** p_a22Oz))))
                                    + (negate (p_a22Pf * c_NPTB_a22Qa))),
                                   ((p_a22OB
                                     * ((p_a22OP + ((p_a22O9 / p_a22OD) ** p_a22OF))
                                        / (((1 + p_a22OP) + ((p_a22O9 / p_a22OD) ** p_a22OF))
                                           + (((c_NPTB_a22Qa / p_a22OH) ** p_a22OJ)
                                              + ((c_RESTc_a22Q6 / p_a22OL) ** p_a22ON)))))
                                    + (negate (p_a22Ph * c_MiRs_a22Q3))),
                                   ((p_a22OR
                                     * ((p_a22P5 + ((c_PTB_a22Q5 / p_a22OT) ** p_a22OV))
                                        / (((1 + p_a22P5) + ((c_PTB_a22Q5 / p_a22OT) ** p_a22OV))
                                           + (((p_a22O5 / p_a22OX) ** p_a22OZ)
                                              + ((c_MiRs_a22Q3 / p_a22P1) ** p_a22P3)))))
                                    + (negate (p_a22Pj * c_RESTc_a22Q6))),
                                   ((p_a22P7 / (1 + ((c_RESTc_a22Q6 / p_a22P9) ** p_a22Pb)))
                                    + (negate (p_a22Pl * c_EndoNeuroTFs_a22Qm)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497247",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497251",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497253",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497265",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497267",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497271",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497273",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497275",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497277",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497295",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497297",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497299",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497301",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497309",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497311",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497313",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497315",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497317",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497319",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a22Pm
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a22R0
                            p_a22Pl = double g_a22Pk
                            (g_a22Pk, gpart_a22R0) = Genome.Split.split gpart_a22QZ
                            p_a22Pj = double g_a22Pi
                            (g_a22Pi, gpart_a22QZ) = Genome.Split.split gpart_a22QY
                            p_a22Ph = double g_a22Pg
                            (g_a22Pg, gpart_a22QY) = Genome.Split.split gpart_a22QX
                            p_a22Pf = double g_a22Pe
                            (g_a22Pe, gpart_a22QX) = Genome.Split.split gpart_a22QW
                            p_a22Pd = double g_a22Pc
                            (g_a22Pc, gpart_a22QW) = Genome.Split.split gpart_a22QV
                            p_a22Pb = Functions.belowten' g_a22Pa
                            (g_a22Pa, gpart_a22QV) = Genome.Split.split gpart_a22QU
                            p_a22P9 = double g_a22P8
                            (g_a22P8, gpart_a22QU) = Genome.Split.split gpart_a22QT
                            p_a22P7 = double g_a22P6
                            (g_a22P6, gpart_a22QT) = Genome.Split.split gpart_a22QS
                            p_a22P5 = double g_a22P4
                            (g_a22P4, gpart_a22QS) = Genome.Split.split gpart_a22QR
                            p_a22P3 = Functions.belowten' g_a22P2
                            (g_a22P2, gpart_a22QR) = Genome.Split.split gpart_a22QQ
                            p_a22P1 = double g_a22P0
                            (g_a22P0, gpart_a22QQ) = Genome.Split.split gpart_a22QP
                            p_a22OZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22OY
                            (g_a22OY, gpart_a22QP) = Genome.Split.split gpart_a22QO
                            p_a22OX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22OW
                            (g_a22OW, gpart_a22QO) = Genome.Split.split gpart_a22QN
                            p_a22OV = Functions.belowten' g_a22OU
                            (g_a22OU, gpart_a22QN) = Genome.Split.split gpart_a22QM
                            p_a22OT = double g_a22OS
                            (g_a22OS, gpart_a22QM) = Genome.Split.split gpart_a22QL
                            p_a22OR = double g_a22OQ
                            (g_a22OQ, gpart_a22QL) = Genome.Split.split gpart_a22QK
                            p_a22OP = double g_a22OO
                            (g_a22OO, gpart_a22QK) = Genome.Split.split gpart_a22QJ
                            p_a22ON = Functions.belowten' g_a22OM
                            (g_a22OM, gpart_a22QJ) = Genome.Split.split gpart_a22QI
                            p_a22OL = double g_a22OK
                            (g_a22OK, gpart_a22QI) = Genome.Split.split gpart_a22QH
                            p_a22OJ = Functions.belowten' g_a22OI
                            (g_a22OI, gpart_a22QH) = Genome.Split.split gpart_a22QG
                            p_a22OH = double g_a22OG
                            (g_a22OG, gpart_a22QG) = Genome.Split.split gpart_a22QF
                            p_a22OF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22OE
                            (g_a22OE, gpart_a22QF) = Genome.Split.split gpart_a22QE
                            p_a22OD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22OC
                            (g_a22OC, gpart_a22QE) = Genome.Split.split gpart_a22QD
                            p_a22OB = double g_a22OA
                            (g_a22OA, gpart_a22QD) = Genome.Split.split gpart_a22QC
                            p_a22Oz = Functions.belowten' g_a22Oy
                            (g_a22Oy, gpart_a22QC) = Genome.Split.split gpart_a22QB
                            p_a22Ox = double g_a22Ow
                            (g_a22Ow, gpart_a22QB) = Genome.Split.split gpart_a22QA
                            p_a22Ov = Functions.belowten' g_a22Ou
                            (g_a22Ou, gpart_a22QA) = Genome.Split.split gpart_a22Qz
                            p_a22Ot = double g_a22Os
                            (g_a22Os, gpart_a22Qz) = Genome.Split.split gpart_a22Qy
                            p_a22Or = Functions.belowten' g_a22Oq
                            (g_a22Oq, gpart_a22Qy) = Genome.Split.split gpart_a22Qx
                            p_a22Op = double g_a22Oo
                            (g_a22Oo, gpart_a22Qx) = Genome.Split.split gpart_a22Qw
                            p_a22On = double g_a22Om
                            (g_a22Om, gpart_a22Qw) = Genome.Split.split gpart_a22Qv
                            p_a22Ol = Functions.belowten' g_a22Ok
                            (g_a22Ok, gpart_a22Qv) = Genome.Split.split gpart_a22Qu
                            p_a22Oj = double g_a22Oi
                            (g_a22Oi, gpart_a22Qu) = Genome.Split.split gpart_a22Qt
                            p_a22Oh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Og
                            (g_a22Og, gpart_a22Qt) = Genome.Split.split gpart_a22Qs
                            p_a22Of
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Oe
                            (g_a22Oe, gpart_a22Qs) = Genome.Split.split gpart_a22Qr
                            p_a22Od = double g_a22Oc
                            (g_a22Oc, gpart_a22Qr) = Genome.Split.split gpart_a22Qq
                            p_a22Ob = double g_a22Oa
                            (g_a22Oa, gpart_a22Qq) = Genome.Split.split gpart_a22Qp
                            p_a22O9 = double g_a22O8
                            (g_a22O8, gpart_a22Qp) = Genome.Split.split gpart_a22Qo
                            p_a22O7 = double g_a22O6
                            (g_a22O6, gpart_a22Qo) = Genome.Split.split gpart_a22Qn
                            p_a22O5 = double g_a22O4
                            (g_a22O4, gpart_a22Qn) = Genome.Split.split genome_a22Pm
                          in
                            \ desc_a22Pn
                              -> case desc_a22Pn of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22O5)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22O7)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22O9)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Ob)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Od)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Of)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Oh)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Oj)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Ol)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22On)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Op)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Or)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Ot)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Ov)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Ox)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Oz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OB)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OD)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OF)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OH)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OJ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OL)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22ON)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OP)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OR)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OT)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OV)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OX)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22OZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22P1)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22P3)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22P5)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22P7)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22P9)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Pb)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Pd)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Pf)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Ph)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Pj)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Pl)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a22Ts
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a22U7
                      p_a22Tr = double g_a22Tq
                      (g_a22Tq, gpart_a22U7) = Genome.Split.split gpart_a22U6
                      p_a22Tp = double g_a22To
                      (g_a22To, gpart_a22U6) = Genome.Split.split gpart_a22U5
                      p_a22Tn = double g_a22Tm
                      (g_a22Tm, gpart_a22U5) = Genome.Split.split gpart_a22U4
                      p_a22Tl = double g_a22Tk
                      (g_a22Tk, gpart_a22U4) = Genome.Split.split gpart_a22U3
                      p_a22Tj = double g_a22Ti
                      (g_a22Ti, gpart_a22U3) = Genome.Split.split gpart_a22U2
                      p_a22Th = Functions.belowten' g_a22Tg
                      (g_a22Tg, gpart_a22U2) = Genome.Split.split gpart_a22U1
                      p_a22Tf = double g_a22Te
                      (g_a22Te, gpart_a22U1) = Genome.Split.split gpart_a22U0
                      p_a22Td = double g_a22Tc
                      (g_a22Tc, gpart_a22U0) = Genome.Split.split gpart_a22TZ
                      p_a22Tb = double g_a22Ta
                      (g_a22Ta, gpart_a22TZ) = Genome.Split.split gpart_a22TY
                      p_a22T9 = Functions.belowten' g_a22T8
                      (g_a22T8, gpart_a22TY) = Genome.Split.split gpart_a22TX
                      p_a22T7 = double g_a22T6
                      (g_a22T6, gpart_a22TX) = Genome.Split.split gpart_a22TW
                      p_a22T5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22T4
                      (g_a22T4, gpart_a22TW) = Genome.Split.split gpart_a22TV
                      p_a22T3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22T2
                      (g_a22T2, gpart_a22TV) = Genome.Split.split gpart_a22TU
                      p_a22T1 = Functions.belowten' g_a22T0
                      (g_a22T0, gpart_a22TU) = Genome.Split.split gpart_a22TT
                      p_a22SZ = double g_a22SY
                      (g_a22SY, gpart_a22TT) = Genome.Split.split gpart_a22TS
                      p_a22SX = double g_a22SW
                      (g_a22SW, gpart_a22TS) = Genome.Split.split gpart_a22TR
                      p_a22SV = double g_a22SU
                      (g_a22SU, gpart_a22TR) = Genome.Split.split gpart_a22TQ
                      p_a22ST = Functions.belowten' g_a22SS
                      (g_a22SS, gpart_a22TQ) = Genome.Split.split gpart_a22TP
                      p_a22SR = double g_a22SQ
                      (g_a22SQ, gpart_a22TP) = Genome.Split.split gpart_a22TO
                      p_a22SP = Functions.belowten' g_a22SO
                      (g_a22SO, gpart_a22TO) = Genome.Split.split gpart_a22TN
                      p_a22SN = double g_a22SM
                      (g_a22SM, gpart_a22TN) = Genome.Split.split gpart_a22TM
                      p_a22SL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22SK
                      (g_a22SK, gpart_a22TM) = Genome.Split.split gpart_a22TL
                      p_a22SJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22SI
                      (g_a22SI, gpart_a22TL) = Genome.Split.split gpart_a22TK
                      p_a22SH = double g_a22SG
                      (g_a22SG, gpart_a22TK) = Genome.Split.split gpart_a22TJ
                      p_a22SF = Functions.belowten' g_a22SE
                      (g_a22SE, gpart_a22TJ) = Genome.Split.split gpart_a22TI
                      p_a22SD = double g_a22SC
                      (g_a22SC, gpart_a22TI) = Genome.Split.split gpart_a22TH
                      p_a22SB = Functions.belowten' g_a22SA
                      (g_a22SA, gpart_a22TH) = Genome.Split.split gpart_a22TG
                      p_a22Sz = double g_a22Sy
                      (g_a22Sy, gpart_a22TG) = Genome.Split.split gpart_a22TF
                      p_a22Sx = Functions.belowten' g_a22Sw
                      (g_a22Sw, gpart_a22TF) = Genome.Split.split gpart_a22TE
                      p_a22Sv = double g_a22Su
                      (g_a22Su, gpart_a22TE) = Genome.Split.split gpart_a22TD
                      p_a22St = double g_a22Ss
                      (g_a22Ss, gpart_a22TD) = Genome.Split.split gpart_a22TC
                      p_a22Sr = Functions.belowten' g_a22Sq
                      (g_a22Sq, gpart_a22TC) = Genome.Split.split gpart_a22TB
                      p_a22Sp = double g_a22So
                      (g_a22So, gpart_a22TB) = Genome.Split.split gpart_a22TA
                      p_a22Sn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Sm
                      (g_a22Sm, gpart_a22TA) = Genome.Split.split gpart_a22Tz
                      p_a22Sl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Sk
                      (g_a22Sk, gpart_a22Tz) = Genome.Split.split gpart_a22Ty
                      p_a22Sj = double g_a22Si
                      (g_a22Si, gpart_a22Ty) = Genome.Split.split gpart_a22Tx
                      p_a22Sh = double g_a22Sg
                      (g_a22Sg, gpart_a22Tx) = Genome.Split.split gpart_a22Tw
                      p_a22Sf = double g_a22Se
                      (g_a22Se, gpart_a22Tw) = Genome.Split.split gpart_a22Tv
                      p_a22Sd = double g_a22Sc
                      (g_a22Sc, gpart_a22Tv) = Genome.Split.split gpart_a22Tu
                      p_a22Sb = double g_a22Sa
                      (g_a22Sa, gpart_a22Tu) = Genome.Split.split genome_a22Ts
                    in  \ x_a22U8
                          -> let
                               c_PTB_a22Ub
                                 = ((Data.Fixed.Vector.toVector x_a22U8) Data.Vector.Unboxed.! 0)
                               c_MiRs_a22U9
                                 = ((Data.Fixed.Vector.toVector x_a22U8) Data.Vector.Unboxed.! 2)
                               c_NPTB_a22Ug
                                 = ((Data.Fixed.Vector.toVector x_a22U8) Data.Vector.Unboxed.! 1)
                               c_RESTc_a22Uc
                                 = ((Data.Fixed.Vector.toVector x_a22U8) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a22Us
                                 = ((Data.Fixed.Vector.toVector x_a22U8) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a22Sj / (1 + ((c_MiRs_a22U9 / p_a22Sp) ** p_a22Sr)))
                                    + (negate (p_a22Tj * c_PTB_a22Ub))),
                                   ((p_a22St
                                     / (1
                                        + ((((c_RESTc_a22Uc / p_a22Sv) ** p_a22Sx)
                                            + ((c_MiRs_a22U9 / p_a22Sz) ** p_a22SB))
                                           + ((c_PTB_a22Ub / p_a22SD) ** p_a22SF))))
                                    + (negate (p_a22Tl * c_NPTB_a22Ug))),
                                   ((p_a22SH
                                     * (p_a22SV
                                        / ((1 + p_a22SV)
                                           + (((c_NPTB_a22Ug / p_a22SN) ** p_a22SP)
                                              + ((c_RESTc_a22Uc / p_a22SR) ** p_a22ST)))))
                                    + (negate (p_a22Tn * c_MiRs_a22U9))),
                                   ((p_a22SX
                                     * ((p_a22Tb + ((c_PTB_a22Ub / p_a22SZ) ** p_a22T1))
                                        / (((1 + p_a22Tb) + ((c_PTB_a22Ub / p_a22SZ) ** p_a22T1))
                                           + (((p_a22Sb / p_a22T3) ** p_a22T5)
                                              + ((c_MiRs_a22U9 / p_a22T7) ** p_a22T9)))))
                                    + (negate (p_a22Tp * c_RESTc_a22Uc))),
                                   ((p_a22Td / (1 + ((c_RESTc_a22Uc / p_a22Tf) ** p_a22Th)))
                                    + (negate (p_a22Tr * c_EndoNeuroTFs_a22Us)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497497",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497499",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497501",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497503",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497505",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497507",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497509",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497529",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497531",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497549",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497551",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a22Ts
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a22V6
                            p_a22Tr = double g_a22Tq
                            (g_a22Tq, gpart_a22V6) = Genome.Split.split gpart_a22V5
                            p_a22Tp = double g_a22To
                            (g_a22To, gpart_a22V5) = Genome.Split.split gpart_a22V4
                            p_a22Tn = double g_a22Tm
                            (g_a22Tm, gpart_a22V4) = Genome.Split.split gpart_a22V3
                            p_a22Tl = double g_a22Tk
                            (g_a22Tk, gpart_a22V3) = Genome.Split.split gpart_a22V2
                            p_a22Tj = double g_a22Ti
                            (g_a22Ti, gpart_a22V2) = Genome.Split.split gpart_a22V1
                            p_a22Th = Functions.belowten' g_a22Tg
                            (g_a22Tg, gpart_a22V1) = Genome.Split.split gpart_a22V0
                            p_a22Tf = double g_a22Te
                            (g_a22Te, gpart_a22V0) = Genome.Split.split gpart_a22UZ
                            p_a22Td = double g_a22Tc
                            (g_a22Tc, gpart_a22UZ) = Genome.Split.split gpart_a22UY
                            p_a22Tb = double g_a22Ta
                            (g_a22Ta, gpart_a22UY) = Genome.Split.split gpart_a22UX
                            p_a22T9 = Functions.belowten' g_a22T8
                            (g_a22T8, gpart_a22UX) = Genome.Split.split gpart_a22UW
                            p_a22T7 = double g_a22T6
                            (g_a22T6, gpart_a22UW) = Genome.Split.split gpart_a22UV
                            p_a22T5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22T4
                            (g_a22T4, gpart_a22UV) = Genome.Split.split gpart_a22UU
                            p_a22T3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22T2
                            (g_a22T2, gpart_a22UU) = Genome.Split.split gpart_a22UT
                            p_a22T1 = Functions.belowten' g_a22T0
                            (g_a22T0, gpart_a22UT) = Genome.Split.split gpart_a22US
                            p_a22SZ = double g_a22SY
                            (g_a22SY, gpart_a22US) = Genome.Split.split gpart_a22UR
                            p_a22SX = double g_a22SW
                            (g_a22SW, gpart_a22UR) = Genome.Split.split gpart_a22UQ
                            p_a22SV = double g_a22SU
                            (g_a22SU, gpart_a22UQ) = Genome.Split.split gpart_a22UP
                            p_a22ST = Functions.belowten' g_a22SS
                            (g_a22SS, gpart_a22UP) = Genome.Split.split gpart_a22UO
                            p_a22SR = double g_a22SQ
                            (g_a22SQ, gpart_a22UO) = Genome.Split.split gpart_a22UN
                            p_a22SP = Functions.belowten' g_a22SO
                            (g_a22SO, gpart_a22UN) = Genome.Split.split gpart_a22UM
                            p_a22SN = double g_a22SM
                            (g_a22SM, gpart_a22UM) = Genome.Split.split gpart_a22UL
                            p_a22SL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22SK
                            (g_a22SK, gpart_a22UL) = Genome.Split.split gpart_a22UK
                            p_a22SJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22SI
                            (g_a22SI, gpart_a22UK) = Genome.Split.split gpart_a22UJ
                            p_a22SH = double g_a22SG
                            (g_a22SG, gpart_a22UJ) = Genome.Split.split gpart_a22UI
                            p_a22SF = Functions.belowten' g_a22SE
                            (g_a22SE, gpart_a22UI) = Genome.Split.split gpart_a22UH
                            p_a22SD = double g_a22SC
                            (g_a22SC, gpart_a22UH) = Genome.Split.split gpart_a22UG
                            p_a22SB = Functions.belowten' g_a22SA
                            (g_a22SA, gpart_a22UG) = Genome.Split.split gpart_a22UF
                            p_a22Sz = double g_a22Sy
                            (g_a22Sy, gpart_a22UF) = Genome.Split.split gpart_a22UE
                            p_a22Sx = Functions.belowten' g_a22Sw
                            (g_a22Sw, gpart_a22UE) = Genome.Split.split gpart_a22UD
                            p_a22Sv = double g_a22Su
                            (g_a22Su, gpart_a22UD) = Genome.Split.split gpart_a22UC
                            p_a22St = double g_a22Ss
                            (g_a22Ss, gpart_a22UC) = Genome.Split.split gpart_a22UB
                            p_a22Sr = Functions.belowten' g_a22Sq
                            (g_a22Sq, gpart_a22UB) = Genome.Split.split gpart_a22UA
                            p_a22Sp = double g_a22So
                            (g_a22So, gpart_a22UA) = Genome.Split.split gpart_a22Uz
                            p_a22Sn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Sm
                            (g_a22Sm, gpart_a22Uz) = Genome.Split.split gpart_a22Uy
                            p_a22Sl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Sk
                            (g_a22Sk, gpart_a22Uy) = Genome.Split.split gpart_a22Ux
                            p_a22Sj = double g_a22Si
                            (g_a22Si, gpart_a22Ux) = Genome.Split.split gpart_a22Uw
                            p_a22Sh = double g_a22Sg
                            (g_a22Sg, gpart_a22Uw) = Genome.Split.split gpart_a22Uv
                            p_a22Sf = double g_a22Se
                            (g_a22Se, gpart_a22Uv) = Genome.Split.split gpart_a22Uu
                            p_a22Sd = double g_a22Sc
                            (g_a22Sc, gpart_a22Uu) = Genome.Split.split gpart_a22Ut
                            p_a22Sb = double g_a22Sa
                            (g_a22Sa, gpart_a22Ut) = Genome.Split.split genome_a22Ts
                          in
                            \ desc_a22Tt
                              -> case desc_a22Tt of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sb)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sd)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sf)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sh)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sj)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sl)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sn)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sp)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sr)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22St)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sv)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sx)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Sz)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SB)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SD)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SF)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SH)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SJ)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SL)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SN)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SP)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SR)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22ST)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SV)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SX)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22SZ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22T1)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22T3)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22T5)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22T7)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22T9)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Tb)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Td)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Tf)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Th)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Tj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Tl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Tn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Tp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Tr)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a22Xy
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a22Yd
                      p_a22Xx = double g_a22Xw
                      (g_a22Xw, gpart_a22Yd) = Genome.Split.split gpart_a22Yc
                      p_a22Xv = double g_a22Xu
                      (g_a22Xu, gpart_a22Yc) = Genome.Split.split gpart_a22Yb
                      p_a22Xt = double g_a22Xs
                      (g_a22Xs, gpart_a22Yb) = Genome.Split.split gpart_a22Ya
                      p_a22Xr = double g_a22Xq
                      (g_a22Xq, gpart_a22Ya) = Genome.Split.split gpart_a22Y9
                      p_a22Xp = double g_a22Xo
                      (g_a22Xo, gpart_a22Y9) = Genome.Split.split gpart_a22Y8
                      p_a22Xn = Functions.belowten' g_a22Xm
                      (g_a22Xm, gpart_a22Y8) = Genome.Split.split gpart_a22Y7
                      p_a22Xl = double g_a22Xk
                      (g_a22Xk, gpart_a22Y7) = Genome.Split.split gpart_a22Y6
                      p_a22Xj = double g_a22Xi
                      (g_a22Xi, gpart_a22Y6) = Genome.Split.split gpart_a22Y5
                      p_a22Xh = double g_a22Xg
                      (g_a22Xg, gpart_a22Y5) = Genome.Split.split gpart_a22Y4
                      p_a22Xf = Functions.belowten' g_a22Xe
                      (g_a22Xe, gpart_a22Y4) = Genome.Split.split gpart_a22Y3
                      p_a22Xd = double g_a22Xc
                      (g_a22Xc, gpart_a22Y3) = Genome.Split.split gpart_a22Y2
                      p_a22Xb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Xa
                      (g_a22Xa, gpart_a22Y2) = Genome.Split.split gpart_a22Y1
                      p_a22X9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22X8
                      (g_a22X8, gpart_a22Y1) = Genome.Split.split gpart_a22Y0
                      p_a22X7 = Functions.belowten' g_a22X6
                      (g_a22X6, gpart_a22Y0) = Genome.Split.split gpart_a22XZ
                      p_a22X5 = double g_a22X4
                      (g_a22X4, gpart_a22XZ) = Genome.Split.split gpart_a22XY
                      p_a22X3 = double g_a22X2
                      (g_a22X2, gpart_a22XY) = Genome.Split.split gpart_a22XX
                      p_a22X1 = double g_a22X0
                      (g_a22X0, gpart_a22XX) = Genome.Split.split gpart_a22XW
                      p_a22WZ = Functions.belowten' g_a22WY
                      (g_a22WY, gpart_a22XW) = Genome.Split.split gpart_a22XV
                      p_a22WX = double g_a22WW
                      (g_a22WW, gpart_a22XV) = Genome.Split.split gpart_a22XU
                      p_a22WV = Functions.belowten' g_a22WU
                      (g_a22WU, gpart_a22XU) = Genome.Split.split gpart_a22XT
                      p_a22WT = double g_a22WS
                      (g_a22WS, gpart_a22XT) = Genome.Split.split gpart_a22XS
                      p_a22WR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22WQ
                      (g_a22WQ, gpart_a22XS) = Genome.Split.split gpart_a22XR
                      p_a22WP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22WO
                      (g_a22WO, gpart_a22XR) = Genome.Split.split gpart_a22XQ
                      p_a22WN = double g_a22WM
                      (g_a22WM, gpart_a22XQ) = Genome.Split.split gpart_a22XP
                      p_a22WL = Functions.belowten' g_a22WK
                      (g_a22WK, gpart_a22XP) = Genome.Split.split gpart_a22XO
                      p_a22WJ = double g_a22WI
                      (g_a22WI, gpart_a22XO) = Genome.Split.split gpart_a22XN
                      p_a22WH = Functions.belowten' g_a22WG
                      (g_a22WG, gpart_a22XN) = Genome.Split.split gpart_a22XM
                      p_a22WF = double g_a22WE
                      (g_a22WE, gpart_a22XM) = Genome.Split.split gpart_a22XL
                      p_a22WD = Functions.belowten' g_a22WC
                      (g_a22WC, gpart_a22XL) = Genome.Split.split gpart_a22XK
                      p_a22WB = double g_a22WA
                      (g_a22WA, gpart_a22XK) = Genome.Split.split gpart_a22XJ
                      p_a22Wz = double g_a22Wy
                      (g_a22Wy, gpart_a22XJ) = Genome.Split.split gpart_a22XI
                      p_a22Wx = Functions.belowten' g_a22Ww
                      (g_a22Ww, gpart_a22XI) = Genome.Split.split gpart_a22XH
                      p_a22Wv = double g_a22Wu
                      (g_a22Wu, gpart_a22XH) = Genome.Split.split gpart_a22XG
                      p_a22Wt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Ws
                      (g_a22Ws, gpart_a22XG) = Genome.Split.split gpart_a22XF
                      p_a22Wr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Wq
                      (g_a22Wq, gpart_a22XF) = Genome.Split.split gpart_a22XE
                      p_a22Wp = double g_a22Wo
                      (g_a22Wo, gpart_a22XE) = Genome.Split.split gpart_a22XD
                      p_a22Wn = double g_a22Wm
                      (g_a22Wm, gpart_a22XD) = Genome.Split.split gpart_a22XC
                      p_a22Wl = double g_a22Wk
                      (g_a22Wk, gpart_a22XC) = Genome.Split.split gpart_a22XB
                      p_a22Wj = double g_a22Wi
                      (g_a22Wi, gpart_a22XB) = Genome.Split.split gpart_a22XA
                      p_a22Wh = double g_a22Wg
                      (g_a22Wg, gpart_a22XA) = Genome.Split.split genome_a22Xy
                    in  \ x_a22Ye
                          -> let
                               c_PTB_a22Yh
                                 = ((Data.Fixed.Vector.toVector x_a22Ye) Data.Vector.Unboxed.! 0)
                               c_MiRs_a22Yf
                                 = ((Data.Fixed.Vector.toVector x_a22Ye) Data.Vector.Unboxed.! 2)
                               c_NPTB_a22Ym
                                 = ((Data.Fixed.Vector.toVector x_a22Ye) Data.Vector.Unboxed.! 1)
                               c_RESTc_a22Yi
                                 = ((Data.Fixed.Vector.toVector x_a22Ye) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a22Yy
                                 = ((Data.Fixed.Vector.toVector x_a22Ye) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a22Wp / (1 + ((c_MiRs_a22Yf / p_a22Wv) ** p_a22Wx)))
                                    + (negate (p_a22Xp * c_PTB_a22Yh))),
                                   ((p_a22Wz
                                     / (1
                                        + ((((c_RESTc_a22Yi / p_a22WB) ** p_a22WD)
                                            + ((c_MiRs_a22Yf / p_a22WF) ** p_a22WH))
                                           + ((c_PTB_a22Yh / p_a22WJ) ** p_a22WL))))
                                    + (negate (p_a22Xr * c_NPTB_a22Ym))),
                                   ((p_a22WN
                                     * (p_a22X1
                                        / ((1 + p_a22X1)
                                           + (((c_NPTB_a22Ym / p_a22WT) ** p_a22WV)
                                              + ((c_RESTc_a22Yi / p_a22WX) ** p_a22WZ)))))
                                    + (negate (p_a22Xt * c_MiRs_a22Yf))),
                                   ((p_a22X3
                                     * ((p_a22Xh + ((c_PTB_a22Yh / p_a22X5) ** p_a22X7))
                                        / (((1 + p_a22Xh) + ((c_PTB_a22Yh / p_a22X5) ** p_a22X7))
                                           + ((c_MiRs_a22Yf / p_a22Xd) ** p_a22Xf))))
                                    + (negate (p_a22Xv * c_RESTc_a22Yi))),
                                   ((p_a22Xj / (1 + ((c_RESTc_a22Yi / p_a22Xl) ** p_a22Xn)))
                                    + (negate (p_a22Xx * c_EndoNeuroTFs_a22Yy)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497748",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497749",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497750",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497751",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497752",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497753",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497754",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497755",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497757",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497758",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497759",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497760",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497761",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497762",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497763",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497764",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497765",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497766",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497767",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497768",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497769",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497770",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497771",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497772",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497773",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497774",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497775",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497776",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497777",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497778",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497779",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497780",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497781",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497782",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497783",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497784",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497785",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497787",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497795",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497798",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497799",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497800",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497801",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497802",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497803",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497805",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497807",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497809",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497811",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497817",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497819",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497821",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497823",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679497826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679497827",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a22Xy
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a22Zc
                            p_a22Xx = double g_a22Xw
                            (g_a22Xw, gpart_a22Zc) = Genome.Split.split gpart_a22Zb
                            p_a22Xv = double g_a22Xu
                            (g_a22Xu, gpart_a22Zb) = Genome.Split.split gpart_a22Za
                            p_a22Xt = double g_a22Xs
                            (g_a22Xs, gpart_a22Za) = Genome.Split.split gpart_a22Z9
                            p_a22Xr = double g_a22Xq
                            (g_a22Xq, gpart_a22Z9) = Genome.Split.split gpart_a22Z8
                            p_a22Xp = double g_a22Xo
                            (g_a22Xo, gpart_a22Z8) = Genome.Split.split gpart_a22Z7
                            p_a22Xn = Functions.belowten' g_a22Xm
                            (g_a22Xm, gpart_a22Z7) = Genome.Split.split gpart_a22Z6
                            p_a22Xl = double g_a22Xk
                            (g_a22Xk, gpart_a22Z6) = Genome.Split.split gpart_a22Z5
                            p_a22Xj = double g_a22Xi
                            (g_a22Xi, gpart_a22Z5) = Genome.Split.split gpart_a22Z4
                            p_a22Xh = double g_a22Xg
                            (g_a22Xg, gpart_a22Z4) = Genome.Split.split gpart_a22Z3
                            p_a22Xf = Functions.belowten' g_a22Xe
                            (g_a22Xe, gpart_a22Z3) = Genome.Split.split gpart_a22Z2
                            p_a22Xd = double g_a22Xc
                            (g_a22Xc, gpart_a22Z2) = Genome.Split.split gpart_a22Z1
                            p_a22Xb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Xa
                            (g_a22Xa, gpart_a22Z1) = Genome.Split.split gpart_a22Z0
                            p_a22X9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22X8
                            (g_a22X8, gpart_a22Z0) = Genome.Split.split gpart_a22YZ
                            p_a22X7 = Functions.belowten' g_a22X6
                            (g_a22X6, gpart_a22YZ) = Genome.Split.split gpart_a22YY
                            p_a22X5 = double g_a22X4
                            (g_a22X4, gpart_a22YY) = Genome.Split.split gpart_a22YX
                            p_a22X3 = double g_a22X2
                            (g_a22X2, gpart_a22YX) = Genome.Split.split gpart_a22YW
                            p_a22X1 = double g_a22X0
                            (g_a22X0, gpart_a22YW) = Genome.Split.split gpart_a22YV
                            p_a22WZ = Functions.belowten' g_a22WY
                            (g_a22WY, gpart_a22YV) = Genome.Split.split gpart_a22YU
                            p_a22WX = double g_a22WW
                            (g_a22WW, gpart_a22YU) = Genome.Split.split gpart_a22YT
                            p_a22WV = Functions.belowten' g_a22WU
                            (g_a22WU, gpart_a22YT) = Genome.Split.split gpart_a22YS
                            p_a22WT = double g_a22WS
                            (g_a22WS, gpart_a22YS) = Genome.Split.split gpart_a22YR
                            p_a22WR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22WQ
                            (g_a22WQ, gpart_a22YR) = Genome.Split.split gpart_a22YQ
                            p_a22WP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22WO
                            (g_a22WO, gpart_a22YQ) = Genome.Split.split gpart_a22YP
                            p_a22WN = double g_a22WM
                            (g_a22WM, gpart_a22YP) = Genome.Split.split gpart_a22YO
                            p_a22WL = Functions.belowten' g_a22WK
                            (g_a22WK, gpart_a22YO) = Genome.Split.split gpart_a22YN
                            p_a22WJ = double g_a22WI
                            (g_a22WI, gpart_a22YN) = Genome.Split.split gpart_a22YM
                            p_a22WH = Functions.belowten' g_a22WG
                            (g_a22WG, gpart_a22YM) = Genome.Split.split gpart_a22YL
                            p_a22WF = double g_a22WE
                            (g_a22WE, gpart_a22YL) = Genome.Split.split gpart_a22YK
                            p_a22WD = Functions.belowten' g_a22WC
                            (g_a22WC, gpart_a22YK) = Genome.Split.split gpart_a22YJ
                            p_a22WB = double g_a22WA
                            (g_a22WA, gpart_a22YJ) = Genome.Split.split gpart_a22YI
                            p_a22Wz = double g_a22Wy
                            (g_a22Wy, gpart_a22YI) = Genome.Split.split gpart_a22YH
                            p_a22Wx = Functions.belowten' g_a22Ww
                            (g_a22Ww, gpart_a22YH) = Genome.Split.split gpart_a22YG
                            p_a22Wv = double g_a22Wu
                            (g_a22Wu, gpart_a22YG) = Genome.Split.split gpart_a22YF
                            p_a22Wt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Ws
                            (g_a22Ws, gpart_a22YF) = Genome.Split.split gpart_a22YE
                            p_a22Wr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a22Wq
                            (g_a22Wq, gpart_a22YE) = Genome.Split.split gpart_a22YD
                            p_a22Wp = double g_a22Wo
                            (g_a22Wo, gpart_a22YD) = Genome.Split.split gpart_a22YC
                            p_a22Wn = double g_a22Wm
                            (g_a22Wm, gpart_a22YC) = Genome.Split.split gpart_a22YB
                            p_a22Wl = double g_a22Wk
                            (g_a22Wk, gpart_a22YB) = Genome.Split.split gpart_a22YA
                            p_a22Wj = double g_a22Wi
                            (g_a22Wi, gpart_a22YA) = Genome.Split.split gpart_a22Yz
                            p_a22Wh = double g_a22Wg
                            (g_a22Wg, gpart_a22Yz) = Genome.Split.split genome_a22Xy
                          in
                            \ desc_a22Xz
                              -> case desc_a22Xz of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wh)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wj)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wl)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wn)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wp)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wr)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wt)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wv)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wx)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Wz)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WB)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WD)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WF)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WH)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WJ)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WL)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WN)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WP)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WR)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WT)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WV)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WX)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22WZ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22X1)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22X3)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22X5)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22X7)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22X9)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xb)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xd)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xf)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xh)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xj)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xl)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xn)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xp)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xr)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xt)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xv)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a22Xx)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a231E
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a232j
                      p_a231D = double g_a231C
                      (g_a231C, gpart_a232j) = Genome.Split.split gpart_a232i
                      p_a231B = double g_a231A
                      (g_a231A, gpart_a232i) = Genome.Split.split gpart_a232h
                      p_a231z = double g_a231y
                      (g_a231y, gpart_a232h) = Genome.Split.split gpart_a232g
                      p_a231x = double g_a231w
                      (g_a231w, gpart_a232g) = Genome.Split.split gpart_a232f
                      p_a231v = double g_a231u
                      (g_a231u, gpart_a232f) = Genome.Split.split gpart_a232e
                      p_a231t = Functions.belowten' g_a231s
                      (g_a231s, gpart_a232e) = Genome.Split.split gpart_a232d
                      p_a231r = double g_a231q
                      (g_a231q, gpart_a232d) = Genome.Split.split gpart_a232c
                      p_a231p = double g_a231o
                      (g_a231o, gpart_a232c) = Genome.Split.split gpart_a232b
                      p_a231n = double g_a231m
                      (g_a231m, gpart_a232b) = Genome.Split.split gpart_a232a
                      p_a231l = Functions.belowten' g_a231k
                      (g_a231k, gpart_a232a) = Genome.Split.split gpart_a2329
                      p_a231j = double g_a231i
                      (g_a231i, gpart_a2329) = Genome.Split.split gpart_a2328
                      p_a231h
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a231g
                      (g_a231g, gpart_a2328) = Genome.Split.split gpart_a2327
                      p_a231f
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a231e
                      (g_a231e, gpart_a2327) = Genome.Split.split gpart_a2326
                      p_a231d = Functions.belowten' g_a231c
                      (g_a231c, gpart_a2326) = Genome.Split.split gpart_a2325
                      p_a231b = double g_a231a
                      (g_a231a, gpart_a2325) = Genome.Split.split gpart_a2324
                      p_a2319 = double g_a2318
                      (g_a2318, gpart_a2324) = Genome.Split.split gpart_a2323
                      p_a2317 = double g_a2316
                      (g_a2316, gpart_a2323) = Genome.Split.split gpart_a2322
                      p_a2315 = Functions.belowten' g_a2314
                      (g_a2314, gpart_a2322) = Genome.Split.split gpart_a2321
                      p_a2313 = double g_a2312
                      (g_a2312, gpart_a2321) = Genome.Split.split gpart_a2320
                      p_a2311 = Functions.belowten' g_a2310
                      (g_a2310, gpart_a2320) = Genome.Split.split gpart_a231Z
                      p_a230Z = double g_a230Y
                      (g_a230Y, gpart_a231Z) = Genome.Split.split gpart_a231Y
                      p_a230X
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a230W
                      (g_a230W, gpart_a231Y) = Genome.Split.split gpart_a231X
                      p_a230V
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a230U
                      (g_a230U, gpart_a231X) = Genome.Split.split gpart_a231W
                      p_a230T = double g_a230S
                      (g_a230S, gpart_a231W) = Genome.Split.split gpart_a231V
                      p_a230R = Functions.belowten' g_a230Q
                      (g_a230Q, gpart_a231V) = Genome.Split.split gpart_a231U
                      p_a230P = double g_a230O
                      (g_a230O, gpart_a231U) = Genome.Split.split gpart_a231T
                      p_a230N = Functions.belowten' g_a230M
                      (g_a230M, gpart_a231T) = Genome.Split.split gpart_a231S
                      p_a230L = double g_a230K
                      (g_a230K, gpart_a231S) = Genome.Split.split gpart_a231R
                      p_a230J = Functions.belowten' g_a230I
                      (g_a230I, gpart_a231R) = Genome.Split.split gpart_a231Q
                      p_a230H = double g_a230G
                      (g_a230G, gpart_a231Q) = Genome.Split.split gpart_a231P
                      p_a230F = double g_a230E
                      (g_a230E, gpart_a231P) = Genome.Split.split gpart_a231O
                      p_a230D = Functions.belowten' g_a230C
                      (g_a230C, gpart_a231O) = Genome.Split.split gpart_a231N
                      p_a230B = double g_a230A
                      (g_a230A, gpart_a231N) = Genome.Split.split gpart_a231M
                      p_a230z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a230y
                      (g_a230y, gpart_a231M) = Genome.Split.split gpart_a231L
                      p_a230x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a230w
                      (g_a230w, gpart_a231L) = Genome.Split.split gpart_a231K
                      p_a230v = double g_a230u
                      (g_a230u, gpart_a231K) = Genome.Split.split gpart_a231J
                      p_a230t = double g_a230s
                      (g_a230s, gpart_a231J) = Genome.Split.split gpart_a231I
                      p_a230r = double g_a230q
                      (g_a230q, gpart_a231I) = Genome.Split.split gpart_a231H
                      p_a230p = double g_a230o
                      (g_a230o, gpart_a231H) = Genome.Split.split gpart_a231G
                      p_a230n = double g_a230m
                      (g_a230m, gpart_a231G) = Genome.Split.split genome_a231E
                    in  \ x_a232k
                          -> let
                               c_PTB_a232n
                                 = ((Data.Fixed.Vector.toVector x_a232k) Data.Vector.Unboxed.! 0)
                               c_MiRs_a232l
                                 = ((Data.Fixed.Vector.toVector x_a232k) Data.Vector.Unboxed.! 2)
                               c_NPTB_a232s
                                 = ((Data.Fixed.Vector.toVector x_a232k) Data.Vector.Unboxed.! 1)
                               c_RESTc_a232o
                                 = ((Data.Fixed.Vector.toVector x_a232k) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a232E
                                 = ((Data.Fixed.Vector.toVector x_a232k) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a230v
                                     / (1
                                        + (((p_a230n / p_a230x) ** p_a230z)
                                           + ((c_MiRs_a232l / p_a230B) ** p_a230D))))
                                    + (negate (p_a231v * c_PTB_a232n))),
                                   ((p_a230F
                                     / (1
                                        + ((((c_RESTc_a232o / p_a230H) ** p_a230J)
                                            + ((c_MiRs_a232l / p_a230L) ** p_a230N))
                                           + ((c_PTB_a232n / p_a230P) ** p_a230R))))
                                    + (negate (p_a231x * c_NPTB_a232s))),
                                   ((p_a230T
                                     * (p_a2317
                                        / ((1 + p_a2317)
                                           + (((c_NPTB_a232s / p_a230Z) ** p_a2311)
                                              + ((c_RESTc_a232o / p_a2313) ** p_a2315)))))
                                    + (negate (p_a231z * c_MiRs_a232l))),
                                   ((p_a2319
                                     * ((p_a231n + ((c_PTB_a232n / p_a231b) ** p_a231d))
                                        / (((1 + p_a231n) + ((c_PTB_a232n / p_a231b) ** p_a231d))
                                           + ((c_MiRs_a232l / p_a231j) ** p_a231l))))
                                    + (negate (p_a231B * c_RESTc_a232o))),
                                   ((p_a231p / (1 + ((c_RESTc_a232o / p_a231r) ** p_a231t)))
                                    + (negate (p_a231D * c_EndoNeuroTFs_a232E)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498002",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498003",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498004",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498005",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498006",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498007",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498008",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498009",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498010",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498011",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498012",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498013",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498014",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498015",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498016",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498017",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498018",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498019",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498020",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498021",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498023",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498025",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498027",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498034",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498035",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498036",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498037",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498038",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498039",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498040",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498041",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498042",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498043",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498044",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498045",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498046",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498047",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498048",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498049",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498050",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498051",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498057",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498059",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498061",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498063",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498065",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498067",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498069",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679498080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679498081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a231E
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a233i
                            p_a231D = double g_a231C
                            (g_a231C, gpart_a233i) = Genome.Split.split gpart_a233h
                            p_a231B = double g_a231A
                            (g_a231A, gpart_a233h) = Genome.Split.split gpart_a233g
                            p_a231z = double g_a231y
                            (g_a231y, gpart_a233g) = Genome.Split.split gpart_a233f
                            p_a231x = double g_a231w
                            (g_a231w, gpart_a233f) = Genome.Split.split gpart_a233e
                            p_a231v = double g_a231u
                            (g_a231u, gpart_a233e) = Genome.Split.split gpart_a233d
                            p_a231t = Functions.belowten' g_a231s
                            (g_a231s, gpart_a233d) = Genome.Split.split gpart_a233c
                            p_a231r = double g_a231q
                            (g_a231q, gpart_a233c) = Genome.Split.split gpart_a233b
                            p_a231p = double g_a231o
                            (g_a231o, gpart_a233b) = Genome.Split.split gpart_a233a
                            p_a231n = double g_a231m
                            (g_a231m, gpart_a233a) = Genome.Split.split gpart_a2339
                            p_a231l = Functions.belowten' g_a231k
                            (g_a231k, gpart_a2339) = Genome.Split.split gpart_a2338
                            p_a231j = double g_a231i
                            (g_a231i, gpart_a2338) = Genome.Split.split gpart_a2337
                            p_a231h
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a231g
                            (g_a231g, gpart_a2337) = Genome.Split.split gpart_a2336
                            p_a231f
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a231e
                            (g_a231e, gpart_a2336) = Genome.Split.split gpart_a2335
                            p_a231d = Functions.belowten' g_a231c
                            (g_a231c, gpart_a2335) = Genome.Split.split gpart_a2334
                            p_a231b = double g_a231a
                            (g_a231a, gpart_a2334) = Genome.Split.split gpart_a2333
                            p_a2319 = double g_a2318
                            (g_a2318, gpart_a2333) = Genome.Split.split gpart_a2332
                            p_a2317 = double g_a2316
                            (g_a2316, gpart_a2332) = Genome.Split.split gpart_a2331
                            p_a2315 = Functions.belowten' g_a2314
                            (g_a2314, gpart_a2331) = Genome.Split.split gpart_a2330
                            p_a2313 = double g_a2312
                            (g_a2312, gpart_a2330) = Genome.Split.split gpart_a232Z
                            p_a2311 = Functions.belowten' g_a2310
                            (g_a2310, gpart_a232Z) = Genome.Split.split gpart_a232Y
                            p_a230Z = double g_a230Y
                            (g_a230Y, gpart_a232Y) = Genome.Split.split gpart_a232X
                            p_a230X
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a230W
                            (g_a230W, gpart_a232X) = Genome.Split.split gpart_a232W
                            p_a230V
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a230U
                            (g_a230U, gpart_a232W) = Genome.Split.split gpart_a232V
                            p_a230T = double g_a230S
                            (g_a230S, gpart_a232V) = Genome.Split.split gpart_a232U
                            p_a230R = Functions.belowten' g_a230Q
                            (g_a230Q, gpart_a232U) = Genome.Split.split gpart_a232T
                            p_a230P = double g_a230O
                            (g_a230O, gpart_a232T) = Genome.Split.split gpart_a232S
                            p_a230N = Functions.belowten' g_a230M
                            (g_a230M, gpart_a232S) = Genome.Split.split gpart_a232R
                            p_a230L = double g_a230K
                            (g_a230K, gpart_a232R) = Genome.Split.split gpart_a232Q
                            p_a230J = Functions.belowten' g_a230I
                            (g_a230I, gpart_a232Q) = Genome.Split.split gpart_a232P
                            p_a230H = double g_a230G
                            (g_a230G, gpart_a232P) = Genome.Split.split gpart_a232O
                            p_a230F = double g_a230E
                            (g_a230E, gpart_a232O) = Genome.Split.split gpart_a232N
                            p_a230D = Functions.belowten' g_a230C
                            (g_a230C, gpart_a232N) = Genome.Split.split gpart_a232M
                            p_a230B = double g_a230A
                            (g_a230A, gpart_a232M) = Genome.Split.split gpart_a232L
                            p_a230z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a230y
                            (g_a230y, gpart_a232L) = Genome.Split.split gpart_a232K
                            p_a230x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a230w
                            (g_a230w, gpart_a232K) = Genome.Split.split gpart_a232J
                            p_a230v = double g_a230u
                            (g_a230u, gpart_a232J) = Genome.Split.split gpart_a232I
                            p_a230t = double g_a230s
                            (g_a230s, gpart_a232I) = Genome.Split.split gpart_a232H
                            p_a230r = double g_a230q
                            (g_a230q, gpart_a232H) = Genome.Split.split gpart_a232G
                            p_a230p = double g_a230o
                            (g_a230o, gpart_a232G) = Genome.Split.split gpart_a232F
                            p_a230n = double g_a230m
                            (g_a230m, gpart_a232F) = Genome.Split.split genome_a231E
                          in
                            \ desc_a231F
                              -> case desc_a231F of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230n)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230p)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230r)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230t)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230v)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230x)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230z)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230B)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230D)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230F)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230H)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230J)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230L)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230N)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230P)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230R)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230T)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230V)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230X)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a230Z)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2311)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2313)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2315)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2317)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2319)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231b)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231d)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231f)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231h)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231j)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231l)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231n)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231p)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231r)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231t)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231v)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231x)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231z)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231B)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a231D)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asTO
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUt
                      p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                      (g_asTM, gpart_asUt) = Genome.Split.split gpart_asUs
                      p_asTL = code-0.1.0.0:Genome.FixedList.Functions.double g_asTK
                      (g_asTK, gpart_asUs) = Genome.Split.split gpart_asUr
                      p_asTJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTI
                      (g_asTI, gpart_asUr) = Genome.Split.split gpart_asUq
                      p_asTH = code-0.1.0.0:Genome.FixedList.Functions.double g_asTG
                      (g_asTG, gpart_asUq) = Genome.Split.split gpart_asUp
                      p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                      (g_asTE, gpart_asUp) = Genome.Split.split gpart_asUo
                      p_asTD = Functions.belowten' g_asTC
                      (g_asTC, gpart_asUo) = Genome.Split.split gpart_asUn
                      p_asTB = code-0.1.0.0:Genome.FixedList.Functions.double g_asTA
                      (g_asTA, gpart_asUn) = Genome.Split.split gpart_asUm
                      p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                      (g_asTy, gpart_asUm) = Genome.Split.split gpart_asUl
                      p_asTx = code-0.1.0.0:Genome.FixedList.Functions.double g_asTw
                      (g_asTw, gpart_asUl) = Genome.Split.split gpart_asUk
                      p_asTv = Functions.belowten' g_asTu
                      (g_asTu, gpart_asUk) = Genome.Split.split gpart_asUj
                      p_asTt = code-0.1.0.0:Genome.FixedList.Functions.double g_asTs
                      (g_asTs, gpart_asUj) = Genome.Split.split gpart_asUi
                      p_asTr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTq
                      (g_asTq, gpart_asUi) = Genome.Split.split gpart_asUh
                      p_asTp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTo
                      (g_asTo, gpart_asUh) = Genome.Split.split gpart_asUg
                      p_asTn = Functions.belowten' g_asTm
                      (g_asTm, gpart_asUg) = Genome.Split.split gpart_asUf
                      p_asTl = code-0.1.0.0:Genome.FixedList.Functions.double g_asTk
                      (g_asTk, gpart_asUf) = Genome.Split.split gpart_asUe
                      p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                      (g_asTi, gpart_asUe) = Genome.Split.split gpart_asUd
                      p_asTh = code-0.1.0.0:Genome.FixedList.Functions.double g_asTg
                      (g_asTg, gpart_asUd) = Genome.Split.split gpart_asUc
                      p_asTf = Functions.belowten' g_asTe
                      (g_asTe, gpart_asUc) = Genome.Split.split gpart_asUb
                      p_asTd = code-0.1.0.0:Genome.FixedList.Functions.double g_asTc
                      (g_asTc, gpart_asUb) = Genome.Split.split gpart_asUa
                      p_asTb = Functions.belowten' g_asTa
                      (g_asTa, gpart_asUa) = Genome.Split.split gpart_asU9
                      p_asT9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT8
                      (g_asT8, gpart_asU9) = Genome.Split.split gpart_asU8
                      p_asT7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT6
                      (g_asT6, gpart_asU8) = Genome.Split.split gpart_asU7
                      p_asT5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT4
                      (g_asT4, gpart_asU7) = Genome.Split.split gpart_asU6
                      p_asT3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT2
                      (g_asT2, gpart_asU6) = Genome.Split.split gpart_asU5
                      p_asT1 = Functions.belowten' g_asT0
                      (g_asT0, gpart_asU5) = Genome.Split.split gpart_asU4
                      p_asSZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSY
                      (g_asSY, gpart_asU4) = Genome.Split.split gpart_asU3
                      p_asSX = Functions.belowten' g_asSW
                      (g_asSW, gpart_asU3) = Genome.Split.split gpart_asU2
                      p_asSV = code-0.1.0.0:Genome.FixedList.Functions.double g_asSU
                      (g_asSU, gpart_asU2) = Genome.Split.split gpart_asU1
                      p_asST = Functions.belowten' g_asSS
                      (g_asSS, gpart_asU1) = Genome.Split.split gpart_asU0
                      p_asSR = code-0.1.0.0:Genome.FixedList.Functions.double g_asSQ
                      (g_asSQ, gpart_asU0) = Genome.Split.split gpart_asTZ
                      p_asSP = code-0.1.0.0:Genome.FixedList.Functions.double g_asSO
                      (g_asSO, gpart_asTZ) = Genome.Split.split gpart_asTY
                      p_asSN = Functions.belowten' g_asSM
                      (g_asSM, gpart_asTY) = Genome.Split.split gpart_asTX
                      p_asSL = code-0.1.0.0:Genome.FixedList.Functions.double g_asSK
                      (g_asSK, gpart_asTX) = Genome.Split.split gpart_asTW
                      p_asSJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSI
                      (g_asSI, gpart_asTW) = Genome.Split.split gpart_asTV
                      p_asSH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSG
                      (g_asSG, gpart_asTV) = Genome.Split.split gpart_asTU
                      p_asSF = code-0.1.0.0:Genome.FixedList.Functions.double g_asSE
                      (g_asSE, gpart_asTU) = Genome.Split.split gpart_asTT
                      p_asSD = code-0.1.0.0:Genome.FixedList.Functions.double g_asSC
                      (g_asSC, gpart_asTT) = Genome.Split.split gpart_asTS
                      p_asSB = code-0.1.0.0:Genome.FixedList.Functions.double g_asSA
                      (g_asSA, gpart_asTS) = Genome.Split.split gpart_asTR
                      p_asSz = code-0.1.0.0:Genome.FixedList.Functions.double g_asSy
                      (g_asSy, gpart_asTR) = Genome.Split.split gpart_asTQ
                      p_asSx = code-0.1.0.0:Genome.FixedList.Functions.double g_asSw
                      (g_asSw, gpart_asTQ) = Genome.Split.split genome_asTO
                    in
                      [Reaction
                         (\ x_asUu
                            -> let c_MiRs_asUv = ((toVector x_asUu) Data.Vector.Unboxed.! 2)
                               in (p_asSF / (1 + ((c_MiRs_asUv / p_asSL) ** p_asSN))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asUw
                            -> let
                                 c_MiRs_asUy = ((toVector x_asUw) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asUx = ((toVector x_asUw) Data.Vector.Unboxed.! 3)
                                 c_PTB_asUz = ((toVector x_asUw) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asSP
                                  / (1
                                     + ((((c_RESTc_asUx / p_asSR) ** p_asST)
                                         + ((c_MiRs_asUy / p_asSV) ** p_asSX))
                                        + ((c_PTB_asUz / p_asSZ) ** p_asT1)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asUA
                            -> let
                                 c_RESTc_asUC = ((toVector x_asUA) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asUB = ((toVector x_asUA) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asT3
                                  * ((p_asTh + ((p_asSB / p_asT5) ** p_asT7))
                                     / (((1 + p_asTh) + ((p_asSB / p_asT5) ** p_asT7))
                                        + (((c_NPTB_asUB / p_asT9) ** p_asTb)
                                           + ((c_RESTc_asUC / p_asTd) ** p_asTf))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asUD
                            -> let
                                 c_MiRs_asUG = ((toVector x_asUD) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUE = ((toVector x_asUD) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTj
                                  * ((p_asTx + ((c_PTB_asUE / p_asTl) ** p_asTn))
                                     / (((1 + p_asTx) + ((c_PTB_asUE / p_asTl) ** p_asTn))
                                        + (((p_asSx / p_asTp) ** p_asTr)
                                           + ((c_MiRs_asUG / p_asTt) ** p_asTv))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asUH
                            -> let c_RESTc_asUI = ((toVector x_asUH) Data.Vector.Unboxed.! 3)
                               in (p_asTz / (1 + ((c_RESTc_asUI / p_asTB) ** p_asTD))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asUJ
                            -> let c_PTB_asUK = ((toVector x_asUJ) Data.Vector.Unboxed.! 0)
                               in (p_asTF * c_PTB_asUK))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asUL
                            -> let c_NPTB_asUM = ((toVector x_asUL) Data.Vector.Unboxed.! 1)
                               in (p_asTH * c_NPTB_asUM))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asUN
                            -> let c_MiRs_asUO = ((toVector x_asUN) Data.Vector.Unboxed.! 2)
                               in (p_asTJ * c_MiRs_asUO))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asUP
                            -> let c_RESTc_asUQ = ((toVector x_asUP) Data.Vector.Unboxed.! 3)
                               in (p_asTL * c_RESTc_asUQ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asUR
                            -> let
                                 c_EndoNeuroTFs_asUS = ((toVector x_asUR) Data.Vector.Unboxed.! 4)
                               in (p_asTN * c_EndoNeuroTFs_asUS))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120805",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120807",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120809",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120811",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120815",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120817",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120819",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120821",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120823",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120827",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120829",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120839",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120841",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120843",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120845",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120847",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120859",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120861",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120865",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120879",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120881",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asTO
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVB
                            p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                            (g_asTM, gpart_asVB) = Genome.Split.split gpart_asVA
                            p_asTL = code-0.1.0.0:Genome.FixedList.Functions.double g_asTK
                            (g_asTK, gpart_asVA) = Genome.Split.split gpart_asVz
                            p_asTJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTI
                            (g_asTI, gpart_asVz) = Genome.Split.split gpart_asVy
                            p_asTH = code-0.1.0.0:Genome.FixedList.Functions.double g_asTG
                            (g_asTG, gpart_asVy) = Genome.Split.split gpart_asVx
                            p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                            (g_asTE, gpart_asVx) = Genome.Split.split gpart_asVw
                            p_asTD = Functions.belowten' g_asTC
                            (g_asTC, gpart_asVw) = Genome.Split.split gpart_asVv
                            p_asTB = code-0.1.0.0:Genome.FixedList.Functions.double g_asTA
                            (g_asTA, gpart_asVv) = Genome.Split.split gpart_asVu
                            p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                            (g_asTy, gpart_asVu) = Genome.Split.split gpart_asVt
                            p_asTx = code-0.1.0.0:Genome.FixedList.Functions.double g_asTw
                            (g_asTw, gpart_asVt) = Genome.Split.split gpart_asVs
                            p_asTv = Functions.belowten' g_asTu
                            (g_asTu, gpart_asVs) = Genome.Split.split gpart_asVr
                            p_asTt = code-0.1.0.0:Genome.FixedList.Functions.double g_asTs
                            (g_asTs, gpart_asVr) = Genome.Split.split gpart_asVq
                            p_asTr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTq
                            (g_asTq, gpart_asVq) = Genome.Split.split gpart_asVp
                            p_asTp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTo
                            (g_asTo, gpart_asVp) = Genome.Split.split gpart_asVo
                            p_asTn = Functions.belowten' g_asTm
                            (g_asTm, gpart_asVo) = Genome.Split.split gpart_asVn
                            p_asTl = code-0.1.0.0:Genome.FixedList.Functions.double g_asTk
                            (g_asTk, gpart_asVn) = Genome.Split.split gpart_asVm
                            p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                            (g_asTi, gpart_asVm) = Genome.Split.split gpart_asVl
                            p_asTh = code-0.1.0.0:Genome.FixedList.Functions.double g_asTg
                            (g_asTg, gpart_asVl) = Genome.Split.split gpart_asVk
                            p_asTf = Functions.belowten' g_asTe
                            (g_asTe, gpart_asVk) = Genome.Split.split gpart_asVj
                            p_asTd = code-0.1.0.0:Genome.FixedList.Functions.double g_asTc
                            (g_asTc, gpart_asVj) = Genome.Split.split gpart_asVi
                            p_asTb = Functions.belowten' g_asTa
                            (g_asTa, gpart_asVi) = Genome.Split.split gpart_asVh
                            p_asT9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT8
                            (g_asT8, gpart_asVh) = Genome.Split.split gpart_asVg
                            p_asT7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT6
                            (g_asT6, gpart_asVg) = Genome.Split.split gpart_asVf
                            p_asT5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT4
                            (g_asT4, gpart_asVf) = Genome.Split.split gpart_asVe
                            p_asT3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT2
                            (g_asT2, gpart_asVe) = Genome.Split.split gpart_asVd
                            p_asT1 = Functions.belowten' g_asT0
                            (g_asT0, gpart_asVd) = Genome.Split.split gpart_asVc
                            p_asSZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSY
                            (g_asSY, gpart_asVc) = Genome.Split.split gpart_asVb
                            p_asSX = Functions.belowten' g_asSW
                            (g_asSW, gpart_asVb) = Genome.Split.split gpart_asVa
                            p_asSV = code-0.1.0.0:Genome.FixedList.Functions.double g_asSU
                            (g_asSU, gpart_asVa) = Genome.Split.split gpart_asV9
                            p_asST = Functions.belowten' g_asSS
                            (g_asSS, gpart_asV9) = Genome.Split.split gpart_asV8
                            p_asSR = code-0.1.0.0:Genome.FixedList.Functions.double g_asSQ
                            (g_asSQ, gpart_asV8) = Genome.Split.split gpart_asV7
                            p_asSP = code-0.1.0.0:Genome.FixedList.Functions.double g_asSO
                            (g_asSO, gpart_asV7) = Genome.Split.split gpart_asV6
                            p_asSN = Functions.belowten' g_asSM
                            (g_asSM, gpart_asV6) = Genome.Split.split gpart_asV5
                            p_asSL = code-0.1.0.0:Genome.FixedList.Functions.double g_asSK
                            (g_asSK, gpart_asV5) = Genome.Split.split gpart_asV4
                            p_asSJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSI
                            (g_asSI, gpart_asV4) = Genome.Split.split gpart_asV3
                            p_asSH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSG
                            (g_asSG, gpart_asV3) = Genome.Split.split gpart_asV2
                            p_asSF = code-0.1.0.0:Genome.FixedList.Functions.double g_asSE
                            (g_asSE, gpart_asV2) = Genome.Split.split gpart_asV1
                            p_asSD = code-0.1.0.0:Genome.FixedList.Functions.double g_asSC
                            (g_asSC, gpart_asV1) = Genome.Split.split gpart_asV0
                            p_asSB = code-0.1.0.0:Genome.FixedList.Functions.double g_asSA
                            (g_asSA, gpart_asV0) = Genome.Split.split gpart_asUZ
                            p_asSz = code-0.1.0.0:Genome.FixedList.Functions.double g_asSy
                            (g_asSy, gpart_asUZ) = Genome.Split.split gpart_asUY
                            p_asSx = code-0.1.0.0:Genome.FixedList.Functions.double g_asSw
                            (g_asSw, gpart_asUY) = Genome.Split.split genome_asTO
                          in
                            \ desc_asTP
                              -> case desc_asTP of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSx)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSz)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSB)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSD)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSF)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSH)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSJ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSL)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSN)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSP)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSR)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asST)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSV)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSX)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSZ)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT1)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT3)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT5)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT7)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT9)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTb)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTd)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTf)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTh)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTj)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTl)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTn)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTp)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTr)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTt)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTv)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTx)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTz)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTB)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTD)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTF)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTH)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTJ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTL)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTN)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asXA
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYf
                      p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                      (g_asXy, gpart_asYf) = Genome.Split.split gpart_asYe
                      p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                      (g_asXw, gpart_asYe) = Genome.Split.split gpart_asYd
                      p_asXv = code-0.1.0.0:Genome.FixedList.Functions.double g_asXu
                      (g_asXu, gpart_asYd) = Genome.Split.split gpart_asYc
                      p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                      (g_asXs, gpart_asYc) = Genome.Split.split gpart_asYb
                      p_asXr = code-0.1.0.0:Genome.FixedList.Functions.double g_asXq
                      (g_asXq, gpart_asYb) = Genome.Split.split gpart_asYa
                      p_asXp = Functions.belowten' g_asXo
                      (g_asXo, gpart_asYa) = Genome.Split.split gpart_asY9
                      p_asXn = code-0.1.0.0:Genome.FixedList.Functions.double g_asXm
                      (g_asXm, gpart_asY9) = Genome.Split.split gpart_asY8
                      p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                      (g_asXk, gpart_asY8) = Genome.Split.split gpart_asY7
                      p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                      (g_asXi, gpart_asY7) = Genome.Split.split gpart_asY6
                      p_asXh = Functions.belowten' g_asXg
                      (g_asXg, gpart_asY6) = Genome.Split.split gpart_asY5
                      p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                      (g_asXe, gpart_asY5) = Genome.Split.split gpart_asY4
                      p_asXd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXc
                      (g_asXc, gpart_asY4) = Genome.Split.split gpart_asY3
                      p_asXb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXa
                      (g_asXa, gpart_asY3) = Genome.Split.split gpart_asY2
                      p_asX9 = Functions.belowten' g_asX8
                      (g_asX8, gpart_asY2) = Genome.Split.split gpart_asY1
                      p_asX7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX6
                      (g_asX6, gpart_asY1) = Genome.Split.split gpart_asY0
                      p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                      (g_asX4, gpart_asY0) = Genome.Split.split gpart_asXZ
                      p_asX3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX2
                      (g_asX2, gpart_asXZ) = Genome.Split.split gpart_asXY
                      p_asX1 = Functions.belowten' g_asX0
                      (g_asX0, gpart_asXY) = Genome.Split.split gpart_asXX
                      p_asWZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWY
                      (g_asWY, gpart_asXX) = Genome.Split.split gpart_asXW
                      p_asWX = Functions.belowten' g_asWW
                      (g_asWW, gpart_asXW) = Genome.Split.split gpart_asXV
                      p_asWV = code-0.1.0.0:Genome.FixedList.Functions.double g_asWU
                      (g_asWU, gpart_asXV) = Genome.Split.split gpart_asXU
                      p_asWT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWS
                      (g_asWS, gpart_asXU) = Genome.Split.split gpart_asXT
                      p_asWR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWQ
                      (g_asWQ, gpart_asXT) = Genome.Split.split gpart_asXS
                      p_asWP = code-0.1.0.0:Genome.FixedList.Functions.double g_asWO
                      (g_asWO, gpart_asXS) = Genome.Split.split gpart_asXR
                      p_asWN = Functions.belowten' g_asWM
                      (g_asWM, gpart_asXR) = Genome.Split.split gpart_asXQ
                      p_asWL = code-0.1.0.0:Genome.FixedList.Functions.double g_asWK
                      (g_asWK, gpart_asXQ) = Genome.Split.split gpart_asXP
                      p_asWJ = Functions.belowten' g_asWI
                      (g_asWI, gpart_asXP) = Genome.Split.split gpart_asXO
                      p_asWH = code-0.1.0.0:Genome.FixedList.Functions.double g_asWG
                      (g_asWG, gpart_asXO) = Genome.Split.split gpart_asXN
                      p_asWF = Functions.belowten' g_asWE
                      (g_asWE, gpart_asXN) = Genome.Split.split gpart_asXM
                      p_asWD = code-0.1.0.0:Genome.FixedList.Functions.double g_asWC
                      (g_asWC, gpart_asXM) = Genome.Split.split gpart_asXL
                      p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                      (g_asWA, gpart_asXL) = Genome.Split.split gpart_asXK
                      p_asWz = Functions.belowten' g_asWy
                      (g_asWy, gpart_asXK) = Genome.Split.split gpart_asXJ
                      p_asWx = code-0.1.0.0:Genome.FixedList.Functions.double g_asWw
                      (g_asWw, gpart_asXJ) = Genome.Split.split gpart_asXI
                      p_asWv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWu
                      (g_asWu, gpart_asXI) = Genome.Split.split gpart_asXH
                      p_asWt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWs
                      (g_asWs, gpart_asXH) = Genome.Split.split gpart_asXG
                      p_asWr = code-0.1.0.0:Genome.FixedList.Functions.double g_asWq
                      (g_asWq, gpart_asXG) = Genome.Split.split gpart_asXF
                      p_asWp = code-0.1.0.0:Genome.FixedList.Functions.double g_asWo
                      (g_asWo, gpart_asXF) = Genome.Split.split gpart_asXE
                      p_asWn = code-0.1.0.0:Genome.FixedList.Functions.double g_asWm
                      (g_asWm, gpart_asXE) = Genome.Split.split gpart_asXD
                      p_asWl = code-0.1.0.0:Genome.FixedList.Functions.double g_asWk
                      (g_asWk, gpart_asXD) = Genome.Split.split gpart_asXC
                      p_asWj = code-0.1.0.0:Genome.FixedList.Functions.double g_asWi
                      (g_asWi, gpart_asXC) = Genome.Split.split genome_asXA
                    in
                      [Reaction
                         (\ x_asYg
                            -> let c_MiRs_asYh = ((toVector x_asYg) Data.Vector.Unboxed.! 2)
                               in (p_asWr / (1 + ((c_MiRs_asYh / p_asWx) ** p_asWz))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYi
                            -> let
                                 c_MiRs_asYk = ((toVector x_asYi) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asYj = ((toVector x_asYi) Data.Vector.Unboxed.! 3)
                                 c_PTB_asYl = ((toVector x_asYi) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWB
                                  / (1
                                     + ((((c_RESTc_asYj / p_asWD) ** p_asWF)
                                         + ((c_MiRs_asYk / p_asWH) ** p_asWJ))
                                        + ((c_PTB_asYl / p_asWL) ** p_asWN)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asYm
                            -> let
                                 c_RESTc_asYo = ((toVector x_asYm) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asYn = ((toVector x_asYm) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asWP
                                  * (p_asX3
                                     / ((1 + p_asX3)
                                        + (((c_NPTB_asYn / p_asWV) ** p_asWX)
                                           + ((c_RESTc_asYo / p_asWZ) ** p_asX1))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asYp
                            -> let
                                 c_MiRs_asYs = ((toVector x_asYp) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYq = ((toVector x_asYp) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asX5
                                  * ((p_asXj + ((c_PTB_asYq / p_asX7) ** p_asX9))
                                     / (((1 + p_asXj) + ((c_PTB_asYq / p_asX7) ** p_asX9))
                                        + (((p_asWj / p_asXb) ** p_asXd)
                                           + ((c_MiRs_asYs / p_asXf) ** p_asXh))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asYt
                            -> let c_RESTc_asYu = ((toVector x_asYt) Data.Vector.Unboxed.! 3)
                               in (p_asXl / (1 + ((c_RESTc_asYu / p_asXn) ** p_asXp))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asYv
                            -> let c_PTB_asYw = ((toVector x_asYv) Data.Vector.Unboxed.! 0)
                               in (p_asXr * c_PTB_asYw))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYx
                            -> let c_NPTB_asYy = ((toVector x_asYx) Data.Vector.Unboxed.! 1)
                               in (p_asXt * c_NPTB_asYy))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asYz
                            -> let c_MiRs_asYA = ((toVector x_asYz) Data.Vector.Unboxed.! 2)
                               in (p_asXv * c_MiRs_asYA))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asYB
                            -> let c_RESTc_asYC = ((toVector x_asYB) Data.Vector.Unboxed.! 3)
                               in (p_asXx * c_RESTc_asYC))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asYD
                            -> let
                                 c_EndoNeuroTFs_asYE = ((toVector x_asYD) Data.Vector.Unboxed.! 4)
                               in (p_asXz * c_EndoNeuroTFs_asYE))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121038",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121039",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121040",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121041",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121042",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121043",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121044",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121045",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121046",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121047",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121048",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121049",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121050",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121051",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121059",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121061",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121063",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121065",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121067",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121069",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121073",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121075",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121085",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121087",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121091",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121093",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121095",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121107",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asXA
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZi
                            p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                            (g_asXy, gpart_asZi) = Genome.Split.split gpart_asZh
                            p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                            (g_asXw, gpart_asZh) = Genome.Split.split gpart_asZg
                            p_asXv = code-0.1.0.0:Genome.FixedList.Functions.double g_asXu
                            (g_asXu, gpart_asZg) = Genome.Split.split gpart_asZf
                            p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                            (g_asXs, gpart_asZf) = Genome.Split.split gpart_asZe
                            p_asXr = code-0.1.0.0:Genome.FixedList.Functions.double g_asXq
                            (g_asXq, gpart_asZe) = Genome.Split.split gpart_asZd
                            p_asXp = Functions.belowten' g_asXo
                            (g_asXo, gpart_asZd) = Genome.Split.split gpart_asZc
                            p_asXn = code-0.1.0.0:Genome.FixedList.Functions.double g_asXm
                            (g_asXm, gpart_asZc) = Genome.Split.split gpart_asZb
                            p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                            (g_asXk, gpart_asZb) = Genome.Split.split gpart_asZa
                            p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                            (g_asXi, gpart_asZa) = Genome.Split.split gpart_asZ9
                            p_asXh = Functions.belowten' g_asXg
                            (g_asXg, gpart_asZ9) = Genome.Split.split gpart_asZ8
                            p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                            (g_asXe, gpart_asZ8) = Genome.Split.split gpart_asZ7
                            p_asXd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXc
                            (g_asXc, gpart_asZ7) = Genome.Split.split gpart_asZ6
                            p_asXb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXa
                            (g_asXa, gpart_asZ6) = Genome.Split.split gpart_asZ5
                            p_asX9 = Functions.belowten' g_asX8
                            (g_asX8, gpart_asZ5) = Genome.Split.split gpart_asZ4
                            p_asX7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX6
                            (g_asX6, gpart_asZ4) = Genome.Split.split gpart_asZ3
                            p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                            (g_asX4, gpart_asZ3) = Genome.Split.split gpart_asZ2
                            p_asX3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX2
                            (g_asX2, gpart_asZ2) = Genome.Split.split gpart_asZ1
                            p_asX1 = Functions.belowten' g_asX0
                            (g_asX0, gpart_asZ1) = Genome.Split.split gpart_asZ0
                            p_asWZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWY
                            (g_asWY, gpart_asZ0) = Genome.Split.split gpart_asYZ
                            p_asWX = Functions.belowten' g_asWW
                            (g_asWW, gpart_asYZ) = Genome.Split.split gpart_asYY
                            p_asWV = code-0.1.0.0:Genome.FixedList.Functions.double g_asWU
                            (g_asWU, gpart_asYY) = Genome.Split.split gpart_asYX
                            p_asWT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWS
                            (g_asWS, gpart_asYX) = Genome.Split.split gpart_asYW
                            p_asWR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWQ
                            (g_asWQ, gpart_asYW) = Genome.Split.split gpart_asYV
                            p_asWP = code-0.1.0.0:Genome.FixedList.Functions.double g_asWO
                            (g_asWO, gpart_asYV) = Genome.Split.split gpart_asYU
                            p_asWN = Functions.belowten' g_asWM
                            (g_asWM, gpart_asYU) = Genome.Split.split gpart_asYT
                            p_asWL = code-0.1.0.0:Genome.FixedList.Functions.double g_asWK
                            (g_asWK, gpart_asYT) = Genome.Split.split gpart_asYS
                            p_asWJ = Functions.belowten' g_asWI
                            (g_asWI, gpart_asYS) = Genome.Split.split gpart_asYR
                            p_asWH = code-0.1.0.0:Genome.FixedList.Functions.double g_asWG
                            (g_asWG, gpart_asYR) = Genome.Split.split gpart_asYQ
                            p_asWF = Functions.belowten' g_asWE
                            (g_asWE, gpart_asYQ) = Genome.Split.split gpart_asYP
                            p_asWD = code-0.1.0.0:Genome.FixedList.Functions.double g_asWC
                            (g_asWC, gpart_asYP) = Genome.Split.split gpart_asYO
                            p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                            (g_asWA, gpart_asYO) = Genome.Split.split gpart_asYN
                            p_asWz = Functions.belowten' g_asWy
                            (g_asWy, gpart_asYN) = Genome.Split.split gpart_asYM
                            p_asWx = code-0.1.0.0:Genome.FixedList.Functions.double g_asWw
                            (g_asWw, gpart_asYM) = Genome.Split.split gpart_asYL
                            p_asWv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWu
                            (g_asWu, gpart_asYL) = Genome.Split.split gpart_asYK
                            p_asWt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWs
                            (g_asWs, gpart_asYK) = Genome.Split.split gpart_asYJ
                            p_asWr = code-0.1.0.0:Genome.FixedList.Functions.double g_asWq
                            (g_asWq, gpart_asYJ) = Genome.Split.split gpart_asYI
                            p_asWp = code-0.1.0.0:Genome.FixedList.Functions.double g_asWo
                            (g_asWo, gpart_asYI) = Genome.Split.split gpart_asYH
                            p_asWn = code-0.1.0.0:Genome.FixedList.Functions.double g_asWm
                            (g_asWm, gpart_asYH) = Genome.Split.split gpart_asYG
                            p_asWl = code-0.1.0.0:Genome.FixedList.Functions.double g_asWk
                            (g_asWk, gpart_asYG) = Genome.Split.split gpart_asYF
                            p_asWj = code-0.1.0.0:Genome.FixedList.Functions.double g_asWi
                            (g_asWi, gpart_asYF) = Genome.Split.split genome_asXA
                          in
                            \ desc_asXB
                              -> case desc_asXB of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWj)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWl)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWn)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWp)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWr)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWt)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWv)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWx)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWz)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWB)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWD)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWF)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWH)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWJ)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWL)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWN)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWP)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWR)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWT)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWV)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWX)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWZ)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX1)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX3)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX5)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX7)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX9)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXb)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXd)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXf)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXh)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXj)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXl)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXn)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXp)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXr)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXt)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXv)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXx)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXz)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at1h
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1W
                      p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                      (g_at1f, gpart_at1W) = Genome.Split.split gpart_at1V
                      p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                      (g_at1d, gpart_at1V) = Genome.Split.split gpart_at1U
                      p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                      (g_at1b, gpart_at1U) = Genome.Split.split gpart_at1T
                      p_at1a = code-0.1.0.0:Genome.FixedList.Functions.double g_at19
                      (g_at19, gpart_at1T) = Genome.Split.split gpart_at1S
                      p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                      (g_at17, gpart_at1S) = Genome.Split.split gpart_at1R
                      p_at16 = Functions.belowten' g_at15
                      (g_at15, gpart_at1R) = Genome.Split.split gpart_at1Q
                      p_at14 = code-0.1.0.0:Genome.FixedList.Functions.double g_at13
                      (g_at13, gpart_at1Q) = Genome.Split.split gpart_at1P
                      p_at12 = code-0.1.0.0:Genome.FixedList.Functions.double g_at11
                      (g_at11, gpart_at1P) = Genome.Split.split gpart_at1O
                      p_at10 = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Z
                      (g_at0Z, gpart_at1O) = Genome.Split.split gpart_at1N
                      p_at0Y = Functions.belowten' g_at0X
                      (g_at0X, gpart_at1N) = Genome.Split.split gpart_at1M
                      p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                      (g_at0V, gpart_at1M) = Genome.Split.split gpart_at1L
                      p_at0U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0T
                      (g_at0T, gpart_at1L) = Genome.Split.split gpart_at1K
                      p_at0S
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0R
                      (g_at0R, gpart_at1K) = Genome.Split.split gpart_at1J
                      p_at0Q = Functions.belowten' g_at0P
                      (g_at0P, gpart_at1J) = Genome.Split.split gpart_at1I
                      p_at0O = code-0.1.0.0:Genome.FixedList.Functions.double g_at0N
                      (g_at0N, gpart_at1I) = Genome.Split.split gpart_at1H
                      p_at0M = code-0.1.0.0:Genome.FixedList.Functions.double g_at0L
                      (g_at0L, gpart_at1H) = Genome.Split.split gpart_at1G
                      p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                      (g_at0J, gpart_at1G) = Genome.Split.split gpart_at1F
                      p_at0I = Functions.belowten' g_at0H
                      (g_at0H, gpart_at1F) = Genome.Split.split gpart_at1E
                      p_at0G = code-0.1.0.0:Genome.FixedList.Functions.double g_at0F
                      (g_at0F, gpart_at1E) = Genome.Split.split gpart_at1D
                      p_at0E = Functions.belowten' g_at0D
                      (g_at0D, gpart_at1D) = Genome.Split.split gpart_at1C
                      p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                      (g_at0B, gpart_at1C) = Genome.Split.split gpart_at1B
                      p_at0A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0z
                      (g_at0z, gpart_at1B) = Genome.Split.split gpart_at1A
                      p_at0y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0x
                      (g_at0x, gpart_at1A) = Genome.Split.split gpart_at1z
                      p_at0w = code-0.1.0.0:Genome.FixedList.Functions.double g_at0v
                      (g_at0v, gpart_at1z) = Genome.Split.split gpart_at1y
                      p_at0u = Functions.belowten' g_at0t
                      (g_at0t, gpart_at1y) = Genome.Split.split gpart_at1x
                      p_at0s = code-0.1.0.0:Genome.FixedList.Functions.double g_at0r
                      (g_at0r, gpart_at1x) = Genome.Split.split gpart_at1w
                      p_at0q = Functions.belowten' g_at0p
                      (g_at0p, gpart_at1w) = Genome.Split.split gpart_at1v
                      p_at0o = code-0.1.0.0:Genome.FixedList.Functions.double g_at0n
                      (g_at0n, gpart_at1v) = Genome.Split.split gpart_at1u
                      p_at0m = Functions.belowten' g_at0l
                      (g_at0l, gpart_at1u) = Genome.Split.split gpart_at1t
                      p_at0k = code-0.1.0.0:Genome.FixedList.Functions.double g_at0j
                      (g_at0j, gpart_at1t) = Genome.Split.split gpart_at1s
                      p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                      (g_at0h, gpart_at1s) = Genome.Split.split gpart_at1r
                      p_at0g = Functions.belowten' g_at0f
                      (g_at0f, gpart_at1r) = Genome.Split.split gpart_at1q
                      p_at0e = code-0.1.0.0:Genome.FixedList.Functions.double g_at0d
                      (g_at0d, gpart_at1q) = Genome.Split.split gpart_at1p
                      p_at0c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0b
                      (g_at0b, gpart_at1p) = Genome.Split.split gpart_at1o
                      p_at0a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at09
                      (g_at09, gpart_at1o) = Genome.Split.split gpart_at1n
                      p_at08 = code-0.1.0.0:Genome.FixedList.Functions.double g_at07
                      (g_at07, gpart_at1n) = Genome.Split.split gpart_at1m
                      p_at06 = code-0.1.0.0:Genome.FixedList.Functions.double g_at05
                      (g_at05, gpart_at1m) = Genome.Split.split gpart_at1l
                      p_at04 = code-0.1.0.0:Genome.FixedList.Functions.double g_at03
                      (g_at03, gpart_at1l) = Genome.Split.split gpart_at1k
                      p_at02 = code-0.1.0.0:Genome.FixedList.Functions.double g_at01
                      (g_at01, gpart_at1k) = Genome.Split.split gpart_at1j
                      p_at00 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZZ
                      (g_asZZ, gpart_at1j) = Genome.Split.split genome_at1h
                    in
                      [Reaction
                         (\ x_at1X
                            -> let c_MiRs_at1Y = ((toVector x_at1X) Data.Vector.Unboxed.! 2)
                               in (p_at08 / (1 + ((c_MiRs_at1Y / p_at0e) ** p_at0g))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1Z
                            -> let
                                 c_MiRs_at21 = ((toVector x_at1Z) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at20 = ((toVector x_at1Z) Data.Vector.Unboxed.! 3)
                                 c_PTB_at22 = ((toVector x_at1Z) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0i
                                  / (1
                                     + ((((c_RESTc_at20 / p_at0k) ** p_at0m)
                                         + ((c_MiRs_at21 / p_at0o) ** p_at0q))
                                        + ((c_PTB_at22 / p_at0s) ** p_at0u)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at23
                            -> let
                                 c_RESTc_at25 = ((toVector x_at23) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at24 = ((toVector x_at23) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at0w
                                  * (p_at0K
                                     / ((1 + p_at0K)
                                        + (((c_NPTB_at24 / p_at0C) ** p_at0E)
                                           + ((c_RESTc_at25 / p_at0G) ** p_at0I))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at26
                            -> let
                                 c_MiRs_at29 = ((toVector x_at26) Data.Vector.Unboxed.! 2)
                                 c_PTB_at27 = ((toVector x_at26) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0M
                                  * ((p_at10 + ((c_PTB_at27 / p_at0O) ** p_at0Q))
                                     / (((1 + p_at10) + ((c_PTB_at27 / p_at0O) ** p_at0Q))
                                        + ((c_MiRs_at29 / p_at0W) ** p_at0Y)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2a
                            -> let c_RESTc_at2b = ((toVector x_at2a) Data.Vector.Unboxed.! 3)
                               in (p_at12 / (1 + ((c_RESTc_at2b / p_at14) ** p_at16))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at2c
                            -> let c_PTB_at2d = ((toVector x_at2c) Data.Vector.Unboxed.! 0)
                               in (p_at18 * c_PTB_at2d))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2e
                            -> let c_NPTB_at2f = ((toVector x_at2e) Data.Vector.Unboxed.! 1)
                               in (p_at1a * c_NPTB_at2f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at2g
                            -> let c_MiRs_at2h = ((toVector x_at2g) Data.Vector.Unboxed.! 2)
                               in (p_at1c * c_MiRs_at2h))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at2i
                            -> let c_RESTc_at2j = ((toVector x_at2i) Data.Vector.Unboxed.! 3)
                               in (p_at1e * c_RESTc_at2j))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at2k
                            -> let
                                 c_EndoNeuroTFs_at2l = ((toVector x_at2k) Data.Vector.Unboxed.! 4)
                               in (p_at1g * c_EndoNeuroTFs_at2l))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121268",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121270",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121272",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121274",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121276",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121278",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121280",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121284",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121286",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121298",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121300",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121302",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121304",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121316",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121317",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121318",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121320",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121322",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121324",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121325",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121326",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121327",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121328",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121329",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121330",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121331",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121332",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121333",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121334",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121336",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121338",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121340",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121346",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at1h
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2Z
                            p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                            (g_at1f, gpart_at2Z) = Genome.Split.split gpart_at2Y
                            p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                            (g_at1d, gpart_at2Y) = Genome.Split.split gpart_at2X
                            p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                            (g_at1b, gpart_at2X) = Genome.Split.split gpart_at2W
                            p_at1a = code-0.1.0.0:Genome.FixedList.Functions.double g_at19
                            (g_at19, gpart_at2W) = Genome.Split.split gpart_at2V
                            p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                            (g_at17, gpart_at2V) = Genome.Split.split gpart_at2U
                            p_at16 = Functions.belowten' g_at15
                            (g_at15, gpart_at2U) = Genome.Split.split gpart_at2T
                            p_at14 = code-0.1.0.0:Genome.FixedList.Functions.double g_at13
                            (g_at13, gpart_at2T) = Genome.Split.split gpart_at2S
                            p_at12 = code-0.1.0.0:Genome.FixedList.Functions.double g_at11
                            (g_at11, gpart_at2S) = Genome.Split.split gpart_at2R
                            p_at10 = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Z
                            (g_at0Z, gpart_at2R) = Genome.Split.split gpart_at2Q
                            p_at0Y = Functions.belowten' g_at0X
                            (g_at0X, gpart_at2Q) = Genome.Split.split gpart_at2P
                            p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                            (g_at0V, gpart_at2P) = Genome.Split.split gpart_at2O
                            p_at0U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0T
                            (g_at0T, gpart_at2O) = Genome.Split.split gpart_at2N
                            p_at0S
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0R
                            (g_at0R, gpart_at2N) = Genome.Split.split gpart_at2M
                            p_at0Q = Functions.belowten' g_at0P
                            (g_at0P, gpart_at2M) = Genome.Split.split gpart_at2L
                            p_at0O = code-0.1.0.0:Genome.FixedList.Functions.double g_at0N
                            (g_at0N, gpart_at2L) = Genome.Split.split gpart_at2K
                            p_at0M = code-0.1.0.0:Genome.FixedList.Functions.double g_at0L
                            (g_at0L, gpart_at2K) = Genome.Split.split gpart_at2J
                            p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                            (g_at0J, gpart_at2J) = Genome.Split.split gpart_at2I
                            p_at0I = Functions.belowten' g_at0H
                            (g_at0H, gpart_at2I) = Genome.Split.split gpart_at2H
                            p_at0G = code-0.1.0.0:Genome.FixedList.Functions.double g_at0F
                            (g_at0F, gpart_at2H) = Genome.Split.split gpart_at2G
                            p_at0E = Functions.belowten' g_at0D
                            (g_at0D, gpart_at2G) = Genome.Split.split gpart_at2F
                            p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                            (g_at0B, gpart_at2F) = Genome.Split.split gpart_at2E
                            p_at0A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0z
                            (g_at0z, gpart_at2E) = Genome.Split.split gpart_at2D
                            p_at0y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0x
                            (g_at0x, gpart_at2D) = Genome.Split.split gpart_at2C
                            p_at0w = code-0.1.0.0:Genome.FixedList.Functions.double g_at0v
                            (g_at0v, gpart_at2C) = Genome.Split.split gpart_at2B
                            p_at0u = Functions.belowten' g_at0t
                            (g_at0t, gpart_at2B) = Genome.Split.split gpart_at2A
                            p_at0s = code-0.1.0.0:Genome.FixedList.Functions.double g_at0r
                            (g_at0r, gpart_at2A) = Genome.Split.split gpart_at2z
                            p_at0q = Functions.belowten' g_at0p
                            (g_at0p, gpart_at2z) = Genome.Split.split gpart_at2y
                            p_at0o = code-0.1.0.0:Genome.FixedList.Functions.double g_at0n
                            (g_at0n, gpart_at2y) = Genome.Split.split gpart_at2x
                            p_at0m = Functions.belowten' g_at0l
                            (g_at0l, gpart_at2x) = Genome.Split.split gpart_at2w
                            p_at0k = code-0.1.0.0:Genome.FixedList.Functions.double g_at0j
                            (g_at0j, gpart_at2w) = Genome.Split.split gpart_at2v
                            p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                            (g_at0h, gpart_at2v) = Genome.Split.split gpart_at2u
                            p_at0g = Functions.belowten' g_at0f
                            (g_at0f, gpart_at2u) = Genome.Split.split gpart_at2t
                            p_at0e = code-0.1.0.0:Genome.FixedList.Functions.double g_at0d
                            (g_at0d, gpart_at2t) = Genome.Split.split gpart_at2s
                            p_at0c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0b
                            (g_at0b, gpart_at2s) = Genome.Split.split gpart_at2r
                            p_at0a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at09
                            (g_at09, gpart_at2r) = Genome.Split.split gpart_at2q
                            p_at08 = code-0.1.0.0:Genome.FixedList.Functions.double g_at07
                            (g_at07, gpart_at2q) = Genome.Split.split gpart_at2p
                            p_at06 = code-0.1.0.0:Genome.FixedList.Functions.double g_at05
                            (g_at05, gpart_at2p) = Genome.Split.split gpart_at2o
                            p_at04 = code-0.1.0.0:Genome.FixedList.Functions.double g_at03
                            (g_at03, gpart_at2o) = Genome.Split.split gpart_at2n
                            p_at02 = code-0.1.0.0:Genome.FixedList.Functions.double g_at01
                            (g_at01, gpart_at2n) = Genome.Split.split gpart_at2m
                            p_at00 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZZ
                            (g_asZZ, gpart_at2m) = Genome.Split.split genome_at1h
                          in
                            \ desc_at1i
                              -> case desc_at1i of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at00)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at02)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at04)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at06)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at08)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0a)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0c)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0e)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0g)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0i)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0k)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0m)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0o)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0q)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0s)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0u)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0w)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0y)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0A)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0C)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0E)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0G)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0I)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0K)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0M)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0O)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Q)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0S)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0U)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0W)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Y)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at10)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at12)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at14)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at16)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at18)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1a)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1c)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1e)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1g)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at4Y
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5D
                      p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                      (g_at4W, gpart_at5D) = Genome.Split.split gpart_at5C
                      p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                      (g_at4U, gpart_at5C) = Genome.Split.split gpart_at5B
                      p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                      (g_at4S, gpart_at5B) = Genome.Split.split gpart_at5A
                      p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                      (g_at4Q, gpart_at5A) = Genome.Split.split gpart_at5z
                      p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                      (g_at4O, gpart_at5z) = Genome.Split.split gpart_at5y
                      p_at4N = Functions.belowten' g_at4M
                      (g_at4M, gpart_at5y) = Genome.Split.split gpart_at5x
                      p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                      (g_at4K, gpart_at5x) = Genome.Split.split gpart_at5w
                      p_at4J = code-0.1.0.0:Genome.FixedList.Functions.double g_at4I
                      (g_at4I, gpart_at5w) = Genome.Split.split gpart_at5v
                      p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                      (g_at4G, gpart_at5v) = Genome.Split.split gpart_at5u
                      p_at4F = Functions.belowten' g_at4E
                      (g_at4E, gpart_at5u) = Genome.Split.split gpart_at5t
                      p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                      (g_at4C, gpart_at5t) = Genome.Split.split gpart_at5s
                      p_at4B
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4A
                      (g_at4A, gpart_at5s) = Genome.Split.split gpart_at5r
                      p_at4z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4y
                      (g_at4y, gpart_at5r) = Genome.Split.split gpart_at5q
                      p_at4x = Functions.belowten' g_at4w
                      (g_at4w, gpart_at5q) = Genome.Split.split gpart_at5p
                      p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                      (g_at4u, gpart_at5p) = Genome.Split.split gpart_at5o
                      p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                      (g_at4s, gpart_at5o) = Genome.Split.split gpart_at5n
                      p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                      (g_at4q, gpart_at5n) = Genome.Split.split gpart_at5m
                      p_at4p = Functions.belowten' g_at4o
                      (g_at4o, gpart_at5m) = Genome.Split.split gpart_at5l
                      p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                      (g_at4m, gpart_at5l) = Genome.Split.split gpart_at5k
                      p_at4l = Functions.belowten' g_at4k
                      (g_at4k, gpart_at5k) = Genome.Split.split gpart_at5j
                      p_at4j = code-0.1.0.0:Genome.FixedList.Functions.double g_at4i
                      (g_at4i, gpart_at5j) = Genome.Split.split gpart_at5i
                      p_at4h
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4g
                      (g_at4g, gpart_at5i) = Genome.Split.split gpart_at5h
                      p_at4f
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4e
                      (g_at4e, gpart_at5h) = Genome.Split.split gpart_at5g
                      p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                      (g_at4c, gpart_at5g) = Genome.Split.split gpart_at5f
                      p_at4b = Functions.belowten' g_at4a
                      (g_at4a, gpart_at5f) = Genome.Split.split gpart_at5e
                      p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                      (g_at48, gpart_at5e) = Genome.Split.split gpart_at5d
                      p_at47 = Functions.belowten' g_at46
                      (g_at46, gpart_at5d) = Genome.Split.split gpart_at5c
                      p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                      (g_at44, gpart_at5c) = Genome.Split.split gpart_at5b
                      p_at43 = Functions.belowten' g_at42
                      (g_at42, gpart_at5b) = Genome.Split.split gpart_at5a
                      p_at41 = code-0.1.0.0:Genome.FixedList.Functions.double g_at40
                      (g_at40, gpart_at5a) = Genome.Split.split gpart_at59
                      p_at3Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3Y
                      (g_at3Y, gpart_at59) = Genome.Split.split gpart_at58
                      p_at3X = Functions.belowten' g_at3W
                      (g_at3W, gpart_at58) = Genome.Split.split gpart_at57
                      p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                      (g_at3U, gpart_at57) = Genome.Split.split gpart_at56
                      p_at3T
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3S
                      (g_at3S, gpart_at56) = Genome.Split.split gpart_at55
                      p_at3R
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3Q
                      (g_at3Q, gpart_at55) = Genome.Split.split gpart_at54
                      p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                      (g_at3O, gpart_at54) = Genome.Split.split gpart_at53
                      p_at3N = code-0.1.0.0:Genome.FixedList.Functions.double g_at3M
                      (g_at3M, gpart_at53) = Genome.Split.split gpart_at52
                      p_at3L = code-0.1.0.0:Genome.FixedList.Functions.double g_at3K
                      (g_at3K, gpart_at52) = Genome.Split.split gpart_at51
                      p_at3J = code-0.1.0.0:Genome.FixedList.Functions.double g_at3I
                      (g_at3I, gpart_at51) = Genome.Split.split gpart_at50
                      p_at3H = code-0.1.0.0:Genome.FixedList.Functions.double g_at3G
                      (g_at3G, gpart_at50) = Genome.Split.split genome_at4Y
                    in
                      [Reaction
                         (\ x_at5E
                            -> let c_MiRs_at5F = ((toVector x_at5E) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at3P
                                  / (1
                                     + (((p_at3H / p_at3R) ** p_at3T)
                                        + ((c_MiRs_at5F / p_at3V) ** p_at3X)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5G
                            -> let
                                 c_MiRs_at5I = ((toVector x_at5G) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at5H = ((toVector x_at5G) Data.Vector.Unboxed.! 3)
                                 c_PTB_at5J = ((toVector x_at5G) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3Z
                                  / (1
                                     + ((((c_RESTc_at5H / p_at41) ** p_at43)
                                         + ((c_MiRs_at5I / p_at45) ** p_at47))
                                        + ((c_PTB_at5J / p_at49) ** p_at4b)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at5K
                            -> let
                                 c_RESTc_at5M = ((toVector x_at5K) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at5L = ((toVector x_at5K) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at4d
                                  * (p_at4r
                                     / ((1 + p_at4r)
                                        + (((c_NPTB_at5L / p_at4j) ** p_at4l)
                                           + ((c_RESTc_at5M / p_at4n) ** p_at4p))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at5N
                            -> let
                                 c_MiRs_at5Q = ((toVector x_at5N) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5O = ((toVector x_at5N) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4t
                                  * ((p_at4H + ((c_PTB_at5O / p_at4v) ** p_at4x))
                                     / (((1 + p_at4H) + ((c_PTB_at5O / p_at4v) ** p_at4x))
                                        + ((c_MiRs_at5Q / p_at4D) ** p_at4F)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at5R
                            -> let c_RESTc_at5S = ((toVector x_at5R) Data.Vector.Unboxed.! 3)
                               in (p_at4J / (1 + ((c_RESTc_at5S / p_at4L) ** p_at4N))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at5T
                            -> let c_PTB_at5U = ((toVector x_at5T) Data.Vector.Unboxed.! 0)
                               in (p_at4P * c_PTB_at5U))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5V
                            -> let c_NPTB_at5W = ((toVector x_at5V) Data.Vector.Unboxed.! 1)
                               in (p_at4R * c_NPTB_at5W))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at5X
                            -> let c_MiRs_at5Y = ((toVector x_at5X) Data.Vector.Unboxed.! 2)
                               in (p_at4T * c_MiRs_at5Y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at5Z
                            -> let c_RESTc_at60 = ((toVector x_at5Z) Data.Vector.Unboxed.! 3)
                               in (p_at4V * c_RESTc_at60))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at61
                            -> let
                                 c_EndoNeuroTFs_at62 = ((toVector x_at61) Data.Vector.Unboxed.! 4)
                               in (p_at4X * c_EndoNeuroTFs_at62))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121497",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121499",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121501",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121503",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121505",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121507",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121509",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121531",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121533",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121551",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121553",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at4Y
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6G
                            p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                            (g_at4W, gpart_at6G) = Genome.Split.split gpart_at6F
                            p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                            (g_at4U, gpart_at6F) = Genome.Split.split gpart_at6E
                            p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                            (g_at4S, gpart_at6E) = Genome.Split.split gpart_at6D
                            p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                            (g_at4Q, gpart_at6D) = Genome.Split.split gpart_at6C
                            p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                            (g_at4O, gpart_at6C) = Genome.Split.split gpart_at6B
                            p_at4N = Functions.belowten' g_at4M
                            (g_at4M, gpart_at6B) = Genome.Split.split gpart_at6A
                            p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                            (g_at4K, gpart_at6A) = Genome.Split.split gpart_at6z
                            p_at4J = code-0.1.0.0:Genome.FixedList.Functions.double g_at4I
                            (g_at4I, gpart_at6z) = Genome.Split.split gpart_at6y
                            p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                            (g_at4G, gpart_at6y) = Genome.Split.split gpart_at6x
                            p_at4F = Functions.belowten' g_at4E
                            (g_at4E, gpart_at6x) = Genome.Split.split gpart_at6w
                            p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                            (g_at4C, gpart_at6w) = Genome.Split.split gpart_at6v
                            p_at4B
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4A
                            (g_at4A, gpart_at6v) = Genome.Split.split gpart_at6u
                            p_at4z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4y
                            (g_at4y, gpart_at6u) = Genome.Split.split gpart_at6t
                            p_at4x = Functions.belowten' g_at4w
                            (g_at4w, gpart_at6t) = Genome.Split.split gpart_at6s
                            p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                            (g_at4u, gpart_at6s) = Genome.Split.split gpart_at6r
                            p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                            (g_at4s, gpart_at6r) = Genome.Split.split gpart_at6q
                            p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                            (g_at4q, gpart_at6q) = Genome.Split.split gpart_at6p
                            p_at4p = Functions.belowten' g_at4o
                            (g_at4o, gpart_at6p) = Genome.Split.split gpart_at6o
                            p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                            (g_at4m, gpart_at6o) = Genome.Split.split gpart_at6n
                            p_at4l = Functions.belowten' g_at4k
                            (g_at4k, gpart_at6n) = Genome.Split.split gpart_at6m
                            p_at4j = code-0.1.0.0:Genome.FixedList.Functions.double g_at4i
                            (g_at4i, gpart_at6m) = Genome.Split.split gpart_at6l
                            p_at4h
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4g
                            (g_at4g, gpart_at6l) = Genome.Split.split gpart_at6k
                            p_at4f
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4e
                            (g_at4e, gpart_at6k) = Genome.Split.split gpart_at6j
                            p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                            (g_at4c, gpart_at6j) = Genome.Split.split gpart_at6i
                            p_at4b = Functions.belowten' g_at4a
                            (g_at4a, gpart_at6i) = Genome.Split.split gpart_at6h
                            p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                            (g_at48, gpart_at6h) = Genome.Split.split gpart_at6g
                            p_at47 = Functions.belowten' g_at46
                            (g_at46, gpart_at6g) = Genome.Split.split gpart_at6f
                            p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                            (g_at44, gpart_at6f) = Genome.Split.split gpart_at6e
                            p_at43 = Functions.belowten' g_at42
                            (g_at42, gpart_at6e) = Genome.Split.split gpart_at6d
                            p_at41 = code-0.1.0.0:Genome.FixedList.Functions.double g_at40
                            (g_at40, gpart_at6d) = Genome.Split.split gpart_at6c
                            p_at3Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3Y
                            (g_at3Y, gpart_at6c) = Genome.Split.split gpart_at6b
                            p_at3X = Functions.belowten' g_at3W
                            (g_at3W, gpart_at6b) = Genome.Split.split gpart_at6a
                            p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                            (g_at3U, gpart_at6a) = Genome.Split.split gpart_at69
                            p_at3T
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3S
                            (g_at3S, gpart_at69) = Genome.Split.split gpart_at68
                            p_at3R
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3Q
                            (g_at3Q, gpart_at68) = Genome.Split.split gpart_at67
                            p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                            (g_at3O, gpart_at67) = Genome.Split.split gpart_at66
                            p_at3N = code-0.1.0.0:Genome.FixedList.Functions.double g_at3M
                            (g_at3M, gpart_at66) = Genome.Split.split gpart_at65
                            p_at3L = code-0.1.0.0:Genome.FixedList.Functions.double g_at3K
                            (g_at3K, gpart_at65) = Genome.Split.split gpart_at64
                            p_at3J = code-0.1.0.0:Genome.FixedList.Functions.double g_at3I
                            (g_at3I, gpart_at64) = Genome.Split.split gpart_at63
                            p_at3H = code-0.1.0.0:Genome.FixedList.Functions.double g_at3G
                            (g_at3G, gpart_at63) = Genome.Split.split genome_at4Y
                          in
                            \ desc_at4Z
                              -> case desc_at4Z of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3H)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3J)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3L)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3N)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3P)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3R)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3T)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3V)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3X)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Z)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at41)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at43)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at45)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at47)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at49)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4b)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4d)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4f)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4h)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4j)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4l)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4n)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4p)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4r)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4t)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4v)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4x)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4z)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4B)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4D)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4F)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4H)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4J)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4L)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4N)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4P)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4V)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4X)
                                   _ -> Nothing }}
