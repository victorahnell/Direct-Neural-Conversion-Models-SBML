src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a26AX
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26BE
                      p_a26AW = double g_a26AV
                      (g_a26AV, gpart_a26BE) = Genome.Split.split gpart_a26BD
                      p_a26AU = double g_a26AT
                      (g_a26AT, gpart_a26BD) = Genome.Split.split gpart_a26BC
                      p_a26AS = double g_a26AR
                      (g_a26AR, gpart_a26BC) = Genome.Split.split gpart_a26BB
                      p_a26AQ = double g_a26AP
                      (g_a26AP, gpart_a26BB) = Genome.Split.split gpart_a26BA
                      p_a26AO = double g_a26AN
                      (g_a26AN, gpart_a26BA) = Genome.Split.split gpart_a26Bz
                      p_a26AM = double g_a26AL
                      (g_a26AL, gpart_a26Bz) = Genome.Split.split gpart_a26By
                      p_a26AK = Functions.belowten' g_a26AJ
                      (g_a26AJ, gpart_a26By) = Genome.Split.split gpart_a26Bx
                      p_a26AI = double g_a26AH
                      (g_a26AH, gpart_a26Bx) = Genome.Split.split gpart_a26Bw
                      p_a26AG = Functions.belowten' g_a26AF
                      (g_a26AF, gpart_a26Bw) = Genome.Split.split gpart_a26Bv
                      p_a26AE = double g_a26AD
                      (g_a26AD, gpart_a26Bv) = Genome.Split.split gpart_a26Bu
                      p_a26AC = double g_a26AB
                      (g_a26AB, gpart_a26Bu) = Genome.Split.split gpart_a26Bt
                      p_a26AA = double g_a26Az
                      (g_a26Az, gpart_a26Bt) = Genome.Split.split gpart_a26Bs
                      p_a26Ay = Functions.belowten' g_a26Ax
                      (g_a26Ax, gpart_a26Bs) = Genome.Split.split gpart_a26Br
                      p_a26Aw = double g_a26Av
                      (g_a26Av, gpart_a26Br) = Genome.Split.split gpart_a26Bq
                      p_a26Au
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26At
                      (g_a26At, gpart_a26Bq) = Genome.Split.split gpart_a26Bp
                      p_a26As
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ar
                      (g_a26Ar, gpart_a26Bp) = Genome.Split.split gpart_a26Bo
                      p_a26Aq = Functions.belowten' g_a26Ap
                      (g_a26Ap, gpart_a26Bo) = Genome.Split.split gpart_a26Bn
                      p_a26Ao = double g_a26An
                      (g_a26An, gpart_a26Bn) = Genome.Split.split gpart_a26Bm
                      p_a26Am = double g_a26Al
                      (g_a26Al, gpart_a26Bm) = Genome.Split.split gpart_a26Bl
                      p_a26Ak = double g_a26Aj
                      (g_a26Aj, gpart_a26Bl) = Genome.Split.split gpart_a26Bk
                      p_a26Ai = Functions.belowten' g_a26Ah
                      (g_a26Ah, gpart_a26Bk) = Genome.Split.split gpart_a26Bj
                      p_a26Ag = double g_a26Af
                      (g_a26Af, gpart_a26Bj) = Genome.Split.split gpart_a26Bi
                      p_a26Ae
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ad
                      (g_a26Ad, gpart_a26Bi) = Genome.Split.split gpart_a26Bh
                      p_a26Ac
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ab
                      (g_a26Ab, gpart_a26Bh) = Genome.Split.split gpart_a26Bg
                      p_a26Aa = double g_a26A9
                      (g_a26A9, gpart_a26Bg) = Genome.Split.split gpart_a26Bf
                      p_a26A8 = Functions.belowten' g_a26A7
                      (g_a26A7, gpart_a26Bf) = Genome.Split.split gpart_a26Be
                      p_a26A6 = double g_a26A5
                      (g_a26A5, gpart_a26Be) = Genome.Split.split gpart_a26Bd
                      p_a26A4 = Functions.belowten' g_a26A3
                      (g_a26A3, gpart_a26Bd) = Genome.Split.split gpart_a26Bc
                      p_a26A2 = double g_a26A1
                      (g_a26A1, gpart_a26Bc) = Genome.Split.split gpart_a26Bb
                      p_a26A0 = double g_a26zZ
                      (g_a26zZ, gpart_a26Bb) = Genome.Split.split gpart_a26Ba
                      p_a26zY = double g_a26zX
                      (g_a26zX, gpart_a26Ba) = Genome.Split.split gpart_a26B9
                      p_a26zW = Functions.belowten' g_a26zV
                      (g_a26zV, gpart_a26B9) = Genome.Split.split gpart_a26B8
                      p_a26zU = double g_a26zT
                      (g_a26zT, gpart_a26B8) = Genome.Split.split gpart_a26B7
                      p_a26zS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26zR
                      (g_a26zR, gpart_a26B7) = Genome.Split.split gpart_a26B6
                      p_a26zQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26zP
                      (g_a26zP, gpart_a26B6) = Genome.Split.split gpart_a26B5
                      p_a26zO = Functions.belowten' g_a26zN
                      (g_a26zN, gpart_a26B5) = Genome.Split.split gpart_a26B4
                      p_a26zM = double g_a26zL
                      (g_a26zL, gpart_a26B4) = Genome.Split.split gpart_a26B3
                      p_a26zK = double g_a26zJ
                      (g_a26zJ, gpart_a26B3) = Genome.Split.split gpart_a26B2
                      p_a26zI = double g_a26zH
                      (g_a26zH, gpart_a26B2) = Genome.Split.split gpart_a26B1
                      p_a26zG = double g_a26zF
                      (g_a26zF, gpart_a26B1) = Genome.Split.split gpart_a26B0
                      p_a26zE = double g_a26zD
                      (g_a26zD, gpart_a26B0) = Genome.Split.split gpart_a26AZ
                      p_a26zC = double g_a26zB
                      (g_a26zB, gpart_a26AZ) = Genome.Split.split genome_a26AX
                    in  \ x_a26BF
                          -> let
                               c_PTB_a26BK
                                 = ((Data.Fixed.Vector.toVector x_a26BF) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26BI
                                 = ((Data.Fixed.Vector.toVector x_a26BF) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26BG
                                 = ((Data.Fixed.Vector.toVector x_a26BF) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26BP
                                 = ((Data.Fixed.Vector.toVector x_a26BF) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26C1
                                 = ((Data.Fixed.Vector.toVector x_a26BF) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26zK
                                     * ((p_a26zY + ((c_NPTB_a26BG / p_a26zM) ** p_a26zO))
                                        / (((1 + p_a26zY) + ((c_NPTB_a26BG / p_a26zM) ** p_a26zO))
                                           + ((c_MiRs_a26BI / p_a26zU) ** p_a26zW))))
                                    + (negate (p_a26AO * c_PTB_a26BK))),
                                   ((p_a26A0
                                     / (1
                                        + (((c_MiRs_a26BI / p_a26A2) ** p_a26A4)
                                           + ((c_PTB_a26BK / p_a26A6) ** p_a26A8))))
                                    + (negate (p_a26AQ * c_NPTB_a26BG))),
                                   ((p_a26Aa
                                     * ((p_a26Ak + ((p_a26zG / p_a26Ac) ** p_a26Ae))
                                        / (((1 + p_a26Ak) + ((p_a26zG / p_a26Ac) ** p_a26Ae))
                                           + ((c_RESTc_a26BP / p_a26Ag) ** p_a26Ai))))
                                    + (negate (p_a26AS * c_MiRs_a26BI))),
                                   ((p_a26Am
                                     * ((p_a26AA + ((c_PTB_a26BK / p_a26Ao) ** p_a26Aq))
                                        / (((1 + p_a26AA) + ((c_PTB_a26BK / p_a26Ao) ** p_a26Aq))
                                           + (((p_a26zC / p_a26As) ** p_a26Au)
                                              + ((c_MiRs_a26BI / p_a26Aw) ** p_a26Ay)))))
                                    + (negate (p_a26AU * c_RESTc_a26BP))),
                                   ((p_a26AC
                                     * ((p_a26AM + ((c_MiRs_a26BI / p_a26AE) ** p_a26AG))
                                        / (((1 + p_a26AM) + ((c_MiRs_a26BI / p_a26AE) ** p_a26AG))
                                           + ((c_RESTc_a26BP / p_a26AI) ** p_a26AK))))
                                    + (negate (p_a26AW * c_EndoNeuroTFs_a26C1)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511720",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511722",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511724",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511726",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511728",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511730",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511734",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511736",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511756",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511758",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511764",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511766",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511768",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511770",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511771",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511772",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511773",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511774",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511777",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511778",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511779",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511780",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511781",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511782",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511783",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511784",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511785",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511786",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511787",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511788",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511789",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511790",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511791",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511792",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511793",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511794",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511795",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511796",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511797",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511798",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511799",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511800",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511801",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511802",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26AX
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26CH
                            p_a26AW = double g_a26AV
                            (g_a26AV, gpart_a26CH) = Genome.Split.split gpart_a26CG
                            p_a26AU = double g_a26AT
                            (g_a26AT, gpart_a26CG) = Genome.Split.split gpart_a26CF
                            p_a26AS = double g_a26AR
                            (g_a26AR, gpart_a26CF) = Genome.Split.split gpart_a26CE
                            p_a26AQ = double g_a26AP
                            (g_a26AP, gpart_a26CE) = Genome.Split.split gpart_a26CD
                            p_a26AO = double g_a26AN
                            (g_a26AN, gpart_a26CD) = Genome.Split.split gpart_a26CC
                            p_a26AM = double g_a26AL
                            (g_a26AL, gpart_a26CC) = Genome.Split.split gpart_a26CB
                            p_a26AK = Functions.belowten' g_a26AJ
                            (g_a26AJ, gpart_a26CB) = Genome.Split.split gpart_a26CA
                            p_a26AI = double g_a26AH
                            (g_a26AH, gpart_a26CA) = Genome.Split.split gpart_a26Cz
                            p_a26AG = Functions.belowten' g_a26AF
                            (g_a26AF, gpart_a26Cz) = Genome.Split.split gpart_a26Cy
                            p_a26AE = double g_a26AD
                            (g_a26AD, gpart_a26Cy) = Genome.Split.split gpart_a26Cx
                            p_a26AC = double g_a26AB
                            (g_a26AB, gpart_a26Cx) = Genome.Split.split gpart_a26Cw
                            p_a26AA = double g_a26Az
                            (g_a26Az, gpart_a26Cw) = Genome.Split.split gpart_a26Cv
                            p_a26Ay = Functions.belowten' g_a26Ax
                            (g_a26Ax, gpart_a26Cv) = Genome.Split.split gpart_a26Cu
                            p_a26Aw = double g_a26Av
                            (g_a26Av, gpart_a26Cu) = Genome.Split.split gpart_a26Ct
                            p_a26Au
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26At
                            (g_a26At, gpart_a26Ct) = Genome.Split.split gpart_a26Cs
                            p_a26As
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ar
                            (g_a26Ar, gpart_a26Cs) = Genome.Split.split gpart_a26Cr
                            p_a26Aq = Functions.belowten' g_a26Ap
                            (g_a26Ap, gpart_a26Cr) = Genome.Split.split gpart_a26Cq
                            p_a26Ao = double g_a26An
                            (g_a26An, gpart_a26Cq) = Genome.Split.split gpart_a26Cp
                            p_a26Am = double g_a26Al
                            (g_a26Al, gpart_a26Cp) = Genome.Split.split gpart_a26Co
                            p_a26Ak = double g_a26Aj
                            (g_a26Aj, gpart_a26Co) = Genome.Split.split gpart_a26Cn
                            p_a26Ai = Functions.belowten' g_a26Ah
                            (g_a26Ah, gpart_a26Cn) = Genome.Split.split gpart_a26Cm
                            p_a26Ag = double g_a26Af
                            (g_a26Af, gpart_a26Cm) = Genome.Split.split gpart_a26Cl
                            p_a26Ae
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ad
                            (g_a26Ad, gpart_a26Cl) = Genome.Split.split gpart_a26Ck
                            p_a26Ac
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ab
                            (g_a26Ab, gpart_a26Ck) = Genome.Split.split gpart_a26Cj
                            p_a26Aa = double g_a26A9
                            (g_a26A9, gpart_a26Cj) = Genome.Split.split gpart_a26Ci
                            p_a26A8 = Functions.belowten' g_a26A7
                            (g_a26A7, gpart_a26Ci) = Genome.Split.split gpart_a26Ch
                            p_a26A6 = double g_a26A5
                            (g_a26A5, gpart_a26Ch) = Genome.Split.split gpart_a26Cg
                            p_a26A4 = Functions.belowten' g_a26A3
                            (g_a26A3, gpart_a26Cg) = Genome.Split.split gpart_a26Cf
                            p_a26A2 = double g_a26A1
                            (g_a26A1, gpart_a26Cf) = Genome.Split.split gpart_a26Ce
                            p_a26A0 = double g_a26zZ
                            (g_a26zZ, gpart_a26Ce) = Genome.Split.split gpart_a26Cd
                            p_a26zY = double g_a26zX
                            (g_a26zX, gpart_a26Cd) = Genome.Split.split gpart_a26Cc
                            p_a26zW = Functions.belowten' g_a26zV
                            (g_a26zV, gpart_a26Cc) = Genome.Split.split gpart_a26Cb
                            p_a26zU = double g_a26zT
                            (g_a26zT, gpart_a26Cb) = Genome.Split.split gpart_a26Ca
                            p_a26zS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26zR
                            (g_a26zR, gpart_a26Ca) = Genome.Split.split gpart_a26C9
                            p_a26zQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26zP
                            (g_a26zP, gpart_a26C9) = Genome.Split.split gpart_a26C8
                            p_a26zO = Functions.belowten' g_a26zN
                            (g_a26zN, gpart_a26C8) = Genome.Split.split gpart_a26C7
                            p_a26zM = double g_a26zL
                            (g_a26zL, gpart_a26C7) = Genome.Split.split gpart_a26C6
                            p_a26zK = double g_a26zJ
                            (g_a26zJ, gpart_a26C6) = Genome.Split.split gpart_a26C5
                            p_a26zI = double g_a26zH
                            (g_a26zH, gpart_a26C5) = Genome.Split.split gpart_a26C4
                            p_a26zG = double g_a26zF
                            (g_a26zF, gpart_a26C4) = Genome.Split.split gpart_a26C3
                            p_a26zE = double g_a26zD
                            (g_a26zD, gpart_a26C3) = Genome.Split.split gpart_a26C2
                            p_a26zC = double g_a26zB
                            (g_a26zB, gpart_a26C2) = Genome.Split.split genome_a26AX
                          in
                            \ desc_a26AY
                              -> case desc_a26AY of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zC)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zE)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zG)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zI)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zK)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zM)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zO)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zQ)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zS)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zU)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zW)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zY)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26A0)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26A2)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26A4)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26A6)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26A8)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Aa)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ac)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ae)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ag)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ai)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ak)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Am)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ao)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Aq)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26As)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Au)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Aw)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ay)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AA)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AC)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AE)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AG)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AI)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AK)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AM)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AO)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AQ)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AS)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AU)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26AW)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a26Fd
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26FU
                      p_a26Fc = double g_a26Fb
                      (g_a26Fb, gpart_a26FU) = Genome.Split.split gpart_a26FT
                      p_a26Fa = double g_a26F9
                      (g_a26F9, gpart_a26FT) = Genome.Split.split gpart_a26FS
                      p_a26F8 = double g_a26F7
                      (g_a26F7, gpart_a26FS) = Genome.Split.split gpart_a26FR
                      p_a26F6 = double g_a26F5
                      (g_a26F5, gpart_a26FR) = Genome.Split.split gpart_a26FQ
                      p_a26F4 = double g_a26F3
                      (g_a26F3, gpart_a26FQ) = Genome.Split.split gpart_a26FP
                      p_a26F2 = double g_a26F1
                      (g_a26F1, gpart_a26FP) = Genome.Split.split gpart_a26FO
                      p_a26F0 = Functions.belowten' g_a26EZ
                      (g_a26EZ, gpart_a26FO) = Genome.Split.split gpart_a26FN
                      p_a26EY = double g_a26EX
                      (g_a26EX, gpart_a26FN) = Genome.Split.split gpart_a26FM
                      p_a26EW = Functions.belowten' g_a26EV
                      (g_a26EV, gpart_a26FM) = Genome.Split.split gpart_a26FL
                      p_a26EU = double g_a26ET
                      (g_a26ET, gpart_a26FL) = Genome.Split.split gpart_a26FK
                      p_a26ES = double g_a26ER
                      (g_a26ER, gpart_a26FK) = Genome.Split.split gpart_a26FJ
                      p_a26EQ = double g_a26EP
                      (g_a26EP, gpart_a26FJ) = Genome.Split.split gpart_a26FI
                      p_a26EO = Functions.belowten' g_a26EN
                      (g_a26EN, gpart_a26FI) = Genome.Split.split gpart_a26FH
                      p_a26EM = double g_a26EL
                      (g_a26EL, gpart_a26FH) = Genome.Split.split gpart_a26FG
                      p_a26EK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26EJ
                      (g_a26EJ, gpart_a26FG) = Genome.Split.split gpart_a26FF
                      p_a26EI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26EH
                      (g_a26EH, gpart_a26FF) = Genome.Split.split gpart_a26FE
                      p_a26EG = Functions.belowten' g_a26EF
                      (g_a26EF, gpart_a26FE) = Genome.Split.split gpart_a26FD
                      p_a26EE = double g_a26ED
                      (g_a26ED, gpart_a26FD) = Genome.Split.split gpart_a26FC
                      p_a26EC = double g_a26EB
                      (g_a26EB, gpart_a26FC) = Genome.Split.split gpart_a26FB
                      p_a26EA = double g_a26Ez
                      (g_a26Ez, gpart_a26FB) = Genome.Split.split gpart_a26FA
                      p_a26Ey = Functions.belowten' g_a26Ex
                      (g_a26Ex, gpart_a26FA) = Genome.Split.split gpart_a26Fz
                      p_a26Ew = double g_a26Ev
                      (g_a26Ev, gpart_a26Fz) = Genome.Split.split gpart_a26Fy
                      p_a26Eu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Et
                      (g_a26Et, gpart_a26Fy) = Genome.Split.split gpart_a26Fx
                      p_a26Es
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Er
                      (g_a26Er, gpart_a26Fx) = Genome.Split.split gpart_a26Fw
                      p_a26Eq = double g_a26Ep
                      (g_a26Ep, gpart_a26Fw) = Genome.Split.split gpart_a26Fv
                      p_a26Eo = Functions.belowten' g_a26En
                      (g_a26En, gpart_a26Fv) = Genome.Split.split gpart_a26Fu
                      p_a26Em = double g_a26El
                      (g_a26El, gpart_a26Fu) = Genome.Split.split gpart_a26Ft
                      p_a26Ek = Functions.belowten' g_a26Ej
                      (g_a26Ej, gpart_a26Ft) = Genome.Split.split gpart_a26Fs
                      p_a26Ei = double g_a26Eh
                      (g_a26Eh, gpart_a26Fs) = Genome.Split.split gpart_a26Fr
                      p_a26Eg = double g_a26Ef
                      (g_a26Ef, gpart_a26Fr) = Genome.Split.split gpart_a26Fq
                      p_a26Ee = double g_a26Ed
                      (g_a26Ed, gpart_a26Fq) = Genome.Split.split gpart_a26Fp
                      p_a26Ec = Functions.belowten' g_a26Eb
                      (g_a26Eb, gpart_a26Fp) = Genome.Split.split gpart_a26Fo
                      p_a26Ea = double g_a26E9
                      (g_a26E9, gpart_a26Fo) = Genome.Split.split gpart_a26Fn
                      p_a26E8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26E7
                      (g_a26E7, gpart_a26Fn) = Genome.Split.split gpart_a26Fm
                      p_a26E6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26E5
                      (g_a26E5, gpart_a26Fm) = Genome.Split.split gpart_a26Fl
                      p_a26E4 = Functions.belowten' g_a26E3
                      (g_a26E3, gpart_a26Fl) = Genome.Split.split gpart_a26Fk
                      p_a26E2 = double g_a26E1
                      (g_a26E1, gpart_a26Fk) = Genome.Split.split gpart_a26Fj
                      p_a26E0 = double g_a26DZ
                      (g_a26DZ, gpart_a26Fj) = Genome.Split.split gpart_a26Fi
                      p_a26DY = double g_a26DX
                      (g_a26DX, gpart_a26Fi) = Genome.Split.split gpart_a26Fh
                      p_a26DW = double g_a26DV
                      (g_a26DV, gpart_a26Fh) = Genome.Split.split gpart_a26Fg
                      p_a26DU = double g_a26DT
                      (g_a26DT, gpart_a26Fg) = Genome.Split.split gpart_a26Ff
                      p_a26DS = double g_a26DR
                      (g_a26DR, gpart_a26Ff) = Genome.Split.split genome_a26Fd
                    in  \ x_a26FV
                          -> let
                               c_PTB_a26G0
                                 = ((Data.Fixed.Vector.toVector x_a26FV) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26FY
                                 = ((Data.Fixed.Vector.toVector x_a26FV) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26FW
                                 = ((Data.Fixed.Vector.toVector x_a26FV) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26G5
                                 = ((Data.Fixed.Vector.toVector x_a26FV) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26Gh
                                 = ((Data.Fixed.Vector.toVector x_a26FV) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26E0
                                     * ((p_a26Ee + ((c_NPTB_a26FW / p_a26E2) ** p_a26E4))
                                        / (((1 + p_a26Ee) + ((c_NPTB_a26FW / p_a26E2) ** p_a26E4))
                                           + ((c_MiRs_a26FY / p_a26Ea) ** p_a26Ec))))
                                    + (negate (p_a26F4 * c_PTB_a26G0))),
                                   ((p_a26Eg
                                     / (1
                                        + (((c_MiRs_a26FY / p_a26Ei) ** p_a26Ek)
                                           + ((c_PTB_a26G0 / p_a26Em) ** p_a26Eo))))
                                    + (negate (p_a26F6 * c_NPTB_a26FW))),
                                   ((p_a26Eq
                                     * (p_a26EA
                                        / ((1 + p_a26EA) + ((c_RESTc_a26G5 / p_a26Ew) ** p_a26Ey))))
                                    + (negate (p_a26F8 * c_MiRs_a26FY))),
                                   ((p_a26EC
                                     * ((p_a26EQ + ((c_PTB_a26G0 / p_a26EE) ** p_a26EG))
                                        / (((1 + p_a26EQ) + ((c_PTB_a26G0 / p_a26EE) ** p_a26EG))
                                           + (((p_a26DS / p_a26EI) ** p_a26EK)
                                              + ((c_MiRs_a26FY / p_a26EM) ** p_a26EO)))))
                                    + (negate (p_a26Fa * c_RESTc_a26G5))),
                                   ((p_a26ES
                                     * ((p_a26F2 + ((c_MiRs_a26FY / p_a26EU) ** p_a26EW))
                                        / (((1 + p_a26F2) + ((c_MiRs_a26FY / p_a26EU) ** p_a26EW))
                                           + ((c_RESTc_a26G5 / p_a26EY) ** p_a26F0))))
                                    + (negate (p_a26Fc * c_EndoNeuroTFs_a26Gh)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511998",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512000",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512020",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512022",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512028",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512036",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512038",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512040",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512042",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512046",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512048",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512051",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512052",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512053",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512054",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512055",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512056",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512057",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512058",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512059",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512060",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512061",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512062",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512063",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512064",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26Fd
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26GX
                            p_a26Fc = double g_a26Fb
                            (g_a26Fb, gpart_a26GX) = Genome.Split.split gpart_a26GW
                            p_a26Fa = double g_a26F9
                            (g_a26F9, gpart_a26GW) = Genome.Split.split gpart_a26GV
                            p_a26F8 = double g_a26F7
                            (g_a26F7, gpart_a26GV) = Genome.Split.split gpart_a26GU
                            p_a26F6 = double g_a26F5
                            (g_a26F5, gpart_a26GU) = Genome.Split.split gpart_a26GT
                            p_a26F4 = double g_a26F3
                            (g_a26F3, gpart_a26GT) = Genome.Split.split gpart_a26GS
                            p_a26F2 = double g_a26F1
                            (g_a26F1, gpart_a26GS) = Genome.Split.split gpart_a26GR
                            p_a26F0 = Functions.belowten' g_a26EZ
                            (g_a26EZ, gpart_a26GR) = Genome.Split.split gpart_a26GQ
                            p_a26EY = double g_a26EX
                            (g_a26EX, gpart_a26GQ) = Genome.Split.split gpart_a26GP
                            p_a26EW = Functions.belowten' g_a26EV
                            (g_a26EV, gpart_a26GP) = Genome.Split.split gpart_a26GO
                            p_a26EU = double g_a26ET
                            (g_a26ET, gpart_a26GO) = Genome.Split.split gpart_a26GN
                            p_a26ES = double g_a26ER
                            (g_a26ER, gpart_a26GN) = Genome.Split.split gpart_a26GM
                            p_a26EQ = double g_a26EP
                            (g_a26EP, gpart_a26GM) = Genome.Split.split gpart_a26GL
                            p_a26EO = Functions.belowten' g_a26EN
                            (g_a26EN, gpart_a26GL) = Genome.Split.split gpart_a26GK
                            p_a26EM = double g_a26EL
                            (g_a26EL, gpart_a26GK) = Genome.Split.split gpart_a26GJ
                            p_a26EK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26EJ
                            (g_a26EJ, gpart_a26GJ) = Genome.Split.split gpart_a26GI
                            p_a26EI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26EH
                            (g_a26EH, gpart_a26GI) = Genome.Split.split gpart_a26GH
                            p_a26EG = Functions.belowten' g_a26EF
                            (g_a26EF, gpart_a26GH) = Genome.Split.split gpart_a26GG
                            p_a26EE = double g_a26ED
                            (g_a26ED, gpart_a26GG) = Genome.Split.split gpart_a26GF
                            p_a26EC = double g_a26EB
                            (g_a26EB, gpart_a26GF) = Genome.Split.split gpart_a26GE
                            p_a26EA = double g_a26Ez
                            (g_a26Ez, gpart_a26GE) = Genome.Split.split gpart_a26GD
                            p_a26Ey = Functions.belowten' g_a26Ex
                            (g_a26Ex, gpart_a26GD) = Genome.Split.split gpart_a26GC
                            p_a26Ew = double g_a26Ev
                            (g_a26Ev, gpart_a26GC) = Genome.Split.split gpart_a26GB
                            p_a26Eu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Et
                            (g_a26Et, gpart_a26GB) = Genome.Split.split gpart_a26GA
                            p_a26Es
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Er
                            (g_a26Er, gpart_a26GA) = Genome.Split.split gpart_a26Gz
                            p_a26Eq = double g_a26Ep
                            (g_a26Ep, gpart_a26Gz) = Genome.Split.split gpart_a26Gy
                            p_a26Eo = Functions.belowten' g_a26En
                            (g_a26En, gpart_a26Gy) = Genome.Split.split gpart_a26Gx
                            p_a26Em = double g_a26El
                            (g_a26El, gpart_a26Gx) = Genome.Split.split gpart_a26Gw
                            p_a26Ek = Functions.belowten' g_a26Ej
                            (g_a26Ej, gpart_a26Gw) = Genome.Split.split gpart_a26Gv
                            p_a26Ei = double g_a26Eh
                            (g_a26Eh, gpart_a26Gv) = Genome.Split.split gpart_a26Gu
                            p_a26Eg = double g_a26Ef
                            (g_a26Ef, gpart_a26Gu) = Genome.Split.split gpart_a26Gt
                            p_a26Ee = double g_a26Ed
                            (g_a26Ed, gpart_a26Gt) = Genome.Split.split gpart_a26Gs
                            p_a26Ec = Functions.belowten' g_a26Eb
                            (g_a26Eb, gpart_a26Gs) = Genome.Split.split gpart_a26Gr
                            p_a26Ea = double g_a26E9
                            (g_a26E9, gpart_a26Gr) = Genome.Split.split gpart_a26Gq
                            p_a26E8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26E7
                            (g_a26E7, gpart_a26Gq) = Genome.Split.split gpart_a26Gp
                            p_a26E6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26E5
                            (g_a26E5, gpart_a26Gp) = Genome.Split.split gpart_a26Go
                            p_a26E4 = Functions.belowten' g_a26E3
                            (g_a26E3, gpart_a26Go) = Genome.Split.split gpart_a26Gn
                            p_a26E2 = double g_a26E1
                            (g_a26E1, gpart_a26Gn) = Genome.Split.split gpart_a26Gm
                            p_a26E0 = double g_a26DZ
                            (g_a26DZ, gpart_a26Gm) = Genome.Split.split gpart_a26Gl
                            p_a26DY = double g_a26DX
                            (g_a26DX, gpart_a26Gl) = Genome.Split.split gpart_a26Gk
                            p_a26DW = double g_a26DV
                            (g_a26DV, gpart_a26Gk) = Genome.Split.split gpart_a26Gj
                            p_a26DU = double g_a26DT
                            (g_a26DT, gpart_a26Gj) = Genome.Split.split gpart_a26Gi
                            p_a26DS = double g_a26DR
                            (g_a26DR, gpart_a26Gi) = Genome.Split.split genome_a26Fd
                          in
                            \ desc_a26Fe
                              -> case desc_a26Fe of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DS)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DU)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DW)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DY)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26E0)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26E2)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26E4)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26E6)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26E8)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ea)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ec)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ee)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Eg)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ei)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ek)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Em)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Eo)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Eq)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Es)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Eu)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ew)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ey)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EA)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EC)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EE)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EG)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EI)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EK)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EM)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EO)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EQ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26ES)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EU)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EW)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26EY)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F0)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F2)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F4)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F6)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26F8)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fa)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fc)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a26Jt
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Ka
                      p_a26Js = double g_a26Jr
                      (g_a26Jr, gpart_a26Ka) = Genome.Split.split gpart_a26K9
                      p_a26Jq = double g_a26Jp
                      (g_a26Jp, gpart_a26K9) = Genome.Split.split gpart_a26K8
                      p_a26Jo = double g_a26Jn
                      (g_a26Jn, gpart_a26K8) = Genome.Split.split gpart_a26K7
                      p_a26Jm = double g_a26Jl
                      (g_a26Jl, gpart_a26K7) = Genome.Split.split gpart_a26K6
                      p_a26Jk = double g_a26Jj
                      (g_a26Jj, gpart_a26K6) = Genome.Split.split gpart_a26K5
                      p_a26Ji = double g_a26Jh
                      (g_a26Jh, gpart_a26K5) = Genome.Split.split gpart_a26K4
                      p_a26Jg = Functions.belowten' g_a26Jf
                      (g_a26Jf, gpart_a26K4) = Genome.Split.split gpart_a26K3
                      p_a26Je = double g_a26Jd
                      (g_a26Jd, gpart_a26K3) = Genome.Split.split gpart_a26K2
                      p_a26Jc = Functions.belowten' g_a26Jb
                      (g_a26Jb, gpart_a26K2) = Genome.Split.split gpart_a26K1
                      p_a26Ja = double g_a26J9
                      (g_a26J9, gpart_a26K1) = Genome.Split.split gpart_a26K0
                      p_a26J8 = double g_a26J7
                      (g_a26J7, gpart_a26K0) = Genome.Split.split gpart_a26JZ
                      p_a26J6 = double g_a26J5
                      (g_a26J5, gpart_a26JZ) = Genome.Split.split gpart_a26JY
                      p_a26J4 = Functions.belowten' g_a26J3
                      (g_a26J3, gpart_a26JY) = Genome.Split.split gpart_a26JX
                      p_a26J2 = double g_a26J1
                      (g_a26J1, gpart_a26JX) = Genome.Split.split gpart_a26JW
                      p_a26J0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26IZ
                      (g_a26IZ, gpart_a26JW) = Genome.Split.split gpart_a26JV
                      p_a26IY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26IX
                      (g_a26IX, gpart_a26JV) = Genome.Split.split gpart_a26JU
                      p_a26IW = Functions.belowten' g_a26IV
                      (g_a26IV, gpart_a26JU) = Genome.Split.split gpart_a26JT
                      p_a26IU = double g_a26IT
                      (g_a26IT, gpart_a26JT) = Genome.Split.split gpart_a26JS
                      p_a26IS = double g_a26IR
                      (g_a26IR, gpart_a26JS) = Genome.Split.split gpart_a26JR
                      p_a26IQ = double g_a26IP
                      (g_a26IP, gpart_a26JR) = Genome.Split.split gpart_a26JQ
                      p_a26IO = Functions.belowten' g_a26IN
                      (g_a26IN, gpart_a26JQ) = Genome.Split.split gpart_a26JP
                      p_a26IM = double g_a26IL
                      (g_a26IL, gpart_a26JP) = Genome.Split.split gpart_a26JO
                      p_a26IK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26IJ
                      (g_a26IJ, gpart_a26JO) = Genome.Split.split gpart_a26JN
                      p_a26II
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26IH
                      (g_a26IH, gpart_a26JN) = Genome.Split.split gpart_a26JM
                      p_a26IG = double g_a26IF
                      (g_a26IF, gpart_a26JM) = Genome.Split.split gpart_a26JL
                      p_a26IE = Functions.belowten' g_a26ID
                      (g_a26ID, gpart_a26JL) = Genome.Split.split gpart_a26JK
                      p_a26IC = double g_a26IB
                      (g_a26IB, gpart_a26JK) = Genome.Split.split gpart_a26JJ
                      p_a26IA = Functions.belowten' g_a26Iz
                      (g_a26Iz, gpart_a26JJ) = Genome.Split.split gpart_a26JI
                      p_a26Iy = double g_a26Ix
                      (g_a26Ix, gpart_a26JI) = Genome.Split.split gpart_a26JH
                      p_a26Iw = double g_a26Iv
                      (g_a26Iv, gpart_a26JH) = Genome.Split.split gpart_a26JG
                      p_a26Iu = double g_a26It
                      (g_a26It, gpart_a26JG) = Genome.Split.split gpart_a26JF
                      p_a26Is = Functions.belowten' g_a26Ir
                      (g_a26Ir, gpart_a26JF) = Genome.Split.split gpart_a26JE
                      p_a26Iq = double g_a26Ip
                      (g_a26Ip, gpart_a26JE) = Genome.Split.split gpart_a26JD
                      p_a26Io
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26In
                      (g_a26In, gpart_a26JD) = Genome.Split.split gpart_a26JC
                      p_a26Im
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Il
                      (g_a26Il, gpart_a26JC) = Genome.Split.split gpart_a26JB
                      p_a26Ik = Functions.belowten' g_a26Ij
                      (g_a26Ij, gpart_a26JB) = Genome.Split.split gpart_a26JA
                      p_a26Ii = double g_a26Ih
                      (g_a26Ih, gpart_a26JA) = Genome.Split.split gpart_a26Jz
                      p_a26Ig = double g_a26If
                      (g_a26If, gpart_a26Jz) = Genome.Split.split gpart_a26Jy
                      p_a26Ie = double g_a26Id
                      (g_a26Id, gpart_a26Jy) = Genome.Split.split gpart_a26Jx
                      p_a26Ic = double g_a26Ib
                      (g_a26Ib, gpart_a26Jx) = Genome.Split.split gpart_a26Jw
                      p_a26Ia = double g_a26I9
                      (g_a26I9, gpart_a26Jw) = Genome.Split.split gpart_a26Jv
                      p_a26I8 = double g_a26I7
                      (g_a26I7, gpart_a26Jv) = Genome.Split.split genome_a26Jt
                    in  \ x_a26Kb
                          -> let
                               c_PTB_a26Kg
                                 = ((Data.Fixed.Vector.toVector x_a26Kb) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26Ke
                                 = ((Data.Fixed.Vector.toVector x_a26Kb) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26Kc
                                 = ((Data.Fixed.Vector.toVector x_a26Kb) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26Kl
                                 = ((Data.Fixed.Vector.toVector x_a26Kb) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26Kx
                                 = ((Data.Fixed.Vector.toVector x_a26Kb) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26Ig
                                     * ((p_a26Iu + ((c_NPTB_a26Kc / p_a26Ii) ** p_a26Ik))
                                        / (((1 + p_a26Iu) + ((c_NPTB_a26Kc / p_a26Ii) ** p_a26Ik))
                                           + ((c_MiRs_a26Ke / p_a26Iq) ** p_a26Is))))
                                    + (negate (p_a26Jk * c_PTB_a26Kg))),
                                   ((p_a26Iw
                                     / (1
                                        + (((c_MiRs_a26Ke / p_a26Iy) ** p_a26IA)
                                           + ((c_PTB_a26Kg / p_a26IC) ** p_a26IE))))
                                    + (negate (p_a26Jm * c_NPTB_a26Kc))),
                                   ((p_a26IG
                                     * (p_a26IQ
                                        / ((1 + p_a26IQ) + ((c_RESTc_a26Kl / p_a26IM) ** p_a26IO))))
                                    + (negate (p_a26Jo * c_MiRs_a26Ke))),
                                   ((p_a26IS
                                     * ((p_a26J6 + ((c_PTB_a26Kg / p_a26IU) ** p_a26IW))
                                        / (((1 + p_a26J6) + ((c_PTB_a26Kg / p_a26IU) ** p_a26IW))
                                           + ((c_MiRs_a26Ke / p_a26J2) ** p_a26J4))))
                                    + (negate (p_a26Jq * c_RESTc_a26Kl))),
                                   ((p_a26J8
                                     * ((p_a26Ji + ((c_MiRs_a26Ke / p_a26Ja) ** p_a26Jc))
                                        / (((1 + p_a26Ji) + ((c_MiRs_a26Ke / p_a26Ja) ** p_a26Jc))
                                           + ((c_RESTc_a26Kl / p_a26Je) ** p_a26Jg))))
                                    + (negate (p_a26Js * c_EndoNeuroTFs_a26Kx)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512250",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512252",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512253",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512254",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512257",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512258",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512259",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512260",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512261",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512262",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512263",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512264",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512265",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512266",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512268",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512270",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512272",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512274",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512276",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512284",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512286",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512298",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512300",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512302",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512316",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512317",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512318",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512320",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512322",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512324",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512325",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512326",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512327",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512328",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512329",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512330",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26Jt
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Ld
                            p_a26Js = double g_a26Jr
                            (g_a26Jr, gpart_a26Ld) = Genome.Split.split gpart_a26Lc
                            p_a26Jq = double g_a26Jp
                            (g_a26Jp, gpart_a26Lc) = Genome.Split.split gpart_a26Lb
                            p_a26Jo = double g_a26Jn
                            (g_a26Jn, gpart_a26Lb) = Genome.Split.split gpart_a26La
                            p_a26Jm = double g_a26Jl
                            (g_a26Jl, gpart_a26La) = Genome.Split.split gpart_a26L9
                            p_a26Jk = double g_a26Jj
                            (g_a26Jj, gpart_a26L9) = Genome.Split.split gpart_a26L8
                            p_a26Ji = double g_a26Jh
                            (g_a26Jh, gpart_a26L8) = Genome.Split.split gpart_a26L7
                            p_a26Jg = Functions.belowten' g_a26Jf
                            (g_a26Jf, gpart_a26L7) = Genome.Split.split gpart_a26L6
                            p_a26Je = double g_a26Jd
                            (g_a26Jd, gpart_a26L6) = Genome.Split.split gpart_a26L5
                            p_a26Jc = Functions.belowten' g_a26Jb
                            (g_a26Jb, gpart_a26L5) = Genome.Split.split gpart_a26L4
                            p_a26Ja = double g_a26J9
                            (g_a26J9, gpart_a26L4) = Genome.Split.split gpart_a26L3
                            p_a26J8 = double g_a26J7
                            (g_a26J7, gpart_a26L3) = Genome.Split.split gpart_a26L2
                            p_a26J6 = double g_a26J5
                            (g_a26J5, gpart_a26L2) = Genome.Split.split gpart_a26L1
                            p_a26J4 = Functions.belowten' g_a26J3
                            (g_a26J3, gpart_a26L1) = Genome.Split.split gpart_a26L0
                            p_a26J2 = double g_a26J1
                            (g_a26J1, gpart_a26L0) = Genome.Split.split gpart_a26KZ
                            p_a26J0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26IZ
                            (g_a26IZ, gpart_a26KZ) = Genome.Split.split gpart_a26KY
                            p_a26IY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26IX
                            (g_a26IX, gpart_a26KY) = Genome.Split.split gpart_a26KX
                            p_a26IW = Functions.belowten' g_a26IV
                            (g_a26IV, gpart_a26KX) = Genome.Split.split gpart_a26KW
                            p_a26IU = double g_a26IT
                            (g_a26IT, gpart_a26KW) = Genome.Split.split gpart_a26KV
                            p_a26IS = double g_a26IR
                            (g_a26IR, gpart_a26KV) = Genome.Split.split gpart_a26KU
                            p_a26IQ = double g_a26IP
                            (g_a26IP, gpart_a26KU) = Genome.Split.split gpart_a26KT
                            p_a26IO = Functions.belowten' g_a26IN
                            (g_a26IN, gpart_a26KT) = Genome.Split.split gpart_a26KS
                            p_a26IM = double g_a26IL
                            (g_a26IL, gpart_a26KS) = Genome.Split.split gpart_a26KR
                            p_a26IK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26IJ
                            (g_a26IJ, gpart_a26KR) = Genome.Split.split gpart_a26KQ
                            p_a26II
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26IH
                            (g_a26IH, gpart_a26KQ) = Genome.Split.split gpart_a26KP
                            p_a26IG = double g_a26IF
                            (g_a26IF, gpart_a26KP) = Genome.Split.split gpart_a26KO
                            p_a26IE = Functions.belowten' g_a26ID
                            (g_a26ID, gpart_a26KO) = Genome.Split.split gpart_a26KN
                            p_a26IC = double g_a26IB
                            (g_a26IB, gpart_a26KN) = Genome.Split.split gpart_a26KM
                            p_a26IA = Functions.belowten' g_a26Iz
                            (g_a26Iz, gpart_a26KM) = Genome.Split.split gpart_a26KL
                            p_a26Iy = double g_a26Ix
                            (g_a26Ix, gpart_a26KL) = Genome.Split.split gpart_a26KK
                            p_a26Iw = double g_a26Iv
                            (g_a26Iv, gpart_a26KK) = Genome.Split.split gpart_a26KJ
                            p_a26Iu = double g_a26It
                            (g_a26It, gpart_a26KJ) = Genome.Split.split gpart_a26KI
                            p_a26Is = Functions.belowten' g_a26Ir
                            (g_a26Ir, gpart_a26KI) = Genome.Split.split gpart_a26KH
                            p_a26Iq = double g_a26Ip
                            (g_a26Ip, gpart_a26KH) = Genome.Split.split gpart_a26KG
                            p_a26Io
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26In
                            (g_a26In, gpart_a26KG) = Genome.Split.split gpart_a26KF
                            p_a26Im
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Il
                            (g_a26Il, gpart_a26KF) = Genome.Split.split gpart_a26KE
                            p_a26Ik = Functions.belowten' g_a26Ij
                            (g_a26Ij, gpart_a26KE) = Genome.Split.split gpart_a26KD
                            p_a26Ii = double g_a26Ih
                            (g_a26Ih, gpart_a26KD) = Genome.Split.split gpart_a26KC
                            p_a26Ig = double g_a26If
                            (g_a26If, gpart_a26KC) = Genome.Split.split gpart_a26KB
                            p_a26Ie = double g_a26Id
                            (g_a26Id, gpart_a26KB) = Genome.Split.split gpart_a26KA
                            p_a26Ic = double g_a26Ib
                            (g_a26Ib, gpart_a26KA) = Genome.Split.split gpart_a26Kz
                            p_a26Ia = double g_a26I9
                            (g_a26I9, gpart_a26Kz) = Genome.Split.split gpart_a26Ky
                            p_a26I8 = double g_a26I7
                            (g_a26I7, gpart_a26Ky) = Genome.Split.split genome_a26Jt
                          in
                            \ desc_a26Ju
                              -> case desc_a26Ju of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26I8)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ia)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ic)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ie)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ig)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ii)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ik)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Im)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Io)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Iq)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Is)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Iu)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Iw)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Iy)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IA)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IC)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IE)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IG)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26II)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IK)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IM)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IO)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IQ)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IS)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IU)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IW)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26IY)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26J0)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26J2)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26J4)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26J6)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26J8)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ja)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Jc)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Je)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Jg)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ji)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Jk)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Jm)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Jo)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Jq)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Js)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a26NJ
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Oq
                      p_a26NI = double g_a26NH
                      (g_a26NH, gpart_a26Oq) = Genome.Split.split gpart_a26Op
                      p_a26NG = double g_a26NF
                      (g_a26NF, gpart_a26Op) = Genome.Split.split gpart_a26Oo
                      p_a26NE = double g_a26ND
                      (g_a26ND, gpart_a26Oo) = Genome.Split.split gpart_a26On
                      p_a26NC = double g_a26NB
                      (g_a26NB, gpart_a26On) = Genome.Split.split gpart_a26Om
                      p_a26NA = double g_a26Nz
                      (g_a26Nz, gpart_a26Om) = Genome.Split.split gpart_a26Ol
                      p_a26Ny = double g_a26Nx
                      (g_a26Nx, gpart_a26Ol) = Genome.Split.split gpart_a26Ok
                      p_a26Nw = Functions.belowten' g_a26Nv
                      (g_a26Nv, gpart_a26Ok) = Genome.Split.split gpart_a26Oj
                      p_a26Nu = double g_a26Nt
                      (g_a26Nt, gpart_a26Oj) = Genome.Split.split gpart_a26Oi
                      p_a26Ns = Functions.belowten' g_a26Nr
                      (g_a26Nr, gpart_a26Oi) = Genome.Split.split gpart_a26Oh
                      p_a26Nq = double g_a26Np
                      (g_a26Np, gpart_a26Oh) = Genome.Split.split gpart_a26Og
                      p_a26No = double g_a26Nn
                      (g_a26Nn, gpart_a26Og) = Genome.Split.split gpart_a26Of
                      p_a26Nm = double g_a26Nl
                      (g_a26Nl, gpart_a26Of) = Genome.Split.split gpart_a26Oe
                      p_a26Nk = Functions.belowten' g_a26Nj
                      (g_a26Nj, gpart_a26Oe) = Genome.Split.split gpart_a26Od
                      p_a26Ni = double g_a26Nh
                      (g_a26Nh, gpart_a26Od) = Genome.Split.split gpart_a26Oc
                      p_a26Ng
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Nf
                      (g_a26Nf, gpart_a26Oc) = Genome.Split.split gpart_a26Ob
                      p_a26Ne
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Nd
                      (g_a26Nd, gpart_a26Ob) = Genome.Split.split gpart_a26Oa
                      p_a26Nc = Functions.belowten' g_a26Nb
                      (g_a26Nb, gpart_a26Oa) = Genome.Split.split gpart_a26O9
                      p_a26Na = double g_a26N9
                      (g_a26N9, gpart_a26O9) = Genome.Split.split gpart_a26O8
                      p_a26N8 = double g_a26N7
                      (g_a26N7, gpart_a26O8) = Genome.Split.split gpart_a26O7
                      p_a26N6 = double g_a26N5
                      (g_a26N5, gpart_a26O7) = Genome.Split.split gpart_a26O6
                      p_a26N4 = Functions.belowten' g_a26N3
                      (g_a26N3, gpart_a26O6) = Genome.Split.split gpart_a26O5
                      p_a26N2 = double g_a26N1
                      (g_a26N1, gpart_a26O5) = Genome.Split.split gpart_a26O4
                      p_a26N0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26MZ
                      (g_a26MZ, gpart_a26O4) = Genome.Split.split gpart_a26O3
                      p_a26MY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26MX
                      (g_a26MX, gpart_a26O3) = Genome.Split.split gpart_a26O2
                      p_a26MW = double g_a26MV
                      (g_a26MV, gpart_a26O2) = Genome.Split.split gpart_a26O1
                      p_a26MU = Functions.belowten' g_a26MT
                      (g_a26MT, gpart_a26O1) = Genome.Split.split gpart_a26O0
                      p_a26MS = double g_a26MR
                      (g_a26MR, gpart_a26O0) = Genome.Split.split gpart_a26NZ
                      p_a26MQ = Functions.belowten' g_a26MP
                      (g_a26MP, gpart_a26NZ) = Genome.Split.split gpart_a26NY
                      p_a26MO = double g_a26MN
                      (g_a26MN, gpart_a26NY) = Genome.Split.split gpart_a26NX
                      p_a26MM = double g_a26ML
                      (g_a26ML, gpart_a26NX) = Genome.Split.split gpart_a26NW
                      p_a26MK = double g_a26MJ
                      (g_a26MJ, gpart_a26NW) = Genome.Split.split gpart_a26NV
                      p_a26MI = Functions.belowten' g_a26MH
                      (g_a26MH, gpart_a26NV) = Genome.Split.split gpart_a26NU
                      p_a26MG = double g_a26MF
                      (g_a26MF, gpart_a26NU) = Genome.Split.split gpart_a26NT
                      p_a26ME
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26MD
                      (g_a26MD, gpart_a26NT) = Genome.Split.split gpart_a26NS
                      p_a26MC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26MB
                      (g_a26MB, gpart_a26NS) = Genome.Split.split gpart_a26NR
                      p_a26MA = Functions.belowten' g_a26Mz
                      (g_a26Mz, gpart_a26NR) = Genome.Split.split gpart_a26NQ
                      p_a26My = double g_a26Mx
                      (g_a26Mx, gpart_a26NQ) = Genome.Split.split gpart_a26NP
                      p_a26Mw = double g_a26Mv
                      (g_a26Mv, gpart_a26NP) = Genome.Split.split gpart_a26NO
                      p_a26Mu = double g_a26Mt
                      (g_a26Mt, gpart_a26NO) = Genome.Split.split gpart_a26NN
                      p_a26Ms = double g_a26Mr
                      (g_a26Mr, gpart_a26NN) = Genome.Split.split gpart_a26NM
                      p_a26Mq = double g_a26Mp
                      (g_a26Mp, gpart_a26NM) = Genome.Split.split gpart_a26NL
                      p_a26Mo = double g_a26Mn
                      (g_a26Mn, gpart_a26NL) = Genome.Split.split genome_a26NJ
                    in  \ x_a26Or
                          -> let
                               c_PTB_a26Ow
                                 = ((Data.Fixed.Vector.toVector x_a26Or) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26Ou
                                 = ((Data.Fixed.Vector.toVector x_a26Or) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26Os
                                 = ((Data.Fixed.Vector.toVector x_a26Or) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26OB
                                 = ((Data.Fixed.Vector.toVector x_a26Or) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26ON
                                 = ((Data.Fixed.Vector.toVector x_a26Or) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26Mw
                                     * ((p_a26MK + ((c_NPTB_a26Os / p_a26My) ** p_a26MA))
                                        / (((1 + p_a26MK) + ((c_NPTB_a26Os / p_a26My) ** p_a26MA))
                                           + (((p_a26Mo / p_a26MC) ** p_a26ME)
                                              + ((c_MiRs_a26Ou / p_a26MG) ** p_a26MI)))))
                                    + (negate (p_a26NA * c_PTB_a26Ow))),
                                   ((p_a26MM
                                     / (1
                                        + (((c_MiRs_a26Ou / p_a26MO) ** p_a26MQ)
                                           + ((c_PTB_a26Ow / p_a26MS) ** p_a26MU))))
                                    + (negate (p_a26NC * c_NPTB_a26Os))),
                                   ((p_a26MW
                                     * (p_a26N6
                                        / ((1 + p_a26N6) + ((c_RESTc_a26OB / p_a26N2) ** p_a26N4))))
                                    + (negate (p_a26NE * c_MiRs_a26Ou))),
                                   ((p_a26N8
                                     * ((p_a26Nm + ((c_PTB_a26Ow / p_a26Na) ** p_a26Nc))
                                        / (((1 + p_a26Nm) + ((c_PTB_a26Ow / p_a26Na) ** p_a26Nc))
                                           + ((c_MiRs_a26Ou / p_a26Ni) ** p_a26Nk))))
                                    + (negate (p_a26NG * c_RESTc_a26OB))),
                                   ((p_a26No
                                     * ((p_a26Ny + ((c_MiRs_a26Ou / p_a26Nq) ** p_a26Ns))
                                        / (((1 + p_a26Ny) + ((c_MiRs_a26Ou / p_a26Nq) ** p_a26Ns))
                                           + ((c_RESTc_a26OB / p_a26Nu) ** p_a26Nw))))
                                    + (negate (p_a26NI * c_EndoNeuroTFs_a26ON)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512518",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512520",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512524",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512526",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512528",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512530",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512532",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512536",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512538",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512544",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512548",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512550",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512552",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512554",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512564",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512566",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512568",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512575",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512576",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512577",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512578",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512579",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512580",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512581",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512582",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512583",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512584",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512586",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512588",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512590",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512592",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512593",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512594",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26NJ
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Pt
                            p_a26NI = double g_a26NH
                            (g_a26NH, gpart_a26Pt) = Genome.Split.split gpart_a26Ps
                            p_a26NG = double g_a26NF
                            (g_a26NF, gpart_a26Ps) = Genome.Split.split gpart_a26Pr
                            p_a26NE = double g_a26ND
                            (g_a26ND, gpart_a26Pr) = Genome.Split.split gpart_a26Pq
                            p_a26NC = double g_a26NB
                            (g_a26NB, gpart_a26Pq) = Genome.Split.split gpart_a26Pp
                            p_a26NA = double g_a26Nz
                            (g_a26Nz, gpart_a26Pp) = Genome.Split.split gpart_a26Po
                            p_a26Ny = double g_a26Nx
                            (g_a26Nx, gpart_a26Po) = Genome.Split.split gpart_a26Pn
                            p_a26Nw = Functions.belowten' g_a26Nv
                            (g_a26Nv, gpart_a26Pn) = Genome.Split.split gpart_a26Pm
                            p_a26Nu = double g_a26Nt
                            (g_a26Nt, gpart_a26Pm) = Genome.Split.split gpart_a26Pl
                            p_a26Ns = Functions.belowten' g_a26Nr
                            (g_a26Nr, gpart_a26Pl) = Genome.Split.split gpart_a26Pk
                            p_a26Nq = double g_a26Np
                            (g_a26Np, gpart_a26Pk) = Genome.Split.split gpart_a26Pj
                            p_a26No = double g_a26Nn
                            (g_a26Nn, gpart_a26Pj) = Genome.Split.split gpart_a26Pi
                            p_a26Nm = double g_a26Nl
                            (g_a26Nl, gpart_a26Pi) = Genome.Split.split gpart_a26Ph
                            p_a26Nk = Functions.belowten' g_a26Nj
                            (g_a26Nj, gpart_a26Ph) = Genome.Split.split gpart_a26Pg
                            p_a26Ni = double g_a26Nh
                            (g_a26Nh, gpart_a26Pg) = Genome.Split.split gpart_a26Pf
                            p_a26Ng
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Nf
                            (g_a26Nf, gpart_a26Pf) = Genome.Split.split gpart_a26Pe
                            p_a26Ne
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Nd
                            (g_a26Nd, gpart_a26Pe) = Genome.Split.split gpart_a26Pd
                            p_a26Nc = Functions.belowten' g_a26Nb
                            (g_a26Nb, gpart_a26Pd) = Genome.Split.split gpart_a26Pc
                            p_a26Na = double g_a26N9
                            (g_a26N9, gpart_a26Pc) = Genome.Split.split gpart_a26Pb
                            p_a26N8 = double g_a26N7
                            (g_a26N7, gpart_a26Pb) = Genome.Split.split gpart_a26Pa
                            p_a26N6 = double g_a26N5
                            (g_a26N5, gpart_a26Pa) = Genome.Split.split gpart_a26P9
                            p_a26N4 = Functions.belowten' g_a26N3
                            (g_a26N3, gpart_a26P9) = Genome.Split.split gpart_a26P8
                            p_a26N2 = double g_a26N1
                            (g_a26N1, gpart_a26P8) = Genome.Split.split gpart_a26P7
                            p_a26N0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26MZ
                            (g_a26MZ, gpart_a26P7) = Genome.Split.split gpart_a26P6
                            p_a26MY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26MX
                            (g_a26MX, gpart_a26P6) = Genome.Split.split gpart_a26P5
                            p_a26MW = double g_a26MV
                            (g_a26MV, gpart_a26P5) = Genome.Split.split gpart_a26P4
                            p_a26MU = Functions.belowten' g_a26MT
                            (g_a26MT, gpart_a26P4) = Genome.Split.split gpart_a26P3
                            p_a26MS = double g_a26MR
                            (g_a26MR, gpart_a26P3) = Genome.Split.split gpart_a26P2
                            p_a26MQ = Functions.belowten' g_a26MP
                            (g_a26MP, gpart_a26P2) = Genome.Split.split gpart_a26P1
                            p_a26MO = double g_a26MN
                            (g_a26MN, gpart_a26P1) = Genome.Split.split gpart_a26P0
                            p_a26MM = double g_a26ML
                            (g_a26ML, gpart_a26P0) = Genome.Split.split gpart_a26OZ
                            p_a26MK = double g_a26MJ
                            (g_a26MJ, gpart_a26OZ) = Genome.Split.split gpart_a26OY
                            p_a26MI = Functions.belowten' g_a26MH
                            (g_a26MH, gpart_a26OY) = Genome.Split.split gpart_a26OX
                            p_a26MG = double g_a26MF
                            (g_a26MF, gpart_a26OX) = Genome.Split.split gpart_a26OW
                            p_a26ME
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26MD
                            (g_a26MD, gpart_a26OW) = Genome.Split.split gpart_a26OV
                            p_a26MC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26MB
                            (g_a26MB, gpart_a26OV) = Genome.Split.split gpart_a26OU
                            p_a26MA = Functions.belowten' g_a26Mz
                            (g_a26Mz, gpart_a26OU) = Genome.Split.split gpart_a26OT
                            p_a26My = double g_a26Mx
                            (g_a26Mx, gpart_a26OT) = Genome.Split.split gpart_a26OS
                            p_a26Mw = double g_a26Mv
                            (g_a26Mv, gpart_a26OS) = Genome.Split.split gpart_a26OR
                            p_a26Mu = double g_a26Mt
                            (g_a26Mt, gpart_a26OR) = Genome.Split.split gpart_a26OQ
                            p_a26Ms = double g_a26Mr
                            (g_a26Mr, gpart_a26OQ) = Genome.Split.split gpart_a26OP
                            p_a26Mq = double g_a26Mp
                            (g_a26Mp, gpart_a26OP) = Genome.Split.split gpart_a26OO
                            p_a26Mo = double g_a26Mn
                            (g_a26Mn, gpart_a26OO) = Genome.Split.split genome_a26NJ
                          in
                            \ desc_a26NK
                              -> case desc_a26NK of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mo)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mq)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ms)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mu)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mw)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26My)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MA)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MC)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26ME)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MG)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MI)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MK)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MM)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MO)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MQ)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MS)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MU)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MW)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MY)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26N0)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26N2)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26N4)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26N6)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26N8)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Na)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Nc)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ne)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ng)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ni)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Nk)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Nm)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26No)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Nq)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ns)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Nu)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Nw)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ny)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26NA)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26NC)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26NE)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26NG)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26NI)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asVf
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVW
                      p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                      (g_asVd, gpart_asVW) = Genome.Split.split gpart_asVV
                      p_asVc = code-0.1.0.0:Genome.FixedList.Functions.double g_asVb
                      (g_asVb, gpart_asVV) = Genome.Split.split gpart_asVU
                      p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                      (g_asV9, gpart_asVU) = Genome.Split.split gpart_asVT
                      p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                      (g_asV7, gpart_asVT) = Genome.Split.split gpart_asVS
                      p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                      (g_asV5, gpart_asVS) = Genome.Split.split gpart_asVR
                      p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                      (g_asV3, gpart_asVR) = Genome.Split.split gpart_asVQ
                      p_asV2 = Functions.belowten' g_asV1
                      (g_asV1, gpart_asVQ) = Genome.Split.split gpart_asVP
                      p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                      (g_asUZ, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asUY = Functions.belowten' g_asUX
                      (g_asUX, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                      (g_asUV, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                      (g_asUT, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                      (g_asUR, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUQ = Functions.belowten' g_asUP
                      (g_asUP, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                      (g_asUN, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUL
                      (g_asUL, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUJ
                      (g_asUJ, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUI = Functions.belowten' g_asUH
                      (g_asUH, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                      (g_asUF, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUE = code-0.1.0.0:Genome.FixedList.Functions.double g_asUD
                      (g_asUD, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUC = code-0.1.0.0:Genome.FixedList.Functions.double g_asUB
                      (g_asUB, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUA = Functions.belowten' g_asUz
                      (g_asUz, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                      (g_asUx, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUv
                      (g_asUv, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUt
                      (g_asUt, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUs = code-0.1.0.0:Genome.FixedList.Functions.double g_asUr
                      (g_asUr, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUq = Functions.belowten' g_asUp
                      (g_asUp, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUo = code-0.1.0.0:Genome.FixedList.Functions.double g_asUn
                      (g_asUn, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asUm = Functions.belowten' g_asUl
                      (g_asUl, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                      (g_asUj, gpart_asVu) = Genome.Split.split gpart_asVt
                      p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                      (g_asUh, gpart_asVt) = Genome.Split.split gpart_asVs
                      p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                      (g_asUf, gpart_asVs) = Genome.Split.split gpart_asVr
                      p_asUe = Functions.belowten' g_asUd
                      (g_asUd, gpart_asVr) = Genome.Split.split gpart_asVq
                      p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                      (g_asUb, gpart_asVq) = Genome.Split.split gpart_asVp
                      p_asUa
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU9
                      (g_asU9, gpart_asVp) = Genome.Split.split gpart_asVo
                      p_asU8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU7
                      (g_asU7, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asU6 = Functions.belowten' g_asU5
                      (g_asU5, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                      (g_asU3, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                      (g_asU1, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asU0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asTZ
                      (g_asTZ, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                      (g_asTX, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                      (g_asTV, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                      (g_asTT, gpart_asVh) = Genome.Split.split genome_asVf
                    in
                      [Reaction
                         (\ x_asVX
                            -> let
                                 c_MiRs_asW0 = ((toVector x_asVX) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asVY = ((toVector x_asVX) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asU2
                                  * ((p_asUg + ((c_NPTB_asVY / p_asU4) ** p_asU6))
                                     / (((1 + p_asUg) + ((c_NPTB_asVY / p_asU4) ** p_asU6))
                                        + ((c_MiRs_asW0 / p_asUc) ** p_asUe)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asW1
                            -> let
                                 c_MiRs_asW2 = ((toVector x_asW1) Data.Vector.Unboxed.! 2)
                                 c_PTB_asW3 = ((toVector x_asW1) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUi
                                  / (1
                                     + (((c_MiRs_asW2 / p_asUk) ** p_asUm)
                                        + ((c_PTB_asW3 / p_asUo) ** p_asUq)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asW4
                            -> let c_RESTc_asW5 = ((toVector x_asW4) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUs
                                  * ((p_asUC + ((p_asTY / p_asUu) ** p_asUw))
                                     / (((1 + p_asUC) + ((p_asTY / p_asUu) ** p_asUw))
                                        + ((c_RESTc_asW5 / p_asUy) ** p_asUA)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asW6
                            -> let
                                 c_MiRs_asW9 = ((toVector x_asW6) Data.Vector.Unboxed.! 2)
                                 c_PTB_asW7 = ((toVector x_asW6) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUE
                                  * ((p_asUS + ((c_PTB_asW7 / p_asUG) ** p_asUI))
                                     / (((1 + p_asUS) + ((c_PTB_asW7 / p_asUG) ** p_asUI))
                                        + (((p_asTU / p_asUK) ** p_asUM)
                                           + ((c_MiRs_asW9 / p_asUO) ** p_asUQ))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asWa
                            -> let
                                 c_RESTc_asWd = ((toVector x_asWa) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asWb = ((toVector x_asWa) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asUU
                                  * ((p_asV4 + ((c_MiRs_asWb / p_asUW) ** p_asUY))
                                     / (((1 + p_asV4) + ((c_MiRs_asWb / p_asUW) ** p_asUY))
                                        + ((c_RESTc_asWd / p_asV0) ** p_asV2)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asWe
                            -> let c_PTB_asWf = ((toVector x_asWe) Data.Vector.Unboxed.! 0)
                               in (p_asV6 * c_PTB_asWf))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWg
                            -> let c_NPTB_asWh = ((toVector x_asWg) Data.Vector.Unboxed.! 1)
                               in (p_asV8 * c_NPTB_asWh))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWi
                            -> let c_MiRs_asWj = ((toVector x_asWi) Data.Vector.Unboxed.! 2)
                               in (p_asVa * c_MiRs_asWj))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWk
                            -> let c_RESTc_asWl = ((toVector x_asWk) Data.Vector.Unboxed.! 3)
                               in (p_asVc * c_RESTc_asWl))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWm
                            -> let
                                 c_EndoNeuroTFs_asWn = ((toVector x_asWm) Data.Vector.Unboxed.! 4)
                               in (p_asVe * c_EndoNeuroTFs_asWn))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120904",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120926",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120928",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120942",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120944",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asVf
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asX8
                            p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                            (g_asVd, gpart_asX8) = Genome.Split.split gpart_asX7
                            p_asVc = code-0.1.0.0:Genome.FixedList.Functions.double g_asVb
                            (g_asVb, gpart_asX7) = Genome.Split.split gpart_asX6
                            p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                            (g_asV9, gpart_asX6) = Genome.Split.split gpart_asX5
                            p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                            (g_asV7, gpart_asX5) = Genome.Split.split gpart_asX4
                            p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                            (g_asV5, gpart_asX4) = Genome.Split.split gpart_asX3
                            p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                            (g_asV3, gpart_asX3) = Genome.Split.split gpart_asX2
                            p_asV2 = Functions.belowten' g_asV1
                            (g_asV1, gpart_asX2) = Genome.Split.split gpart_asX1
                            p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                            (g_asUZ, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asUY = Functions.belowten' g_asUX
                            (g_asUX, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                            (g_asUV, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                            (g_asUT, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                            (g_asUR, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asUQ = Functions.belowten' g_asUP
                            (g_asUP, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                            (g_asUN, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUL
                            (g_asUL, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUJ
                            (g_asUJ, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUI = Functions.belowten' g_asUH
                            (g_asUH, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                            (g_asUF, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUE = code-0.1.0.0:Genome.FixedList.Functions.double g_asUD
                            (g_asUD, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUC = code-0.1.0.0:Genome.FixedList.Functions.double g_asUB
                            (g_asUB, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUA = Functions.belowten' g_asUz
                            (g_asUz, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                            (g_asUx, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUv
                            (g_asUv, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUt
                            (g_asUt, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUs = code-0.1.0.0:Genome.FixedList.Functions.double g_asUr
                            (g_asUr, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUq = Functions.belowten' g_asUp
                            (g_asUp, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUo = code-0.1.0.0:Genome.FixedList.Functions.double g_asUn
                            (g_asUn, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUm = Functions.belowten' g_asUl
                            (g_asUl, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                            (g_asUj, gpart_asWG) = Genome.Split.split gpart_asWF
                            p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                            (g_asUh, gpart_asWF) = Genome.Split.split gpart_asWE
                            p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                            (g_asUf, gpart_asWE) = Genome.Split.split gpart_asWD
                            p_asUe = Functions.belowten' g_asUd
                            (g_asUd, gpart_asWD) = Genome.Split.split gpart_asWC
                            p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                            (g_asUb, gpart_asWC) = Genome.Split.split gpart_asWB
                            p_asUa
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU9
                            (g_asU9, gpart_asWB) = Genome.Split.split gpart_asWA
                            p_asU8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU7
                            (g_asU7, gpart_asWA) = Genome.Split.split gpart_asWz
                            p_asU6 = Functions.belowten' g_asU5
                            (g_asU5, gpart_asWz) = Genome.Split.split gpart_asWy
                            p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                            (g_asU3, gpart_asWy) = Genome.Split.split gpart_asWx
                            p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                            (g_asU1, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asU0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asTZ
                            (g_asTZ, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                            (g_asTX, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                            (g_asTV, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                            (g_asTT, gpart_asWt) = Genome.Split.split genome_asVf
                          in
                            \ desc_asVg
                              -> case desc_asVg of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTU)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTW)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTY)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU0)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU2)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU4)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU6)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU8)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUc)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUe)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUg)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUi)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUk)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUm)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUo)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUq)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUs)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUu)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUw)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUy)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUA)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUC)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUE)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUG)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUI)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUK)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUM)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUO)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUQ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUS)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUU)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUW)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUY)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV8)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVa)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVc)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVe)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZb
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZS
                      p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                      (g_asZ9, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                      (g_asZ7, gpart_asZR) = Genome.Split.split gpart_asZQ
                      p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                      (g_asZ5, gpart_asZQ) = Genome.Split.split gpart_asZP
                      p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                      (g_asZ3, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asZ2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ1
                      (g_asZ1, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                      (g_asYZ, gpart_asZN) = Genome.Split.split gpart_asZM
                      p_asYY = Functions.belowten' g_asYX
                      (g_asYX, gpart_asZM) = Genome.Split.split gpart_asZL
                      p_asYW = code-0.1.0.0:Genome.FixedList.Functions.double g_asYV
                      (g_asYV, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asYU = Functions.belowten' g_asYT
                      (g_asYT, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                      (g_asYR, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                      (g_asYP, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                      (g_asYN, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYM = Functions.belowten' g_asYL
                      (g_asYL, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                      (g_asYJ, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYH
                      (g_asYH, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYF
                      (g_asYF, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYE = Functions.belowten' g_asYD
                      (g_asYD, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                      (g_asYB, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYA = code-0.1.0.0:Genome.FixedList.Functions.double g_asYz
                      (g_asYz, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                      (g_asYx, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYw = Functions.belowten' g_asYv
                      (g_asYv, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                      (g_asYt, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYr
                      (g_asYr, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYp
                      (g_asYp, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYo = code-0.1.0.0:Genome.FixedList.Functions.double g_asYn
                      (g_asYn, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYm = Functions.belowten' g_asYl
                      (g_asYl, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYk = code-0.1.0.0:Genome.FixedList.Functions.double g_asYj
                      (g_asYj, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asYi = Functions.belowten' g_asYh
                      (g_asYh, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asYg = code-0.1.0.0:Genome.FixedList.Functions.double g_asYf
                      (g_asYf, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                      (g_asYd, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                      (g_asYb, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asYa = Functions.belowten' g_asY9
                      (g_asY9, gpart_asZn) = Genome.Split.split gpart_asZm
                      p_asY8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY7
                      (g_asY7, gpart_asZm) = Genome.Split.split gpart_asZl
                      p_asY6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY5
                      (g_asY5, gpart_asZl) = Genome.Split.split gpart_asZk
                      p_asY4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY3
                      (g_asY3, gpart_asZk) = Genome.Split.split gpart_asZj
                      p_asY2 = Functions.belowten' g_asY1
                      (g_asY1, gpart_asZj) = Genome.Split.split gpart_asZi
                      p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                      (g_asXZ, gpart_asZi) = Genome.Split.split gpart_asZh
                      p_asXY = code-0.1.0.0:Genome.FixedList.Functions.double g_asXX
                      (g_asXX, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                      (g_asXV, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asXU = code-0.1.0.0:Genome.FixedList.Functions.double g_asXT
                      (g_asXT, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                      (g_asXR, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                      (g_asXP, gpart_asZd) = Genome.Split.split genome_asZb
                    in
                      [Reaction
                         (\ x_asZT
                            -> let
                                 c_MiRs_asZW = ((toVector x_asZT) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asZU = ((toVector x_asZT) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asXY
                                  * ((p_asYc + ((c_NPTB_asZU / p_asY0) ** p_asY2))
                                     / (((1 + p_asYc) + ((c_NPTB_asZU / p_asY0) ** p_asY2))
                                        + ((c_MiRs_asZW / p_asY8) ** p_asYa)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZX
                            -> let
                                 c_MiRs_asZY = ((toVector x_asZX) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZZ = ((toVector x_asZX) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYe
                                  / (1
                                     + (((c_MiRs_asZY / p_asYg) ** p_asYi)
                                        + ((c_PTB_asZZ / p_asYk) ** p_asYm)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at00
                            -> let c_RESTc_at01 = ((toVector x_at00) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYo
                                  * (p_asYy
                                     / ((1 + p_asYy) + ((c_RESTc_at01 / p_asYu) ** p_asYw)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at02
                            -> let
                                 c_MiRs_at05 = ((toVector x_at02) Data.Vector.Unboxed.! 2)
                                 c_PTB_at03 = ((toVector x_at02) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYA
                                  * ((p_asYO + ((c_PTB_at03 / p_asYC) ** p_asYE))
                                     / (((1 + p_asYO) + ((c_PTB_at03 / p_asYC) ** p_asYE))
                                        + (((p_asXQ / p_asYG) ** p_asYI)
                                           + ((c_MiRs_at05 / p_asYK) ** p_asYM))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at06
                            -> let
                                 c_RESTc_at09 = ((toVector x_at06) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at07 = ((toVector x_at06) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asYQ
                                  * ((p_asZ0 + ((c_MiRs_at07 / p_asYS) ** p_asYU))
                                     / (((1 + p_asZ0) + ((c_MiRs_at07 / p_asYS) ** p_asYU))
                                        + ((c_RESTc_at09 / p_asYW) ** p_asYY)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0a
                            -> let c_PTB_at0b = ((toVector x_at0a) Data.Vector.Unboxed.! 0)
                               in (p_asZ2 * c_PTB_at0b))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0c
                            -> let c_NPTB_at0d = ((toVector x_at0c) Data.Vector.Unboxed.! 1)
                               in (p_asZ4 * c_NPTB_at0d))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0e
                            -> let c_MiRs_at0f = ((toVector x_at0e) Data.Vector.Unboxed.! 2)
                               in (p_asZ6 * c_MiRs_at0f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0g
                            -> let c_RESTc_at0h = ((toVector x_at0g) Data.Vector.Unboxed.! 3)
                               in (p_asZ8 * c_RESTc_at0h))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0i
                            -> let
                                 c_EndoNeuroTFs_at0j = ((toVector x_at0i) Data.Vector.Unboxed.! 4)
                               in (p_asZa * c_EndoNeuroTFs_at0j))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121138",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121140",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121148",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121150",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121170",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121172",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121178",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121180",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121198",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121200",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121206",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZb
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0Z
                            p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                            (g_asZ9, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                            (g_asZ7, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                            (g_asZ5, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                            (g_asZ3, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asZ2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ1
                            (g_asZ1, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                            (g_asYZ, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asYY = Functions.belowten' g_asYX
                            (g_asYX, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asYW = code-0.1.0.0:Genome.FixedList.Functions.double g_asYV
                            (g_asYV, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asYU = Functions.belowten' g_asYT
                            (g_asYT, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                            (g_asYR, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                            (g_asYP, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                            (g_asYN, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asYM = Functions.belowten' g_asYL
                            (g_asYL, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                            (g_asYJ, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYH
                            (g_asYH, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYF
                            (g_asYF, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYE = Functions.belowten' g_asYD
                            (g_asYD, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                            (g_asYB, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYA = code-0.1.0.0:Genome.FixedList.Functions.double g_asYz
                            (g_asYz, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                            (g_asYx, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYw = Functions.belowten' g_asYv
                            (g_asYv, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                            (g_asYt, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYr
                            (g_asYr, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYp
                            (g_asYp, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYo = code-0.1.0.0:Genome.FixedList.Functions.double g_asYn
                            (g_asYn, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYm = Functions.belowten' g_asYl
                            (g_asYl, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYk = code-0.1.0.0:Genome.FixedList.Functions.double g_asYj
                            (g_asYj, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYi = Functions.belowten' g_asYh
                            (g_asYh, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asYg = code-0.1.0.0:Genome.FixedList.Functions.double g_asYf
                            (g_asYf, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                            (g_asYd, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                            (g_asYb, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asYa = Functions.belowten' g_asY9
                            (g_asY9, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asY8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY7
                            (g_asY7, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asY6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY5
                            (g_asY5, gpart_at0s) = Genome.Split.split gpart_at0r
                            p_asY4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY3
                            (g_asY3, gpart_at0r) = Genome.Split.split gpart_at0q
                            p_asY2 = Functions.belowten' g_asY1
                            (g_asY1, gpart_at0q) = Genome.Split.split gpart_at0p
                            p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                            (g_asXZ, gpart_at0p) = Genome.Split.split gpart_at0o
                            p_asXY = code-0.1.0.0:Genome.FixedList.Functions.double g_asXX
                            (g_asXX, gpart_at0o) = Genome.Split.split gpart_at0n
                            p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                            (g_asXV, gpart_at0n) = Genome.Split.split gpart_at0m
                            p_asXU = code-0.1.0.0:Genome.FixedList.Functions.double g_asXT
                            (g_asXT, gpart_at0m) = Genome.Split.split gpart_at0l
                            p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                            (g_asXR, gpart_at0l) = Genome.Split.split gpart_at0k
                            p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                            (g_asXP, gpart_at0k) = Genome.Split.split genome_asZb
                          in
                            \ desc_asZc
                              -> case desc_asZc of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXQ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXS)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXU)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXW)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXY)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY0)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY2)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY4)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY6)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY8)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYa)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYc)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYe)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYg)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYi)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYk)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYm)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYo)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYq)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYs)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYu)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYw)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYy)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYA)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYM)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYO)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYQ)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYS)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYU)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYW)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYY)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ0)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ2)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ4)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ6)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ8)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZa)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at32
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3J
                      p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                      (g_at30, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Y
                      (g_at2Y, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                      (g_at2W, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2V = code-0.1.0.0:Genome.FixedList.Functions.double g_at2U
                      (g_at2U, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                      (g_at2S, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2R = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Q
                      (g_at2Q, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2P = Functions.belowten' g_at2O
                      (g_at2O, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                      (g_at2M, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2L = Functions.belowten' g_at2K
                      (g_at2K, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                      (g_at2I, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                      (g_at2G, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2F = code-0.1.0.0:Genome.FixedList.Functions.double g_at2E
                      (g_at2E, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2D = Functions.belowten' g_at2C
                      (g_at2C, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2B = code-0.1.0.0:Genome.FixedList.Functions.double g_at2A
                      (g_at2A, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2y
                      (g_at2y, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2w
                      (g_at2w, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2v = Functions.belowten' g_at2u
                      (g_at2u, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                      (g_at2s, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                      (g_at2q, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                      (g_at2o, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2n = Functions.belowten' g_at2m
                      (g_at2m, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2l = code-0.1.0.0:Genome.FixedList.Functions.double g_at2k
                      (g_at2k, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2j
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2i
                      (g_at2i, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2h
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2g
                      (g_at2g, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                      (g_at2e, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at2d = Functions.belowten' g_at2c
                      (g_at2c, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                      (g_at2a, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at29 = Functions.belowten' g_at28
                      (g_at28, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                      (g_at26, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at25 = code-0.1.0.0:Genome.FixedList.Functions.double g_at24
                      (g_at24, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                      (g_at22, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at21 = Functions.belowten' g_at20
                      (g_at20, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                      (g_at1Y, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at1X
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1W
                      (g_at1W, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at1V
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1U
                      (g_at1U, gpart_at3b) = Genome.Split.split gpart_at3a
                      p_at1T = Functions.belowten' g_at1S
                      (g_at1S, gpart_at3a) = Genome.Split.split gpart_at39
                      p_at1R = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Q
                      (g_at1Q, gpart_at39) = Genome.Split.split gpart_at38
                      p_at1P = code-0.1.0.0:Genome.FixedList.Functions.double g_at1O
                      (g_at1O, gpart_at38) = Genome.Split.split gpart_at37
                      p_at1N = code-0.1.0.0:Genome.FixedList.Functions.double g_at1M
                      (g_at1M, gpart_at37) = Genome.Split.split gpart_at36
                      p_at1L = code-0.1.0.0:Genome.FixedList.Functions.double g_at1K
                      (g_at1K, gpart_at36) = Genome.Split.split gpart_at35
                      p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                      (g_at1I, gpart_at35) = Genome.Split.split gpart_at34
                      p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                      (g_at1G, gpart_at34) = Genome.Split.split genome_at32
                    in
                      [Reaction
                         (\ x_at3K
                            -> let
                                 c_MiRs_at3N = ((toVector x_at3K) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at3L = ((toVector x_at3K) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at1P
                                  * ((p_at23 + ((c_NPTB_at3L / p_at1R) ** p_at1T))
                                     / (((1 + p_at23) + ((c_NPTB_at3L / p_at1R) ** p_at1T))
                                        + ((c_MiRs_at3N / p_at1Z) ** p_at21)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3O
                            -> let
                                 c_MiRs_at3P = ((toVector x_at3O) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3Q = ((toVector x_at3O) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at25
                                  / (1
                                     + (((c_MiRs_at3P / p_at27) ** p_at29)
                                        + ((c_PTB_at3Q / p_at2b) ** p_at2d)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3R
                            -> let c_RESTc_at3S = ((toVector x_at3R) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2f
                                  * (p_at2p
                                     / ((1 + p_at2p) + ((c_RESTc_at3S / p_at2l) ** p_at2n)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3T
                            -> let
                                 c_MiRs_at3W = ((toVector x_at3T) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3U = ((toVector x_at3T) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2r
                                  * ((p_at2F + ((c_PTB_at3U / p_at2t) ** p_at2v))
                                     / (((1 + p_at2F) + ((c_PTB_at3U / p_at2t) ** p_at2v))
                                        + ((c_MiRs_at3W / p_at2B) ** p_at2D)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3X
                            -> let
                                 c_RESTc_at40 = ((toVector x_at3X) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at3Y = ((toVector x_at3X) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2H
                                  * ((p_at2R + ((c_MiRs_at3Y / p_at2J) ** p_at2L))
                                     / (((1 + p_at2R) + ((c_MiRs_at3Y / p_at2J) ** p_at2L))
                                        + ((c_RESTc_at40 / p_at2N) ** p_at2P)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at41
                            -> let c_PTB_at42 = ((toVector x_at41) Data.Vector.Unboxed.! 0)
                               in (p_at2T * c_PTB_at42))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at43
                            -> let c_NPTB_at44 = ((toVector x_at43) Data.Vector.Unboxed.! 1)
                               in (p_at2V * c_NPTB_at44))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at45
                            -> let c_MiRs_at46 = ((toVector x_at45) Data.Vector.Unboxed.! 2)
                               in (p_at2X * c_MiRs_at46))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at47
                            -> let c_RESTc_at48 = ((toVector x_at47) Data.Vector.Unboxed.! 3)
                               in (p_at2Z * c_RESTc_at48))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at49
                            -> let
                                 c_EndoNeuroTFs_at4a = ((toVector x_at49) Data.Vector.Unboxed.! 4)
                               in (p_at31 * c_EndoNeuroTFs_at4a))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121373",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121379",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121381",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121387",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121389",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121409",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121411",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121425",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121427",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121433",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121449",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121451",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at32
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4Q
                            p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                            (g_at30, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at2Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Y
                            (g_at2Y, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                            (g_at2W, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2V = code-0.1.0.0:Genome.FixedList.Functions.double g_at2U
                            (g_at2U, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                            (g_at2S, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2R = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Q
                            (g_at2Q, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2P = Functions.belowten' g_at2O
                            (g_at2O, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                            (g_at2M, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2L = Functions.belowten' g_at2K
                            (g_at2K, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                            (g_at2I, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                            (g_at2G, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2F = code-0.1.0.0:Genome.FixedList.Functions.double g_at2E
                            (g_at2E, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2D = Functions.belowten' g_at2C
                            (g_at2C, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2B = code-0.1.0.0:Genome.FixedList.Functions.double g_at2A
                            (g_at2A, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2y
                            (g_at2y, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2w
                            (g_at2w, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2v = Functions.belowten' g_at2u
                            (g_at2u, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                            (g_at2s, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                            (g_at2q, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                            (g_at2o, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2n = Functions.belowten' g_at2m
                            (g_at2m, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2l = code-0.1.0.0:Genome.FixedList.Functions.double g_at2k
                            (g_at2k, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2j
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2i
                            (g_at2i, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2h
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2g
                            (g_at2g, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                            (g_at2e, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at2d = Functions.belowten' g_at2c
                            (g_at2c, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                            (g_at2a, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at29 = Functions.belowten' g_at28
                            (g_at28, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                            (g_at26, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at25 = code-0.1.0.0:Genome.FixedList.Functions.double g_at24
                            (g_at24, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                            (g_at22, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at21 = Functions.belowten' g_at20
                            (g_at20, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                            (g_at1Y, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at1X
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1W
                            (g_at1W, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at1V
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1U
                            (g_at1U, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at1T = Functions.belowten' g_at1S
                            (g_at1S, gpart_at4h) = Genome.Split.split gpart_at4g
                            p_at1R = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Q
                            (g_at1Q, gpart_at4g) = Genome.Split.split gpart_at4f
                            p_at1P = code-0.1.0.0:Genome.FixedList.Functions.double g_at1O
                            (g_at1O, gpart_at4f) = Genome.Split.split gpart_at4e
                            p_at1N = code-0.1.0.0:Genome.FixedList.Functions.double g_at1M
                            (g_at1M, gpart_at4e) = Genome.Split.split gpart_at4d
                            p_at1L = code-0.1.0.0:Genome.FixedList.Functions.double g_at1K
                            (g_at1K, gpart_at4d) = Genome.Split.split gpart_at4c
                            p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                            (g_at1I, gpart_at4c) = Genome.Split.split gpart_at4b
                            p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                            (g_at1G, gpart_at4b) = Genome.Split.split genome_at32
                          in
                            \ desc_at33
                              -> case desc_at33 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1H)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1J)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1L)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1N)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1P)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1R)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1T)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1V)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1X)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Z)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at21)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at23)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at25)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at27)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at29)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2b)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2d)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2f)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2h)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2j)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2l)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2n)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2p)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2r)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2t)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2v)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2x)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2z)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2B)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2D)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2F)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2H)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2J)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2L)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2N)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2P)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2R)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2T)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2V)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2X)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Z)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at31)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at6T
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7A
                      p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                      (g_at6R, gpart_at7A) = Genome.Split.split gpart_at7z
                      p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                      (g_at6P, gpart_at7z) = Genome.Split.split gpart_at7y
                      p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                      (g_at6N, gpart_at7y) = Genome.Split.split gpart_at7x
                      p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                      (g_at6L, gpart_at7x) = Genome.Split.split gpart_at7w
                      p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                      (g_at6J, gpart_at7w) = Genome.Split.split gpart_at7v
                      p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                      (g_at6H, gpart_at7v) = Genome.Split.split gpart_at7u
                      p_at6G = Functions.belowten' g_at6F
                      (g_at6F, gpart_at7u) = Genome.Split.split gpart_at7t
                      p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                      (g_at6D, gpart_at7t) = Genome.Split.split gpart_at7s
                      p_at6C = Functions.belowten' g_at6B
                      (g_at6B, gpart_at7s) = Genome.Split.split gpart_at7r
                      p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                      (g_at6z, gpart_at7r) = Genome.Split.split gpart_at7q
                      p_at6y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6x
                      (g_at6x, gpart_at7q) = Genome.Split.split gpart_at7p
                      p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                      (g_at6v, gpart_at7p) = Genome.Split.split gpart_at7o
                      p_at6u = Functions.belowten' g_at6t
                      (g_at6t, gpart_at7o) = Genome.Split.split gpart_at7n
                      p_at6s = code-0.1.0.0:Genome.FixedList.Functions.double g_at6r
                      (g_at6r, gpart_at7n) = Genome.Split.split gpart_at7m
                      p_at6q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6p
                      (g_at6p, gpart_at7m) = Genome.Split.split gpart_at7l
                      p_at6o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6n
                      (g_at6n, gpart_at7l) = Genome.Split.split gpart_at7k
                      p_at6m = Functions.belowten' g_at6l
                      (g_at6l, gpart_at7k) = Genome.Split.split gpart_at7j
                      p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                      (g_at6j, gpart_at7j) = Genome.Split.split gpart_at7i
                      p_at6i = code-0.1.0.0:Genome.FixedList.Functions.double g_at6h
                      (g_at6h, gpart_at7i) = Genome.Split.split gpart_at7h
                      p_at6g = code-0.1.0.0:Genome.FixedList.Functions.double g_at6f
                      (g_at6f, gpart_at7h) = Genome.Split.split gpart_at7g
                      p_at6e = Functions.belowten' g_at6d
                      (g_at6d, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at6c = code-0.1.0.0:Genome.FixedList.Functions.double g_at6b
                      (g_at6b, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at6a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at69
                      (g_at69, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at68
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at67
                      (g_at67, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at66 = code-0.1.0.0:Genome.FixedList.Functions.double g_at65
                      (g_at65, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at64 = Functions.belowten' g_at63
                      (g_at63, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                      (g_at61, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at60 = Functions.belowten' g_at5Z
                      (g_at5Z, gpart_at79) = Genome.Split.split gpart_at78
                      p_at5Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5X
                      (g_at5X, gpart_at78) = Genome.Split.split gpart_at77
                      p_at5W = code-0.1.0.0:Genome.FixedList.Functions.double g_at5V
                      (g_at5V, gpart_at77) = Genome.Split.split gpart_at76
                      p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                      (g_at5T, gpart_at76) = Genome.Split.split gpart_at75
                      p_at5S = Functions.belowten' g_at5R
                      (g_at5R, gpart_at75) = Genome.Split.split gpart_at74
                      p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                      (g_at5P, gpart_at74) = Genome.Split.split gpart_at73
                      p_at5O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5N
                      (g_at5N, gpart_at73) = Genome.Split.split gpart_at72
                      p_at5M
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5L
                      (g_at5L, gpart_at72) = Genome.Split.split gpart_at71
                      p_at5K = Functions.belowten' g_at5J
                      (g_at5J, gpart_at71) = Genome.Split.split gpart_at70
                      p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                      (g_at5H, gpart_at70) = Genome.Split.split gpart_at6Z
                      p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                      (g_at5F, gpart_at6Z) = Genome.Split.split gpart_at6Y
                      p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                      (g_at5D, gpart_at6Y) = Genome.Split.split gpart_at6X
                      p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                      (g_at5B, gpart_at6X) = Genome.Split.split gpart_at6W
                      p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                      (g_at5z, gpart_at6W) = Genome.Split.split gpart_at6V
                      p_at5y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5x
                      (g_at5x, gpart_at6V) = Genome.Split.split genome_at6T
                    in
                      [Reaction
                         (\ x_at7B
                            -> let
                                 c_MiRs_at7E = ((toVector x_at7B) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at7C = ((toVector x_at7B) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at5G
                                  * ((p_at5U + ((c_NPTB_at7C / p_at5I) ** p_at5K))
                                     / (((1 + p_at5U) + ((c_NPTB_at7C / p_at5I) ** p_at5K))
                                        + (((p_at5y / p_at5M) ** p_at5O)
                                           + ((c_MiRs_at7E / p_at5Q) ** p_at5S))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7F
                            -> let
                                 c_MiRs_at7G = ((toVector x_at7F) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7H = ((toVector x_at7F) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5W
                                  / (1
                                     + (((c_MiRs_at7G / p_at5Y) ** p_at60)
                                        + ((c_PTB_at7H / p_at62) ** p_at64)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7I
                            -> let c_RESTc_at7J = ((toVector x_at7I) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at66
                                  * (p_at6g
                                     / ((1 + p_at6g) + ((c_RESTc_at7J / p_at6c) ** p_at6e)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7K
                            -> let
                                 c_MiRs_at7N = ((toVector x_at7K) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7L = ((toVector x_at7K) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6i
                                  * ((p_at6w + ((c_PTB_at7L / p_at6k) ** p_at6m))
                                     / (((1 + p_at6w) + ((c_PTB_at7L / p_at6k) ** p_at6m))
                                        + ((c_MiRs_at7N / p_at6s) ** p_at6u)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7O
                            -> let
                                 c_RESTc_at7R = ((toVector x_at7O) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at7P = ((toVector x_at7O) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6y
                                  * ((p_at6I + ((c_MiRs_at7P / p_at6A) ** p_at6C))
                                     / (((1 + p_at6I) + ((c_MiRs_at7P / p_at6A) ** p_at6C))
                                        + ((c_RESTc_at7R / p_at6E) ** p_at6G)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at7S
                            -> let c_PTB_at7T = ((toVector x_at7S) Data.Vector.Unboxed.! 0)
                               in (p_at6K * c_PTB_at7T))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7U
                            -> let c_NPTB_at7V = ((toVector x_at7U) Data.Vector.Unboxed.! 1)
                               in (p_at6M * c_NPTB_at7V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at7W
                            -> let c_MiRs_at7X = ((toVector x_at7W) Data.Vector.Unboxed.! 2)
                               in (p_at6O * c_MiRs_at7X))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at7Y
                            -> let c_RESTc_at7Z = ((toVector x_at7Y) Data.Vector.Unboxed.! 3)
                               in (p_at6Q * c_RESTc_at7Z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at80
                            -> let
                                 c_EndoNeuroTFs_at81 = ((toVector x_at80) Data.Vector.Unboxed.! 4)
                               in (p_at6S * c_EndoNeuroTFs_at81))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121611",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121612",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121620",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121624",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121626",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121628",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121631",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121632",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121633",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121634",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121635",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121636",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121638",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121640",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121642",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121644",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121648",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121650",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121652",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121654",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121656",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121658",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121660",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121662",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121663",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121664",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121665",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121666",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121668",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121670",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121672",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121674",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121676",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121678",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121684",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6T
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8H
                            p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                            (g_at6R, gpart_at8H) = Genome.Split.split gpart_at8G
                            p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                            (g_at6P, gpart_at8G) = Genome.Split.split gpart_at8F
                            p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                            (g_at6N, gpart_at8F) = Genome.Split.split gpart_at8E
                            p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                            (g_at6L, gpart_at8E) = Genome.Split.split gpart_at8D
                            p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                            (g_at6J, gpart_at8D) = Genome.Split.split gpart_at8C
                            p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                            (g_at6H, gpart_at8C) = Genome.Split.split gpart_at8B
                            p_at6G = Functions.belowten' g_at6F
                            (g_at6F, gpart_at8B) = Genome.Split.split gpart_at8A
                            p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                            (g_at6D, gpart_at8A) = Genome.Split.split gpart_at8z
                            p_at6C = Functions.belowten' g_at6B
                            (g_at6B, gpart_at8z) = Genome.Split.split gpart_at8y
                            p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                            (g_at6z, gpart_at8y) = Genome.Split.split gpart_at8x
                            p_at6y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6x
                            (g_at6x, gpart_at8x) = Genome.Split.split gpart_at8w
                            p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                            (g_at6v, gpart_at8w) = Genome.Split.split gpart_at8v
                            p_at6u = Functions.belowten' g_at6t
                            (g_at6t, gpart_at8v) = Genome.Split.split gpart_at8u
                            p_at6s = code-0.1.0.0:Genome.FixedList.Functions.double g_at6r
                            (g_at6r, gpart_at8u) = Genome.Split.split gpart_at8t
                            p_at6q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6p
                            (g_at6p, gpart_at8t) = Genome.Split.split gpart_at8s
                            p_at6o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6n
                            (g_at6n, gpart_at8s) = Genome.Split.split gpart_at8r
                            p_at6m = Functions.belowten' g_at6l
                            (g_at6l, gpart_at8r) = Genome.Split.split gpart_at8q
                            p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                            (g_at6j, gpart_at8q) = Genome.Split.split gpart_at8p
                            p_at6i = code-0.1.0.0:Genome.FixedList.Functions.double g_at6h
                            (g_at6h, gpart_at8p) = Genome.Split.split gpart_at8o
                            p_at6g = code-0.1.0.0:Genome.FixedList.Functions.double g_at6f
                            (g_at6f, gpart_at8o) = Genome.Split.split gpart_at8n
                            p_at6e = Functions.belowten' g_at6d
                            (g_at6d, gpart_at8n) = Genome.Split.split gpart_at8m
                            p_at6c = code-0.1.0.0:Genome.FixedList.Functions.double g_at6b
                            (g_at6b, gpart_at8m) = Genome.Split.split gpart_at8l
                            p_at6a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at69
                            (g_at69, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at68
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at67
                            (g_at67, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at66 = code-0.1.0.0:Genome.FixedList.Functions.double g_at65
                            (g_at65, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at64 = Functions.belowten' g_at63
                            (g_at63, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                            (g_at61, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at60 = Functions.belowten' g_at5Z
                            (g_at5Z, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at5Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5X
                            (g_at5X, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at5W = code-0.1.0.0:Genome.FixedList.Functions.double g_at5V
                            (g_at5V, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                            (g_at5T, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at5S = Functions.belowten' g_at5R
                            (g_at5R, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                            (g_at5P, gpart_at8b) = Genome.Split.split gpart_at8a
                            p_at5O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5N
                            (g_at5N, gpart_at8a) = Genome.Split.split gpart_at89
                            p_at5M
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5L
                            (g_at5L, gpart_at89) = Genome.Split.split gpart_at88
                            p_at5K = Functions.belowten' g_at5J
                            (g_at5J, gpart_at88) = Genome.Split.split gpart_at87
                            p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                            (g_at5H, gpart_at87) = Genome.Split.split gpart_at86
                            p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                            (g_at5F, gpart_at86) = Genome.Split.split gpart_at85
                            p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                            (g_at5D, gpart_at85) = Genome.Split.split gpart_at84
                            p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                            (g_at5B, gpart_at84) = Genome.Split.split gpart_at83
                            p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                            (g_at5z, gpart_at83) = Genome.Split.split gpart_at82
                            p_at5y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5x
                            (g_at5x, gpart_at82) = Genome.Split.split genome_at6T
                          in
                            \ desc_at6U
                              -> case desc_at6U of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5y)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5A)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5C)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5E)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5G)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5I)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5K)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5M)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5O)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Q)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5S)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5U)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at60)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at62)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at64)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at66)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at68)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6a)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6c)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6e)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6g)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6i)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6k)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6m)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6o)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6q)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6s)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6u)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6w)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6y)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6A)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6C)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6E)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6G)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6I)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6K)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6M)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6O)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Q)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6S)
                                   _ -> Nothing }}
