src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a2c3r
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2c4b
                      p_a2c3q = double g_a2c3p
                      (g_a2c3p, gpart_a2c4b) = Genome.Split.split gpart_a2c4a
                      p_a2c3o = double g_a2c3n
                      (g_a2c3n, gpart_a2c4a) = Genome.Split.split gpart_a2c49
                      p_a2c3m = double g_a2c3l
                      (g_a2c3l, gpart_a2c49) = Genome.Split.split gpart_a2c48
                      p_a2c3k = double g_a2c3j
                      (g_a2c3j, gpart_a2c48) = Genome.Split.split gpart_a2c47
                      p_a2c3i = double g_a2c3h
                      (g_a2c3h, gpart_a2c47) = Genome.Split.split gpart_a2c46
                      p_a2c3g = double g_a2c3f
                      (g_a2c3f, gpart_a2c46) = Genome.Split.split gpart_a2c45
                      p_a2c3e = Functions.belowten' g_a2c3d
                      (g_a2c3d, gpart_a2c45) = Genome.Split.split gpart_a2c44
                      p_a2c3c = double g_a2c3b
                      (g_a2c3b, gpart_a2c44) = Genome.Split.split gpart_a2c43
                      p_a2c3a = Functions.belowten' g_a2c39
                      (g_a2c39, gpart_a2c43) = Genome.Split.split gpart_a2c42
                      p_a2c38 = double g_a2c37
                      (g_a2c37, gpart_a2c42) = Genome.Split.split gpart_a2c41
                      p_a2c36 = double g_a2c35
                      (g_a2c35, gpart_a2c41) = Genome.Split.split gpart_a2c40
                      p_a2c34 = double g_a2c33
                      (g_a2c33, gpart_a2c40) = Genome.Split.split gpart_a2c3Z
                      p_a2c32 = Functions.belowten' g_a2c31
                      (g_a2c31, gpart_a2c3Z) = Genome.Split.split gpart_a2c3Y
                      p_a2c30 = double g_a2c2Z
                      (g_a2c2Z, gpart_a2c3Y) = Genome.Split.split gpart_a2c3X
                      p_a2c2Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2X
                      (g_a2c2X, gpart_a2c3X) = Genome.Split.split gpart_a2c3W
                      p_a2c2W
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2V
                      (g_a2c2V, gpart_a2c3W) = Genome.Split.split gpart_a2c3V
                      p_a2c2U = Functions.belowten' g_a2c2T
                      (g_a2c2T, gpart_a2c3V) = Genome.Split.split gpart_a2c3U
                      p_a2c2S = double g_a2c2R
                      (g_a2c2R, gpart_a2c3U) = Genome.Split.split gpart_a2c3T
                      p_a2c2Q = double g_a2c2P
                      (g_a2c2P, gpart_a2c3T) = Genome.Split.split gpart_a2c3S
                      p_a2c2O = double g_a2c2N
                      (g_a2c2N, gpart_a2c3S) = Genome.Split.split gpart_a2c3R
                      p_a2c2M = Functions.belowten' g_a2c2L
                      (g_a2c2L, gpart_a2c3R) = Genome.Split.split gpart_a2c3Q
                      p_a2c2K = double g_a2c2J
                      (g_a2c2J, gpart_a2c3Q) = Genome.Split.split gpart_a2c3P
                      p_a2c2I
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2H
                      (g_a2c2H, gpart_a2c3P) = Genome.Split.split gpart_a2c3O
                      p_a2c2G
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2F
                      (g_a2c2F, gpart_a2c3O) = Genome.Split.split gpart_a2c3N
                      p_a2c2E = double g_a2c2D
                      (g_a2c2D, gpart_a2c3N) = Genome.Split.split gpart_a2c3M
                      p_a2c2C = double g_a2c2B
                      (g_a2c2B, gpart_a2c3M) = Genome.Split.split gpart_a2c3L
                      p_a2c2A = Functions.belowten' g_a2c2z
                      (g_a2c2z, gpart_a2c3L) = Genome.Split.split gpart_a2c3K
                      p_a2c2y = double g_a2c2x
                      (g_a2c2x, gpart_a2c3K) = Genome.Split.split gpart_a2c3J
                      p_a2c2w = Functions.belowten' g_a2c2v
                      (g_a2c2v, gpart_a2c3J) = Genome.Split.split gpart_a2c3I
                      p_a2c2u = double g_a2c2t
                      (g_a2c2t, gpart_a2c3I) = Genome.Split.split gpart_a2c3H
                      p_a2c2s = Functions.belowten' g_a2c2r
                      (g_a2c2r, gpart_a2c3H) = Genome.Split.split gpart_a2c3G
                      p_a2c2q = double g_a2c2p
                      (g_a2c2p, gpart_a2c3G) = Genome.Split.split gpart_a2c3F
                      p_a2c2o = double g_a2c2n
                      (g_a2c2n, gpart_a2c3F) = Genome.Split.split gpart_a2c3E
                      p_a2c2m = double g_a2c2l
                      (g_a2c2l, gpart_a2c3E) = Genome.Split.split gpart_a2c3D
                      p_a2c2k = Functions.belowten' g_a2c2j
                      (g_a2c2j, gpart_a2c3D) = Genome.Split.split gpart_a2c3C
                      p_a2c2i = double g_a2c2h
                      (g_a2c2h, gpart_a2c3C) = Genome.Split.split gpart_a2c3B
                      p_a2c2g
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2f
                      (g_a2c2f, gpart_a2c3B) = Genome.Split.split gpart_a2c3A
                      p_a2c2e
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2d
                      (g_a2c2d, gpart_a2c3A) = Genome.Split.split gpart_a2c3z
                      p_a2c2c = Functions.belowten' g_a2c2b
                      (g_a2c2b, gpart_a2c3z) = Genome.Split.split gpart_a2c3y
                      p_a2c2a = double g_a2c29
                      (g_a2c29, gpart_a2c3y) = Genome.Split.split gpart_a2c3x
                      p_a2c28 = double g_a2c27
                      (g_a2c27, gpart_a2c3x) = Genome.Split.split gpart_a2c3w
                      p_a2c26 = double g_a2c25
                      (g_a2c25, gpart_a2c3w) = Genome.Split.split gpart_a2c3v
                      p_a2c24 = double g_a2c23
                      (g_a2c23, gpart_a2c3v) = Genome.Split.split gpart_a2c3u
                      p_a2c22 = double g_a2c21
                      (g_a2c21, gpart_a2c3u) = Genome.Split.split gpart_a2c3t
                      p_a2c20 = double g_a2c1Z
                      (g_a2c1Z, gpart_a2c3t) = Genome.Split.split genome_a2c3r
                    in  \ x_a2c4c
                          -> let
                               c_PTB_a2c4h
                                 = ((Data.Fixed.Vector.toVector x_a2c4c) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2c4f
                                 = ((Data.Fixed.Vector.toVector x_a2c4c) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2c4d
                                 = ((Data.Fixed.Vector.toVector x_a2c4c) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2c4i
                                 = ((Data.Fixed.Vector.toVector x_a2c4c) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2c4A
                                 = ((Data.Fixed.Vector.toVector x_a2c4c) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2c28
                                     * ((p_a2c2m + ((c_NPTB_a2c4d / p_a2c2a) ** p_a2c2c))
                                        / (((1 + p_a2c2m) + ((c_NPTB_a2c4d / p_a2c2a) ** p_a2c2c))
                                           + ((c_MiRs_a2c4f / p_a2c2i) ** p_a2c2k))))
                                    + (negate (p_a2c3i * c_PTB_a2c4h))),
                                   ((p_a2c2o
                                     * ((p_a2c2C + ((c_RESTc_a2c4i / p_a2c2q) ** p_a2c2s))
                                        / (((1 + p_a2c2C) + ((c_RESTc_a2c4i / p_a2c2q) ** p_a2c2s))
                                           + (((c_MiRs_a2c4f / p_a2c2u) ** p_a2c2w)
                                              + ((c_PTB_a2c4h / p_a2c2y) ** p_a2c2A)))))
                                    + (negate (p_a2c3k * c_NPTB_a2c4d))),
                                   ((p_a2c2E
                                     * ((p_a2c2O + ((p_a2c24 / p_a2c2G) ** p_a2c2I))
                                        / (((1 + p_a2c2O) + ((p_a2c24 / p_a2c2G) ** p_a2c2I))
                                           + ((c_RESTc_a2c4i / p_a2c2K) ** p_a2c2M))))
                                    + (negate (p_a2c3m * c_MiRs_a2c4f))),
                                   ((p_a2c2Q
                                     * ((p_a2c34 + ((c_PTB_a2c4h / p_a2c2S) ** p_a2c2U))
                                        / (((1 + p_a2c34) + ((c_PTB_a2c4h / p_a2c2S) ** p_a2c2U))
                                           + (((p_a2c20 / p_a2c2W) ** p_a2c2Y)
                                              + ((c_MiRs_a2c4f / p_a2c30) ** p_a2c32)))))
                                    + (negate (p_a2c3o * c_RESTc_a2c4i))),
                                   ((p_a2c36
                                     * ((p_a2c3g + ((c_MiRs_a2c4f / p_a2c38) ** p_a2c3a))
                                        / (((1 + p_a2c3g) + ((c_MiRs_a2c4f / p_a2c38) ** p_a2c3a))
                                           + ((c_RESTc_a2c4i / p_a2c3c) ** p_a2c3e))))
                                    + (negate (p_a2c3q * c_EndoNeuroTFs_a2c4A)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532700",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532702",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532704",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532705",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532706",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532707",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532708",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532710",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532712",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532714",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532716",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532718",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532720",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532722",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532724",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532726",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532728",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532730",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532742",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532744",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532758",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532760",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532764",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532766",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532768",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532770",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532771",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532772",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532773",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532774",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532777",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532778",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532779",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532780",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532781",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532782",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532783",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532784",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532785",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532786",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532787",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532788",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2c3r
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2c5j
                            p_a2c3q = double g_a2c3p
                            (g_a2c3p, gpart_a2c5j) = Genome.Split.split gpart_a2c5i
                            p_a2c3o = double g_a2c3n
                            (g_a2c3n, gpart_a2c5i) = Genome.Split.split gpart_a2c5h
                            p_a2c3m = double g_a2c3l
                            (g_a2c3l, gpart_a2c5h) = Genome.Split.split gpart_a2c5g
                            p_a2c3k = double g_a2c3j
                            (g_a2c3j, gpart_a2c5g) = Genome.Split.split gpart_a2c5f
                            p_a2c3i = double g_a2c3h
                            (g_a2c3h, gpart_a2c5f) = Genome.Split.split gpart_a2c5e
                            p_a2c3g = double g_a2c3f
                            (g_a2c3f, gpart_a2c5e) = Genome.Split.split gpart_a2c5d
                            p_a2c3e = Functions.belowten' g_a2c3d
                            (g_a2c3d, gpart_a2c5d) = Genome.Split.split gpart_a2c5c
                            p_a2c3c = double g_a2c3b
                            (g_a2c3b, gpart_a2c5c) = Genome.Split.split gpart_a2c5b
                            p_a2c3a = Functions.belowten' g_a2c39
                            (g_a2c39, gpart_a2c5b) = Genome.Split.split gpart_a2c5a
                            p_a2c38 = double g_a2c37
                            (g_a2c37, gpart_a2c5a) = Genome.Split.split gpart_a2c59
                            p_a2c36 = double g_a2c35
                            (g_a2c35, gpart_a2c59) = Genome.Split.split gpart_a2c58
                            p_a2c34 = double g_a2c33
                            (g_a2c33, gpart_a2c58) = Genome.Split.split gpart_a2c57
                            p_a2c32 = Functions.belowten' g_a2c31
                            (g_a2c31, gpart_a2c57) = Genome.Split.split gpart_a2c56
                            p_a2c30 = double g_a2c2Z
                            (g_a2c2Z, gpart_a2c56) = Genome.Split.split gpart_a2c55
                            p_a2c2Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2X
                            (g_a2c2X, gpart_a2c55) = Genome.Split.split gpart_a2c54
                            p_a2c2W
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2V
                            (g_a2c2V, gpart_a2c54) = Genome.Split.split gpart_a2c53
                            p_a2c2U = Functions.belowten' g_a2c2T
                            (g_a2c2T, gpart_a2c53) = Genome.Split.split gpart_a2c52
                            p_a2c2S = double g_a2c2R
                            (g_a2c2R, gpart_a2c52) = Genome.Split.split gpart_a2c51
                            p_a2c2Q = double g_a2c2P
                            (g_a2c2P, gpart_a2c51) = Genome.Split.split gpart_a2c50
                            p_a2c2O = double g_a2c2N
                            (g_a2c2N, gpart_a2c50) = Genome.Split.split gpart_a2c4Z
                            p_a2c2M = Functions.belowten' g_a2c2L
                            (g_a2c2L, gpart_a2c4Z) = Genome.Split.split gpart_a2c4Y
                            p_a2c2K = double g_a2c2J
                            (g_a2c2J, gpart_a2c4Y) = Genome.Split.split gpart_a2c4X
                            p_a2c2I
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2H
                            (g_a2c2H, gpart_a2c4X) = Genome.Split.split gpart_a2c4W
                            p_a2c2G
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2F
                            (g_a2c2F, gpart_a2c4W) = Genome.Split.split gpart_a2c4V
                            p_a2c2E = double g_a2c2D
                            (g_a2c2D, gpart_a2c4V) = Genome.Split.split gpart_a2c4U
                            p_a2c2C = double g_a2c2B
                            (g_a2c2B, gpart_a2c4U) = Genome.Split.split gpart_a2c4T
                            p_a2c2A = Functions.belowten' g_a2c2z
                            (g_a2c2z, gpart_a2c4T) = Genome.Split.split gpart_a2c4S
                            p_a2c2y = double g_a2c2x
                            (g_a2c2x, gpart_a2c4S) = Genome.Split.split gpart_a2c4R
                            p_a2c2w = Functions.belowten' g_a2c2v
                            (g_a2c2v, gpart_a2c4R) = Genome.Split.split gpart_a2c4Q
                            p_a2c2u = double g_a2c2t
                            (g_a2c2t, gpart_a2c4Q) = Genome.Split.split gpart_a2c4P
                            p_a2c2s = Functions.belowten' g_a2c2r
                            (g_a2c2r, gpart_a2c4P) = Genome.Split.split gpart_a2c4O
                            p_a2c2q = double g_a2c2p
                            (g_a2c2p, gpart_a2c4O) = Genome.Split.split gpart_a2c4N
                            p_a2c2o = double g_a2c2n
                            (g_a2c2n, gpart_a2c4N) = Genome.Split.split gpart_a2c4M
                            p_a2c2m = double g_a2c2l
                            (g_a2c2l, gpart_a2c4M) = Genome.Split.split gpart_a2c4L
                            p_a2c2k = Functions.belowten' g_a2c2j
                            (g_a2c2j, gpart_a2c4L) = Genome.Split.split gpart_a2c4K
                            p_a2c2i = double g_a2c2h
                            (g_a2c2h, gpart_a2c4K) = Genome.Split.split gpart_a2c4J
                            p_a2c2g
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2f
                            (g_a2c2f, gpart_a2c4J) = Genome.Split.split gpart_a2c4I
                            p_a2c2e
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c2d
                            (g_a2c2d, gpart_a2c4I) = Genome.Split.split gpart_a2c4H
                            p_a2c2c = Functions.belowten' g_a2c2b
                            (g_a2c2b, gpart_a2c4H) = Genome.Split.split gpart_a2c4G
                            p_a2c2a = double g_a2c29
                            (g_a2c29, gpart_a2c4G) = Genome.Split.split gpart_a2c4F
                            p_a2c28 = double g_a2c27
                            (g_a2c27, gpart_a2c4F) = Genome.Split.split gpart_a2c4E
                            p_a2c26 = double g_a2c25
                            (g_a2c25, gpart_a2c4E) = Genome.Split.split gpart_a2c4D
                            p_a2c24 = double g_a2c23
                            (g_a2c23, gpart_a2c4D) = Genome.Split.split gpart_a2c4C
                            p_a2c22 = double g_a2c21
                            (g_a2c21, gpart_a2c4C) = Genome.Split.split gpart_a2c4B
                            p_a2c20 = double g_a2c1Z
                            (g_a2c1Z, gpart_a2c4B) = Genome.Split.split genome_a2c3r
                          in
                            \ desc_a2c3s
                              -> case desc_a2c3s of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c20)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c22)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c24)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c26)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c28)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2a)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2c)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2e)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2g)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2i)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2k)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2m)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2o)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2q)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2s)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2u)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2w)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2y)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2A)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2C)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2E)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2G)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2I)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2K)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2M)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2O)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2Q)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2S)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2U)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2W)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c2Y)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c30)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c32)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c34)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c36)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c38)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c3a)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c3c)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c3e)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c3g)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c3i)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c3k)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c3m)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c3o)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c3q)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a2c7V
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2c8F
                      p_a2c7U = double g_a2c7T
                      (g_a2c7T, gpart_a2c8F) = Genome.Split.split gpart_a2c8E
                      p_a2c7S = double g_a2c7R
                      (g_a2c7R, gpart_a2c8E) = Genome.Split.split gpart_a2c8D
                      p_a2c7Q = double g_a2c7P
                      (g_a2c7P, gpart_a2c8D) = Genome.Split.split gpart_a2c8C
                      p_a2c7O = double g_a2c7N
                      (g_a2c7N, gpart_a2c8C) = Genome.Split.split gpart_a2c8B
                      p_a2c7M = double g_a2c7L
                      (g_a2c7L, gpart_a2c8B) = Genome.Split.split gpart_a2c8A
                      p_a2c7K = double g_a2c7J
                      (g_a2c7J, gpart_a2c8A) = Genome.Split.split gpart_a2c8z
                      p_a2c7I = Functions.belowten' g_a2c7H
                      (g_a2c7H, gpart_a2c8z) = Genome.Split.split gpart_a2c8y
                      p_a2c7G = double g_a2c7F
                      (g_a2c7F, gpart_a2c8y) = Genome.Split.split gpart_a2c8x
                      p_a2c7E = Functions.belowten' g_a2c7D
                      (g_a2c7D, gpart_a2c8x) = Genome.Split.split gpart_a2c8w
                      p_a2c7C = double g_a2c7B
                      (g_a2c7B, gpart_a2c8w) = Genome.Split.split gpart_a2c8v
                      p_a2c7A = double g_a2c7z
                      (g_a2c7z, gpart_a2c8v) = Genome.Split.split gpart_a2c8u
                      p_a2c7y = double g_a2c7x
                      (g_a2c7x, gpart_a2c8u) = Genome.Split.split gpart_a2c8t
                      p_a2c7w = Functions.belowten' g_a2c7v
                      (g_a2c7v, gpart_a2c8t) = Genome.Split.split gpart_a2c8s
                      p_a2c7u = double g_a2c7t
                      (g_a2c7t, gpart_a2c8s) = Genome.Split.split gpart_a2c8r
                      p_a2c7s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c7r
                      (g_a2c7r, gpart_a2c8r) = Genome.Split.split gpart_a2c8q
                      p_a2c7q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c7p
                      (g_a2c7p, gpart_a2c8q) = Genome.Split.split gpart_a2c8p
                      p_a2c7o = Functions.belowten' g_a2c7n
                      (g_a2c7n, gpart_a2c8p) = Genome.Split.split gpart_a2c8o
                      p_a2c7m = double g_a2c7l
                      (g_a2c7l, gpart_a2c8o) = Genome.Split.split gpart_a2c8n
                      p_a2c7k = double g_a2c7j
                      (g_a2c7j, gpart_a2c8n) = Genome.Split.split gpart_a2c8m
                      p_a2c7i = double g_a2c7h
                      (g_a2c7h, gpart_a2c8m) = Genome.Split.split gpart_a2c8l
                      p_a2c7g = Functions.belowten' g_a2c7f
                      (g_a2c7f, gpart_a2c8l) = Genome.Split.split gpart_a2c8k
                      p_a2c7e = double g_a2c7d
                      (g_a2c7d, gpart_a2c8k) = Genome.Split.split gpart_a2c8j
                      p_a2c7c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c7b
                      (g_a2c7b, gpart_a2c8j) = Genome.Split.split gpart_a2c8i
                      p_a2c7a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c79
                      (g_a2c79, gpart_a2c8i) = Genome.Split.split gpart_a2c8h
                      p_a2c78 = double g_a2c77
                      (g_a2c77, gpart_a2c8h) = Genome.Split.split gpart_a2c8g
                      p_a2c76 = double g_a2c75
                      (g_a2c75, gpart_a2c8g) = Genome.Split.split gpart_a2c8f
                      p_a2c74 = Functions.belowten' g_a2c73
                      (g_a2c73, gpart_a2c8f) = Genome.Split.split gpart_a2c8e
                      p_a2c72 = double g_a2c71
                      (g_a2c71, gpart_a2c8e) = Genome.Split.split gpart_a2c8d
                      p_a2c70 = Functions.belowten' g_a2c6Z
                      (g_a2c6Z, gpart_a2c8d) = Genome.Split.split gpart_a2c8c
                      p_a2c6Y = double g_a2c6X
                      (g_a2c6X, gpart_a2c8c) = Genome.Split.split gpart_a2c8b
                      p_a2c6W = Functions.belowten' g_a2c6V
                      (g_a2c6V, gpart_a2c8b) = Genome.Split.split gpart_a2c8a
                      p_a2c6U = double g_a2c6T
                      (g_a2c6T, gpart_a2c8a) = Genome.Split.split gpart_a2c89
                      p_a2c6S = double g_a2c6R
                      (g_a2c6R, gpart_a2c89) = Genome.Split.split gpart_a2c88
                      p_a2c6Q = double g_a2c6P
                      (g_a2c6P, gpart_a2c88) = Genome.Split.split gpart_a2c87
                      p_a2c6O = Functions.belowten' g_a2c6N
                      (g_a2c6N, gpart_a2c87) = Genome.Split.split gpart_a2c86
                      p_a2c6M = double g_a2c6L
                      (g_a2c6L, gpart_a2c86) = Genome.Split.split gpart_a2c85
                      p_a2c6K
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c6J
                      (g_a2c6J, gpart_a2c85) = Genome.Split.split gpart_a2c84
                      p_a2c6I
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c6H
                      (g_a2c6H, gpart_a2c84) = Genome.Split.split gpart_a2c83
                      p_a2c6G = Functions.belowten' g_a2c6F
                      (g_a2c6F, gpart_a2c83) = Genome.Split.split gpart_a2c82
                      p_a2c6E = double g_a2c6D
                      (g_a2c6D, gpart_a2c82) = Genome.Split.split gpart_a2c81
                      p_a2c6C = double g_a2c6B
                      (g_a2c6B, gpart_a2c81) = Genome.Split.split gpart_a2c80
                      p_a2c6A = double g_a2c6z
                      (g_a2c6z, gpart_a2c80) = Genome.Split.split gpart_a2c7Z
                      p_a2c6y = double g_a2c6x
                      (g_a2c6x, gpart_a2c7Z) = Genome.Split.split gpart_a2c7Y
                      p_a2c6w = double g_a2c6v
                      (g_a2c6v, gpart_a2c7Y) = Genome.Split.split gpart_a2c7X
                      p_a2c6u = double g_a2c6t
                      (g_a2c6t, gpart_a2c7X) = Genome.Split.split genome_a2c7V
                    in  \ x_a2c8G
                          -> let
                               c_PTB_a2c8L
                                 = ((Data.Fixed.Vector.toVector x_a2c8G) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2c8J
                                 = ((Data.Fixed.Vector.toVector x_a2c8G) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2c8H
                                 = ((Data.Fixed.Vector.toVector x_a2c8G) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2c8M
                                 = ((Data.Fixed.Vector.toVector x_a2c8G) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2c94
                                 = ((Data.Fixed.Vector.toVector x_a2c8G) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2c6C
                                     * ((p_a2c6Q + ((c_NPTB_a2c8H / p_a2c6E) ** p_a2c6G))
                                        / (((1 + p_a2c6Q) + ((c_NPTB_a2c8H / p_a2c6E) ** p_a2c6G))
                                           + ((c_MiRs_a2c8J / p_a2c6M) ** p_a2c6O))))
                                    + (negate (p_a2c7M * c_PTB_a2c8L))),
                                   ((p_a2c6S
                                     * ((p_a2c76 + ((c_RESTc_a2c8M / p_a2c6U) ** p_a2c6W))
                                        / (((1 + p_a2c76) + ((c_RESTc_a2c8M / p_a2c6U) ** p_a2c6W))
                                           + (((c_MiRs_a2c8J / p_a2c6Y) ** p_a2c70)
                                              + ((c_PTB_a2c8L / p_a2c72) ** p_a2c74)))))
                                    + (negate (p_a2c7O * c_NPTB_a2c8H))),
                                   ((p_a2c78
                                     * (p_a2c7i
                                        / ((1 + p_a2c7i) + ((c_RESTc_a2c8M / p_a2c7e) ** p_a2c7g))))
                                    + (negate (p_a2c7Q * c_MiRs_a2c8J))),
                                   ((p_a2c7k
                                     * ((p_a2c7y + ((c_PTB_a2c8L / p_a2c7m) ** p_a2c7o))
                                        / (((1 + p_a2c7y) + ((c_PTB_a2c8L / p_a2c7m) ** p_a2c7o))
                                           + (((p_a2c6u / p_a2c7q) ** p_a2c7s)
                                              + ((c_MiRs_a2c8J / p_a2c7u) ** p_a2c7w)))))
                                    + (negate (p_a2c7S * c_RESTc_a2c8M))),
                                   ((p_a2c7A
                                     * ((p_a2c7K + ((c_MiRs_a2c8J / p_a2c7C) ** p_a2c7E))
                                        / (((1 + p_a2c7K) + ((c_MiRs_a2c8J / p_a2c7C) ** p_a2c7E))
                                           + ((c_RESTc_a2c8M / p_a2c7G) ** p_a2c7I))))
                                    + (negate (p_a2c7U * c_EndoNeuroTFs_a2c94)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532992",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532994",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679532998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679532999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533020",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533022",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533028",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533036",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533038",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533040",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533042",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533046",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533048",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533051",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533052",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533053",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533054",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533055",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533056",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533057",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533058",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533059",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533060",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533061",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533062",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533063",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533064",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2c7V
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2c9N
                            p_a2c7U = double g_a2c7T
                            (g_a2c7T, gpart_a2c9N) = Genome.Split.split gpart_a2c9M
                            p_a2c7S = double g_a2c7R
                            (g_a2c7R, gpart_a2c9M) = Genome.Split.split gpart_a2c9L
                            p_a2c7Q = double g_a2c7P
                            (g_a2c7P, gpart_a2c9L) = Genome.Split.split gpart_a2c9K
                            p_a2c7O = double g_a2c7N
                            (g_a2c7N, gpart_a2c9K) = Genome.Split.split gpart_a2c9J
                            p_a2c7M = double g_a2c7L
                            (g_a2c7L, gpart_a2c9J) = Genome.Split.split gpart_a2c9I
                            p_a2c7K = double g_a2c7J
                            (g_a2c7J, gpart_a2c9I) = Genome.Split.split gpart_a2c9H
                            p_a2c7I = Functions.belowten' g_a2c7H
                            (g_a2c7H, gpart_a2c9H) = Genome.Split.split gpart_a2c9G
                            p_a2c7G = double g_a2c7F
                            (g_a2c7F, gpart_a2c9G) = Genome.Split.split gpart_a2c9F
                            p_a2c7E = Functions.belowten' g_a2c7D
                            (g_a2c7D, gpart_a2c9F) = Genome.Split.split gpart_a2c9E
                            p_a2c7C = double g_a2c7B
                            (g_a2c7B, gpart_a2c9E) = Genome.Split.split gpart_a2c9D
                            p_a2c7A = double g_a2c7z
                            (g_a2c7z, gpart_a2c9D) = Genome.Split.split gpart_a2c9C
                            p_a2c7y = double g_a2c7x
                            (g_a2c7x, gpart_a2c9C) = Genome.Split.split gpart_a2c9B
                            p_a2c7w = Functions.belowten' g_a2c7v
                            (g_a2c7v, gpart_a2c9B) = Genome.Split.split gpart_a2c9A
                            p_a2c7u = double g_a2c7t
                            (g_a2c7t, gpart_a2c9A) = Genome.Split.split gpart_a2c9z
                            p_a2c7s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c7r
                            (g_a2c7r, gpart_a2c9z) = Genome.Split.split gpart_a2c9y
                            p_a2c7q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c7p
                            (g_a2c7p, gpart_a2c9y) = Genome.Split.split gpart_a2c9x
                            p_a2c7o = Functions.belowten' g_a2c7n
                            (g_a2c7n, gpart_a2c9x) = Genome.Split.split gpart_a2c9w
                            p_a2c7m = double g_a2c7l
                            (g_a2c7l, gpart_a2c9w) = Genome.Split.split gpart_a2c9v
                            p_a2c7k = double g_a2c7j
                            (g_a2c7j, gpart_a2c9v) = Genome.Split.split gpart_a2c9u
                            p_a2c7i = double g_a2c7h
                            (g_a2c7h, gpart_a2c9u) = Genome.Split.split gpart_a2c9t
                            p_a2c7g = Functions.belowten' g_a2c7f
                            (g_a2c7f, gpart_a2c9t) = Genome.Split.split gpart_a2c9s
                            p_a2c7e = double g_a2c7d
                            (g_a2c7d, gpart_a2c9s) = Genome.Split.split gpart_a2c9r
                            p_a2c7c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c7b
                            (g_a2c7b, gpart_a2c9r) = Genome.Split.split gpart_a2c9q
                            p_a2c7a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c79
                            (g_a2c79, gpart_a2c9q) = Genome.Split.split gpart_a2c9p
                            p_a2c78 = double g_a2c77
                            (g_a2c77, gpart_a2c9p) = Genome.Split.split gpart_a2c9o
                            p_a2c76 = double g_a2c75
                            (g_a2c75, gpart_a2c9o) = Genome.Split.split gpart_a2c9n
                            p_a2c74 = Functions.belowten' g_a2c73
                            (g_a2c73, gpart_a2c9n) = Genome.Split.split gpart_a2c9m
                            p_a2c72 = double g_a2c71
                            (g_a2c71, gpart_a2c9m) = Genome.Split.split gpart_a2c9l
                            p_a2c70 = Functions.belowten' g_a2c6Z
                            (g_a2c6Z, gpart_a2c9l) = Genome.Split.split gpart_a2c9k
                            p_a2c6Y = double g_a2c6X
                            (g_a2c6X, gpart_a2c9k) = Genome.Split.split gpart_a2c9j
                            p_a2c6W = Functions.belowten' g_a2c6V
                            (g_a2c6V, gpart_a2c9j) = Genome.Split.split gpart_a2c9i
                            p_a2c6U = double g_a2c6T
                            (g_a2c6T, gpart_a2c9i) = Genome.Split.split gpart_a2c9h
                            p_a2c6S = double g_a2c6R
                            (g_a2c6R, gpart_a2c9h) = Genome.Split.split gpart_a2c9g
                            p_a2c6Q = double g_a2c6P
                            (g_a2c6P, gpart_a2c9g) = Genome.Split.split gpart_a2c9f
                            p_a2c6O = Functions.belowten' g_a2c6N
                            (g_a2c6N, gpart_a2c9f) = Genome.Split.split gpart_a2c9e
                            p_a2c6M = double g_a2c6L
                            (g_a2c6L, gpart_a2c9e) = Genome.Split.split gpart_a2c9d
                            p_a2c6K
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c6J
                            (g_a2c6J, gpart_a2c9d) = Genome.Split.split gpart_a2c9c
                            p_a2c6I
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2c6H
                            (g_a2c6H, gpart_a2c9c) = Genome.Split.split gpart_a2c9b
                            p_a2c6G = Functions.belowten' g_a2c6F
                            (g_a2c6F, gpart_a2c9b) = Genome.Split.split gpart_a2c9a
                            p_a2c6E = double g_a2c6D
                            (g_a2c6D, gpart_a2c9a) = Genome.Split.split gpart_a2c99
                            p_a2c6C = double g_a2c6B
                            (g_a2c6B, gpart_a2c99) = Genome.Split.split gpart_a2c98
                            p_a2c6A = double g_a2c6z
                            (g_a2c6z, gpart_a2c98) = Genome.Split.split gpart_a2c97
                            p_a2c6y = double g_a2c6x
                            (g_a2c6x, gpart_a2c97) = Genome.Split.split gpart_a2c96
                            p_a2c6w = double g_a2c6v
                            (g_a2c6v, gpart_a2c96) = Genome.Split.split gpart_a2c95
                            p_a2c6u = double g_a2c6t
                            (g_a2c6t, gpart_a2c95) = Genome.Split.split genome_a2c7V
                          in
                            \ desc_a2c7W
                              -> case desc_a2c7W of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6u)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6w)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6y)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6A)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6C)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6E)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6G)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6I)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6K)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6M)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6O)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6Q)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6S)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6U)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c6Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c70)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c72)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c74)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c76)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c78)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7a)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7c)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7e)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7g)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7i)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7k)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7m)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7o)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7q)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7s)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7u)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7w)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7y)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7A)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7C)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7E)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7G)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7I)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7K)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7M)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7O)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7Q)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7S)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2c7U)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a2ccp
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2cd9
                      p_a2cco = double g_a2ccn
                      (g_a2ccn, gpart_a2cd9) = Genome.Split.split gpart_a2cd8
                      p_a2ccm = double g_a2ccl
                      (g_a2ccl, gpart_a2cd8) = Genome.Split.split gpart_a2cd7
                      p_a2cck = double g_a2ccj
                      (g_a2ccj, gpart_a2cd7) = Genome.Split.split gpart_a2cd6
                      p_a2cci = double g_a2cch
                      (g_a2cch, gpart_a2cd6) = Genome.Split.split gpart_a2cd5
                      p_a2ccg = double g_a2ccf
                      (g_a2ccf, gpart_a2cd5) = Genome.Split.split gpart_a2cd4
                      p_a2cce = double g_a2ccd
                      (g_a2ccd, gpart_a2cd4) = Genome.Split.split gpart_a2cd3
                      p_a2ccc = Functions.belowten' g_a2ccb
                      (g_a2ccb, gpart_a2cd3) = Genome.Split.split gpart_a2cd2
                      p_a2cca = double g_a2cc9
                      (g_a2cc9, gpart_a2cd2) = Genome.Split.split gpart_a2cd1
                      p_a2cc8 = Functions.belowten' g_a2cc7
                      (g_a2cc7, gpart_a2cd1) = Genome.Split.split gpart_a2cd0
                      p_a2cc6 = double g_a2cc5
                      (g_a2cc5, gpart_a2cd0) = Genome.Split.split gpart_a2ccZ
                      p_a2cc4 = double g_a2cc3
                      (g_a2cc3, gpart_a2ccZ) = Genome.Split.split gpart_a2ccY
                      p_a2cc2 = double g_a2cc1
                      (g_a2cc1, gpart_a2ccY) = Genome.Split.split gpart_a2ccX
                      p_a2cc0 = Functions.belowten' g_a2cbZ
                      (g_a2cbZ, gpart_a2ccX) = Genome.Split.split gpart_a2ccW
                      p_a2cbY = double g_a2cbX
                      (g_a2cbX, gpart_a2ccW) = Genome.Split.split gpart_a2ccV
                      p_a2cbW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbV
                      (g_a2cbV, gpart_a2ccV) = Genome.Split.split gpart_a2ccU
                      p_a2cbU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbT
                      (g_a2cbT, gpart_a2ccU) = Genome.Split.split gpart_a2ccT
                      p_a2cbS = Functions.belowten' g_a2cbR
                      (g_a2cbR, gpart_a2ccT) = Genome.Split.split gpart_a2ccS
                      p_a2cbQ = double g_a2cbP
                      (g_a2cbP, gpart_a2ccS) = Genome.Split.split gpart_a2ccR
                      p_a2cbO = double g_a2cbN
                      (g_a2cbN, gpart_a2ccR) = Genome.Split.split gpart_a2ccQ
                      p_a2cbM = double g_a2cbL
                      (g_a2cbL, gpart_a2ccQ) = Genome.Split.split gpart_a2ccP
                      p_a2cbK = Functions.belowten' g_a2cbJ
                      (g_a2cbJ, gpart_a2ccP) = Genome.Split.split gpart_a2ccO
                      p_a2cbI = double g_a2cbH
                      (g_a2cbH, gpart_a2ccO) = Genome.Split.split gpart_a2ccN
                      p_a2cbG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbF
                      (g_a2cbF, gpart_a2ccN) = Genome.Split.split gpart_a2ccM
                      p_a2cbE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbD
                      (g_a2cbD, gpart_a2ccM) = Genome.Split.split gpart_a2ccL
                      p_a2cbC = double g_a2cbB
                      (g_a2cbB, gpart_a2ccL) = Genome.Split.split gpart_a2ccK
                      p_a2cbA = double g_a2cbz
                      (g_a2cbz, gpart_a2ccK) = Genome.Split.split gpart_a2ccJ
                      p_a2cby = Functions.belowten' g_a2cbx
                      (g_a2cbx, gpart_a2ccJ) = Genome.Split.split gpart_a2ccI
                      p_a2cbw = double g_a2cbv
                      (g_a2cbv, gpart_a2ccI) = Genome.Split.split gpart_a2ccH
                      p_a2cbu = Functions.belowten' g_a2cbt
                      (g_a2cbt, gpart_a2ccH) = Genome.Split.split gpart_a2ccG
                      p_a2cbs = double g_a2cbr
                      (g_a2cbr, gpart_a2ccG) = Genome.Split.split gpart_a2ccF
                      p_a2cbq = Functions.belowten' g_a2cbp
                      (g_a2cbp, gpart_a2ccF) = Genome.Split.split gpart_a2ccE
                      p_a2cbo = double g_a2cbn
                      (g_a2cbn, gpart_a2ccE) = Genome.Split.split gpart_a2ccD
                      p_a2cbm = double g_a2cbl
                      (g_a2cbl, gpart_a2ccD) = Genome.Split.split gpart_a2ccC
                      p_a2cbk = double g_a2cbj
                      (g_a2cbj, gpart_a2ccC) = Genome.Split.split gpart_a2ccB
                      p_a2cbi = Functions.belowten' g_a2cbh
                      (g_a2cbh, gpart_a2ccB) = Genome.Split.split gpart_a2ccA
                      p_a2cbg = double g_a2cbf
                      (g_a2cbf, gpart_a2ccA) = Genome.Split.split gpart_a2ccz
                      p_a2cbe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbd
                      (g_a2cbd, gpart_a2ccz) = Genome.Split.split gpart_a2ccy
                      p_a2cbc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbb
                      (g_a2cbb, gpart_a2ccy) = Genome.Split.split gpart_a2ccx
                      p_a2cba = Functions.belowten' g_a2cb9
                      (g_a2cb9, gpart_a2ccx) = Genome.Split.split gpart_a2ccw
                      p_a2cb8 = double g_a2cb7
                      (g_a2cb7, gpart_a2ccw) = Genome.Split.split gpart_a2ccv
                      p_a2cb6 = double g_a2cb5
                      (g_a2cb5, gpart_a2ccv) = Genome.Split.split gpart_a2ccu
                      p_a2cb4 = double g_a2cb3
                      (g_a2cb3, gpart_a2ccu) = Genome.Split.split gpart_a2cct
                      p_a2cb2 = double g_a2cb1
                      (g_a2cb1, gpart_a2cct) = Genome.Split.split gpart_a2ccs
                      p_a2cb0 = double g_a2caZ
                      (g_a2caZ, gpart_a2ccs) = Genome.Split.split gpart_a2ccr
                      p_a2caY = double g_a2caX
                      (g_a2caX, gpart_a2ccr) = Genome.Split.split genome_a2ccp
                    in  \ x_a2cda
                          -> let
                               c_PTB_a2cdf
                                 = ((Data.Fixed.Vector.toVector x_a2cda) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2cdd
                                 = ((Data.Fixed.Vector.toVector x_a2cda) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2cdb
                                 = ((Data.Fixed.Vector.toVector x_a2cda) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2cdg
                                 = ((Data.Fixed.Vector.toVector x_a2cda) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2cdy
                                 = ((Data.Fixed.Vector.toVector x_a2cda) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2cb6
                                     * ((p_a2cbk + ((c_NPTB_a2cdb / p_a2cb8) ** p_a2cba))
                                        / (((1 + p_a2cbk) + ((c_NPTB_a2cdb / p_a2cb8) ** p_a2cba))
                                           + ((c_MiRs_a2cdd / p_a2cbg) ** p_a2cbi))))
                                    + (negate (p_a2ccg * c_PTB_a2cdf))),
                                   ((p_a2cbm
                                     * ((p_a2cbA + ((c_RESTc_a2cdg / p_a2cbo) ** p_a2cbq))
                                        / (((1 + p_a2cbA) + ((c_RESTc_a2cdg / p_a2cbo) ** p_a2cbq))
                                           + (((c_MiRs_a2cdd / p_a2cbs) ** p_a2cbu)
                                              + ((c_PTB_a2cdf / p_a2cbw) ** p_a2cby)))))
                                    + (negate (p_a2cci * c_NPTB_a2cdb))),
                                   ((p_a2cbC
                                     * (p_a2cbM
                                        / ((1 + p_a2cbM) + ((c_RESTc_a2cdg / p_a2cbI) ** p_a2cbK))))
                                    + (negate (p_a2cck * c_MiRs_a2cdd))),
                                   ((p_a2cbO
                                     * ((p_a2cc2 + ((c_PTB_a2cdf / p_a2cbQ) ** p_a2cbS))
                                        / (((1 + p_a2cc2) + ((c_PTB_a2cdf / p_a2cbQ) ** p_a2cbS))
                                           + ((c_MiRs_a2cdd / p_a2cbY) ** p_a2cc0))))
                                    + (negate (p_a2ccm * c_RESTc_a2cdg))),
                                   ((p_a2cc4
                                     * ((p_a2cce + ((c_MiRs_a2cdd / p_a2cc6) ** p_a2cc8))
                                        / (((1 + p_a2cce) + ((c_MiRs_a2cdd / p_a2cc6) ** p_a2cc8))
                                           + ((c_RESTc_a2cdg / p_a2cca) ** p_a2ccc))))
                                    + (negate (p_a2cco * c_EndoNeuroTFs_a2cdy)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533257",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533258",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533259",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533260",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533261",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533262",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533263",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533264",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533265",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533266",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533268",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533270",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533272",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533274",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533276",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533284",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533286",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533298",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533300",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533302",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533314",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533316",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533317",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533318",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533320",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533322",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533324",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533325",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533326",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533327",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533328",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533329",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533330",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533331",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533332",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533333",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533334",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533336",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533338",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533340",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2ccp
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ceh
                            p_a2cco = double g_a2ccn
                            (g_a2ccn, gpart_a2ceh) = Genome.Split.split gpart_a2ceg
                            p_a2ccm = double g_a2ccl
                            (g_a2ccl, gpart_a2ceg) = Genome.Split.split gpart_a2cef
                            p_a2cck = double g_a2ccj
                            (g_a2ccj, gpart_a2cef) = Genome.Split.split gpart_a2cee
                            p_a2cci = double g_a2cch
                            (g_a2cch, gpart_a2cee) = Genome.Split.split gpart_a2ced
                            p_a2ccg = double g_a2ccf
                            (g_a2ccf, gpart_a2ced) = Genome.Split.split gpart_a2cec
                            p_a2cce = double g_a2ccd
                            (g_a2ccd, gpart_a2cec) = Genome.Split.split gpart_a2ceb
                            p_a2ccc = Functions.belowten' g_a2ccb
                            (g_a2ccb, gpart_a2ceb) = Genome.Split.split gpart_a2cea
                            p_a2cca = double g_a2cc9
                            (g_a2cc9, gpart_a2cea) = Genome.Split.split gpart_a2ce9
                            p_a2cc8 = Functions.belowten' g_a2cc7
                            (g_a2cc7, gpart_a2ce9) = Genome.Split.split gpart_a2ce8
                            p_a2cc6 = double g_a2cc5
                            (g_a2cc5, gpart_a2ce8) = Genome.Split.split gpart_a2ce7
                            p_a2cc4 = double g_a2cc3
                            (g_a2cc3, gpart_a2ce7) = Genome.Split.split gpart_a2ce6
                            p_a2cc2 = double g_a2cc1
                            (g_a2cc1, gpart_a2ce6) = Genome.Split.split gpart_a2ce5
                            p_a2cc0 = Functions.belowten' g_a2cbZ
                            (g_a2cbZ, gpart_a2ce5) = Genome.Split.split gpart_a2ce4
                            p_a2cbY = double g_a2cbX
                            (g_a2cbX, gpart_a2ce4) = Genome.Split.split gpart_a2ce3
                            p_a2cbW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbV
                            (g_a2cbV, gpart_a2ce3) = Genome.Split.split gpart_a2ce2
                            p_a2cbU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbT
                            (g_a2cbT, gpart_a2ce2) = Genome.Split.split gpart_a2ce1
                            p_a2cbS = Functions.belowten' g_a2cbR
                            (g_a2cbR, gpart_a2ce1) = Genome.Split.split gpart_a2ce0
                            p_a2cbQ = double g_a2cbP
                            (g_a2cbP, gpart_a2ce0) = Genome.Split.split gpart_a2cdZ
                            p_a2cbO = double g_a2cbN
                            (g_a2cbN, gpart_a2cdZ) = Genome.Split.split gpart_a2cdY
                            p_a2cbM = double g_a2cbL
                            (g_a2cbL, gpart_a2cdY) = Genome.Split.split gpart_a2cdX
                            p_a2cbK = Functions.belowten' g_a2cbJ
                            (g_a2cbJ, gpart_a2cdX) = Genome.Split.split gpart_a2cdW
                            p_a2cbI = double g_a2cbH
                            (g_a2cbH, gpart_a2cdW) = Genome.Split.split gpart_a2cdV
                            p_a2cbG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbF
                            (g_a2cbF, gpart_a2cdV) = Genome.Split.split gpart_a2cdU
                            p_a2cbE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbD
                            (g_a2cbD, gpart_a2cdU) = Genome.Split.split gpart_a2cdT
                            p_a2cbC = double g_a2cbB
                            (g_a2cbB, gpart_a2cdT) = Genome.Split.split gpart_a2cdS
                            p_a2cbA = double g_a2cbz
                            (g_a2cbz, gpart_a2cdS) = Genome.Split.split gpart_a2cdR
                            p_a2cby = Functions.belowten' g_a2cbx
                            (g_a2cbx, gpart_a2cdR) = Genome.Split.split gpart_a2cdQ
                            p_a2cbw = double g_a2cbv
                            (g_a2cbv, gpart_a2cdQ) = Genome.Split.split gpart_a2cdP
                            p_a2cbu = Functions.belowten' g_a2cbt
                            (g_a2cbt, gpart_a2cdP) = Genome.Split.split gpart_a2cdO
                            p_a2cbs = double g_a2cbr
                            (g_a2cbr, gpart_a2cdO) = Genome.Split.split gpart_a2cdN
                            p_a2cbq = Functions.belowten' g_a2cbp
                            (g_a2cbp, gpart_a2cdN) = Genome.Split.split gpart_a2cdM
                            p_a2cbo = double g_a2cbn
                            (g_a2cbn, gpart_a2cdM) = Genome.Split.split gpart_a2cdL
                            p_a2cbm = double g_a2cbl
                            (g_a2cbl, gpart_a2cdL) = Genome.Split.split gpart_a2cdK
                            p_a2cbk = double g_a2cbj
                            (g_a2cbj, gpart_a2cdK) = Genome.Split.split gpart_a2cdJ
                            p_a2cbi = Functions.belowten' g_a2cbh
                            (g_a2cbh, gpart_a2cdJ) = Genome.Split.split gpart_a2cdI
                            p_a2cbg = double g_a2cbf
                            (g_a2cbf, gpart_a2cdI) = Genome.Split.split gpart_a2cdH
                            p_a2cbe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbd
                            (g_a2cbd, gpart_a2cdH) = Genome.Split.split gpart_a2cdG
                            p_a2cbc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cbb
                            (g_a2cbb, gpart_a2cdG) = Genome.Split.split gpart_a2cdF
                            p_a2cba = Functions.belowten' g_a2cb9
                            (g_a2cb9, gpart_a2cdF) = Genome.Split.split gpart_a2cdE
                            p_a2cb8 = double g_a2cb7
                            (g_a2cb7, gpart_a2cdE) = Genome.Split.split gpart_a2cdD
                            p_a2cb6 = double g_a2cb5
                            (g_a2cb5, gpart_a2cdD) = Genome.Split.split gpart_a2cdC
                            p_a2cb4 = double g_a2cb3
                            (g_a2cb3, gpart_a2cdC) = Genome.Split.split gpart_a2cdB
                            p_a2cb2 = double g_a2cb1
                            (g_a2cb1, gpart_a2cdB) = Genome.Split.split gpart_a2cdA
                            p_a2cb0 = double g_a2caZ
                            (g_a2caZ, gpart_a2cdA) = Genome.Split.split gpart_a2cdz
                            p_a2caY = double g_a2caX
                            (g_a2caX, gpart_a2cdz) = Genome.Split.split genome_a2ccp
                          in
                            \ desc_a2ccq
                              -> case desc_a2ccq of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2caY)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cb0)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cb2)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cb4)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cb6)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cb8)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cba)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbc)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbe)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbg)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbi)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbk)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbm)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbo)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbq)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbs)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbu)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbw)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cby)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbA)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbC)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbE)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbG)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbI)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbK)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbM)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbO)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbQ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbS)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbU)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbW)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cbY)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cc0)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cc2)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cc4)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cc6)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cc8)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cca)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ccc)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cce)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ccg)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cci)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cck)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ccm)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cco)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a2cgT
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2chD
                      p_a2cgS = double g_a2cgR
                      (g_a2cgR, gpart_a2chD) = Genome.Split.split gpart_a2chC
                      p_a2cgQ = double g_a2cgP
                      (g_a2cgP, gpart_a2chC) = Genome.Split.split gpart_a2chB
                      p_a2cgO = double g_a2cgN
                      (g_a2cgN, gpart_a2chB) = Genome.Split.split gpart_a2chA
                      p_a2cgM = double g_a2cgL
                      (g_a2cgL, gpart_a2chA) = Genome.Split.split gpart_a2chz
                      p_a2cgK = double g_a2cgJ
                      (g_a2cgJ, gpart_a2chz) = Genome.Split.split gpart_a2chy
                      p_a2cgI = double g_a2cgH
                      (g_a2cgH, gpart_a2chy) = Genome.Split.split gpart_a2chx
                      p_a2cgG = Functions.belowten' g_a2cgF
                      (g_a2cgF, gpart_a2chx) = Genome.Split.split gpart_a2chw
                      p_a2cgE = double g_a2cgD
                      (g_a2cgD, gpart_a2chw) = Genome.Split.split gpart_a2chv
                      p_a2cgC = Functions.belowten' g_a2cgB
                      (g_a2cgB, gpart_a2chv) = Genome.Split.split gpart_a2chu
                      p_a2cgA = double g_a2cgz
                      (g_a2cgz, gpart_a2chu) = Genome.Split.split gpart_a2cht
                      p_a2cgy = double g_a2cgx
                      (g_a2cgx, gpart_a2cht) = Genome.Split.split gpart_a2chs
                      p_a2cgw = double g_a2cgv
                      (g_a2cgv, gpart_a2chs) = Genome.Split.split gpart_a2chr
                      p_a2cgu = Functions.belowten' g_a2cgt
                      (g_a2cgt, gpart_a2chr) = Genome.Split.split gpart_a2chq
                      p_a2cgs = double g_a2cgr
                      (g_a2cgr, gpart_a2chq) = Genome.Split.split gpart_a2chp
                      p_a2cgq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cgp
                      (g_a2cgp, gpart_a2chp) = Genome.Split.split gpart_a2cho
                      p_a2cgo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cgn
                      (g_a2cgn, gpart_a2cho) = Genome.Split.split gpart_a2chn
                      p_a2cgm = Functions.belowten' g_a2cgl
                      (g_a2cgl, gpart_a2chn) = Genome.Split.split gpart_a2chm
                      p_a2cgk = double g_a2cgj
                      (g_a2cgj, gpart_a2chm) = Genome.Split.split gpart_a2chl
                      p_a2cgi = double g_a2cgh
                      (g_a2cgh, gpart_a2chl) = Genome.Split.split gpart_a2chk
                      p_a2cgg = double g_a2cgf
                      (g_a2cgf, gpart_a2chk) = Genome.Split.split gpart_a2chj
                      p_a2cge = Functions.belowten' g_a2cgd
                      (g_a2cgd, gpart_a2chj) = Genome.Split.split gpart_a2chi
                      p_a2cgc = double g_a2cgb
                      (g_a2cgb, gpart_a2chi) = Genome.Split.split gpart_a2chh
                      p_a2cga
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cg9
                      (g_a2cg9, gpart_a2chh) = Genome.Split.split gpart_a2chg
                      p_a2cg8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cg7
                      (g_a2cg7, gpart_a2chg) = Genome.Split.split gpart_a2chf
                      p_a2cg6 = double g_a2cg5
                      (g_a2cg5, gpart_a2chf) = Genome.Split.split gpart_a2che
                      p_a2cg4 = double g_a2cg3
                      (g_a2cg3, gpart_a2che) = Genome.Split.split gpart_a2chd
                      p_a2cg2 = Functions.belowten' g_a2cg1
                      (g_a2cg1, gpart_a2chd) = Genome.Split.split gpart_a2chc
                      p_a2cg0 = double g_a2cfZ
                      (g_a2cfZ, gpart_a2chc) = Genome.Split.split gpart_a2chb
                      p_a2cfY = Functions.belowten' g_a2cfX
                      (g_a2cfX, gpart_a2chb) = Genome.Split.split gpart_a2cha
                      p_a2cfW = double g_a2cfV
                      (g_a2cfV, gpart_a2cha) = Genome.Split.split gpart_a2ch9
                      p_a2cfU = Functions.belowten' g_a2cfT
                      (g_a2cfT, gpart_a2ch9) = Genome.Split.split gpart_a2ch8
                      p_a2cfS = double g_a2cfR
                      (g_a2cfR, gpart_a2ch8) = Genome.Split.split gpart_a2ch7
                      p_a2cfQ = double g_a2cfP
                      (g_a2cfP, gpart_a2ch7) = Genome.Split.split gpart_a2ch6
                      p_a2cfO = double g_a2cfN
                      (g_a2cfN, gpart_a2ch6) = Genome.Split.split gpart_a2ch5
                      p_a2cfM = Functions.belowten' g_a2cfL
                      (g_a2cfL, gpart_a2ch5) = Genome.Split.split gpart_a2ch4
                      p_a2cfK = double g_a2cfJ
                      (g_a2cfJ, gpart_a2ch4) = Genome.Split.split gpart_a2ch3
                      p_a2cfI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cfH
                      (g_a2cfH, gpart_a2ch3) = Genome.Split.split gpart_a2ch2
                      p_a2cfG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cfF
                      (g_a2cfF, gpart_a2ch2) = Genome.Split.split gpart_a2ch1
                      p_a2cfE = Functions.belowten' g_a2cfD
                      (g_a2cfD, gpart_a2ch1) = Genome.Split.split gpart_a2ch0
                      p_a2cfC = double g_a2cfB
                      (g_a2cfB, gpart_a2ch0) = Genome.Split.split gpart_a2cgZ
                      p_a2cfA = double g_a2cfz
                      (g_a2cfz, gpart_a2cgZ) = Genome.Split.split gpart_a2cgY
                      p_a2cfy = double g_a2cfx
                      (g_a2cfx, gpart_a2cgY) = Genome.Split.split gpart_a2cgX
                      p_a2cfw = double g_a2cfv
                      (g_a2cfv, gpart_a2cgX) = Genome.Split.split gpart_a2cgW
                      p_a2cfu = double g_a2cft
                      (g_a2cft, gpart_a2cgW) = Genome.Split.split gpart_a2cgV
                      p_a2cfs = double g_a2cfr
                      (g_a2cfr, gpart_a2cgV) = Genome.Split.split genome_a2cgT
                    in  \ x_a2chE
                          -> let
                               c_PTB_a2chJ
                                 = ((Data.Fixed.Vector.toVector x_a2chE) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2chH
                                 = ((Data.Fixed.Vector.toVector x_a2chE) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2chF
                                 = ((Data.Fixed.Vector.toVector x_a2chE) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2chK
                                 = ((Data.Fixed.Vector.toVector x_a2chE) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2ci2
                                 = ((Data.Fixed.Vector.toVector x_a2chE) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2cfA
                                     * ((p_a2cfO + ((c_NPTB_a2chF / p_a2cfC) ** p_a2cfE))
                                        / (((1 + p_a2cfO) + ((c_NPTB_a2chF / p_a2cfC) ** p_a2cfE))
                                           + (((p_a2cfs / p_a2cfG) ** p_a2cfI)
                                              + ((c_MiRs_a2chH / p_a2cfK) ** p_a2cfM)))))
                                    + (negate (p_a2cgK * c_PTB_a2chJ))),
                                   ((p_a2cfQ
                                     * ((p_a2cg4 + ((c_RESTc_a2chK / p_a2cfS) ** p_a2cfU))
                                        / (((1 + p_a2cg4) + ((c_RESTc_a2chK / p_a2cfS) ** p_a2cfU))
                                           + (((c_MiRs_a2chH / p_a2cfW) ** p_a2cfY)
                                              + ((c_PTB_a2chJ / p_a2cg0) ** p_a2cg2)))))
                                    + (negate (p_a2cgM * c_NPTB_a2chF))),
                                   ((p_a2cg6
                                     * (p_a2cgg
                                        / ((1 + p_a2cgg) + ((c_RESTc_a2chK / p_a2cgc) ** p_a2cge))))
                                    + (negate (p_a2cgO * c_MiRs_a2chH))),
                                   ((p_a2cgi
                                     * ((p_a2cgw + ((c_PTB_a2chJ / p_a2cgk) ** p_a2cgm))
                                        / (((1 + p_a2cgw) + ((c_PTB_a2chJ / p_a2cgk) ** p_a2cgm))
                                           + ((c_MiRs_a2chH / p_a2cgs) ** p_a2cgu))))
                                    + (negate (p_a2cgQ * c_RESTc_a2chK))),
                                   ((p_a2cgy
                                     * ((p_a2cgI + ((c_MiRs_a2chH / p_a2cgA) ** p_a2cgC))
                                        / (((1 + p_a2cgI) + ((c_MiRs_a2chH / p_a2cgA) ** p_a2cgC))
                                           + ((c_RESTc_a2chK / p_a2cgE) ** p_a2cgG))))
                                    + (negate (p_a2cgS * c_EndoNeuroTFs_a2ci2)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533536",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533538",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533544",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533548",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533550",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533552",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533554",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533568",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533575",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533576",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533577",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533578",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533579",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533580",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533581",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533582",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533583",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533584",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533586",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533588",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533590",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533592",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533593",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533594",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533595",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533596",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533597",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533598",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533599",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533600",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533601",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533602",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533603",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533604",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533605",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533606",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533607",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533608",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533609",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533610",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533611",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533612",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533620",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679533621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679533622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2cgT
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ciL
                            p_a2cgS = double g_a2cgR
                            (g_a2cgR, gpart_a2ciL) = Genome.Split.split gpart_a2ciK
                            p_a2cgQ = double g_a2cgP
                            (g_a2cgP, gpart_a2ciK) = Genome.Split.split gpart_a2ciJ
                            p_a2cgO = double g_a2cgN
                            (g_a2cgN, gpart_a2ciJ) = Genome.Split.split gpart_a2ciI
                            p_a2cgM = double g_a2cgL
                            (g_a2cgL, gpart_a2ciI) = Genome.Split.split gpart_a2ciH
                            p_a2cgK = double g_a2cgJ
                            (g_a2cgJ, gpart_a2ciH) = Genome.Split.split gpart_a2ciG
                            p_a2cgI = double g_a2cgH
                            (g_a2cgH, gpart_a2ciG) = Genome.Split.split gpart_a2ciF
                            p_a2cgG = Functions.belowten' g_a2cgF
                            (g_a2cgF, gpart_a2ciF) = Genome.Split.split gpart_a2ciE
                            p_a2cgE = double g_a2cgD
                            (g_a2cgD, gpart_a2ciE) = Genome.Split.split gpart_a2ciD
                            p_a2cgC = Functions.belowten' g_a2cgB
                            (g_a2cgB, gpart_a2ciD) = Genome.Split.split gpart_a2ciC
                            p_a2cgA = double g_a2cgz
                            (g_a2cgz, gpart_a2ciC) = Genome.Split.split gpart_a2ciB
                            p_a2cgy = double g_a2cgx
                            (g_a2cgx, gpart_a2ciB) = Genome.Split.split gpart_a2ciA
                            p_a2cgw = double g_a2cgv
                            (g_a2cgv, gpart_a2ciA) = Genome.Split.split gpart_a2ciz
                            p_a2cgu = Functions.belowten' g_a2cgt
                            (g_a2cgt, gpart_a2ciz) = Genome.Split.split gpart_a2ciy
                            p_a2cgs = double g_a2cgr
                            (g_a2cgr, gpart_a2ciy) = Genome.Split.split gpart_a2cix
                            p_a2cgq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cgp
                            (g_a2cgp, gpart_a2cix) = Genome.Split.split gpart_a2ciw
                            p_a2cgo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cgn
                            (g_a2cgn, gpart_a2ciw) = Genome.Split.split gpart_a2civ
                            p_a2cgm = Functions.belowten' g_a2cgl
                            (g_a2cgl, gpart_a2civ) = Genome.Split.split gpart_a2ciu
                            p_a2cgk = double g_a2cgj
                            (g_a2cgj, gpart_a2ciu) = Genome.Split.split gpart_a2cit
                            p_a2cgi = double g_a2cgh
                            (g_a2cgh, gpart_a2cit) = Genome.Split.split gpart_a2cis
                            p_a2cgg = double g_a2cgf
                            (g_a2cgf, gpart_a2cis) = Genome.Split.split gpart_a2cir
                            p_a2cge = Functions.belowten' g_a2cgd
                            (g_a2cgd, gpart_a2cir) = Genome.Split.split gpart_a2ciq
                            p_a2cgc = double g_a2cgb
                            (g_a2cgb, gpart_a2ciq) = Genome.Split.split gpart_a2cip
                            p_a2cga
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cg9
                            (g_a2cg9, gpart_a2cip) = Genome.Split.split gpart_a2cio
                            p_a2cg8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cg7
                            (g_a2cg7, gpart_a2cio) = Genome.Split.split gpart_a2cin
                            p_a2cg6 = double g_a2cg5
                            (g_a2cg5, gpart_a2cin) = Genome.Split.split gpart_a2cim
                            p_a2cg4 = double g_a2cg3
                            (g_a2cg3, gpart_a2cim) = Genome.Split.split gpart_a2cil
                            p_a2cg2 = Functions.belowten' g_a2cg1
                            (g_a2cg1, gpart_a2cil) = Genome.Split.split gpart_a2cik
                            p_a2cg0 = double g_a2cfZ
                            (g_a2cfZ, gpart_a2cik) = Genome.Split.split gpart_a2cij
                            p_a2cfY = Functions.belowten' g_a2cfX
                            (g_a2cfX, gpart_a2cij) = Genome.Split.split gpart_a2cii
                            p_a2cfW = double g_a2cfV
                            (g_a2cfV, gpart_a2cii) = Genome.Split.split gpart_a2cih
                            p_a2cfU = Functions.belowten' g_a2cfT
                            (g_a2cfT, gpart_a2cih) = Genome.Split.split gpart_a2cig
                            p_a2cfS = double g_a2cfR
                            (g_a2cfR, gpart_a2cig) = Genome.Split.split gpart_a2cif
                            p_a2cfQ = double g_a2cfP
                            (g_a2cfP, gpart_a2cif) = Genome.Split.split gpart_a2cie
                            p_a2cfO = double g_a2cfN
                            (g_a2cfN, gpart_a2cie) = Genome.Split.split gpart_a2cid
                            p_a2cfM = Functions.belowten' g_a2cfL
                            (g_a2cfL, gpart_a2cid) = Genome.Split.split gpart_a2cic
                            p_a2cfK = double g_a2cfJ
                            (g_a2cfJ, gpart_a2cic) = Genome.Split.split gpart_a2cib
                            p_a2cfI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cfH
                            (g_a2cfH, gpart_a2cib) = Genome.Split.split gpart_a2cia
                            p_a2cfG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2cfF
                            (g_a2cfF, gpart_a2cia) = Genome.Split.split gpart_a2ci9
                            p_a2cfE = Functions.belowten' g_a2cfD
                            (g_a2cfD, gpart_a2ci9) = Genome.Split.split gpart_a2ci8
                            p_a2cfC = double g_a2cfB
                            (g_a2cfB, gpart_a2ci8) = Genome.Split.split gpart_a2ci7
                            p_a2cfA = double g_a2cfz
                            (g_a2cfz, gpart_a2ci7) = Genome.Split.split gpart_a2ci6
                            p_a2cfy = double g_a2cfx
                            (g_a2cfx, gpart_a2ci6) = Genome.Split.split gpart_a2ci5
                            p_a2cfw = double g_a2cfv
                            (g_a2cfv, gpart_a2ci5) = Genome.Split.split gpart_a2ci4
                            p_a2cfu = double g_a2cft
                            (g_a2cft, gpart_a2ci4) = Genome.Split.split gpart_a2ci3
                            p_a2cfs = double g_a2cfr
                            (g_a2cfr, gpart_a2ci3) = Genome.Split.split genome_a2cgT
                          in
                            \ desc_a2cgU
                              -> case desc_a2cgU of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfs)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfu)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfw)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfy)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfA)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfC)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfE)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfG)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfI)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfK)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfM)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfO)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfQ)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfS)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfU)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfW)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cfY)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cg0)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cg2)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cg4)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cg6)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cg8)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cga)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgc)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cge)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgg)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgi)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgk)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgm)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgo)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgq)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgs)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgu)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgw)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgy)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgA)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgC)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgE)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgG)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgI)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgK)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgM)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgO)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgQ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2cgS)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asVB
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWl
                      p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                      (g_asVz, gpart_asWl) = Genome.Split.split gpart_asWk
                      p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                      (g_asVx, gpart_asWk) = Genome.Split.split gpart_asWj
                      p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                      (g_asVv, gpart_asWj) = Genome.Split.split gpart_asWi
                      p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                      (g_asVt, gpart_asWi) = Genome.Split.split gpart_asWh
                      p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                      (g_asVr, gpart_asWh) = Genome.Split.split gpart_asWg
                      p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                      (g_asVp, gpart_asWg) = Genome.Split.split gpart_asWf
                      p_asVo = Functions.belowten' g_asVn
                      (g_asVn, gpart_asWf) = Genome.Split.split gpart_asWe
                      p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                      (g_asVl, gpart_asWe) = Genome.Split.split gpart_asWd
                      p_asVk = Functions.belowten' g_asVj
                      (g_asVj, gpart_asWd) = Genome.Split.split gpart_asWc
                      p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                      (g_asVh, gpart_asWc) = Genome.Split.split gpart_asWb
                      p_asVg = code-0.1.0.0:Genome.FixedList.Functions.double g_asVf
                      (g_asVf, gpart_asWb) = Genome.Split.split gpart_asWa
                      p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                      (g_asVd, gpart_asWa) = Genome.Split.split gpart_asW9
                      p_asVc = Functions.belowten' g_asVb
                      (g_asVb, gpart_asW9) = Genome.Split.split gpart_asW8
                      p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                      (g_asV9, gpart_asW8) = Genome.Split.split gpart_asW7
                      p_asV8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV7
                      (g_asV7, gpart_asW7) = Genome.Split.split gpart_asW6
                      p_asV6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV5
                      (g_asV5, gpart_asW6) = Genome.Split.split gpart_asW5
                      p_asV4 = Functions.belowten' g_asV3
                      (g_asV3, gpart_asW5) = Genome.Split.split gpart_asW4
                      p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                      (g_asV1, gpart_asW4) = Genome.Split.split gpart_asW3
                      p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                      (g_asUZ, gpart_asW3) = Genome.Split.split gpart_asW2
                      p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                      (g_asUX, gpart_asW2) = Genome.Split.split gpart_asW1
                      p_asUW = Functions.belowten' g_asUV
                      (g_asUV, gpart_asW1) = Genome.Split.split gpart_asW0
                      p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                      (g_asUT, gpart_asW0) = Genome.Split.split gpart_asVZ
                      p_asUS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUR
                      (g_asUR, gpart_asVZ) = Genome.Split.split gpart_asVY
                      p_asUQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUP
                      (g_asUP, gpart_asVY) = Genome.Split.split gpart_asVX
                      p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                      (g_asUN, gpart_asVX) = Genome.Split.split gpart_asVW
                      p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                      (g_asUL, gpart_asVW) = Genome.Split.split gpart_asVV
                      p_asUK = Functions.belowten' g_asUJ
                      (g_asUJ, gpart_asVV) = Genome.Split.split gpart_asVU
                      p_asUI = code-0.1.0.0:Genome.FixedList.Functions.double g_asUH
                      (g_asUH, gpart_asVU) = Genome.Split.split gpart_asVT
                      p_asUG = Functions.belowten' g_asUF
                      (g_asUF, gpart_asVT) = Genome.Split.split gpart_asVS
                      p_asUE = code-0.1.0.0:Genome.FixedList.Functions.double g_asUD
                      (g_asUD, gpart_asVS) = Genome.Split.split gpart_asVR
                      p_asUC = Functions.belowten' g_asUB
                      (g_asUB, gpart_asVR) = Genome.Split.split gpart_asVQ
                      p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                      (g_asUz, gpart_asVQ) = Genome.Split.split gpart_asVP
                      p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                      (g_asUx, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                      (g_asUv, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asUu = Functions.belowten' g_asUt
                      (g_asUt, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asUs = code-0.1.0.0:Genome.FixedList.Functions.double g_asUr
                      (g_asUr, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUp
                      (g_asUp, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUn
                      (g_asUn, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUm = Functions.belowten' g_asUl
                      (g_asUl, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                      (g_asUj, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                      (g_asUh, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                      (g_asUf, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUe = code-0.1.0.0:Genome.FixedList.Functions.double g_asUd
                      (g_asUd, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                      (g_asUb, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                      (g_asU9, gpart_asVD) = Genome.Split.split genome_asVB
                    in
                      [Reaction
                         (\ x_asWm
                            -> let
                                 c_MiRs_asWp = ((toVector x_asWm) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asWn = ((toVector x_asWm) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asUi
                                  * ((p_asUw + ((c_NPTB_asWn / p_asUk) ** p_asUm))
                                     / (((1 + p_asUw) + ((c_NPTB_asWn / p_asUk) ** p_asUm))
                                        + ((c_MiRs_asWp / p_asUs) ** p_asUu)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWq
                            -> let
                                 c_PTB_asWu = ((toVector x_asWq) Data.Vector.Unboxed.! 0)
                                 c_MiRs_asWt = ((toVector x_asWq) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asWr = ((toVector x_asWq) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUy
                                  * ((p_asUM + ((c_RESTc_asWr / p_asUA) ** p_asUC))
                                     / (((1 + p_asUM) + ((c_RESTc_asWr / p_asUA) ** p_asUC))
                                        + (((c_MiRs_asWt / p_asUE) ** p_asUG)
                                           + ((c_PTB_asWu / p_asUI) ** p_asUK))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asWv
                            -> let c_RESTc_asWw = ((toVector x_asWv) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUO
                                  * ((p_asUY + ((p_asUe / p_asUQ) ** p_asUS))
                                     / (((1 + p_asUY) + ((p_asUe / p_asUQ) ** p_asUS))
                                        + ((c_RESTc_asWw / p_asUU) ** p_asUW)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asWx
                            -> let
                                 c_MiRs_asWA = ((toVector x_asWx) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWy = ((toVector x_asWx) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asV0
                                  * ((p_asVe + ((c_PTB_asWy / p_asV2) ** p_asV4))
                                     / (((1 + p_asVe) + ((c_PTB_asWy / p_asV2) ** p_asV4))
                                        + (((p_asUa / p_asV6) ** p_asV8)
                                           + ((c_MiRs_asWA / p_asVa) ** p_asVc))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asWB
                            -> let
                                 c_RESTc_asWE = ((toVector x_asWB) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asWC = ((toVector x_asWB) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asVg
                                  * ((p_asVq + ((c_MiRs_asWC / p_asVi) ** p_asVk))
                                     / (((1 + p_asVq) + ((c_MiRs_asWC / p_asVi) ** p_asVk))
                                        + ((c_RESTc_asWE / p_asVm) ** p_asVo)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asWF
                            -> let c_PTB_asWG = ((toVector x_asWF) Data.Vector.Unboxed.! 0)
                               in (p_asVs * c_PTB_asWG))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWH
                            -> let c_NPTB_asWI = ((toVector x_asWH) Data.Vector.Unboxed.! 1)
                               in (p_asVu * c_NPTB_asWI))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWJ
                            -> let c_MiRs_asWK = ((toVector x_asWJ) Data.Vector.Unboxed.! 2)
                               in (p_asVw * c_MiRs_asWK))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWL
                            -> let c_RESTc_asWM = ((toVector x_asWL) Data.Vector.Unboxed.! 3)
                               in (p_asVy * c_RESTc_asWM))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWN
                            -> let
                                 c_EndoNeuroTFs_asWO = ((toVector x_asWN) Data.Vector.Unboxed.! 4)
                               in (p_asVA * c_EndoNeuroTFs_asWO))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120920",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120922",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120948",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120950",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120966",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asVB
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXC
                            p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                            (g_asVz, gpart_asXC) = Genome.Split.split gpart_asXB
                            p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                            (g_asVx, gpart_asXB) = Genome.Split.split gpart_asXA
                            p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                            (g_asVv, gpart_asXA) = Genome.Split.split gpart_asXz
                            p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                            (g_asVt, gpart_asXz) = Genome.Split.split gpart_asXy
                            p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                            (g_asVr, gpart_asXy) = Genome.Split.split gpart_asXx
                            p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                            (g_asVp, gpart_asXx) = Genome.Split.split gpart_asXw
                            p_asVo = Functions.belowten' g_asVn
                            (g_asVn, gpart_asXw) = Genome.Split.split gpart_asXv
                            p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                            (g_asVl, gpart_asXv) = Genome.Split.split gpart_asXu
                            p_asVk = Functions.belowten' g_asVj
                            (g_asVj, gpart_asXu) = Genome.Split.split gpart_asXt
                            p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                            (g_asVh, gpart_asXt) = Genome.Split.split gpart_asXs
                            p_asVg = code-0.1.0.0:Genome.FixedList.Functions.double g_asVf
                            (g_asVf, gpart_asXs) = Genome.Split.split gpart_asXr
                            p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                            (g_asVd, gpart_asXr) = Genome.Split.split gpart_asXq
                            p_asVc = Functions.belowten' g_asVb
                            (g_asVb, gpart_asXq) = Genome.Split.split gpart_asXp
                            p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                            (g_asV9, gpart_asXp) = Genome.Split.split gpart_asXo
                            p_asV8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV7
                            (g_asV7, gpart_asXo) = Genome.Split.split gpart_asXn
                            p_asV6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV5
                            (g_asV5, gpart_asXn) = Genome.Split.split gpart_asXm
                            p_asV4 = Functions.belowten' g_asV3
                            (g_asV3, gpart_asXm) = Genome.Split.split gpart_asXl
                            p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                            (g_asV1, gpart_asXl) = Genome.Split.split gpart_asXk
                            p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                            (g_asUZ, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                            (g_asUX, gpart_asXj) = Genome.Split.split gpart_asXi
                            p_asUW = Functions.belowten' g_asUV
                            (g_asUV, gpart_asXi) = Genome.Split.split gpart_asXh
                            p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                            (g_asUT, gpart_asXh) = Genome.Split.split gpart_asXg
                            p_asUS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUR
                            (g_asUR, gpart_asXg) = Genome.Split.split gpart_asXf
                            p_asUQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUP
                            (g_asUP, gpart_asXf) = Genome.Split.split gpart_asXe
                            p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                            (g_asUN, gpart_asXe) = Genome.Split.split gpart_asXd
                            p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                            (g_asUL, gpart_asXd) = Genome.Split.split gpart_asXc
                            p_asUK = Functions.belowten' g_asUJ
                            (g_asUJ, gpart_asXc) = Genome.Split.split gpart_asXb
                            p_asUI = code-0.1.0.0:Genome.FixedList.Functions.double g_asUH
                            (g_asUH, gpart_asXb) = Genome.Split.split gpart_asXa
                            p_asUG = Functions.belowten' g_asUF
                            (g_asUF, gpart_asXa) = Genome.Split.split gpart_asX9
                            p_asUE = code-0.1.0.0:Genome.FixedList.Functions.double g_asUD
                            (g_asUD, gpart_asX9) = Genome.Split.split gpart_asX8
                            p_asUC = Functions.belowten' g_asUB
                            (g_asUB, gpart_asX8) = Genome.Split.split gpart_asX7
                            p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                            (g_asUz, gpart_asX7) = Genome.Split.split gpart_asX6
                            p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                            (g_asUx, gpart_asX6) = Genome.Split.split gpart_asX5
                            p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                            (g_asUv, gpart_asX5) = Genome.Split.split gpart_asX4
                            p_asUu = Functions.belowten' g_asUt
                            (g_asUt, gpart_asX4) = Genome.Split.split gpart_asX3
                            p_asUs = code-0.1.0.0:Genome.FixedList.Functions.double g_asUr
                            (g_asUr, gpart_asX3) = Genome.Split.split gpart_asX2
                            p_asUq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUp
                            (g_asUp, gpart_asX2) = Genome.Split.split gpart_asX1
                            p_asUo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUn
                            (g_asUn, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asUm = Functions.belowten' g_asUl
                            (g_asUl, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                            (g_asUj, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                            (g_asUh, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                            (g_asUf, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asUe = code-0.1.0.0:Genome.FixedList.Functions.double g_asUd
                            (g_asUd, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                            (g_asUb, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                            (g_asU9, gpart_asWU) = Genome.Split.split genome_asVB
                          in
                            \ desc_asVC
                              -> case desc_asVC of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUc)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUe)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUg)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUi)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUk)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUm)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUo)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUq)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUs)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUu)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUw)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUy)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUA)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUC)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUE)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUG)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUI)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUK)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUM)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUO)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUQ)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUS)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUU)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUW)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUY)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV8)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVa)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVc)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVe)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVg)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVi)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVk)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVm)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVo)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVq)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVs)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVu)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVw)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVy)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVA)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZL
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0v
                      p_asZK = code-0.1.0.0:Genome.FixedList.Functions.double g_asZJ
                      (g_asZJ, gpart_at0v) = Genome.Split.split gpart_at0u
                      p_asZI = code-0.1.0.0:Genome.FixedList.Functions.double g_asZH
                      (g_asZH, gpart_at0u) = Genome.Split.split gpart_at0t
                      p_asZG = code-0.1.0.0:Genome.FixedList.Functions.double g_asZF
                      (g_asZF, gpart_at0t) = Genome.Split.split gpart_at0s
                      p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                      (g_asZD, gpart_at0s) = Genome.Split.split gpart_at0r
                      p_asZC = code-0.1.0.0:Genome.FixedList.Functions.double g_asZB
                      (g_asZB, gpart_at0r) = Genome.Split.split gpart_at0q
                      p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                      (g_asZz, gpart_at0q) = Genome.Split.split gpart_at0p
                      p_asZy = Functions.belowten' g_asZx
                      (g_asZx, gpart_at0p) = Genome.Split.split gpart_at0o
                      p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                      (g_asZv, gpart_at0o) = Genome.Split.split gpart_at0n
                      p_asZu = Functions.belowten' g_asZt
                      (g_asZt, gpart_at0n) = Genome.Split.split gpart_at0m
                      p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                      (g_asZr, gpart_at0m) = Genome.Split.split gpart_at0l
                      p_asZq = code-0.1.0.0:Genome.FixedList.Functions.double g_asZp
                      (g_asZp, gpart_at0l) = Genome.Split.split gpart_at0k
                      p_asZo = code-0.1.0.0:Genome.FixedList.Functions.double g_asZn
                      (g_asZn, gpart_at0k) = Genome.Split.split gpart_at0j
                      p_asZm = Functions.belowten' g_asZl
                      (g_asZl, gpart_at0j) = Genome.Split.split gpart_at0i
                      p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                      (g_asZj, gpart_at0i) = Genome.Split.split gpart_at0h
                      p_asZi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZh
                      (g_asZh, gpart_at0h) = Genome.Split.split gpart_at0g
                      p_asZg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZf
                      (g_asZf, gpart_at0g) = Genome.Split.split gpart_at0f
                      p_asZe = Functions.belowten' g_asZd
                      (g_asZd, gpart_at0f) = Genome.Split.split gpart_at0e
                      p_asZc = code-0.1.0.0:Genome.FixedList.Functions.double g_asZb
                      (g_asZb, gpart_at0e) = Genome.Split.split gpart_at0d
                      p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                      (g_asZ9, gpart_at0d) = Genome.Split.split gpart_at0c
                      p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                      (g_asZ7, gpart_at0c) = Genome.Split.split gpart_at0b
                      p_asZ6 = Functions.belowten' g_asZ5
                      (g_asZ5, gpart_at0b) = Genome.Split.split gpart_at0a
                      p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                      (g_asZ3, gpart_at0a) = Genome.Split.split gpart_at09
                      p_asZ2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ1
                      (g_asZ1, gpart_at09) = Genome.Split.split gpart_at08
                      p_asZ0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYZ
                      (g_asYZ, gpart_at08) = Genome.Split.split gpart_at07
                      p_asYY = code-0.1.0.0:Genome.FixedList.Functions.double g_asYX
                      (g_asYX, gpart_at07) = Genome.Split.split gpart_at06
                      p_asYW = code-0.1.0.0:Genome.FixedList.Functions.double g_asYV
                      (g_asYV, gpart_at06) = Genome.Split.split gpart_at05
                      p_asYU = Functions.belowten' g_asYT
                      (g_asYT, gpart_at05) = Genome.Split.split gpart_at04
                      p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                      (g_asYR, gpart_at04) = Genome.Split.split gpart_at03
                      p_asYQ = Functions.belowten' g_asYP
                      (g_asYP, gpart_at03) = Genome.Split.split gpart_at02
                      p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                      (g_asYN, gpart_at02) = Genome.Split.split gpart_at01
                      p_asYM = Functions.belowten' g_asYL
                      (g_asYL, gpart_at01) = Genome.Split.split gpart_at00
                      p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                      (g_asYJ, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                      (g_asYH, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                      (g_asYF, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asYE = Functions.belowten' g_asYD
                      (g_asYD, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                      (g_asYB, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asYA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYz
                      (g_asYz, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asYy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYx
                      (g_asYx, gpart_asZU) = Genome.Split.split gpart_asZT
                      p_asYw = Functions.belowten' g_asYv
                      (g_asYv, gpart_asZT) = Genome.Split.split gpart_asZS
                      p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                      (g_asYt, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asYs = code-0.1.0.0:Genome.FixedList.Functions.double g_asYr
                      (g_asYr, gpart_asZR) = Genome.Split.split gpart_asZQ
                      p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                      (g_asYp, gpart_asZQ) = Genome.Split.split gpart_asZP
                      p_asYo = code-0.1.0.0:Genome.FixedList.Functions.double g_asYn
                      (g_asYn, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                      (g_asYl, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asYk = code-0.1.0.0:Genome.FixedList.Functions.double g_asYj
                      (g_asYj, gpart_asZN) = Genome.Split.split genome_asZL
                    in
                      [Reaction
                         (\ x_at0w
                            -> let
                                 c_MiRs_at0z = ((toVector x_at0w) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at0x = ((toVector x_at0w) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asYs
                                  * ((p_asYG + ((c_NPTB_at0x / p_asYu) ** p_asYw))
                                     / (((1 + p_asYG) + ((c_NPTB_at0x / p_asYu) ** p_asYw))
                                        + ((c_MiRs_at0z / p_asYC) ** p_asYE)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0A
                            -> let
                                 c_PTB_at0E = ((toVector x_at0A) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at0D = ((toVector x_at0A) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at0B = ((toVector x_at0A) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYI
                                  * ((p_asYW + ((c_RESTc_at0B / p_asYK) ** p_asYM))
                                     / (((1 + p_asYW) + ((c_RESTc_at0B / p_asYK) ** p_asYM))
                                        + (((c_MiRs_at0D / p_asYO) ** p_asYQ)
                                           + ((c_PTB_at0E / p_asYS) ** p_asYU))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at0F
                            -> let c_RESTc_at0G = ((toVector x_at0F) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYY
                                  * (p_asZ8
                                     / ((1 + p_asZ8) + ((c_RESTc_at0G / p_asZ4) ** p_asZ6)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0H
                            -> let
                                 c_MiRs_at0K = ((toVector x_at0H) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0I = ((toVector x_at0H) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZa
                                  * ((p_asZo + ((c_PTB_at0I / p_asZc) ** p_asZe))
                                     / (((1 + p_asZo) + ((c_PTB_at0I / p_asZc) ** p_asZe))
                                        + (((p_asYk / p_asZg) ** p_asZi)
                                           + ((c_MiRs_at0K / p_asZk) ** p_asZm))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0L
                            -> let
                                 c_RESTc_at0O = ((toVector x_at0L) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at0M = ((toVector x_at0L) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asZq
                                  * ((p_asZA + ((c_MiRs_at0M / p_asZs) ** p_asZu))
                                     / (((1 + p_asZA) + ((c_MiRs_at0M / p_asZs) ** p_asZu))
                                        + ((c_RESTc_at0O / p_asZw) ** p_asZy)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0P
                            -> let c_PTB_at0Q = ((toVector x_at0P) Data.Vector.Unboxed.! 0)
                               in (p_asZC * c_PTB_at0Q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0R
                            -> let c_NPTB_at0S = ((toVector x_at0R) Data.Vector.Unboxed.! 1)
                               in (p_asZE * c_NPTB_at0S))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0T
                            -> let c_MiRs_at0U = ((toVector x_at0T) Data.Vector.Unboxed.! 2)
                               in (p_asZG * c_MiRs_at0U))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0V
                            -> let c_RESTc_at0W = ((toVector x_at0V) Data.Vector.Unboxed.! 3)
                               in (p_asZI * c_RESTc_at0W))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0X
                            -> let
                                 c_EndoNeuroTFs_at0Y = ((toVector x_at0X) Data.Vector.Unboxed.! 4)
                               in (p_asZK * c_EndoNeuroTFs_at0Y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121178",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121180",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121198",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121200",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121206",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121208",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121218",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121220",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121222",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121224",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121232",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121234",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121244",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121250",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121252",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZL
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1H
                            p_asZK = code-0.1.0.0:Genome.FixedList.Functions.double g_asZJ
                            (g_asZJ, gpart_at1H) = Genome.Split.split gpart_at1G
                            p_asZI = code-0.1.0.0:Genome.FixedList.Functions.double g_asZH
                            (g_asZH, gpart_at1G) = Genome.Split.split gpart_at1F
                            p_asZG = code-0.1.0.0:Genome.FixedList.Functions.double g_asZF
                            (g_asZF, gpart_at1F) = Genome.Split.split gpart_at1E
                            p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                            (g_asZD, gpart_at1E) = Genome.Split.split gpart_at1D
                            p_asZC = code-0.1.0.0:Genome.FixedList.Functions.double g_asZB
                            (g_asZB, gpart_at1D) = Genome.Split.split gpart_at1C
                            p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                            (g_asZz, gpart_at1C) = Genome.Split.split gpart_at1B
                            p_asZy = Functions.belowten' g_asZx
                            (g_asZx, gpart_at1B) = Genome.Split.split gpart_at1A
                            p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                            (g_asZv, gpart_at1A) = Genome.Split.split gpart_at1z
                            p_asZu = Functions.belowten' g_asZt
                            (g_asZt, gpart_at1z) = Genome.Split.split gpart_at1y
                            p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                            (g_asZr, gpart_at1y) = Genome.Split.split gpart_at1x
                            p_asZq = code-0.1.0.0:Genome.FixedList.Functions.double g_asZp
                            (g_asZp, gpart_at1x) = Genome.Split.split gpart_at1w
                            p_asZo = code-0.1.0.0:Genome.FixedList.Functions.double g_asZn
                            (g_asZn, gpart_at1w) = Genome.Split.split gpart_at1v
                            p_asZm = Functions.belowten' g_asZl
                            (g_asZl, gpart_at1v) = Genome.Split.split gpart_at1u
                            p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                            (g_asZj, gpart_at1u) = Genome.Split.split gpart_at1t
                            p_asZi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZh
                            (g_asZh, gpart_at1t) = Genome.Split.split gpart_at1s
                            p_asZg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZf
                            (g_asZf, gpart_at1s) = Genome.Split.split gpart_at1r
                            p_asZe = Functions.belowten' g_asZd
                            (g_asZd, gpart_at1r) = Genome.Split.split gpart_at1q
                            p_asZc = code-0.1.0.0:Genome.FixedList.Functions.double g_asZb
                            (g_asZb, gpart_at1q) = Genome.Split.split gpart_at1p
                            p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                            (g_asZ9, gpart_at1p) = Genome.Split.split gpart_at1o
                            p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                            (g_asZ7, gpart_at1o) = Genome.Split.split gpart_at1n
                            p_asZ6 = Functions.belowten' g_asZ5
                            (g_asZ5, gpart_at1n) = Genome.Split.split gpart_at1m
                            p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                            (g_asZ3, gpart_at1m) = Genome.Split.split gpart_at1l
                            p_asZ2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ1
                            (g_asZ1, gpart_at1l) = Genome.Split.split gpart_at1k
                            p_asZ0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYZ
                            (g_asYZ, gpart_at1k) = Genome.Split.split gpart_at1j
                            p_asYY = code-0.1.0.0:Genome.FixedList.Functions.double g_asYX
                            (g_asYX, gpart_at1j) = Genome.Split.split gpart_at1i
                            p_asYW = code-0.1.0.0:Genome.FixedList.Functions.double g_asYV
                            (g_asYV, gpart_at1i) = Genome.Split.split gpart_at1h
                            p_asYU = Functions.belowten' g_asYT
                            (g_asYT, gpart_at1h) = Genome.Split.split gpart_at1g
                            p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                            (g_asYR, gpart_at1g) = Genome.Split.split gpart_at1f
                            p_asYQ = Functions.belowten' g_asYP
                            (g_asYP, gpart_at1f) = Genome.Split.split gpart_at1e
                            p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                            (g_asYN, gpart_at1e) = Genome.Split.split gpart_at1d
                            p_asYM = Functions.belowten' g_asYL
                            (g_asYL, gpart_at1d) = Genome.Split.split gpart_at1c
                            p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                            (g_asYJ, gpart_at1c) = Genome.Split.split gpart_at1b
                            p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                            (g_asYH, gpart_at1b) = Genome.Split.split gpart_at1a
                            p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                            (g_asYF, gpart_at1a) = Genome.Split.split gpart_at19
                            p_asYE = Functions.belowten' g_asYD
                            (g_asYD, gpart_at19) = Genome.Split.split gpart_at18
                            p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                            (g_asYB, gpart_at18) = Genome.Split.split gpart_at17
                            p_asYA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYz
                            (g_asYz, gpart_at17) = Genome.Split.split gpart_at16
                            p_asYy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYx
                            (g_asYx, gpart_at16) = Genome.Split.split gpart_at15
                            p_asYw = Functions.belowten' g_asYv
                            (g_asYv, gpart_at15) = Genome.Split.split gpart_at14
                            p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                            (g_asYt, gpart_at14) = Genome.Split.split gpart_at13
                            p_asYs = code-0.1.0.0:Genome.FixedList.Functions.double g_asYr
                            (g_asYr, gpart_at13) = Genome.Split.split gpart_at12
                            p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                            (g_asYp, gpart_at12) = Genome.Split.split gpart_at11
                            p_asYo = code-0.1.0.0:Genome.FixedList.Functions.double g_asYn
                            (g_asYn, gpart_at11) = Genome.Split.split gpart_at10
                            p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                            (g_asYl, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asYk = code-0.1.0.0:Genome.FixedList.Functions.double g_asYj
                            (g_asYj, gpart_at0Z) = Genome.Split.split genome_asZL
                          in
                            \ desc_asZM
                              -> case desc_asZM of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYk)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYm)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYo)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYq)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYs)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYu)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYw)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYy)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYA)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYM)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYO)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYQ)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYS)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYU)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYW)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYY)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ0)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ2)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ4)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ6)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ8)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZa)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZc)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZe)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZg)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZi)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZk)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZm)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZo)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZq)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZs)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZu)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZw)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZy)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZA)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZC)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZE)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZG)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZI)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZK)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at3Q
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4A
                      p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                      (g_at3O, gpart_at4A) = Genome.Split.split gpart_at4z
                      p_at3N = code-0.1.0.0:Genome.FixedList.Functions.double g_at3M
                      (g_at3M, gpart_at4z) = Genome.Split.split gpart_at4y
                      p_at3L = code-0.1.0.0:Genome.FixedList.Functions.double g_at3K
                      (g_at3K, gpart_at4y) = Genome.Split.split gpart_at4x
                      p_at3J = code-0.1.0.0:Genome.FixedList.Functions.double g_at3I
                      (g_at3I, gpart_at4x) = Genome.Split.split gpart_at4w
                      p_at3H = code-0.1.0.0:Genome.FixedList.Functions.double g_at3G
                      (g_at3G, gpart_at4w) = Genome.Split.split gpart_at4v
                      p_at3F = code-0.1.0.0:Genome.FixedList.Functions.double g_at3E
                      (g_at3E, gpart_at4v) = Genome.Split.split gpart_at4u
                      p_at3D = Functions.belowten' g_at3C
                      (g_at3C, gpart_at4u) = Genome.Split.split gpart_at4t
                      p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                      (g_at3A, gpart_at4t) = Genome.Split.split gpart_at4s
                      p_at3z = Functions.belowten' g_at3y
                      (g_at3y, gpart_at4s) = Genome.Split.split gpart_at4r
                      p_at3x = code-0.1.0.0:Genome.FixedList.Functions.double g_at3w
                      (g_at3w, gpart_at4r) = Genome.Split.split gpart_at4q
                      p_at3v = code-0.1.0.0:Genome.FixedList.Functions.double g_at3u
                      (g_at3u, gpart_at4q) = Genome.Split.split gpart_at4p
                      p_at3t = code-0.1.0.0:Genome.FixedList.Functions.double g_at3s
                      (g_at3s, gpart_at4p) = Genome.Split.split gpart_at4o
                      p_at3r = Functions.belowten' g_at3q
                      (g_at3q, gpart_at4o) = Genome.Split.split gpart_at4n
                      p_at3p = code-0.1.0.0:Genome.FixedList.Functions.double g_at3o
                      (g_at3o, gpart_at4n) = Genome.Split.split gpart_at4m
                      p_at3n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3m
                      (g_at3m, gpart_at4m) = Genome.Split.split gpart_at4l
                      p_at3l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3k
                      (g_at3k, gpart_at4l) = Genome.Split.split gpart_at4k
                      p_at3j = Functions.belowten' g_at3i
                      (g_at3i, gpart_at4k) = Genome.Split.split gpart_at4j
                      p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                      (g_at3g, gpart_at4j) = Genome.Split.split gpart_at4i
                      p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                      (g_at3e, gpart_at4i) = Genome.Split.split gpart_at4h
                      p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                      (g_at3c, gpart_at4h) = Genome.Split.split gpart_at4g
                      p_at3b = Functions.belowten' g_at3a
                      (g_at3a, gpart_at4g) = Genome.Split.split gpart_at4f
                      p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                      (g_at38, gpart_at4f) = Genome.Split.split gpart_at4e
                      p_at37
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at36
                      (g_at36, gpart_at4e) = Genome.Split.split gpart_at4d
                      p_at35
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at34
                      (g_at34, gpart_at4d) = Genome.Split.split gpart_at4c
                      p_at33 = code-0.1.0.0:Genome.FixedList.Functions.double g_at32
                      (g_at32, gpart_at4c) = Genome.Split.split gpart_at4b
                      p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                      (g_at30, gpart_at4b) = Genome.Split.split gpart_at4a
                      p_at2Z = Functions.belowten' g_at2Y
                      (g_at2Y, gpart_at4a) = Genome.Split.split gpart_at49
                      p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                      (g_at2W, gpart_at49) = Genome.Split.split gpart_at48
                      p_at2V = Functions.belowten' g_at2U
                      (g_at2U, gpart_at48) = Genome.Split.split gpart_at47
                      p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                      (g_at2S, gpart_at47) = Genome.Split.split gpart_at46
                      p_at2R = Functions.belowten' g_at2Q
                      (g_at2Q, gpart_at46) = Genome.Split.split gpart_at45
                      p_at2P = code-0.1.0.0:Genome.FixedList.Functions.double g_at2O
                      (g_at2O, gpart_at45) = Genome.Split.split gpart_at44
                      p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                      (g_at2M, gpart_at44) = Genome.Split.split gpart_at43
                      p_at2L = code-0.1.0.0:Genome.FixedList.Functions.double g_at2K
                      (g_at2K, gpart_at43) = Genome.Split.split gpart_at42
                      p_at2J = Functions.belowten' g_at2I
                      (g_at2I, gpart_at42) = Genome.Split.split gpart_at41
                      p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                      (g_at2G, gpart_at41) = Genome.Split.split gpart_at40
                      p_at2F
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2E
                      (g_at2E, gpart_at40) = Genome.Split.split gpart_at3Z
                      p_at2D
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2C
                      (g_at2C, gpart_at3Z) = Genome.Split.split gpart_at3Y
                      p_at2B = Functions.belowten' g_at2A
                      (g_at2A, gpart_at3Y) = Genome.Split.split gpart_at3X
                      p_at2z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2y
                      (g_at2y, gpart_at3X) = Genome.Split.split gpart_at3W
                      p_at2x = code-0.1.0.0:Genome.FixedList.Functions.double g_at2w
                      (g_at2w, gpart_at3W) = Genome.Split.split gpart_at3V
                      p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                      (g_at2u, gpart_at3V) = Genome.Split.split gpart_at3U
                      p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                      (g_at2s, gpart_at3U) = Genome.Split.split gpart_at3T
                      p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                      (g_at2q, gpart_at3T) = Genome.Split.split gpart_at3S
                      p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                      (g_at2o, gpart_at3S) = Genome.Split.split genome_at3Q
                    in
                      [Reaction
                         (\ x_at4B
                            -> let
                                 c_MiRs_at4E = ((toVector x_at4B) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at4C = ((toVector x_at4B) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at2x
                                  * ((p_at2L + ((c_NPTB_at4C / p_at2z) ** p_at2B))
                                     / (((1 + p_at2L) + ((c_NPTB_at4C / p_at2z) ** p_at2B))
                                        + ((c_MiRs_at4E / p_at2H) ** p_at2J)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4F
                            -> let
                                 c_PTB_at4J = ((toVector x_at4F) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at4I = ((toVector x_at4F) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at4G = ((toVector x_at4F) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2N
                                  * ((p_at31 + ((c_RESTc_at4G / p_at2P) ** p_at2R))
                                     / (((1 + p_at31) + ((c_RESTc_at4G / p_at2P) ** p_at2R))
                                        + (((c_MiRs_at4I / p_at2T) ** p_at2V)
                                           + ((c_PTB_at4J / p_at2X) ** p_at2Z))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at4K
                            -> let c_RESTc_at4L = ((toVector x_at4K) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at33
                                  * (p_at3d
                                     / ((1 + p_at3d) + ((c_RESTc_at4L / p_at39) ** p_at3b)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at4M
                            -> let
                                 c_MiRs_at4P = ((toVector x_at4M) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4N = ((toVector x_at4M) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3f
                                  * ((p_at3t + ((c_PTB_at4N / p_at3h) ** p_at3j))
                                     / (((1 + p_at3t) + ((c_PTB_at4N / p_at3h) ** p_at3j))
                                        + ((c_MiRs_at4P / p_at3p) ** p_at3r)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at4Q
                            -> let
                                 c_RESTc_at4T = ((toVector x_at4Q) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at4R = ((toVector x_at4Q) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at3v
                                  * ((p_at3F + ((c_MiRs_at4R / p_at3x) ** p_at3z))
                                     / (((1 + p_at3F) + ((c_MiRs_at4R / p_at3x) ** p_at3z))
                                        + ((c_RESTc_at4T / p_at3B) ** p_at3D)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at4U
                            -> let c_PTB_at4V = ((toVector x_at4U) Data.Vector.Unboxed.! 0)
                               in (p_at3H * c_PTB_at4V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4W
                            -> let c_NPTB_at4X = ((toVector x_at4W) Data.Vector.Unboxed.! 1)
                               in (p_at3J * c_NPTB_at4X))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at4Y
                            -> let c_MiRs_at4Z = ((toVector x_at4Y) Data.Vector.Unboxed.! 2)
                               in (p_at3L * c_MiRs_at4Z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at50
                            -> let c_RESTc_at51 = ((toVector x_at50) Data.Vector.Unboxed.! 3)
                               in (p_at3N * c_RESTc_at51))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at52
                            -> let
                                 c_EndoNeuroTFs_at53 = ((toVector x_at52) Data.Vector.Unboxed.! 4)
                               in (p_at3P * c_EndoNeuroTFs_at53))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121431",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121433",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121449",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121451",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121457",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121459",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121461",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121465",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121475",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121476",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121477",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121478",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121479",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121480",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121481",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121482",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121483",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121484",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121485",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121486",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121487",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121488",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121489",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121497",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121499",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121501",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121503",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121505",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at3Q
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5M
                            p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                            (g_at3O, gpart_at5M) = Genome.Split.split gpart_at5L
                            p_at3N = code-0.1.0.0:Genome.FixedList.Functions.double g_at3M
                            (g_at3M, gpart_at5L) = Genome.Split.split gpart_at5K
                            p_at3L = code-0.1.0.0:Genome.FixedList.Functions.double g_at3K
                            (g_at3K, gpart_at5K) = Genome.Split.split gpart_at5J
                            p_at3J = code-0.1.0.0:Genome.FixedList.Functions.double g_at3I
                            (g_at3I, gpart_at5J) = Genome.Split.split gpart_at5I
                            p_at3H = code-0.1.0.0:Genome.FixedList.Functions.double g_at3G
                            (g_at3G, gpart_at5I) = Genome.Split.split gpart_at5H
                            p_at3F = code-0.1.0.0:Genome.FixedList.Functions.double g_at3E
                            (g_at3E, gpart_at5H) = Genome.Split.split gpart_at5G
                            p_at3D = Functions.belowten' g_at3C
                            (g_at3C, gpart_at5G) = Genome.Split.split gpart_at5F
                            p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                            (g_at3A, gpart_at5F) = Genome.Split.split gpart_at5E
                            p_at3z = Functions.belowten' g_at3y
                            (g_at3y, gpart_at5E) = Genome.Split.split gpart_at5D
                            p_at3x = code-0.1.0.0:Genome.FixedList.Functions.double g_at3w
                            (g_at3w, gpart_at5D) = Genome.Split.split gpart_at5C
                            p_at3v = code-0.1.0.0:Genome.FixedList.Functions.double g_at3u
                            (g_at3u, gpart_at5C) = Genome.Split.split gpart_at5B
                            p_at3t = code-0.1.0.0:Genome.FixedList.Functions.double g_at3s
                            (g_at3s, gpart_at5B) = Genome.Split.split gpart_at5A
                            p_at3r = Functions.belowten' g_at3q
                            (g_at3q, gpart_at5A) = Genome.Split.split gpart_at5z
                            p_at3p = code-0.1.0.0:Genome.FixedList.Functions.double g_at3o
                            (g_at3o, gpart_at5z) = Genome.Split.split gpart_at5y
                            p_at3n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3m
                            (g_at3m, gpart_at5y) = Genome.Split.split gpart_at5x
                            p_at3l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3k
                            (g_at3k, gpart_at5x) = Genome.Split.split gpart_at5w
                            p_at3j = Functions.belowten' g_at3i
                            (g_at3i, gpart_at5w) = Genome.Split.split gpart_at5v
                            p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                            (g_at3g, gpart_at5v) = Genome.Split.split gpart_at5u
                            p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                            (g_at3e, gpart_at5u) = Genome.Split.split gpart_at5t
                            p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                            (g_at3c, gpart_at5t) = Genome.Split.split gpart_at5s
                            p_at3b = Functions.belowten' g_at3a
                            (g_at3a, gpart_at5s) = Genome.Split.split gpart_at5r
                            p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                            (g_at38, gpart_at5r) = Genome.Split.split gpart_at5q
                            p_at37
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at36
                            (g_at36, gpart_at5q) = Genome.Split.split gpart_at5p
                            p_at35
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at34
                            (g_at34, gpart_at5p) = Genome.Split.split gpart_at5o
                            p_at33 = code-0.1.0.0:Genome.FixedList.Functions.double g_at32
                            (g_at32, gpart_at5o) = Genome.Split.split gpart_at5n
                            p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                            (g_at30, gpart_at5n) = Genome.Split.split gpart_at5m
                            p_at2Z = Functions.belowten' g_at2Y
                            (g_at2Y, gpart_at5m) = Genome.Split.split gpart_at5l
                            p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                            (g_at2W, gpart_at5l) = Genome.Split.split gpart_at5k
                            p_at2V = Functions.belowten' g_at2U
                            (g_at2U, gpart_at5k) = Genome.Split.split gpart_at5j
                            p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                            (g_at2S, gpart_at5j) = Genome.Split.split gpart_at5i
                            p_at2R = Functions.belowten' g_at2Q
                            (g_at2Q, gpart_at5i) = Genome.Split.split gpart_at5h
                            p_at2P = code-0.1.0.0:Genome.FixedList.Functions.double g_at2O
                            (g_at2O, gpart_at5h) = Genome.Split.split gpart_at5g
                            p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                            (g_at2M, gpart_at5g) = Genome.Split.split gpart_at5f
                            p_at2L = code-0.1.0.0:Genome.FixedList.Functions.double g_at2K
                            (g_at2K, gpart_at5f) = Genome.Split.split gpart_at5e
                            p_at2J = Functions.belowten' g_at2I
                            (g_at2I, gpart_at5e) = Genome.Split.split gpart_at5d
                            p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                            (g_at2G, gpart_at5d) = Genome.Split.split gpart_at5c
                            p_at2F
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2E
                            (g_at2E, gpart_at5c) = Genome.Split.split gpart_at5b
                            p_at2D
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2C
                            (g_at2C, gpart_at5b) = Genome.Split.split gpart_at5a
                            p_at2B = Functions.belowten' g_at2A
                            (g_at2A, gpart_at5a) = Genome.Split.split gpart_at59
                            p_at2z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2y
                            (g_at2y, gpart_at59) = Genome.Split.split gpart_at58
                            p_at2x = code-0.1.0.0:Genome.FixedList.Functions.double g_at2w
                            (g_at2w, gpart_at58) = Genome.Split.split gpart_at57
                            p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                            (g_at2u, gpart_at57) = Genome.Split.split gpart_at56
                            p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                            (g_at2s, gpart_at56) = Genome.Split.split gpart_at55
                            p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                            (g_at2q, gpart_at55) = Genome.Split.split gpart_at54
                            p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                            (g_at2o, gpart_at54) = Genome.Split.split genome_at3Q
                          in
                            \ desc_at3R
                              -> case desc_at3R of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2p)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2r)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2t)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2v)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2x)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2z)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2B)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2D)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2F)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2H)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2J)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2L)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2N)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2P)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2R)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2T)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2V)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2X)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Z)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at31)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at33)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at35)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at37)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at39)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3b)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3d)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3f)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3h)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3j)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3l)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3n)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3p)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3r)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3t)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3v)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3x)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3z)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3B)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3D)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3F)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3H)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3J)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3L)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3N)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3P)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at7V
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8F
                      p_at7U = code-0.1.0.0:Genome.FixedList.Functions.double g_at7T
                      (g_at7T, gpart_at8F) = Genome.Split.split gpart_at8E
                      p_at7S = code-0.1.0.0:Genome.FixedList.Functions.double g_at7R
                      (g_at7R, gpart_at8E) = Genome.Split.split gpart_at8D
                      p_at7Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7P
                      (g_at7P, gpart_at8D) = Genome.Split.split gpart_at8C
                      p_at7O = code-0.1.0.0:Genome.FixedList.Functions.double g_at7N
                      (g_at7N, gpart_at8C) = Genome.Split.split gpart_at8B
                      p_at7M = code-0.1.0.0:Genome.FixedList.Functions.double g_at7L
                      (g_at7L, gpart_at8B) = Genome.Split.split gpart_at8A
                      p_at7K = code-0.1.0.0:Genome.FixedList.Functions.double g_at7J
                      (g_at7J, gpart_at8A) = Genome.Split.split gpart_at8z
                      p_at7I = Functions.belowten' g_at7H
                      (g_at7H, gpart_at8z) = Genome.Split.split gpart_at8y
                      p_at7G = code-0.1.0.0:Genome.FixedList.Functions.double g_at7F
                      (g_at7F, gpart_at8y) = Genome.Split.split gpart_at8x
                      p_at7E = Functions.belowten' g_at7D
                      (g_at7D, gpart_at8x) = Genome.Split.split gpart_at8w
                      p_at7C = code-0.1.0.0:Genome.FixedList.Functions.double g_at7B
                      (g_at7B, gpart_at8w) = Genome.Split.split gpart_at8v
                      p_at7A = code-0.1.0.0:Genome.FixedList.Functions.double g_at7z
                      (g_at7z, gpart_at8v) = Genome.Split.split gpart_at8u
                      p_at7y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7x
                      (g_at7x, gpart_at8u) = Genome.Split.split gpart_at8t
                      p_at7w = Functions.belowten' g_at7v
                      (g_at7v, gpart_at8t) = Genome.Split.split gpart_at8s
                      p_at7u = code-0.1.0.0:Genome.FixedList.Functions.double g_at7t
                      (g_at7t, gpart_at8s) = Genome.Split.split gpart_at8r
                      p_at7s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7r
                      (g_at7r, gpart_at8r) = Genome.Split.split gpart_at8q
                      p_at7q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7p
                      (g_at7p, gpart_at8q) = Genome.Split.split gpart_at8p
                      p_at7o = Functions.belowten' g_at7n
                      (g_at7n, gpart_at8p) = Genome.Split.split gpart_at8o
                      p_at7m = code-0.1.0.0:Genome.FixedList.Functions.double g_at7l
                      (g_at7l, gpart_at8o) = Genome.Split.split gpart_at8n
                      p_at7k = code-0.1.0.0:Genome.FixedList.Functions.double g_at7j
                      (g_at7j, gpart_at8n) = Genome.Split.split gpart_at8m
                      p_at7i = code-0.1.0.0:Genome.FixedList.Functions.double g_at7h
                      (g_at7h, gpart_at8m) = Genome.Split.split gpart_at8l
                      p_at7g = Functions.belowten' g_at7f
                      (g_at7f, gpart_at8l) = Genome.Split.split gpart_at8k
                      p_at7e = code-0.1.0.0:Genome.FixedList.Functions.double g_at7d
                      (g_at7d, gpart_at8k) = Genome.Split.split gpart_at8j
                      p_at7c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7b
                      (g_at7b, gpart_at8j) = Genome.Split.split gpart_at8i
                      p_at7a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at79
                      (g_at79, gpart_at8i) = Genome.Split.split gpart_at8h
                      p_at78 = code-0.1.0.0:Genome.FixedList.Functions.double g_at77
                      (g_at77, gpart_at8h) = Genome.Split.split gpart_at8g
                      p_at76 = code-0.1.0.0:Genome.FixedList.Functions.double g_at75
                      (g_at75, gpart_at8g) = Genome.Split.split gpart_at8f
                      p_at74 = Functions.belowten' g_at73
                      (g_at73, gpart_at8f) = Genome.Split.split gpart_at8e
                      p_at72 = code-0.1.0.0:Genome.FixedList.Functions.double g_at71
                      (g_at71, gpart_at8e) = Genome.Split.split gpart_at8d
                      p_at70 = Functions.belowten' g_at6Z
                      (g_at6Z, gpart_at8d) = Genome.Split.split gpart_at8c
                      p_at6Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6X
                      (g_at6X, gpart_at8c) = Genome.Split.split gpart_at8b
                      p_at6W = Functions.belowten' g_at6V
                      (g_at6V, gpart_at8b) = Genome.Split.split gpart_at8a
                      p_at6U = code-0.1.0.0:Genome.FixedList.Functions.double g_at6T
                      (g_at6T, gpart_at8a) = Genome.Split.split gpart_at89
                      p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                      (g_at6R, gpart_at89) = Genome.Split.split gpart_at88
                      p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                      (g_at6P, gpart_at88) = Genome.Split.split gpart_at87
                      p_at6O = Functions.belowten' g_at6N
                      (g_at6N, gpart_at87) = Genome.Split.split gpart_at86
                      p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                      (g_at6L, gpart_at86) = Genome.Split.split gpart_at85
                      p_at6K
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6J
                      (g_at6J, gpart_at85) = Genome.Split.split gpart_at84
                      p_at6I
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6H
                      (g_at6H, gpart_at84) = Genome.Split.split gpart_at83
                      p_at6G = Functions.belowten' g_at6F
                      (g_at6F, gpart_at83) = Genome.Split.split gpart_at82
                      p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                      (g_at6D, gpart_at82) = Genome.Split.split gpart_at81
                      p_at6C = code-0.1.0.0:Genome.FixedList.Functions.double g_at6B
                      (g_at6B, gpart_at81) = Genome.Split.split gpart_at80
                      p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                      (g_at6z, gpart_at80) = Genome.Split.split gpart_at7Z
                      p_at6y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6x
                      (g_at6x, gpart_at7Z) = Genome.Split.split gpart_at7Y
                      p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                      (g_at6v, gpart_at7Y) = Genome.Split.split gpart_at7X
                      p_at6u = code-0.1.0.0:Genome.FixedList.Functions.double g_at6t
                      (g_at6t, gpart_at7X) = Genome.Split.split genome_at7V
                    in
                      [Reaction
                         (\ x_at8G
                            -> let
                                 c_MiRs_at8J = ((toVector x_at8G) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at8H = ((toVector x_at8G) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at6C
                                  * ((p_at6Q + ((c_NPTB_at8H / p_at6E) ** p_at6G))
                                     / (((1 + p_at6Q) + ((c_NPTB_at8H / p_at6E) ** p_at6G))
                                        + (((p_at6u / p_at6I) ** p_at6K)
                                           + ((c_MiRs_at8J / p_at6M) ** p_at6O))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at8K
                            -> let
                                 c_PTB_at8O = ((toVector x_at8K) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at8N = ((toVector x_at8K) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at8L = ((toVector x_at8K) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at6S
                                  * ((p_at76 + ((c_RESTc_at8L / p_at6U) ** p_at6W))
                                     / (((1 + p_at76) + ((c_RESTc_at8L / p_at6U) ** p_at6W))
                                        + (((c_MiRs_at8N / p_at6Y) ** p_at70)
                                           + ((c_PTB_at8O / p_at72) ** p_at74))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at8P
                            -> let c_RESTc_at8Q = ((toVector x_at8P) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at78
                                  * (p_at7i
                                     / ((1 + p_at7i) + ((c_RESTc_at8Q / p_at7e) ** p_at7g)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at8R
                            -> let
                                 c_MiRs_at8U = ((toVector x_at8R) Data.Vector.Unboxed.! 2)
                                 c_PTB_at8S = ((toVector x_at8R) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at7k
                                  * ((p_at7y + ((c_PTB_at8S / p_at7m) ** p_at7o))
                                     / (((1 + p_at7y) + ((c_PTB_at8S / p_at7m) ** p_at7o))
                                        + ((c_MiRs_at8U / p_at7u) ** p_at7w)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at8V
                            -> let
                                 c_RESTc_at8Y = ((toVector x_at8V) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at8W = ((toVector x_at8V) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at7A
                                  * ((p_at7K + ((c_MiRs_at8W / p_at7C) ** p_at7E))
                                     / (((1 + p_at7K) + ((c_MiRs_at8W / p_at7C) ** p_at7E))
                                        + ((c_RESTc_at8Y / p_at7G) ** p_at7I)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at8Z
                            -> let c_PTB_at90 = ((toVector x_at8Z) Data.Vector.Unboxed.! 0)
                               in (p_at7M * c_PTB_at90))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at91
                            -> let c_NPTB_at92 = ((toVector x_at91) Data.Vector.Unboxed.! 1)
                               in (p_at7O * c_NPTB_at92))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at93
                            -> let c_MiRs_at94 = ((toVector x_at93) Data.Vector.Unboxed.! 2)
                               in (p_at7Q * c_MiRs_at94))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at95
                            -> let c_RESTc_at96 = ((toVector x_at95) Data.Vector.Unboxed.! 3)
                               in (p_at7S * c_RESTc_at96))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at97
                            -> let
                                 c_EndoNeuroTFs_at98 = ((toVector x_at97) Data.Vector.Unboxed.! 4)
                               in (p_at7U * c_EndoNeuroTFs_at98))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121670",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121672",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121674",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121676",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121678",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121684",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121686",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121696",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121698",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121700",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121702",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121704",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121705",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121706",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121707",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121708",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121710",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121712",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121714",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121716",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121718",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121720",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121722",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121724",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121726",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121728",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121730",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at7V
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at9R
                            p_at7U = code-0.1.0.0:Genome.FixedList.Functions.double g_at7T
                            (g_at7T, gpart_at9R) = Genome.Split.split gpart_at9Q
                            p_at7S = code-0.1.0.0:Genome.FixedList.Functions.double g_at7R
                            (g_at7R, gpart_at9Q) = Genome.Split.split gpart_at9P
                            p_at7Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7P
                            (g_at7P, gpart_at9P) = Genome.Split.split gpart_at9O
                            p_at7O = code-0.1.0.0:Genome.FixedList.Functions.double g_at7N
                            (g_at7N, gpart_at9O) = Genome.Split.split gpart_at9N
                            p_at7M = code-0.1.0.0:Genome.FixedList.Functions.double g_at7L
                            (g_at7L, gpart_at9N) = Genome.Split.split gpart_at9M
                            p_at7K = code-0.1.0.0:Genome.FixedList.Functions.double g_at7J
                            (g_at7J, gpart_at9M) = Genome.Split.split gpart_at9L
                            p_at7I = Functions.belowten' g_at7H
                            (g_at7H, gpart_at9L) = Genome.Split.split gpart_at9K
                            p_at7G = code-0.1.0.0:Genome.FixedList.Functions.double g_at7F
                            (g_at7F, gpart_at9K) = Genome.Split.split gpart_at9J
                            p_at7E = Functions.belowten' g_at7D
                            (g_at7D, gpart_at9J) = Genome.Split.split gpart_at9I
                            p_at7C = code-0.1.0.0:Genome.FixedList.Functions.double g_at7B
                            (g_at7B, gpart_at9I) = Genome.Split.split gpart_at9H
                            p_at7A = code-0.1.0.0:Genome.FixedList.Functions.double g_at7z
                            (g_at7z, gpart_at9H) = Genome.Split.split gpart_at9G
                            p_at7y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7x
                            (g_at7x, gpart_at9G) = Genome.Split.split gpart_at9F
                            p_at7w = Functions.belowten' g_at7v
                            (g_at7v, gpart_at9F) = Genome.Split.split gpart_at9E
                            p_at7u = code-0.1.0.0:Genome.FixedList.Functions.double g_at7t
                            (g_at7t, gpart_at9E) = Genome.Split.split gpart_at9D
                            p_at7s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7r
                            (g_at7r, gpart_at9D) = Genome.Split.split gpart_at9C
                            p_at7q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7p
                            (g_at7p, gpart_at9C) = Genome.Split.split gpart_at9B
                            p_at7o = Functions.belowten' g_at7n
                            (g_at7n, gpart_at9B) = Genome.Split.split gpart_at9A
                            p_at7m = code-0.1.0.0:Genome.FixedList.Functions.double g_at7l
                            (g_at7l, gpart_at9A) = Genome.Split.split gpart_at9z
                            p_at7k = code-0.1.0.0:Genome.FixedList.Functions.double g_at7j
                            (g_at7j, gpart_at9z) = Genome.Split.split gpart_at9y
                            p_at7i = code-0.1.0.0:Genome.FixedList.Functions.double g_at7h
                            (g_at7h, gpart_at9y) = Genome.Split.split gpart_at9x
                            p_at7g = Functions.belowten' g_at7f
                            (g_at7f, gpart_at9x) = Genome.Split.split gpart_at9w
                            p_at7e = code-0.1.0.0:Genome.FixedList.Functions.double g_at7d
                            (g_at7d, gpart_at9w) = Genome.Split.split gpart_at9v
                            p_at7c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7b
                            (g_at7b, gpart_at9v) = Genome.Split.split gpart_at9u
                            p_at7a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at79
                            (g_at79, gpart_at9u) = Genome.Split.split gpart_at9t
                            p_at78 = code-0.1.0.0:Genome.FixedList.Functions.double g_at77
                            (g_at77, gpart_at9t) = Genome.Split.split gpart_at9s
                            p_at76 = code-0.1.0.0:Genome.FixedList.Functions.double g_at75
                            (g_at75, gpart_at9s) = Genome.Split.split gpart_at9r
                            p_at74 = Functions.belowten' g_at73
                            (g_at73, gpart_at9r) = Genome.Split.split gpart_at9q
                            p_at72 = code-0.1.0.0:Genome.FixedList.Functions.double g_at71
                            (g_at71, gpart_at9q) = Genome.Split.split gpart_at9p
                            p_at70 = Functions.belowten' g_at6Z
                            (g_at6Z, gpart_at9p) = Genome.Split.split gpart_at9o
                            p_at6Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6X
                            (g_at6X, gpart_at9o) = Genome.Split.split gpart_at9n
                            p_at6W = Functions.belowten' g_at6V
                            (g_at6V, gpart_at9n) = Genome.Split.split gpart_at9m
                            p_at6U = code-0.1.0.0:Genome.FixedList.Functions.double g_at6T
                            (g_at6T, gpart_at9m) = Genome.Split.split gpart_at9l
                            p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                            (g_at6R, gpart_at9l) = Genome.Split.split gpart_at9k
                            p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                            (g_at6P, gpart_at9k) = Genome.Split.split gpart_at9j
                            p_at6O = Functions.belowten' g_at6N
                            (g_at6N, gpart_at9j) = Genome.Split.split gpart_at9i
                            p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                            (g_at6L, gpart_at9i) = Genome.Split.split gpart_at9h
                            p_at6K
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6J
                            (g_at6J, gpart_at9h) = Genome.Split.split gpart_at9g
                            p_at6I
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6H
                            (g_at6H, gpart_at9g) = Genome.Split.split gpart_at9f
                            p_at6G = Functions.belowten' g_at6F
                            (g_at6F, gpart_at9f) = Genome.Split.split gpart_at9e
                            p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                            (g_at6D, gpart_at9e) = Genome.Split.split gpart_at9d
                            p_at6C = code-0.1.0.0:Genome.FixedList.Functions.double g_at6B
                            (g_at6B, gpart_at9d) = Genome.Split.split gpart_at9c
                            p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                            (g_at6z, gpart_at9c) = Genome.Split.split gpart_at9b
                            p_at6y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6x
                            (g_at6x, gpart_at9b) = Genome.Split.split gpart_at9a
                            p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                            (g_at6v, gpart_at9a) = Genome.Split.split gpart_at99
                            p_at6u = code-0.1.0.0:Genome.FixedList.Functions.double g_at6t
                            (g_at6t, gpart_at99) = Genome.Split.split genome_at7V
                          in
                            \ desc_at7W
                              -> case desc_at7W of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6u)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6w)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6y)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6A)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6C)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6E)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6G)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6I)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6K)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6M)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6O)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Q)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6S)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6U)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at70)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at72)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at74)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at76)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at78)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7a)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7c)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7e)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7g)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7i)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7k)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7m)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7o)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7q)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7s)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7u)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7w)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7y)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7A)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7C)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7E)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7G)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7I)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7K)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7M)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7O)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7Q)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7S)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7U)
                                   _ -> Nothing }}
