src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1Zdm
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZdZ
                      p_a1Zdl = double g_a1Zdk
                      (g_a1Zdk, gpart_a1ZdZ) = Genome.Split.split gpart_a1ZdY
                      p_a1Zdj = double g_a1Zdi
                      (g_a1Zdi, gpart_a1ZdY) = Genome.Split.split gpart_a1ZdX
                      p_a1Zdh = double g_a1Zdg
                      (g_a1Zdg, gpart_a1ZdX) = Genome.Split.split gpart_a1ZdW
                      p_a1Zdf = double g_a1Zde
                      (g_a1Zde, gpart_a1ZdW) = Genome.Split.split gpart_a1ZdV
                      p_a1Zdd = double g_a1Zdc
                      (g_a1Zdc, gpart_a1ZdV) = Genome.Split.split gpart_a1ZdU
                      p_a1Zdb = Functions.belowten' g_a1Zda
                      (g_a1Zda, gpart_a1ZdU) = Genome.Split.split gpart_a1ZdT
                      p_a1Zd9 = double g_a1Zd8
                      (g_a1Zd8, gpart_a1ZdT) = Genome.Split.split gpart_a1ZdS
                      p_a1Zd7 = double g_a1Zd6
                      (g_a1Zd6, gpart_a1ZdS) = Genome.Split.split gpart_a1ZdR
                      p_a1Zd5 = double g_a1Zd4
                      (g_a1Zd4, gpart_a1ZdR) = Genome.Split.split gpart_a1ZdQ
                      p_a1Zd3 = Functions.belowten' g_a1Zd2
                      (g_a1Zd2, gpart_a1ZdQ) = Genome.Split.split gpart_a1ZdP
                      p_a1Zd1 = double g_a1Zd0
                      (g_a1Zd0, gpart_a1ZdP) = Genome.Split.split gpart_a1ZdO
                      p_a1ZcZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcY
                      (g_a1ZcY, gpart_a1ZdO) = Genome.Split.split gpart_a1ZdN
                      p_a1ZcX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcW
                      (g_a1ZcW, gpart_a1ZdN) = Genome.Split.split gpart_a1ZdM
                      p_a1ZcV = Functions.belowten' g_a1ZcU
                      (g_a1ZcU, gpart_a1ZdM) = Genome.Split.split gpart_a1ZdL
                      p_a1ZcT = double g_a1ZcS
                      (g_a1ZcS, gpart_a1ZdL) = Genome.Split.split gpart_a1ZdK
                      p_a1ZcR = double g_a1ZcQ
                      (g_a1ZcQ, gpart_a1ZdK) = Genome.Split.split gpart_a1ZdJ
                      p_a1ZcP = double g_a1ZcO
                      (g_a1ZcO, gpart_a1ZdJ) = Genome.Split.split gpart_a1ZdI
                      p_a1ZcN = Functions.belowten' g_a1ZcM
                      (g_a1ZcM, gpart_a1ZdI) = Genome.Split.split gpart_a1ZdH
                      p_a1ZcL = double g_a1ZcK
                      (g_a1ZcK, gpart_a1ZdH) = Genome.Split.split gpart_a1ZdG
                      p_a1ZcJ = Functions.belowten' g_a1ZcI
                      (g_a1ZcI, gpart_a1ZdG) = Genome.Split.split gpart_a1ZdF
                      p_a1ZcH = double g_a1ZcG
                      (g_a1ZcG, gpart_a1ZdF) = Genome.Split.split gpart_a1ZdE
                      p_a1ZcF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcE
                      (g_a1ZcE, gpart_a1ZdE) = Genome.Split.split gpart_a1ZdD
                      p_a1ZcD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcC
                      (g_a1ZcC, gpart_a1ZdD) = Genome.Split.split gpart_a1ZdC
                      p_a1ZcB = double g_a1ZcA
                      (g_a1ZcA, gpart_a1ZdC) = Genome.Split.split gpart_a1ZdB
                      p_a1Zcz = Functions.belowten' g_a1Zcy
                      (g_a1Zcy, gpart_a1ZdB) = Genome.Split.split gpart_a1ZdA
                      p_a1Zcx = double g_a1Zcw
                      (g_a1Zcw, gpart_a1ZdA) = Genome.Split.split gpart_a1Zdz
                      p_a1Zcv = Functions.belowten' g_a1Zcu
                      (g_a1Zcu, gpart_a1Zdz) = Genome.Split.split gpart_a1Zdy
                      p_a1Zct = double g_a1Zcs
                      (g_a1Zcs, gpart_a1Zdy) = Genome.Split.split gpart_a1Zdx
                      p_a1Zcr = double g_a1Zcq
                      (g_a1Zcq, gpart_a1Zdx) = Genome.Split.split gpart_a1Zdw
                      p_a1Zcp = Functions.belowten' g_a1Zco
                      (g_a1Zco, gpart_a1Zdw) = Genome.Split.split gpart_a1Zdv
                      p_a1Zcn = double g_a1Zcm
                      (g_a1Zcm, gpart_a1Zdv) = Genome.Split.split gpart_a1Zdu
                      p_a1Zcl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zck
                      (g_a1Zck, gpart_a1Zdu) = Genome.Split.split gpart_a1Zdt
                      p_a1Zcj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zci
                      (g_a1Zci, gpart_a1Zdt) = Genome.Split.split gpart_a1Zds
                      p_a1Zch = double g_a1Zcg
                      (g_a1Zcg, gpart_a1Zds) = Genome.Split.split gpart_a1Zdr
                      p_a1Zcf = double g_a1Zce
                      (g_a1Zce, gpart_a1Zdr) = Genome.Split.split gpart_a1Zdq
                      p_a1Zcd = double g_a1Zcc
                      (g_a1Zcc, gpart_a1Zdq) = Genome.Split.split gpart_a1Zdp
                      p_a1Zcb = double g_a1Zca
                      (g_a1Zca, gpart_a1Zdp) = Genome.Split.split gpart_a1Zdo
                      p_a1Zc9 = double g_a1Zc8
                      (g_a1Zc8, gpart_a1Zdo) = Genome.Split.split genome_a1Zdm
                    in  \ x_a1Ze0
                          -> let
                               c_PTB_a1Ze3
                                 = ((Data.Fixed.Vector.toVector x_a1Ze0) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1Ze1
                                 = ((Data.Fixed.Vector.toVector x_a1Ze0) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Ze7
                                 = ((Data.Fixed.Vector.toVector x_a1Ze0) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zea
                                 = ((Data.Fixed.Vector.toVector x_a1Ze0) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zek
                                 = ((Data.Fixed.Vector.toVector x_a1Ze0) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zch / (1 + ((c_MiRs_a1Ze1 / p_a1Zcn) ** p_a1Zcp)))
                                    + (negate (p_a1Zdd * c_PTB_a1Ze3))),
                                   ((p_a1Zcr
                                     / (1
                                        + (((c_MiRs_a1Ze1 / p_a1Zct) ** p_a1Zcv)
                                           + ((c_PTB_a1Ze3 / p_a1Zcx) ** p_a1Zcz))))
                                    + (negate (p_a1Zdf * c_NPTB_a1Ze7))),
                                   ((p_a1ZcB
                                     * ((p_a1ZcP
                                         + (((p_a1Zcd / p_a1ZcD) ** p_a1ZcF)
                                            + ((c_PTB_a1Ze3 / p_a1ZcH) ** p_a1ZcJ)))
                                        / (((1 + p_a1ZcP)
                                            + (((p_a1Zcd / p_a1ZcD) ** p_a1ZcF)
                                               + ((c_PTB_a1Ze3 / p_a1ZcH) ** p_a1ZcJ)))
                                           + ((c_RESTc_a1Zea / p_a1ZcL) ** p_a1ZcN))))
                                    + (negate (p_a1Zdh * c_MiRs_a1Ze1))),
                                   ((p_a1ZcR
                                     * ((p_a1Zd5 + ((c_PTB_a1Ze3 / p_a1ZcT) ** p_a1ZcV))
                                        / (((1 + p_a1Zd5) + ((c_PTB_a1Ze3 / p_a1ZcT) ** p_a1ZcV))
                                           + (((p_a1Zc9 / p_a1ZcX) ** p_a1ZcZ)
                                              + ((c_MiRs_a1Ze1 / p_a1Zd1) ** p_a1Zd3)))))
                                    + (negate (p_a1Zdj * c_RESTc_a1Zea))),
                                   ((p_a1Zd7 / (1 + ((c_RESTc_a1Zea / p_a1Zd9) ** p_a1Zdb)))
                                    + (negate (p_a1Zdl * c_EndoNeuroTFs_a1Zek)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483356",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483357",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483358",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483359",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483361",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483363",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483364",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483365",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483366",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483367",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483368",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483369",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483371",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483373",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483379",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483381",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483387",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483389",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483407",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483409",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zdm
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZeW
                            p_a1Zdl = double g_a1Zdk
                            (g_a1Zdk, gpart_a1ZeW) = Genome.Split.split gpart_a1ZeV
                            p_a1Zdj = double g_a1Zdi
                            (g_a1Zdi, gpart_a1ZeV) = Genome.Split.split gpart_a1ZeU
                            p_a1Zdh = double g_a1Zdg
                            (g_a1Zdg, gpart_a1ZeU) = Genome.Split.split gpart_a1ZeT
                            p_a1Zdf = double g_a1Zde
                            (g_a1Zde, gpart_a1ZeT) = Genome.Split.split gpart_a1ZeS
                            p_a1Zdd = double g_a1Zdc
                            (g_a1Zdc, gpart_a1ZeS) = Genome.Split.split gpart_a1ZeR
                            p_a1Zdb = Functions.belowten' g_a1Zda
                            (g_a1Zda, gpart_a1ZeR) = Genome.Split.split gpart_a1ZeQ
                            p_a1Zd9 = double g_a1Zd8
                            (g_a1Zd8, gpart_a1ZeQ) = Genome.Split.split gpart_a1ZeP
                            p_a1Zd7 = double g_a1Zd6
                            (g_a1Zd6, gpart_a1ZeP) = Genome.Split.split gpart_a1ZeO
                            p_a1Zd5 = double g_a1Zd4
                            (g_a1Zd4, gpart_a1ZeO) = Genome.Split.split gpart_a1ZeN
                            p_a1Zd3 = Functions.belowten' g_a1Zd2
                            (g_a1Zd2, gpart_a1ZeN) = Genome.Split.split gpart_a1ZeM
                            p_a1Zd1 = double g_a1Zd0
                            (g_a1Zd0, gpart_a1ZeM) = Genome.Split.split gpart_a1ZeL
                            p_a1ZcZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcY
                            (g_a1ZcY, gpart_a1ZeL) = Genome.Split.split gpart_a1ZeK
                            p_a1ZcX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcW
                            (g_a1ZcW, gpart_a1ZeK) = Genome.Split.split gpart_a1ZeJ
                            p_a1ZcV = Functions.belowten' g_a1ZcU
                            (g_a1ZcU, gpart_a1ZeJ) = Genome.Split.split gpart_a1ZeI
                            p_a1ZcT = double g_a1ZcS
                            (g_a1ZcS, gpart_a1ZeI) = Genome.Split.split gpart_a1ZeH
                            p_a1ZcR = double g_a1ZcQ
                            (g_a1ZcQ, gpart_a1ZeH) = Genome.Split.split gpart_a1ZeG
                            p_a1ZcP = double g_a1ZcO
                            (g_a1ZcO, gpart_a1ZeG) = Genome.Split.split gpart_a1ZeF
                            p_a1ZcN = Functions.belowten' g_a1ZcM
                            (g_a1ZcM, gpart_a1ZeF) = Genome.Split.split gpart_a1ZeE
                            p_a1ZcL = double g_a1ZcK
                            (g_a1ZcK, gpart_a1ZeE) = Genome.Split.split gpart_a1ZeD
                            p_a1ZcJ = Functions.belowten' g_a1ZcI
                            (g_a1ZcI, gpart_a1ZeD) = Genome.Split.split gpart_a1ZeC
                            p_a1ZcH = double g_a1ZcG
                            (g_a1ZcG, gpart_a1ZeC) = Genome.Split.split gpart_a1ZeB
                            p_a1ZcF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcE
                            (g_a1ZcE, gpart_a1ZeB) = Genome.Split.split gpart_a1ZeA
                            p_a1ZcD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZcC
                            (g_a1ZcC, gpart_a1ZeA) = Genome.Split.split gpart_a1Zez
                            p_a1ZcB = double g_a1ZcA
                            (g_a1ZcA, gpart_a1Zez) = Genome.Split.split gpart_a1Zey
                            p_a1Zcz = Functions.belowten' g_a1Zcy
                            (g_a1Zcy, gpart_a1Zey) = Genome.Split.split gpart_a1Zex
                            p_a1Zcx = double g_a1Zcw
                            (g_a1Zcw, gpart_a1Zex) = Genome.Split.split gpart_a1Zew
                            p_a1Zcv = Functions.belowten' g_a1Zcu
                            (g_a1Zcu, gpart_a1Zew) = Genome.Split.split gpart_a1Zev
                            p_a1Zct = double g_a1Zcs
                            (g_a1Zcs, gpart_a1Zev) = Genome.Split.split gpart_a1Zeu
                            p_a1Zcr = double g_a1Zcq
                            (g_a1Zcq, gpart_a1Zeu) = Genome.Split.split gpart_a1Zet
                            p_a1Zcp = Functions.belowten' g_a1Zco
                            (g_a1Zco, gpart_a1Zet) = Genome.Split.split gpart_a1Zes
                            p_a1Zcn = double g_a1Zcm
                            (g_a1Zcm, gpart_a1Zes) = Genome.Split.split gpart_a1Zer
                            p_a1Zcl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zck
                            (g_a1Zck, gpart_a1Zer) = Genome.Split.split gpart_a1Zeq
                            p_a1Zcj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zci
                            (g_a1Zci, gpart_a1Zeq) = Genome.Split.split gpart_a1Zep
                            p_a1Zch = double g_a1Zcg
                            (g_a1Zcg, gpart_a1Zep) = Genome.Split.split gpart_a1Zeo
                            p_a1Zcf = double g_a1Zce
                            (g_a1Zce, gpart_a1Zeo) = Genome.Split.split gpart_a1Zen
                            p_a1Zcd = double g_a1Zcc
                            (g_a1Zcc, gpart_a1Zen) = Genome.Split.split gpart_a1Zem
                            p_a1Zcb = double g_a1Zca
                            (g_a1Zca, gpart_a1Zem) = Genome.Split.split gpart_a1Zel
                            p_a1Zc9 = double g_a1Zc8
                            (g_a1Zc8, gpart_a1Zel) = Genome.Split.split genome_a1Zdm
                          in
                            \ desc_a1Zdn
                              -> case desc_a1Zdn of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zc9)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcb)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcd)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcf)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zch)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcj)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcl)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcn)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcp)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcr)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zct)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcv)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcx)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zcz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcB)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcD)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcF)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcH)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcJ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcL)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcN)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcP)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcR)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcT)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcV)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcX)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZcZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd1)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd3)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd5)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd7)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd9)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdb)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdd)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdf)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdh)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdj)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdl)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1Zhk
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZhX
                      p_a1Zhj = double g_a1Zhi
                      (g_a1Zhi, gpart_a1ZhX) = Genome.Split.split gpart_a1ZhW
                      p_a1Zhh = double g_a1Zhg
                      (g_a1Zhg, gpart_a1ZhW) = Genome.Split.split gpart_a1ZhV
                      p_a1Zhf = double g_a1Zhe
                      (g_a1Zhe, gpart_a1ZhV) = Genome.Split.split gpart_a1ZhU
                      p_a1Zhd = double g_a1Zhc
                      (g_a1Zhc, gpart_a1ZhU) = Genome.Split.split gpart_a1ZhT
                      p_a1Zhb = double g_a1Zha
                      (g_a1Zha, gpart_a1ZhT) = Genome.Split.split gpart_a1ZhS
                      p_a1Zh9 = Functions.belowten' g_a1Zh8
                      (g_a1Zh8, gpart_a1ZhS) = Genome.Split.split gpart_a1ZhR
                      p_a1Zh7 = double g_a1Zh6
                      (g_a1Zh6, gpart_a1ZhR) = Genome.Split.split gpart_a1ZhQ
                      p_a1Zh5 = double g_a1Zh4
                      (g_a1Zh4, gpart_a1ZhQ) = Genome.Split.split gpart_a1ZhP
                      p_a1Zh3 = double g_a1Zh2
                      (g_a1Zh2, gpart_a1ZhP) = Genome.Split.split gpart_a1ZhO
                      p_a1Zh1 = Functions.belowten' g_a1Zh0
                      (g_a1Zh0, gpart_a1ZhO) = Genome.Split.split gpart_a1ZhN
                      p_a1ZgZ = double g_a1ZgY
                      (g_a1ZgY, gpart_a1ZhN) = Genome.Split.split gpart_a1ZhM
                      p_a1ZgX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgW
                      (g_a1ZgW, gpart_a1ZhM) = Genome.Split.split gpart_a1ZhL
                      p_a1ZgV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgU
                      (g_a1ZgU, gpart_a1ZhL) = Genome.Split.split gpart_a1ZhK
                      p_a1ZgT = Functions.belowten' g_a1ZgS
                      (g_a1ZgS, gpart_a1ZhK) = Genome.Split.split gpart_a1ZhJ
                      p_a1ZgR = double g_a1ZgQ
                      (g_a1ZgQ, gpart_a1ZhJ) = Genome.Split.split gpart_a1ZhI
                      p_a1ZgP = double g_a1ZgO
                      (g_a1ZgO, gpart_a1ZhI) = Genome.Split.split gpart_a1ZhH
                      p_a1ZgN = double g_a1ZgM
                      (g_a1ZgM, gpart_a1ZhH) = Genome.Split.split gpart_a1ZhG
                      p_a1ZgL = Functions.belowten' g_a1ZgK
                      (g_a1ZgK, gpart_a1ZhG) = Genome.Split.split gpart_a1ZhF
                      p_a1ZgJ = double g_a1ZgI
                      (g_a1ZgI, gpart_a1ZhF) = Genome.Split.split gpart_a1ZhE
                      p_a1ZgH = Functions.belowten' g_a1ZgG
                      (g_a1ZgG, gpart_a1ZhE) = Genome.Split.split gpart_a1ZhD
                      p_a1ZgF = double g_a1ZgE
                      (g_a1ZgE, gpart_a1ZhD) = Genome.Split.split gpart_a1ZhC
                      p_a1ZgD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgC
                      (g_a1ZgC, gpart_a1ZhC) = Genome.Split.split gpart_a1ZhB
                      p_a1ZgB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgA
                      (g_a1ZgA, gpart_a1ZhB) = Genome.Split.split gpart_a1ZhA
                      p_a1Zgz = double g_a1Zgy
                      (g_a1Zgy, gpart_a1ZhA) = Genome.Split.split gpart_a1Zhz
                      p_a1Zgx = Functions.belowten' g_a1Zgw
                      (g_a1Zgw, gpart_a1Zhz) = Genome.Split.split gpart_a1Zhy
                      p_a1Zgv = double g_a1Zgu
                      (g_a1Zgu, gpart_a1Zhy) = Genome.Split.split gpart_a1Zhx
                      p_a1Zgt = Functions.belowten' g_a1Zgs
                      (g_a1Zgs, gpart_a1Zhx) = Genome.Split.split gpart_a1Zhw
                      p_a1Zgr = double g_a1Zgq
                      (g_a1Zgq, gpart_a1Zhw) = Genome.Split.split gpart_a1Zhv
                      p_a1Zgp = double g_a1Zgo
                      (g_a1Zgo, gpart_a1Zhv) = Genome.Split.split gpart_a1Zhu
                      p_a1Zgn = Functions.belowten' g_a1Zgm
                      (g_a1Zgm, gpart_a1Zhu) = Genome.Split.split gpart_a1Zht
                      p_a1Zgl = double g_a1Zgk
                      (g_a1Zgk, gpart_a1Zht) = Genome.Split.split gpart_a1Zhs
                      p_a1Zgj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgi
                      (g_a1Zgi, gpart_a1Zhs) = Genome.Split.split gpart_a1Zhr
                      p_a1Zgh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgg
                      (g_a1Zgg, gpart_a1Zhr) = Genome.Split.split gpart_a1Zhq
                      p_a1Zgf = double g_a1Zge
                      (g_a1Zge, gpart_a1Zhq) = Genome.Split.split gpart_a1Zhp
                      p_a1Zgd = double g_a1Zgc
                      (g_a1Zgc, gpart_a1Zhp) = Genome.Split.split gpart_a1Zho
                      p_a1Zgb = double g_a1Zga
                      (g_a1Zga, gpart_a1Zho) = Genome.Split.split gpart_a1Zhn
                      p_a1Zg9 = double g_a1Zg8
                      (g_a1Zg8, gpart_a1Zhn) = Genome.Split.split gpart_a1Zhm
                      p_a1Zg7 = double g_a1Zg6
                      (g_a1Zg6, gpart_a1Zhm) = Genome.Split.split genome_a1Zhk
                    in  \ x_a1ZhY
                          -> let
                               c_PTB_a1Zi1
                                 = ((Data.Fixed.Vector.toVector x_a1ZhY) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZhZ
                                 = ((Data.Fixed.Vector.toVector x_a1ZhY) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zi5
                                 = ((Data.Fixed.Vector.toVector x_a1ZhY) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zi8
                                 = ((Data.Fixed.Vector.toVector x_a1ZhY) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zii
                                 = ((Data.Fixed.Vector.toVector x_a1ZhY) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zgf / (1 + ((c_MiRs_a1ZhZ / p_a1Zgl) ** p_a1Zgn)))
                                    + (negate (p_a1Zhb * c_PTB_a1Zi1))),
                                   ((p_a1Zgp
                                     / (1
                                        + (((c_MiRs_a1ZhZ / p_a1Zgr) ** p_a1Zgt)
                                           + ((c_PTB_a1Zi1 / p_a1Zgv) ** p_a1Zgx))))
                                    + (negate (p_a1Zhd * c_NPTB_a1Zi5))),
                                   ((p_a1Zgz
                                     * ((p_a1ZgN + ((c_PTB_a1Zi1 / p_a1ZgF) ** p_a1ZgH))
                                        / (((1 + p_a1ZgN) + ((c_PTB_a1Zi1 / p_a1ZgF) ** p_a1ZgH))
                                           + ((c_RESTc_a1Zi8 / p_a1ZgJ) ** p_a1ZgL))))
                                    + (negate (p_a1Zhf * c_MiRs_a1ZhZ))),
                                   ((p_a1ZgP
                                     * ((p_a1Zh3 + ((c_PTB_a1Zi1 / p_a1ZgR) ** p_a1ZgT))
                                        / (((1 + p_a1Zh3) + ((c_PTB_a1Zi1 / p_a1ZgR) ** p_a1ZgT))
                                           + (((p_a1Zg7 / p_a1ZgV) ** p_a1ZgX)
                                              + ((c_MiRs_a1ZhZ / p_a1ZgZ) ** p_a1Zh1)))))
                                    + (negate (p_a1Zhh * c_RESTc_a1Zi8))),
                                   ((p_a1Zh5 / (1 + ((c_RESTc_a1Zi8 / p_a1Zh7) ** p_a1Zh9)))
                                    + (negate (p_a1Zhj * c_EndoNeuroTFs_a1Zii)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483613",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483615",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483633",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483635",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483647",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483649",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483651",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483653",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483655",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zhk
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZiU
                            p_a1Zhj = double g_a1Zhi
                            (g_a1Zhi, gpart_a1ZiU) = Genome.Split.split gpart_a1ZiT
                            p_a1Zhh = double g_a1Zhg
                            (g_a1Zhg, gpart_a1ZiT) = Genome.Split.split gpart_a1ZiS
                            p_a1Zhf = double g_a1Zhe
                            (g_a1Zhe, gpart_a1ZiS) = Genome.Split.split gpart_a1ZiR
                            p_a1Zhd = double g_a1Zhc
                            (g_a1Zhc, gpart_a1ZiR) = Genome.Split.split gpart_a1ZiQ
                            p_a1Zhb = double g_a1Zha
                            (g_a1Zha, gpart_a1ZiQ) = Genome.Split.split gpart_a1ZiP
                            p_a1Zh9 = Functions.belowten' g_a1Zh8
                            (g_a1Zh8, gpart_a1ZiP) = Genome.Split.split gpart_a1ZiO
                            p_a1Zh7 = double g_a1Zh6
                            (g_a1Zh6, gpart_a1ZiO) = Genome.Split.split gpart_a1ZiN
                            p_a1Zh5 = double g_a1Zh4
                            (g_a1Zh4, gpart_a1ZiN) = Genome.Split.split gpart_a1ZiM
                            p_a1Zh3 = double g_a1Zh2
                            (g_a1Zh2, gpart_a1ZiM) = Genome.Split.split gpart_a1ZiL
                            p_a1Zh1 = Functions.belowten' g_a1Zh0
                            (g_a1Zh0, gpart_a1ZiL) = Genome.Split.split gpart_a1ZiK
                            p_a1ZgZ = double g_a1ZgY
                            (g_a1ZgY, gpart_a1ZiK) = Genome.Split.split gpart_a1ZiJ
                            p_a1ZgX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgW
                            (g_a1ZgW, gpart_a1ZiJ) = Genome.Split.split gpart_a1ZiI
                            p_a1ZgV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgU
                            (g_a1ZgU, gpart_a1ZiI) = Genome.Split.split gpart_a1ZiH
                            p_a1ZgT = Functions.belowten' g_a1ZgS
                            (g_a1ZgS, gpart_a1ZiH) = Genome.Split.split gpart_a1ZiG
                            p_a1ZgR = double g_a1ZgQ
                            (g_a1ZgQ, gpart_a1ZiG) = Genome.Split.split gpart_a1ZiF
                            p_a1ZgP = double g_a1ZgO
                            (g_a1ZgO, gpart_a1ZiF) = Genome.Split.split gpart_a1ZiE
                            p_a1ZgN = double g_a1ZgM
                            (g_a1ZgM, gpart_a1ZiE) = Genome.Split.split gpart_a1ZiD
                            p_a1ZgL = Functions.belowten' g_a1ZgK
                            (g_a1ZgK, gpart_a1ZiD) = Genome.Split.split gpart_a1ZiC
                            p_a1ZgJ = double g_a1ZgI
                            (g_a1ZgI, gpart_a1ZiC) = Genome.Split.split gpart_a1ZiB
                            p_a1ZgH = Functions.belowten' g_a1ZgG
                            (g_a1ZgG, gpart_a1ZiB) = Genome.Split.split gpart_a1ZiA
                            p_a1ZgF = double g_a1ZgE
                            (g_a1ZgE, gpart_a1ZiA) = Genome.Split.split gpart_a1Ziz
                            p_a1ZgD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgC
                            (g_a1ZgC, gpart_a1Ziz) = Genome.Split.split gpart_a1Ziy
                            p_a1ZgB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgA
                            (g_a1ZgA, gpart_a1Ziy) = Genome.Split.split gpart_a1Zix
                            p_a1Zgz = double g_a1Zgy
                            (g_a1Zgy, gpart_a1Zix) = Genome.Split.split gpart_a1Ziw
                            p_a1Zgx = Functions.belowten' g_a1Zgw
                            (g_a1Zgw, gpart_a1Ziw) = Genome.Split.split gpart_a1Ziv
                            p_a1Zgv = double g_a1Zgu
                            (g_a1Zgu, gpart_a1Ziv) = Genome.Split.split gpart_a1Ziu
                            p_a1Zgt = Functions.belowten' g_a1Zgs
                            (g_a1Zgs, gpart_a1Ziu) = Genome.Split.split gpart_a1Zit
                            p_a1Zgr = double g_a1Zgq
                            (g_a1Zgq, gpart_a1Zit) = Genome.Split.split gpart_a1Zis
                            p_a1Zgp = double g_a1Zgo
                            (g_a1Zgo, gpart_a1Zis) = Genome.Split.split gpart_a1Zir
                            p_a1Zgn = Functions.belowten' g_a1Zgm
                            (g_a1Zgm, gpart_a1Zir) = Genome.Split.split gpart_a1Ziq
                            p_a1Zgl = double g_a1Zgk
                            (g_a1Zgk, gpart_a1Ziq) = Genome.Split.split gpart_a1Zip
                            p_a1Zgj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgi
                            (g_a1Zgi, gpart_a1Zip) = Genome.Split.split gpart_a1Zio
                            p_a1Zgh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgg
                            (g_a1Zgg, gpart_a1Zio) = Genome.Split.split gpart_a1Zin
                            p_a1Zgf = double g_a1Zge
                            (g_a1Zge, gpart_a1Zin) = Genome.Split.split gpart_a1Zim
                            p_a1Zgd = double g_a1Zgc
                            (g_a1Zgc, gpart_a1Zim) = Genome.Split.split gpart_a1Zil
                            p_a1Zgb = double g_a1Zga
                            (g_a1Zga, gpart_a1Zil) = Genome.Split.split gpart_a1Zik
                            p_a1Zg9 = double g_a1Zg8
                            (g_a1Zg8, gpart_a1Zik) = Genome.Split.split gpart_a1Zij
                            p_a1Zg7 = double g_a1Zg6
                            (g_a1Zg6, gpart_a1Zij) = Genome.Split.split genome_a1Zhk
                          in
                            \ desc_a1Zhl
                              -> case desc_a1Zhl of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg7)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg9)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgb)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgd)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgf)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgh)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgj)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgl)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgn)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgp)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgr)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgt)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgv)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgx)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgz)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgB)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgD)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgF)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgH)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgJ)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgL)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgN)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgP)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgR)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgT)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgV)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgX)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgZ)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh1)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh3)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh5)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh7)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh9)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhb)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhd)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhf)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhh)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhj)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1Zli
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZlV
                      p_a1Zlh = double g_a1Zlg
                      (g_a1Zlg, gpart_a1ZlV) = Genome.Split.split gpart_a1ZlU
                      p_a1Zlf = double g_a1Zle
                      (g_a1Zle, gpart_a1ZlU) = Genome.Split.split gpart_a1ZlT
                      p_a1Zld = double g_a1Zlc
                      (g_a1Zlc, gpart_a1ZlT) = Genome.Split.split gpart_a1ZlS
                      p_a1Zlb = double g_a1Zla
                      (g_a1Zla, gpart_a1ZlS) = Genome.Split.split gpart_a1ZlR
                      p_a1Zl9 = double g_a1Zl8
                      (g_a1Zl8, gpart_a1ZlR) = Genome.Split.split gpart_a1ZlQ
                      p_a1Zl7 = Functions.belowten' g_a1Zl6
                      (g_a1Zl6, gpart_a1ZlQ) = Genome.Split.split gpart_a1ZlP
                      p_a1Zl5 = double g_a1Zl4
                      (g_a1Zl4, gpart_a1ZlP) = Genome.Split.split gpart_a1ZlO
                      p_a1Zl3 = double g_a1Zl2
                      (g_a1Zl2, gpart_a1ZlO) = Genome.Split.split gpart_a1ZlN
                      p_a1Zl1 = double g_a1Zl0
                      (g_a1Zl0, gpart_a1ZlN) = Genome.Split.split gpart_a1ZlM
                      p_a1ZkZ = Functions.belowten' g_a1ZkY
                      (g_a1ZkY, gpart_a1ZlM) = Genome.Split.split gpart_a1ZlL
                      p_a1ZkX = double g_a1ZkW
                      (g_a1ZkW, gpart_a1ZlL) = Genome.Split.split gpart_a1ZlK
                      p_a1ZkV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkU
                      (g_a1ZkU, gpart_a1ZlK) = Genome.Split.split gpart_a1ZlJ
                      p_a1ZkT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkS
                      (g_a1ZkS, gpart_a1ZlJ) = Genome.Split.split gpart_a1ZlI
                      p_a1ZkR = Functions.belowten' g_a1ZkQ
                      (g_a1ZkQ, gpart_a1ZlI) = Genome.Split.split gpart_a1ZlH
                      p_a1ZkP = double g_a1ZkO
                      (g_a1ZkO, gpart_a1ZlH) = Genome.Split.split gpart_a1ZlG
                      p_a1ZkN = double g_a1ZkM
                      (g_a1ZkM, gpart_a1ZlG) = Genome.Split.split gpart_a1ZlF
                      p_a1ZkL = double g_a1ZkK
                      (g_a1ZkK, gpart_a1ZlF) = Genome.Split.split gpart_a1ZlE
                      p_a1ZkJ = Functions.belowten' g_a1ZkI
                      (g_a1ZkI, gpart_a1ZlE) = Genome.Split.split gpart_a1ZlD
                      p_a1ZkH = double g_a1ZkG
                      (g_a1ZkG, gpart_a1ZlD) = Genome.Split.split gpart_a1ZlC
                      p_a1ZkF = Functions.belowten' g_a1ZkE
                      (g_a1ZkE, gpart_a1ZlC) = Genome.Split.split gpart_a1ZlB
                      p_a1ZkD = double g_a1ZkC
                      (g_a1ZkC, gpart_a1ZlB) = Genome.Split.split gpart_a1ZlA
                      p_a1ZkB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkA
                      (g_a1ZkA, gpart_a1ZlA) = Genome.Split.split gpart_a1Zlz
                      p_a1Zkz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zky
                      (g_a1Zky, gpart_a1Zlz) = Genome.Split.split gpart_a1Zly
                      p_a1Zkx = double g_a1Zkw
                      (g_a1Zkw, gpart_a1Zly) = Genome.Split.split gpart_a1Zlx
                      p_a1Zkv = Functions.belowten' g_a1Zku
                      (g_a1Zku, gpart_a1Zlx) = Genome.Split.split gpart_a1Zlw
                      p_a1Zkt = double g_a1Zks
                      (g_a1Zks, gpart_a1Zlw) = Genome.Split.split gpart_a1Zlv
                      p_a1Zkr = Functions.belowten' g_a1Zkq
                      (g_a1Zkq, gpart_a1Zlv) = Genome.Split.split gpart_a1Zlu
                      p_a1Zkp = double g_a1Zko
                      (g_a1Zko, gpart_a1Zlu) = Genome.Split.split gpart_a1Zlt
                      p_a1Zkn = double g_a1Zkm
                      (g_a1Zkm, gpart_a1Zlt) = Genome.Split.split gpart_a1Zls
                      p_a1Zkl = Functions.belowten' g_a1Zkk
                      (g_a1Zkk, gpart_a1Zls) = Genome.Split.split gpart_a1Zlr
                      p_a1Zkj = double g_a1Zki
                      (g_a1Zki, gpart_a1Zlr) = Genome.Split.split gpart_a1Zlq
                      p_a1Zkh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zkg
                      (g_a1Zkg, gpart_a1Zlq) = Genome.Split.split gpart_a1Zlp
                      p_a1Zkf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zke
                      (g_a1Zke, gpart_a1Zlp) = Genome.Split.split gpart_a1Zlo
                      p_a1Zkd = double g_a1Zkc
                      (g_a1Zkc, gpart_a1Zlo) = Genome.Split.split gpart_a1Zln
                      p_a1Zkb = double g_a1Zka
                      (g_a1Zka, gpart_a1Zln) = Genome.Split.split gpart_a1Zlm
                      p_a1Zk9 = double g_a1Zk8
                      (g_a1Zk8, gpart_a1Zlm) = Genome.Split.split gpart_a1Zll
                      p_a1Zk7 = double g_a1Zk6
                      (g_a1Zk6, gpart_a1Zll) = Genome.Split.split gpart_a1Zlk
                      p_a1Zk5 = double g_a1Zk4
                      (g_a1Zk4, gpart_a1Zlk) = Genome.Split.split genome_a1Zli
                    in  \ x_a1ZlW
                          -> let
                               c_PTB_a1ZlZ
                                 = ((Data.Fixed.Vector.toVector x_a1ZlW) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZlX
                                 = ((Data.Fixed.Vector.toVector x_a1ZlW) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zm3
                                 = ((Data.Fixed.Vector.toVector x_a1ZlW) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zm6
                                 = ((Data.Fixed.Vector.toVector x_a1ZlW) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zmg
                                 = ((Data.Fixed.Vector.toVector x_a1ZlW) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zkd / (1 + ((c_MiRs_a1ZlX / p_a1Zkj) ** p_a1Zkl)))
                                    + (negate (p_a1Zl9 * c_PTB_a1ZlZ))),
                                   ((p_a1Zkn
                                     / (1
                                        + (((c_MiRs_a1ZlX / p_a1Zkp) ** p_a1Zkr)
                                           + ((c_PTB_a1ZlZ / p_a1Zkt) ** p_a1Zkv))))
                                    + (negate (p_a1Zlb * c_NPTB_a1Zm3))),
                                   ((p_a1Zkx
                                     * ((p_a1ZkL + ((c_PTB_a1ZlZ / p_a1ZkD) ** p_a1ZkF))
                                        / (((1 + p_a1ZkL) + ((c_PTB_a1ZlZ / p_a1ZkD) ** p_a1ZkF))
                                           + ((c_RESTc_a1Zm6 / p_a1ZkH) ** p_a1ZkJ))))
                                    + (negate (p_a1Zld * c_MiRs_a1ZlX))),
                                   ((p_a1ZkN
                                     * ((p_a1Zl1 + ((c_PTB_a1ZlZ / p_a1ZkP) ** p_a1ZkR))
                                        / (((1 + p_a1Zl1) + ((c_PTB_a1ZlZ / p_a1ZkP) ** p_a1ZkR))
                                           + ((c_MiRs_a1ZlX / p_a1ZkX) ** p_a1ZkZ))))
                                    + (negate (p_a1Zlf * c_RESTc_a1Zm6))),
                                   ((p_a1Zl3 / (1 + ((c_RESTc_a1Zm6 / p_a1Zl5) ** p_a1Zl7)))
                                    + (negate (p_a1Zlh * c_EndoNeuroTFs_a1Zmg)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483859",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483861",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483865",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483879",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483881",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483899",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483901",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zli
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZmS
                            p_a1Zlh = double g_a1Zlg
                            (g_a1Zlg, gpart_a1ZmS) = Genome.Split.split gpart_a1ZmR
                            p_a1Zlf = double g_a1Zle
                            (g_a1Zle, gpart_a1ZmR) = Genome.Split.split gpart_a1ZmQ
                            p_a1Zld = double g_a1Zlc
                            (g_a1Zlc, gpart_a1ZmQ) = Genome.Split.split gpart_a1ZmP
                            p_a1Zlb = double g_a1Zla
                            (g_a1Zla, gpart_a1ZmP) = Genome.Split.split gpart_a1ZmO
                            p_a1Zl9 = double g_a1Zl8
                            (g_a1Zl8, gpart_a1ZmO) = Genome.Split.split gpart_a1ZmN
                            p_a1Zl7 = Functions.belowten' g_a1Zl6
                            (g_a1Zl6, gpart_a1ZmN) = Genome.Split.split gpart_a1ZmM
                            p_a1Zl5 = double g_a1Zl4
                            (g_a1Zl4, gpart_a1ZmM) = Genome.Split.split gpart_a1ZmL
                            p_a1Zl3 = double g_a1Zl2
                            (g_a1Zl2, gpart_a1ZmL) = Genome.Split.split gpart_a1ZmK
                            p_a1Zl1 = double g_a1Zl0
                            (g_a1Zl0, gpart_a1ZmK) = Genome.Split.split gpart_a1ZmJ
                            p_a1ZkZ = Functions.belowten' g_a1ZkY
                            (g_a1ZkY, gpart_a1ZmJ) = Genome.Split.split gpart_a1ZmI
                            p_a1ZkX = double g_a1ZkW
                            (g_a1ZkW, gpart_a1ZmI) = Genome.Split.split gpart_a1ZmH
                            p_a1ZkV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkU
                            (g_a1ZkU, gpart_a1ZmH) = Genome.Split.split gpart_a1ZmG
                            p_a1ZkT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkS
                            (g_a1ZkS, gpart_a1ZmG) = Genome.Split.split gpart_a1ZmF
                            p_a1ZkR = Functions.belowten' g_a1ZkQ
                            (g_a1ZkQ, gpart_a1ZmF) = Genome.Split.split gpart_a1ZmE
                            p_a1ZkP = double g_a1ZkO
                            (g_a1ZkO, gpart_a1ZmE) = Genome.Split.split gpart_a1ZmD
                            p_a1ZkN = double g_a1ZkM
                            (g_a1ZkM, gpart_a1ZmD) = Genome.Split.split gpart_a1ZmC
                            p_a1ZkL = double g_a1ZkK
                            (g_a1ZkK, gpart_a1ZmC) = Genome.Split.split gpart_a1ZmB
                            p_a1ZkJ = Functions.belowten' g_a1ZkI
                            (g_a1ZkI, gpart_a1ZmB) = Genome.Split.split gpart_a1ZmA
                            p_a1ZkH = double g_a1ZkG
                            (g_a1ZkG, gpart_a1ZmA) = Genome.Split.split gpart_a1Zmz
                            p_a1ZkF = Functions.belowten' g_a1ZkE
                            (g_a1ZkE, gpart_a1Zmz) = Genome.Split.split gpart_a1Zmy
                            p_a1ZkD = double g_a1ZkC
                            (g_a1ZkC, gpart_a1Zmy) = Genome.Split.split gpart_a1Zmx
                            p_a1ZkB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkA
                            (g_a1ZkA, gpart_a1Zmx) = Genome.Split.split gpart_a1Zmw
                            p_a1Zkz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zky
                            (g_a1Zky, gpart_a1Zmw) = Genome.Split.split gpart_a1Zmv
                            p_a1Zkx = double g_a1Zkw
                            (g_a1Zkw, gpart_a1Zmv) = Genome.Split.split gpart_a1Zmu
                            p_a1Zkv = Functions.belowten' g_a1Zku
                            (g_a1Zku, gpart_a1Zmu) = Genome.Split.split gpart_a1Zmt
                            p_a1Zkt = double g_a1Zks
                            (g_a1Zks, gpart_a1Zmt) = Genome.Split.split gpart_a1Zms
                            p_a1Zkr = Functions.belowten' g_a1Zkq
                            (g_a1Zkq, gpart_a1Zms) = Genome.Split.split gpart_a1Zmr
                            p_a1Zkp = double g_a1Zko
                            (g_a1Zko, gpart_a1Zmr) = Genome.Split.split gpart_a1Zmq
                            p_a1Zkn = double g_a1Zkm
                            (g_a1Zkm, gpart_a1Zmq) = Genome.Split.split gpart_a1Zmp
                            p_a1Zkl = Functions.belowten' g_a1Zkk
                            (g_a1Zkk, gpart_a1Zmp) = Genome.Split.split gpart_a1Zmo
                            p_a1Zkj = double g_a1Zki
                            (g_a1Zki, gpart_a1Zmo) = Genome.Split.split gpart_a1Zmn
                            p_a1Zkh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zkg
                            (g_a1Zkg, gpart_a1Zmn) = Genome.Split.split gpart_a1Zmm
                            p_a1Zkf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zke
                            (g_a1Zke, gpart_a1Zmm) = Genome.Split.split gpart_a1Zml
                            p_a1Zkd = double g_a1Zkc
                            (g_a1Zkc, gpart_a1Zml) = Genome.Split.split gpart_a1Zmk
                            p_a1Zkb = double g_a1Zka
                            (g_a1Zka, gpart_a1Zmk) = Genome.Split.split gpart_a1Zmj
                            p_a1Zk9 = double g_a1Zk8
                            (g_a1Zk8, gpart_a1Zmj) = Genome.Split.split gpart_a1Zmi
                            p_a1Zk7 = double g_a1Zk6
                            (g_a1Zk6, gpart_a1Zmi) = Genome.Split.split gpart_a1Zmh
                            p_a1Zk5 = double g_a1Zk4
                            (g_a1Zk4, gpart_a1Zmh) = Genome.Split.split genome_a1Zli
                          in
                            \ desc_a1Zlj
                              -> case desc_a1Zlj of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk5)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk7)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk9)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkb)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkd)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkf)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkh)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkj)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkl)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkn)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkp)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkr)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkt)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkv)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkx)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkz)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkB)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkD)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkF)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkH)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkJ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkL)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkN)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkP)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkR)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkT)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkV)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkX)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkZ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl1)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl3)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl5)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl7)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl9)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlb)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zld)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlf)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlh)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1Zpg
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZpT
                      p_a1Zpf = double g_a1Zpe
                      (g_a1Zpe, gpart_a1ZpT) = Genome.Split.split gpart_a1ZpS
                      p_a1Zpd = double g_a1Zpc
                      (g_a1Zpc, gpart_a1ZpS) = Genome.Split.split gpart_a1ZpR
                      p_a1Zpb = double g_a1Zpa
                      (g_a1Zpa, gpart_a1ZpR) = Genome.Split.split gpart_a1ZpQ
                      p_a1Zp9 = double g_a1Zp8
                      (g_a1Zp8, gpart_a1ZpQ) = Genome.Split.split gpart_a1ZpP
                      p_a1Zp7 = double g_a1Zp6
                      (g_a1Zp6, gpart_a1ZpP) = Genome.Split.split gpart_a1ZpO
                      p_a1Zp5 = Functions.belowten' g_a1Zp4
                      (g_a1Zp4, gpart_a1ZpO) = Genome.Split.split gpart_a1ZpN
                      p_a1Zp3 = double g_a1Zp2
                      (g_a1Zp2, gpart_a1ZpN) = Genome.Split.split gpart_a1ZpM
                      p_a1Zp1 = double g_a1Zp0
                      (g_a1Zp0, gpart_a1ZpM) = Genome.Split.split gpart_a1ZpL
                      p_a1ZoZ = double g_a1ZoY
                      (g_a1ZoY, gpart_a1ZpL) = Genome.Split.split gpart_a1ZpK
                      p_a1ZoX = Functions.belowten' g_a1ZoW
                      (g_a1ZoW, gpart_a1ZpK) = Genome.Split.split gpart_a1ZpJ
                      p_a1ZoV = double g_a1ZoU
                      (g_a1ZoU, gpart_a1ZpJ) = Genome.Split.split gpart_a1ZpI
                      p_a1ZoT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoS
                      (g_a1ZoS, gpart_a1ZpI) = Genome.Split.split gpart_a1ZpH
                      p_a1ZoR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoQ
                      (g_a1ZoQ, gpart_a1ZpH) = Genome.Split.split gpart_a1ZpG
                      p_a1ZoP = Functions.belowten' g_a1ZoO
                      (g_a1ZoO, gpart_a1ZpG) = Genome.Split.split gpart_a1ZpF
                      p_a1ZoN = double g_a1ZoM
                      (g_a1ZoM, gpart_a1ZpF) = Genome.Split.split gpart_a1ZpE
                      p_a1ZoL = double g_a1ZoK
                      (g_a1ZoK, gpart_a1ZpE) = Genome.Split.split gpart_a1ZpD
                      p_a1ZoJ = double g_a1ZoI
                      (g_a1ZoI, gpart_a1ZpD) = Genome.Split.split gpart_a1ZpC
                      p_a1ZoH = Functions.belowten' g_a1ZoG
                      (g_a1ZoG, gpart_a1ZpC) = Genome.Split.split gpart_a1ZpB
                      p_a1ZoF = double g_a1ZoE
                      (g_a1ZoE, gpart_a1ZpB) = Genome.Split.split gpart_a1ZpA
                      p_a1ZoD = Functions.belowten' g_a1ZoC
                      (g_a1ZoC, gpart_a1ZpA) = Genome.Split.split gpart_a1Zpz
                      p_a1ZoB = double g_a1ZoA
                      (g_a1ZoA, gpart_a1Zpz) = Genome.Split.split gpart_a1Zpy
                      p_a1Zoz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoy
                      (g_a1Zoy, gpart_a1Zpy) = Genome.Split.split gpart_a1Zpx
                      p_a1Zox
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zow
                      (g_a1Zow, gpart_a1Zpx) = Genome.Split.split gpart_a1Zpw
                      p_a1Zov = double g_a1Zou
                      (g_a1Zou, gpart_a1Zpw) = Genome.Split.split gpart_a1Zpv
                      p_a1Zot = Functions.belowten' g_a1Zos
                      (g_a1Zos, gpart_a1Zpv) = Genome.Split.split gpart_a1Zpu
                      p_a1Zor = double g_a1Zoq
                      (g_a1Zoq, gpart_a1Zpu) = Genome.Split.split gpart_a1Zpt
                      p_a1Zop = Functions.belowten' g_a1Zoo
                      (g_a1Zoo, gpart_a1Zpt) = Genome.Split.split gpart_a1Zps
                      p_a1Zon = double g_a1Zom
                      (g_a1Zom, gpart_a1Zps) = Genome.Split.split gpart_a1Zpr
                      p_a1Zol = double g_a1Zok
                      (g_a1Zok, gpart_a1Zpr) = Genome.Split.split gpart_a1Zpq
                      p_a1Zoj = Functions.belowten' g_a1Zoi
                      (g_a1Zoi, gpart_a1Zpq) = Genome.Split.split gpart_a1Zpp
                      p_a1Zoh = double g_a1Zog
                      (g_a1Zog, gpart_a1Zpp) = Genome.Split.split gpart_a1Zpo
                      p_a1Zof
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoe
                      (g_a1Zoe, gpart_a1Zpo) = Genome.Split.split gpart_a1Zpn
                      p_a1Zod
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoc
                      (g_a1Zoc, gpart_a1Zpn) = Genome.Split.split gpart_a1Zpm
                      p_a1Zob = double g_a1Zoa
                      (g_a1Zoa, gpart_a1Zpm) = Genome.Split.split gpart_a1Zpl
                      p_a1Zo9 = double g_a1Zo8
                      (g_a1Zo8, gpart_a1Zpl) = Genome.Split.split gpart_a1Zpk
                      p_a1Zo7 = double g_a1Zo6
                      (g_a1Zo6, gpart_a1Zpk) = Genome.Split.split gpart_a1Zpj
                      p_a1Zo5 = double g_a1Zo4
                      (g_a1Zo4, gpart_a1Zpj) = Genome.Split.split gpart_a1Zpi
                      p_a1Zo3 = double g_a1Zo2
                      (g_a1Zo2, gpart_a1Zpi) = Genome.Split.split genome_a1Zpg
                    in  \ x_a1ZpU
                          -> let
                               c_PTB_a1ZpX
                                 = ((Data.Fixed.Vector.toVector x_a1ZpU) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZpV
                                 = ((Data.Fixed.Vector.toVector x_a1ZpU) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zq1
                                 = ((Data.Fixed.Vector.toVector x_a1ZpU) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zq4
                                 = ((Data.Fixed.Vector.toVector x_a1ZpU) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zqe
                                 = ((Data.Fixed.Vector.toVector x_a1ZpU) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zob
                                     / (1
                                        + (((p_a1Zo3 / p_a1Zod) ** p_a1Zof)
                                           + ((c_MiRs_a1ZpV / p_a1Zoh) ** p_a1Zoj))))
                                    + (negate (p_a1Zp7 * c_PTB_a1ZpX))),
                                   ((p_a1Zol
                                     / (1
                                        + (((c_MiRs_a1ZpV / p_a1Zon) ** p_a1Zop)
                                           + ((c_PTB_a1ZpX / p_a1Zor) ** p_a1Zot))))
                                    + (negate (p_a1Zp9 * c_NPTB_a1Zq1))),
                                   ((p_a1Zov
                                     * ((p_a1ZoJ + ((c_PTB_a1ZpX / p_a1ZoB) ** p_a1ZoD))
                                        / (((1 + p_a1ZoJ) + ((c_PTB_a1ZpX / p_a1ZoB) ** p_a1ZoD))
                                           + ((c_RESTc_a1Zq4 / p_a1ZoF) ** p_a1ZoH))))
                                    + (negate (p_a1Zpb * c_MiRs_a1ZpV))),
                                   ((p_a1ZoL
                                     * ((p_a1ZoZ + ((c_PTB_a1ZpX / p_a1ZoN) ** p_a1ZoP))
                                        / (((1 + p_a1ZoZ) + ((c_PTB_a1ZpX / p_a1ZoN) ** p_a1ZoP))
                                           + ((c_MiRs_a1ZpV / p_a1ZoV) ** p_a1ZoX))))
                                    + (negate (p_a1Zpd * c_RESTc_a1Zq4))),
                                   ((p_a1Zp1 / (1 + ((c_RESTc_a1Zq4 / p_a1Zp3) ** p_a1Zp5)))
                                    + (negate (p_a1Zpf * c_EndoNeuroTFs_a1Zqe)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484105",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484107",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484125",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484127",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484145",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484147",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zpg
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZqQ
                            p_a1Zpf = double g_a1Zpe
                            (g_a1Zpe, gpart_a1ZqQ) = Genome.Split.split gpart_a1ZqP
                            p_a1Zpd = double g_a1Zpc
                            (g_a1Zpc, gpart_a1ZqP) = Genome.Split.split gpart_a1ZqO
                            p_a1Zpb = double g_a1Zpa
                            (g_a1Zpa, gpart_a1ZqO) = Genome.Split.split gpart_a1ZqN
                            p_a1Zp9 = double g_a1Zp8
                            (g_a1Zp8, gpart_a1ZqN) = Genome.Split.split gpart_a1ZqM
                            p_a1Zp7 = double g_a1Zp6
                            (g_a1Zp6, gpart_a1ZqM) = Genome.Split.split gpart_a1ZqL
                            p_a1Zp5 = Functions.belowten' g_a1Zp4
                            (g_a1Zp4, gpart_a1ZqL) = Genome.Split.split gpart_a1ZqK
                            p_a1Zp3 = double g_a1Zp2
                            (g_a1Zp2, gpart_a1ZqK) = Genome.Split.split gpart_a1ZqJ
                            p_a1Zp1 = double g_a1Zp0
                            (g_a1Zp0, gpart_a1ZqJ) = Genome.Split.split gpart_a1ZqI
                            p_a1ZoZ = double g_a1ZoY
                            (g_a1ZoY, gpart_a1ZqI) = Genome.Split.split gpart_a1ZqH
                            p_a1ZoX = Functions.belowten' g_a1ZoW
                            (g_a1ZoW, gpart_a1ZqH) = Genome.Split.split gpart_a1ZqG
                            p_a1ZoV = double g_a1ZoU
                            (g_a1ZoU, gpart_a1ZqG) = Genome.Split.split gpart_a1ZqF
                            p_a1ZoT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoS
                            (g_a1ZoS, gpart_a1ZqF) = Genome.Split.split gpart_a1ZqE
                            p_a1ZoR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZoQ
                            (g_a1ZoQ, gpart_a1ZqE) = Genome.Split.split gpart_a1ZqD
                            p_a1ZoP = Functions.belowten' g_a1ZoO
                            (g_a1ZoO, gpart_a1ZqD) = Genome.Split.split gpart_a1ZqC
                            p_a1ZoN = double g_a1ZoM
                            (g_a1ZoM, gpart_a1ZqC) = Genome.Split.split gpart_a1ZqB
                            p_a1ZoL = double g_a1ZoK
                            (g_a1ZoK, gpart_a1ZqB) = Genome.Split.split gpart_a1ZqA
                            p_a1ZoJ = double g_a1ZoI
                            (g_a1ZoI, gpart_a1ZqA) = Genome.Split.split gpart_a1Zqz
                            p_a1ZoH = Functions.belowten' g_a1ZoG
                            (g_a1ZoG, gpart_a1Zqz) = Genome.Split.split gpart_a1Zqy
                            p_a1ZoF = double g_a1ZoE
                            (g_a1ZoE, gpart_a1Zqy) = Genome.Split.split gpart_a1Zqx
                            p_a1ZoD = Functions.belowten' g_a1ZoC
                            (g_a1ZoC, gpart_a1Zqx) = Genome.Split.split gpart_a1Zqw
                            p_a1ZoB = double g_a1ZoA
                            (g_a1ZoA, gpart_a1Zqw) = Genome.Split.split gpart_a1Zqv
                            p_a1Zoz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoy
                            (g_a1Zoy, gpart_a1Zqv) = Genome.Split.split gpart_a1Zqu
                            p_a1Zox
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zow
                            (g_a1Zow, gpart_a1Zqu) = Genome.Split.split gpart_a1Zqt
                            p_a1Zov = double g_a1Zou
                            (g_a1Zou, gpart_a1Zqt) = Genome.Split.split gpart_a1Zqs
                            p_a1Zot = Functions.belowten' g_a1Zos
                            (g_a1Zos, gpart_a1Zqs) = Genome.Split.split gpart_a1Zqr
                            p_a1Zor = double g_a1Zoq
                            (g_a1Zoq, gpart_a1Zqr) = Genome.Split.split gpart_a1Zqq
                            p_a1Zop = Functions.belowten' g_a1Zoo
                            (g_a1Zoo, gpart_a1Zqq) = Genome.Split.split gpart_a1Zqp
                            p_a1Zon = double g_a1Zom
                            (g_a1Zom, gpart_a1Zqp) = Genome.Split.split gpart_a1Zqo
                            p_a1Zol = double g_a1Zok
                            (g_a1Zok, gpart_a1Zqo) = Genome.Split.split gpart_a1Zqn
                            p_a1Zoj = Functions.belowten' g_a1Zoi
                            (g_a1Zoi, gpart_a1Zqn) = Genome.Split.split gpart_a1Zqm
                            p_a1Zoh = double g_a1Zog
                            (g_a1Zog, gpart_a1Zqm) = Genome.Split.split gpart_a1Zql
                            p_a1Zof
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoe
                            (g_a1Zoe, gpart_a1Zql) = Genome.Split.split gpart_a1Zqk
                            p_a1Zod
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoc
                            (g_a1Zoc, gpart_a1Zqk) = Genome.Split.split gpart_a1Zqj
                            p_a1Zob = double g_a1Zoa
                            (g_a1Zoa, gpart_a1Zqj) = Genome.Split.split gpart_a1Zqi
                            p_a1Zo9 = double g_a1Zo8
                            (g_a1Zo8, gpart_a1Zqi) = Genome.Split.split gpart_a1Zqh
                            p_a1Zo7 = double g_a1Zo6
                            (g_a1Zo6, gpart_a1Zqh) = Genome.Split.split gpart_a1Zqg
                            p_a1Zo5 = double g_a1Zo4
                            (g_a1Zo4, gpart_a1Zqg) = Genome.Split.split gpart_a1Zqf
                            p_a1Zo3 = double g_a1Zo2
                            (g_a1Zo2, gpart_a1Zqf) = Genome.Split.split genome_a1Zpg
                          in
                            \ desc_a1Zph
                              -> case desc_a1Zph of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo3)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo5)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo7)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo9)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zob)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zod)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zof)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoh)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoj)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zol)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zon)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zop)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zor)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zot)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zov)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zox)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoz)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoB)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoD)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoF)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoH)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoJ)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoL)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoN)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoP)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoR)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoT)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoV)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoX)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoZ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp1)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp3)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp5)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp7)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp9)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpb)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpd)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpf)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asUb
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUO
                      p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                      (g_asU9, gpart_asUO) = Genome.Split.split gpart_asUN
                      p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                      (g_asU7, gpart_asUN) = Genome.Split.split gpart_asUM
                      p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                      (g_asU5, gpart_asUM) = Genome.Split.split gpart_asUL
                      p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                      (g_asU3, gpart_asUL) = Genome.Split.split gpart_asUK
                      p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                      (g_asU1, gpart_asUK) = Genome.Split.split gpart_asUJ
                      p_asU0 = Functions.belowten' g_asTZ
                      (g_asTZ, gpart_asUJ) = Genome.Split.split gpart_asUI
                      p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                      (g_asTX, gpart_asUI) = Genome.Split.split gpart_asUH
                      p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                      (g_asTV, gpart_asUH) = Genome.Split.split gpart_asUG
                      p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                      (g_asTT, gpart_asUG) = Genome.Split.split gpart_asUF
                      p_asTS = Functions.belowten' g_asTR
                      (g_asTR, gpart_asUF) = Genome.Split.split gpart_asUE
                      p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                      (g_asTP, gpart_asUE) = Genome.Split.split gpart_asUD
                      p_asTO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTN
                      (g_asTN, gpart_asUD) = Genome.Split.split gpart_asUC
                      p_asTM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTL
                      (g_asTL, gpart_asUC) = Genome.Split.split gpart_asUB
                      p_asTK = Functions.belowten' g_asTJ
                      (g_asTJ, gpart_asUB) = Genome.Split.split gpart_asUA
                      p_asTI = code-0.1.0.0:Genome.FixedList.Functions.double g_asTH
                      (g_asTH, gpart_asUA) = Genome.Split.split gpart_asUz
                      p_asTG = code-0.1.0.0:Genome.FixedList.Functions.double g_asTF
                      (g_asTF, gpart_asUz) = Genome.Split.split gpart_asUy
                      p_asTE = code-0.1.0.0:Genome.FixedList.Functions.double g_asTD
                      (g_asTD, gpart_asUy) = Genome.Split.split gpart_asUx
                      p_asTC = Functions.belowten' g_asTB
                      (g_asTB, gpart_asUx) = Genome.Split.split gpart_asUw
                      p_asTA = code-0.1.0.0:Genome.FixedList.Functions.double g_asTz
                      (g_asTz, gpart_asUw) = Genome.Split.split gpart_asUv
                      p_asTy = Functions.belowten' g_asTx
                      (g_asTx, gpart_asUv) = Genome.Split.split gpart_asUu
                      p_asTw = code-0.1.0.0:Genome.FixedList.Functions.double g_asTv
                      (g_asTv, gpart_asUu) = Genome.Split.split gpart_asUt
                      p_asTu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTt
                      (g_asTt, gpart_asUt) = Genome.Split.split gpart_asUs
                      p_asTs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTr
                      (g_asTr, gpart_asUs) = Genome.Split.split gpart_asUr
                      p_asTq = code-0.1.0.0:Genome.FixedList.Functions.double g_asTp
                      (g_asTp, gpart_asUr) = Genome.Split.split gpart_asUq
                      p_asTo = Functions.belowten' g_asTn
                      (g_asTn, gpart_asUq) = Genome.Split.split gpart_asUp
                      p_asTm = code-0.1.0.0:Genome.FixedList.Functions.double g_asTl
                      (g_asTl, gpart_asUp) = Genome.Split.split gpart_asUo
                      p_asTk = Functions.belowten' g_asTj
                      (g_asTj, gpart_asUo) = Genome.Split.split gpart_asUn
                      p_asTi = code-0.1.0.0:Genome.FixedList.Functions.double g_asTh
                      (g_asTh, gpart_asUn) = Genome.Split.split gpart_asUm
                      p_asTg = code-0.1.0.0:Genome.FixedList.Functions.double g_asTf
                      (g_asTf, gpart_asUm) = Genome.Split.split gpart_asUl
                      p_asTe = Functions.belowten' g_asTd
                      (g_asTd, gpart_asUl) = Genome.Split.split gpart_asUk
                      p_asTc = code-0.1.0.0:Genome.FixedList.Functions.double g_asTb
                      (g_asTb, gpart_asUk) = Genome.Split.split gpart_asUj
                      p_asTa
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT9
                      (g_asT9, gpart_asUj) = Genome.Split.split gpart_asUi
                      p_asT8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT7
                      (g_asT7, gpart_asUi) = Genome.Split.split gpart_asUh
                      p_asT6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT5
                      (g_asT5, gpart_asUh) = Genome.Split.split gpart_asUg
                      p_asT4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT3
                      (g_asT3, gpart_asUg) = Genome.Split.split gpart_asUf
                      p_asT2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT1
                      (g_asT1, gpart_asUf) = Genome.Split.split gpart_asUe
                      p_asT0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asSZ
                      (g_asSZ, gpart_asUe) = Genome.Split.split gpart_asUd
                      p_asSY = code-0.1.0.0:Genome.FixedList.Functions.double g_asSX
                      (g_asSX, gpart_asUd) = Genome.Split.split genome_asUb
                    in
                      [Reaction
                         (\ x_asUP
                            -> let c_MiRs_asUQ = ((toVector x_asUP) Data.Vector.Unboxed.! 2)
                               in (p_asT6 / (1 + ((c_MiRs_asUQ / p_asTc) ** p_asTe))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asUR
                            -> let
                                 c_MiRs_asUS = ((toVector x_asUR) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUT = ((toVector x_asUR) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTg
                                  / (1
                                     + (((c_MiRs_asUS / p_asTi) ** p_asTk)
                                        + ((c_PTB_asUT / p_asTm) ** p_asTo)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asUU
                            -> let
                                 c_RESTc_asUX = ((toVector x_asUU) Data.Vector.Unboxed.! 3)
                                 c_PTB_asUV = ((toVector x_asUU) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTq
                                  * ((p_asTE
                                      + (((p_asT2 / p_asTs) ** p_asTu)
                                         + ((c_PTB_asUV / p_asTw) ** p_asTy)))
                                     / (((1 + p_asTE)
                                         + (((p_asT2 / p_asTs) ** p_asTu)
                                            + ((c_PTB_asUV / p_asTw) ** p_asTy)))
                                        + ((c_RESTc_asUX / p_asTA) ** p_asTC)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asUY
                            -> let
                                 c_MiRs_asV1 = ((toVector x_asUY) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUZ = ((toVector x_asUY) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTG
                                  * ((p_asTU + ((c_PTB_asUZ / p_asTI) ** p_asTK))
                                     / (((1 + p_asTU) + ((c_PTB_asUZ / p_asTI) ** p_asTK))
                                        + (((p_asSY / p_asTM) ** p_asTO)
                                           + ((c_MiRs_asV1 / p_asTQ) ** p_asTS))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asV2
                            -> let c_RESTc_asV3 = ((toVector x_asV2) Data.Vector.Unboxed.! 3)
                               in (p_asTW / (1 + ((c_RESTc_asV3 / p_asTY) ** p_asU0))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asV4
                            -> let c_PTB_asV5 = ((toVector x_asV4) Data.Vector.Unboxed.! 0)
                               in (p_asU2 * c_PTB_asV5))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asV6
                            -> let c_NPTB_asV7 = ((toVector x_asV6) Data.Vector.Unboxed.! 1)
                               in (p_asU4 * c_NPTB_asV7))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asV8
                            -> let c_MiRs_asV9 = ((toVector x_asV8) Data.Vector.Unboxed.! 2)
                               in (p_asU6 * c_MiRs_asV9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asVa
                            -> let c_RESTc_asVb = ((toVector x_asVa) Data.Vector.Unboxed.! 3)
                               in (p_asU8 * c_RESTc_asVb))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asVc
                            -> let
                                 c_EndoNeuroTFs_asVd = ((toVector x_asVc) Data.Vector.Unboxed.! 4)
                               in (p_asUa * c_EndoNeuroTFs_asVd))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120831",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120832",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120833",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120834",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120835",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120836",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120837",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120838",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120839",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120840",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120841",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120842",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120843",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120844",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120845",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120846",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120847",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120848",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120849",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120850",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120851",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120852",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120853",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120854",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120855",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120856",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120858",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120860",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120862",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120864",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120866",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120868",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120876",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120878",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120882",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120884",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asUb
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVU
                            p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                            (g_asU9, gpart_asVU) = Genome.Split.split gpart_asVT
                            p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                            (g_asU7, gpart_asVT) = Genome.Split.split gpart_asVS
                            p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                            (g_asU5, gpart_asVS) = Genome.Split.split gpart_asVR
                            p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                            (g_asU3, gpart_asVR) = Genome.Split.split gpart_asVQ
                            p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                            (g_asU1, gpart_asVQ) = Genome.Split.split gpart_asVP
                            p_asU0 = Functions.belowten' g_asTZ
                            (g_asTZ, gpart_asVP) = Genome.Split.split gpart_asVO
                            p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                            (g_asTX, gpart_asVO) = Genome.Split.split gpart_asVN
                            p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                            (g_asTV, gpart_asVN) = Genome.Split.split gpart_asVM
                            p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                            (g_asTT, gpart_asVM) = Genome.Split.split gpart_asVL
                            p_asTS = Functions.belowten' g_asTR
                            (g_asTR, gpart_asVL) = Genome.Split.split gpart_asVK
                            p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                            (g_asTP, gpart_asVK) = Genome.Split.split gpart_asVJ
                            p_asTO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTN
                            (g_asTN, gpart_asVJ) = Genome.Split.split gpart_asVI
                            p_asTM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTL
                            (g_asTL, gpart_asVI) = Genome.Split.split gpart_asVH
                            p_asTK = Functions.belowten' g_asTJ
                            (g_asTJ, gpart_asVH) = Genome.Split.split gpart_asVG
                            p_asTI = code-0.1.0.0:Genome.FixedList.Functions.double g_asTH
                            (g_asTH, gpart_asVG) = Genome.Split.split gpart_asVF
                            p_asTG = code-0.1.0.0:Genome.FixedList.Functions.double g_asTF
                            (g_asTF, gpart_asVF) = Genome.Split.split gpart_asVE
                            p_asTE = code-0.1.0.0:Genome.FixedList.Functions.double g_asTD
                            (g_asTD, gpart_asVE) = Genome.Split.split gpart_asVD
                            p_asTC = Functions.belowten' g_asTB
                            (g_asTB, gpart_asVD) = Genome.Split.split gpart_asVC
                            p_asTA = code-0.1.0.0:Genome.FixedList.Functions.double g_asTz
                            (g_asTz, gpart_asVC) = Genome.Split.split gpart_asVB
                            p_asTy = Functions.belowten' g_asTx
                            (g_asTx, gpart_asVB) = Genome.Split.split gpart_asVA
                            p_asTw = code-0.1.0.0:Genome.FixedList.Functions.double g_asTv
                            (g_asTv, gpart_asVA) = Genome.Split.split gpart_asVz
                            p_asTu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTt
                            (g_asTt, gpart_asVz) = Genome.Split.split gpart_asVy
                            p_asTs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTr
                            (g_asTr, gpart_asVy) = Genome.Split.split gpart_asVx
                            p_asTq = code-0.1.0.0:Genome.FixedList.Functions.double g_asTp
                            (g_asTp, gpart_asVx) = Genome.Split.split gpart_asVw
                            p_asTo = Functions.belowten' g_asTn
                            (g_asTn, gpart_asVw) = Genome.Split.split gpart_asVv
                            p_asTm = code-0.1.0.0:Genome.FixedList.Functions.double g_asTl
                            (g_asTl, gpart_asVv) = Genome.Split.split gpart_asVu
                            p_asTk = Functions.belowten' g_asTj
                            (g_asTj, gpart_asVu) = Genome.Split.split gpart_asVt
                            p_asTi = code-0.1.0.0:Genome.FixedList.Functions.double g_asTh
                            (g_asTh, gpart_asVt) = Genome.Split.split gpart_asVs
                            p_asTg = code-0.1.0.0:Genome.FixedList.Functions.double g_asTf
                            (g_asTf, gpart_asVs) = Genome.Split.split gpart_asVr
                            p_asTe = Functions.belowten' g_asTd
                            (g_asTd, gpart_asVr) = Genome.Split.split gpart_asVq
                            p_asTc = code-0.1.0.0:Genome.FixedList.Functions.double g_asTb
                            (g_asTb, gpart_asVq) = Genome.Split.split gpart_asVp
                            p_asTa
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT9
                            (g_asT9, gpart_asVp) = Genome.Split.split gpart_asVo
                            p_asT8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT7
                            (g_asT7, gpart_asVo) = Genome.Split.split gpart_asVn
                            p_asT6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT5
                            (g_asT5, gpart_asVn) = Genome.Split.split gpart_asVm
                            p_asT4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT3
                            (g_asT3, gpart_asVm) = Genome.Split.split gpart_asVl
                            p_asT2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT1
                            (g_asT1, gpart_asVl) = Genome.Split.split gpart_asVk
                            p_asT0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asSZ
                            (g_asSZ, gpart_asVk) = Genome.Split.split gpart_asVj
                            p_asSY = code-0.1.0.0:Genome.FixedList.Functions.double g_asSX
                            (g_asSX, gpart_asVj) = Genome.Split.split genome_asUb
                          in
                            \ desc_asUc
                              -> case desc_asUc of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSY)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT0)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT2)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT4)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT6)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT8)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTa)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTc)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTe)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTg)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTi)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTk)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTm)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTo)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTq)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTs)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTu)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTw)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTy)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTA)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTC)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTE)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTG)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTI)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTK)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTM)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTO)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTQ)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTS)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTU)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTW)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTY)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU0)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU2)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU4)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU6)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU8)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asXP
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYs
                      p_asXO = code-0.1.0.0:Genome.FixedList.Functions.double g_asXN
                      (g_asXN, gpart_asYs) = Genome.Split.split gpart_asYr
                      p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                      (g_asXL, gpart_asYr) = Genome.Split.split gpart_asYq
                      p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                      (g_asXJ, gpart_asYq) = Genome.Split.split gpart_asYp
                      p_asXI = code-0.1.0.0:Genome.FixedList.Functions.double g_asXH
                      (g_asXH, gpart_asYp) = Genome.Split.split gpart_asYo
                      p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                      (g_asXF, gpart_asYo) = Genome.Split.split gpart_asYn
                      p_asXE = Functions.belowten' g_asXD
                      (g_asXD, gpart_asYn) = Genome.Split.split gpart_asYm
                      p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                      (g_asXB, gpart_asYm) = Genome.Split.split gpart_asYl
                      p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                      (g_asXz, gpart_asYl) = Genome.Split.split gpart_asYk
                      p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                      (g_asXx, gpart_asYk) = Genome.Split.split gpart_asYj
                      p_asXw = Functions.belowten' g_asXv
                      (g_asXv, gpart_asYj) = Genome.Split.split gpart_asYi
                      p_asXu = code-0.1.0.0:Genome.FixedList.Functions.double g_asXt
                      (g_asXt, gpart_asYi) = Genome.Split.split gpart_asYh
                      p_asXs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXr
                      (g_asXr, gpart_asYh) = Genome.Split.split gpart_asYg
                      p_asXq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXp
                      (g_asXp, gpart_asYg) = Genome.Split.split gpart_asYf
                      p_asXo = Functions.belowten' g_asXn
                      (g_asXn, gpart_asYf) = Genome.Split.split gpart_asYe
                      p_asXm = code-0.1.0.0:Genome.FixedList.Functions.double g_asXl
                      (g_asXl, gpart_asYe) = Genome.Split.split gpart_asYd
                      p_asXk = code-0.1.0.0:Genome.FixedList.Functions.double g_asXj
                      (g_asXj, gpart_asYd) = Genome.Split.split gpart_asYc
                      p_asXi = code-0.1.0.0:Genome.FixedList.Functions.double g_asXh
                      (g_asXh, gpart_asYc) = Genome.Split.split gpart_asYb
                      p_asXg = Functions.belowten' g_asXf
                      (g_asXf, gpart_asYb) = Genome.Split.split gpart_asYa
                      p_asXe = code-0.1.0.0:Genome.FixedList.Functions.double g_asXd
                      (g_asXd, gpart_asYa) = Genome.Split.split gpart_asY9
                      p_asXc = Functions.belowten' g_asXb
                      (g_asXb, gpart_asY9) = Genome.Split.split gpart_asY8
                      p_asXa = code-0.1.0.0:Genome.FixedList.Functions.double g_asX9
                      (g_asX9, gpart_asY8) = Genome.Split.split gpart_asY7
                      p_asX8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX7
                      (g_asX7, gpart_asY7) = Genome.Split.split gpart_asY6
                      p_asX6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX5
                      (g_asX5, gpart_asY6) = Genome.Split.split gpart_asY5
                      p_asX4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX3
                      (g_asX3, gpart_asY5) = Genome.Split.split gpart_asY4
                      p_asX2 = Functions.belowten' g_asX1
                      (g_asX1, gpart_asY4) = Genome.Split.split gpart_asY3
                      p_asX0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asWZ
                      (g_asWZ, gpart_asY3) = Genome.Split.split gpart_asY2
                      p_asWY = Functions.belowten' g_asWX
                      (g_asWX, gpart_asY2) = Genome.Split.split gpart_asY1
                      p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                      (g_asWV, gpart_asY1) = Genome.Split.split gpart_asY0
                      p_asWU = code-0.1.0.0:Genome.FixedList.Functions.double g_asWT
                      (g_asWT, gpart_asY0) = Genome.Split.split gpart_asXZ
                      p_asWS = Functions.belowten' g_asWR
                      (g_asWR, gpart_asXZ) = Genome.Split.split gpart_asXY
                      p_asWQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWP
                      (g_asWP, gpart_asXY) = Genome.Split.split gpart_asXX
                      p_asWO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWN
                      (g_asWN, gpart_asXX) = Genome.Split.split gpart_asXW
                      p_asWM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWL
                      (g_asWL, gpart_asXW) = Genome.Split.split gpart_asXV
                      p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                      (g_asWJ, gpart_asXV) = Genome.Split.split gpart_asXU
                      p_asWI = code-0.1.0.0:Genome.FixedList.Functions.double g_asWH
                      (g_asWH, gpart_asXU) = Genome.Split.split gpart_asXT
                      p_asWG = code-0.1.0.0:Genome.FixedList.Functions.double g_asWF
                      (g_asWF, gpart_asXT) = Genome.Split.split gpart_asXS
                      p_asWE = code-0.1.0.0:Genome.FixedList.Functions.double g_asWD
                      (g_asWD, gpart_asXS) = Genome.Split.split gpart_asXR
                      p_asWC = code-0.1.0.0:Genome.FixedList.Functions.double g_asWB
                      (g_asWB, gpart_asXR) = Genome.Split.split genome_asXP
                    in
                      [Reaction
                         (\ x_asYt
                            -> let c_MiRs_asYu = ((toVector x_asYt) Data.Vector.Unboxed.! 2)
                               in (p_asWK / (1 + ((c_MiRs_asYu / p_asWQ) ** p_asWS))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYv
                            -> let
                                 c_MiRs_asYw = ((toVector x_asYv) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYx = ((toVector x_asYv) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWU
                                  / (1
                                     + (((c_MiRs_asYw / p_asWW) ** p_asWY)
                                        + ((c_PTB_asYx / p_asX0) ** p_asX2)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asYy
                            -> let
                                 c_RESTc_asYB = ((toVector x_asYy) Data.Vector.Unboxed.! 3)
                                 c_PTB_asYz = ((toVector x_asYy) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asX4
                                  * ((p_asXi + ((c_PTB_asYz / p_asXa) ** p_asXc))
                                     / (((1 + p_asXi) + ((c_PTB_asYz / p_asXa) ** p_asXc))
                                        + ((c_RESTc_asYB / p_asXe) ** p_asXg)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asYC
                            -> let
                                 c_MiRs_asYF = ((toVector x_asYC) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYD = ((toVector x_asYC) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXk
                                  * ((p_asXy + ((c_PTB_asYD / p_asXm) ** p_asXo))
                                     / (((1 + p_asXy) + ((c_PTB_asYD / p_asXm) ** p_asXo))
                                        + (((p_asWC / p_asXq) ** p_asXs)
                                           + ((c_MiRs_asYF / p_asXu) ** p_asXw))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asYG
                            -> let c_RESTc_asYH = ((toVector x_asYG) Data.Vector.Unboxed.! 3)
                               in (p_asXA / (1 + ((c_RESTc_asYH / p_asXC) ** p_asXE))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asYI
                            -> let c_PTB_asYJ = ((toVector x_asYI) Data.Vector.Unboxed.! 0)
                               in (p_asXG * c_PTB_asYJ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYK
                            -> let c_NPTB_asYL = ((toVector x_asYK) Data.Vector.Unboxed.! 1)
                               in (p_asXI * c_NPTB_asYL))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asYM
                            -> let c_MiRs_asYN = ((toVector x_asYM) Data.Vector.Unboxed.! 2)
                               in (p_asXK * c_MiRs_asYN))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asYO
                            -> let c_RESTc_asYP = ((toVector x_asYO) Data.Vector.Unboxed.! 3)
                               in (p_asXM * c_RESTc_asYP))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asYQ
                            -> let
                                 c_EndoNeuroTFs_asYR = ((toVector x_asYQ) Data.Vector.Unboxed.! 4)
                               in (p_asXO * c_EndoNeuroTFs_asYR))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121057",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121058",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121059",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121060",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121061",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121062",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121063",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121064",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121067",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121068",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121069",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121070",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121071",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121072",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121073",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121074",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121075",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121076",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121077",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121078",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121079",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121080",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121081",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121082",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121083",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121084",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121085",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121086",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121087",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121088",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121089",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121090",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121091",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121092",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121093",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121094",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121095",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121096",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121097",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121098",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121099",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121100",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121101",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121102",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121103",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121104",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121105",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121106",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121107",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121108",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121110",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121122",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121124",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121126",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121128",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121132",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asXP
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZt
                            p_asXO = code-0.1.0.0:Genome.FixedList.Functions.double g_asXN
                            (g_asXN, gpart_asZt) = Genome.Split.split gpart_asZs
                            p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                            (g_asXL, gpart_asZs) = Genome.Split.split gpart_asZr
                            p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                            (g_asXJ, gpart_asZr) = Genome.Split.split gpart_asZq
                            p_asXI = code-0.1.0.0:Genome.FixedList.Functions.double g_asXH
                            (g_asXH, gpart_asZq) = Genome.Split.split gpart_asZp
                            p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                            (g_asXF, gpart_asZp) = Genome.Split.split gpart_asZo
                            p_asXE = Functions.belowten' g_asXD
                            (g_asXD, gpart_asZo) = Genome.Split.split gpart_asZn
                            p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                            (g_asXB, gpart_asZn) = Genome.Split.split gpart_asZm
                            p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                            (g_asXz, gpart_asZm) = Genome.Split.split gpart_asZl
                            p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                            (g_asXx, gpart_asZl) = Genome.Split.split gpart_asZk
                            p_asXw = Functions.belowten' g_asXv
                            (g_asXv, gpart_asZk) = Genome.Split.split gpart_asZj
                            p_asXu = code-0.1.0.0:Genome.FixedList.Functions.double g_asXt
                            (g_asXt, gpart_asZj) = Genome.Split.split gpart_asZi
                            p_asXs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXr
                            (g_asXr, gpart_asZi) = Genome.Split.split gpart_asZh
                            p_asXq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXp
                            (g_asXp, gpart_asZh) = Genome.Split.split gpart_asZg
                            p_asXo = Functions.belowten' g_asXn
                            (g_asXn, gpart_asZg) = Genome.Split.split gpart_asZf
                            p_asXm = code-0.1.0.0:Genome.FixedList.Functions.double g_asXl
                            (g_asXl, gpart_asZf) = Genome.Split.split gpart_asZe
                            p_asXk = code-0.1.0.0:Genome.FixedList.Functions.double g_asXj
                            (g_asXj, gpart_asZe) = Genome.Split.split gpart_asZd
                            p_asXi = code-0.1.0.0:Genome.FixedList.Functions.double g_asXh
                            (g_asXh, gpart_asZd) = Genome.Split.split gpart_asZc
                            p_asXg = Functions.belowten' g_asXf
                            (g_asXf, gpart_asZc) = Genome.Split.split gpart_asZb
                            p_asXe = code-0.1.0.0:Genome.FixedList.Functions.double g_asXd
                            (g_asXd, gpart_asZb) = Genome.Split.split gpart_asZa
                            p_asXc = Functions.belowten' g_asXb
                            (g_asXb, gpart_asZa) = Genome.Split.split gpart_asZ9
                            p_asXa = code-0.1.0.0:Genome.FixedList.Functions.double g_asX9
                            (g_asX9, gpart_asZ9) = Genome.Split.split gpart_asZ8
                            p_asX8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX7
                            (g_asX7, gpart_asZ8) = Genome.Split.split gpart_asZ7
                            p_asX6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX5
                            (g_asX5, gpart_asZ7) = Genome.Split.split gpart_asZ6
                            p_asX4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX3
                            (g_asX3, gpart_asZ6) = Genome.Split.split gpart_asZ5
                            p_asX2 = Functions.belowten' g_asX1
                            (g_asX1, gpart_asZ5) = Genome.Split.split gpart_asZ4
                            p_asX0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asWZ
                            (g_asWZ, gpart_asZ4) = Genome.Split.split gpart_asZ3
                            p_asWY = Functions.belowten' g_asWX
                            (g_asWX, gpart_asZ3) = Genome.Split.split gpart_asZ2
                            p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                            (g_asWV, gpart_asZ2) = Genome.Split.split gpart_asZ1
                            p_asWU = code-0.1.0.0:Genome.FixedList.Functions.double g_asWT
                            (g_asWT, gpart_asZ1) = Genome.Split.split gpart_asZ0
                            p_asWS = Functions.belowten' g_asWR
                            (g_asWR, gpart_asZ0) = Genome.Split.split gpart_asYZ
                            p_asWQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWP
                            (g_asWP, gpart_asYZ) = Genome.Split.split gpart_asYY
                            p_asWO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWN
                            (g_asWN, gpart_asYY) = Genome.Split.split gpart_asYX
                            p_asWM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWL
                            (g_asWL, gpart_asYX) = Genome.Split.split gpart_asYW
                            p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                            (g_asWJ, gpart_asYW) = Genome.Split.split gpart_asYV
                            p_asWI = code-0.1.0.0:Genome.FixedList.Functions.double g_asWH
                            (g_asWH, gpart_asYV) = Genome.Split.split gpart_asYU
                            p_asWG = code-0.1.0.0:Genome.FixedList.Functions.double g_asWF
                            (g_asWF, gpart_asYU) = Genome.Split.split gpart_asYT
                            p_asWE = code-0.1.0.0:Genome.FixedList.Functions.double g_asWD
                            (g_asWD, gpart_asYT) = Genome.Split.split gpart_asYS
                            p_asWC = code-0.1.0.0:Genome.FixedList.Functions.double g_asWB
                            (g_asWB, gpart_asYS) = Genome.Split.split genome_asXP
                          in
                            \ desc_asXQ
                              -> case desc_asXQ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWC)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWE)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWG)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWI)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWK)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWM)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWO)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWQ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWS)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWU)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWW)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWY)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX0)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX2)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX4)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX6)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX8)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXa)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXc)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXe)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXg)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXi)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXk)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXm)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXo)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXq)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXs)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXu)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXw)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXy)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXA)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXC)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXE)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXG)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXI)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXK)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXM)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXO)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at1o
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at21
                      p_at1n = code-0.1.0.0:Genome.FixedList.Functions.double g_at1m
                      (g_at1m, gpart_at21) = Genome.Split.split gpart_at20
                      p_at1l = code-0.1.0.0:Genome.FixedList.Functions.double g_at1k
                      (g_at1k, gpart_at20) = Genome.Split.split gpart_at1Z
                      p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                      (g_at1i, gpart_at1Z) = Genome.Split.split gpart_at1Y
                      p_at1h = code-0.1.0.0:Genome.FixedList.Functions.double g_at1g
                      (g_at1g, gpart_at1Y) = Genome.Split.split gpart_at1X
                      p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                      (g_at1e, gpart_at1X) = Genome.Split.split gpart_at1W
                      p_at1d = Functions.belowten' g_at1c
                      (g_at1c, gpart_at1W) = Genome.Split.split gpart_at1V
                      p_at1b = code-0.1.0.0:Genome.FixedList.Functions.double g_at1a
                      (g_at1a, gpart_at1V) = Genome.Split.split gpart_at1U
                      p_at19 = code-0.1.0.0:Genome.FixedList.Functions.double g_at18
                      (g_at18, gpart_at1U) = Genome.Split.split gpart_at1T
                      p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                      (g_at16, gpart_at1T) = Genome.Split.split gpart_at1S
                      p_at15 = Functions.belowten' g_at14
                      (g_at14, gpart_at1S) = Genome.Split.split gpart_at1R
                      p_at13 = code-0.1.0.0:Genome.FixedList.Functions.double g_at12
                      (g_at12, gpart_at1R) = Genome.Split.split gpart_at1Q
                      p_at11
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at10
                      (g_at10, gpart_at1Q) = Genome.Split.split gpart_at1P
                      p_at0Z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0Y
                      (g_at0Y, gpart_at1P) = Genome.Split.split gpart_at1O
                      p_at0X = Functions.belowten' g_at0W
                      (g_at0W, gpart_at1O) = Genome.Split.split gpart_at1N
                      p_at0V = code-0.1.0.0:Genome.FixedList.Functions.double g_at0U
                      (g_at0U, gpart_at1N) = Genome.Split.split gpart_at1M
                      p_at0T = code-0.1.0.0:Genome.FixedList.Functions.double g_at0S
                      (g_at0S, gpart_at1M) = Genome.Split.split gpart_at1L
                      p_at0R = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Q
                      (g_at0Q, gpart_at1L) = Genome.Split.split gpart_at1K
                      p_at0P = Functions.belowten' g_at0O
                      (g_at0O, gpart_at1K) = Genome.Split.split gpart_at1J
                      p_at0N = code-0.1.0.0:Genome.FixedList.Functions.double g_at0M
                      (g_at0M, gpart_at1J) = Genome.Split.split gpart_at1I
                      p_at0L = Functions.belowten' g_at0K
                      (g_at0K, gpart_at1I) = Genome.Split.split gpart_at1H
                      p_at0J = code-0.1.0.0:Genome.FixedList.Functions.double g_at0I
                      (g_at0I, gpart_at1H) = Genome.Split.split gpart_at1G
                      p_at0H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0G
                      (g_at0G, gpart_at1G) = Genome.Split.split gpart_at1F
                      p_at0F
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0E
                      (g_at0E, gpart_at1F) = Genome.Split.split gpart_at1E
                      p_at0D = code-0.1.0.0:Genome.FixedList.Functions.double g_at0C
                      (g_at0C, gpart_at1E) = Genome.Split.split gpart_at1D
                      p_at0B = Functions.belowten' g_at0A
                      (g_at0A, gpart_at1D) = Genome.Split.split gpart_at1C
                      p_at0z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0y
                      (g_at0y, gpart_at1C) = Genome.Split.split gpart_at1B
                      p_at0x = Functions.belowten' g_at0w
                      (g_at0w, gpart_at1B) = Genome.Split.split gpart_at1A
                      p_at0v = code-0.1.0.0:Genome.FixedList.Functions.double g_at0u
                      (g_at0u, gpart_at1A) = Genome.Split.split gpart_at1z
                      p_at0t = code-0.1.0.0:Genome.FixedList.Functions.double g_at0s
                      (g_at0s, gpart_at1z) = Genome.Split.split gpart_at1y
                      p_at0r = Functions.belowten' g_at0q
                      (g_at0q, gpart_at1y) = Genome.Split.split gpart_at1x
                      p_at0p = code-0.1.0.0:Genome.FixedList.Functions.double g_at0o
                      (g_at0o, gpart_at1x) = Genome.Split.split gpart_at1w
                      p_at0n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0m
                      (g_at0m, gpart_at1w) = Genome.Split.split gpart_at1v
                      p_at0l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0k
                      (g_at0k, gpart_at1v) = Genome.Split.split gpart_at1u
                      p_at0j = code-0.1.0.0:Genome.FixedList.Functions.double g_at0i
                      (g_at0i, gpart_at1u) = Genome.Split.split gpart_at1t
                      p_at0h = code-0.1.0.0:Genome.FixedList.Functions.double g_at0g
                      (g_at0g, gpart_at1t) = Genome.Split.split gpart_at1s
                      p_at0f = code-0.1.0.0:Genome.FixedList.Functions.double g_at0e
                      (g_at0e, gpart_at1s) = Genome.Split.split gpart_at1r
                      p_at0d = code-0.1.0.0:Genome.FixedList.Functions.double g_at0c
                      (g_at0c, gpart_at1r) = Genome.Split.split gpart_at1q
                      p_at0b = code-0.1.0.0:Genome.FixedList.Functions.double g_at0a
                      (g_at0a, gpart_at1q) = Genome.Split.split genome_at1o
                    in
                      [Reaction
                         (\ x_at22
                            -> let c_MiRs_at23 = ((toVector x_at22) Data.Vector.Unboxed.! 2)
                               in (p_at0j / (1 + ((c_MiRs_at23 / p_at0p) ** p_at0r))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at24
                            -> let
                                 c_MiRs_at25 = ((toVector x_at24) Data.Vector.Unboxed.! 2)
                                 c_PTB_at26 = ((toVector x_at24) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0t
                                  / (1
                                     + (((c_MiRs_at25 / p_at0v) ** p_at0x)
                                        + ((c_PTB_at26 / p_at0z) ** p_at0B)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at27
                            -> let
                                 c_RESTc_at2a = ((toVector x_at27) Data.Vector.Unboxed.! 3)
                                 c_PTB_at28 = ((toVector x_at27) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0D
                                  * ((p_at0R + ((c_PTB_at28 / p_at0J) ** p_at0L))
                                     / (((1 + p_at0R) + ((c_PTB_at28 / p_at0J) ** p_at0L))
                                        + ((c_RESTc_at2a / p_at0N) ** p_at0P)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at2b
                            -> let
                                 c_MiRs_at2e = ((toVector x_at2b) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2c = ((toVector x_at2b) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0T
                                  * ((p_at17 + ((c_PTB_at2c / p_at0V) ** p_at0X))
                                     / (((1 + p_at17) + ((c_PTB_at2c / p_at0V) ** p_at0X))
                                        + ((c_MiRs_at2e / p_at13) ** p_at15)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2f
                            -> let c_RESTc_at2g = ((toVector x_at2f) Data.Vector.Unboxed.! 3)
                               in (p_at19 / (1 + ((c_RESTc_at2g / p_at1b) ** p_at1d))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at2h
                            -> let c_PTB_at2i = ((toVector x_at2h) Data.Vector.Unboxed.! 0)
                               in (p_at1f * c_PTB_at2i))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2j
                            -> let c_NPTB_at2k = ((toVector x_at2j) Data.Vector.Unboxed.! 1)
                               in (p_at1h * c_NPTB_at2k))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at2l
                            -> let c_MiRs_at2m = ((toVector x_at2l) Data.Vector.Unboxed.! 2)
                               in (p_at1j * c_MiRs_at2m))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at2n
                            -> let c_RESTc_at2o = ((toVector x_at2n) Data.Vector.Unboxed.! 3)
                               in (p_at1l * c_RESTc_at2o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at2p
                            -> let
                                 c_EndoNeuroTFs_at2q = ((toVector x_at2p) Data.Vector.Unboxed.! 4)
                               in (p_at1n * c_EndoNeuroTFs_at2q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121289",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121291",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121299",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121301",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121309",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121311",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121313",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121315",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121317",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121319",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121321",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121323",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121326",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121327",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121329",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121331",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121333",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121334",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121335",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121336",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121337",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121339",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121341",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121343",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121351",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121352",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121353",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at1o
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at32
                            p_at1n = code-0.1.0.0:Genome.FixedList.Functions.double g_at1m
                            (g_at1m, gpart_at32) = Genome.Split.split gpart_at31
                            p_at1l = code-0.1.0.0:Genome.FixedList.Functions.double g_at1k
                            (g_at1k, gpart_at31) = Genome.Split.split gpart_at30
                            p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                            (g_at1i, gpart_at30) = Genome.Split.split gpart_at2Z
                            p_at1h = code-0.1.0.0:Genome.FixedList.Functions.double g_at1g
                            (g_at1g, gpart_at2Z) = Genome.Split.split gpart_at2Y
                            p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                            (g_at1e, gpart_at2Y) = Genome.Split.split gpart_at2X
                            p_at1d = Functions.belowten' g_at1c
                            (g_at1c, gpart_at2X) = Genome.Split.split gpart_at2W
                            p_at1b = code-0.1.0.0:Genome.FixedList.Functions.double g_at1a
                            (g_at1a, gpart_at2W) = Genome.Split.split gpart_at2V
                            p_at19 = code-0.1.0.0:Genome.FixedList.Functions.double g_at18
                            (g_at18, gpart_at2V) = Genome.Split.split gpart_at2U
                            p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                            (g_at16, gpart_at2U) = Genome.Split.split gpart_at2T
                            p_at15 = Functions.belowten' g_at14
                            (g_at14, gpart_at2T) = Genome.Split.split gpart_at2S
                            p_at13 = code-0.1.0.0:Genome.FixedList.Functions.double g_at12
                            (g_at12, gpart_at2S) = Genome.Split.split gpart_at2R
                            p_at11
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at10
                            (g_at10, gpart_at2R) = Genome.Split.split gpart_at2Q
                            p_at0Z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0Y
                            (g_at0Y, gpart_at2Q) = Genome.Split.split gpart_at2P
                            p_at0X = Functions.belowten' g_at0W
                            (g_at0W, gpart_at2P) = Genome.Split.split gpart_at2O
                            p_at0V = code-0.1.0.0:Genome.FixedList.Functions.double g_at0U
                            (g_at0U, gpart_at2O) = Genome.Split.split gpart_at2N
                            p_at0T = code-0.1.0.0:Genome.FixedList.Functions.double g_at0S
                            (g_at0S, gpart_at2N) = Genome.Split.split gpart_at2M
                            p_at0R = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Q
                            (g_at0Q, gpart_at2M) = Genome.Split.split gpart_at2L
                            p_at0P = Functions.belowten' g_at0O
                            (g_at0O, gpart_at2L) = Genome.Split.split gpart_at2K
                            p_at0N = code-0.1.0.0:Genome.FixedList.Functions.double g_at0M
                            (g_at0M, gpart_at2K) = Genome.Split.split gpart_at2J
                            p_at0L = Functions.belowten' g_at0K
                            (g_at0K, gpart_at2J) = Genome.Split.split gpart_at2I
                            p_at0J = code-0.1.0.0:Genome.FixedList.Functions.double g_at0I
                            (g_at0I, gpart_at2I) = Genome.Split.split gpart_at2H
                            p_at0H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0G
                            (g_at0G, gpart_at2H) = Genome.Split.split gpart_at2G
                            p_at0F
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0E
                            (g_at0E, gpart_at2G) = Genome.Split.split gpart_at2F
                            p_at0D = code-0.1.0.0:Genome.FixedList.Functions.double g_at0C
                            (g_at0C, gpart_at2F) = Genome.Split.split gpart_at2E
                            p_at0B = Functions.belowten' g_at0A
                            (g_at0A, gpart_at2E) = Genome.Split.split gpart_at2D
                            p_at0z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0y
                            (g_at0y, gpart_at2D) = Genome.Split.split gpart_at2C
                            p_at0x = Functions.belowten' g_at0w
                            (g_at0w, gpart_at2C) = Genome.Split.split gpart_at2B
                            p_at0v = code-0.1.0.0:Genome.FixedList.Functions.double g_at0u
                            (g_at0u, gpart_at2B) = Genome.Split.split gpart_at2A
                            p_at0t = code-0.1.0.0:Genome.FixedList.Functions.double g_at0s
                            (g_at0s, gpart_at2A) = Genome.Split.split gpart_at2z
                            p_at0r = Functions.belowten' g_at0q
                            (g_at0q, gpart_at2z) = Genome.Split.split gpart_at2y
                            p_at0p = code-0.1.0.0:Genome.FixedList.Functions.double g_at0o
                            (g_at0o, gpart_at2y) = Genome.Split.split gpart_at2x
                            p_at0n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0m
                            (g_at0m, gpart_at2x) = Genome.Split.split gpart_at2w
                            p_at0l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0k
                            (g_at0k, gpart_at2w) = Genome.Split.split gpart_at2v
                            p_at0j = code-0.1.0.0:Genome.FixedList.Functions.double g_at0i
                            (g_at0i, gpart_at2v) = Genome.Split.split gpart_at2u
                            p_at0h = code-0.1.0.0:Genome.FixedList.Functions.double g_at0g
                            (g_at0g, gpart_at2u) = Genome.Split.split gpart_at2t
                            p_at0f = code-0.1.0.0:Genome.FixedList.Functions.double g_at0e
                            (g_at0e, gpart_at2t) = Genome.Split.split gpart_at2s
                            p_at0d = code-0.1.0.0:Genome.FixedList.Functions.double g_at0c
                            (g_at0c, gpart_at2s) = Genome.Split.split gpart_at2r
                            p_at0b = code-0.1.0.0:Genome.FixedList.Functions.double g_at0a
                            (g_at0a, gpart_at2r) = Genome.Split.split genome_at1o
                          in
                            \ desc_at1p
                              -> case desc_at1p of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0b)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0d)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0f)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0h)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0j)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0l)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0n)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0p)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0r)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0t)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0v)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0x)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0z)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0B)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0D)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0F)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0H)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0J)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0L)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0N)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0P)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0R)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0T)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0V)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0X)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Z)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at11)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at13)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at15)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at17)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at19)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1b)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1d)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1f)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1h)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1j)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1l)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1n)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at4X
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5A
                      p_at4W = code-0.1.0.0:Genome.FixedList.Functions.double g_at4V
                      (g_at4V, gpart_at5A) = Genome.Split.split gpart_at5z
                      p_at4U = code-0.1.0.0:Genome.FixedList.Functions.double g_at4T
                      (g_at4T, gpart_at5z) = Genome.Split.split gpart_at5y
                      p_at4S = code-0.1.0.0:Genome.FixedList.Functions.double g_at4R
                      (g_at4R, gpart_at5y) = Genome.Split.split gpart_at5x
                      p_at4Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at4P
                      (g_at4P, gpart_at5x) = Genome.Split.split gpart_at5w
                      p_at4O = code-0.1.0.0:Genome.FixedList.Functions.double g_at4N
                      (g_at4N, gpart_at5w) = Genome.Split.split gpart_at5v
                      p_at4M = Functions.belowten' g_at4L
                      (g_at4L, gpart_at5v) = Genome.Split.split gpart_at5u
                      p_at4K = code-0.1.0.0:Genome.FixedList.Functions.double g_at4J
                      (g_at4J, gpart_at5u) = Genome.Split.split gpart_at5t
                      p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                      (g_at4H, gpart_at5t) = Genome.Split.split gpart_at5s
                      p_at4G = code-0.1.0.0:Genome.FixedList.Functions.double g_at4F
                      (g_at4F, gpart_at5s) = Genome.Split.split gpart_at5r
                      p_at4E = Functions.belowten' g_at4D
                      (g_at4D, gpart_at5r) = Genome.Split.split gpart_at5q
                      p_at4C = code-0.1.0.0:Genome.FixedList.Functions.double g_at4B
                      (g_at4B, gpart_at5q) = Genome.Split.split gpart_at5p
                      p_at4A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4z
                      (g_at4z, gpart_at5p) = Genome.Split.split gpart_at5o
                      p_at4y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4x
                      (g_at4x, gpart_at5o) = Genome.Split.split gpart_at5n
                      p_at4w = Functions.belowten' g_at4v
                      (g_at4v, gpart_at5n) = Genome.Split.split gpart_at5m
                      p_at4u = code-0.1.0.0:Genome.FixedList.Functions.double g_at4t
                      (g_at4t, gpart_at5m) = Genome.Split.split gpart_at5l
                      p_at4s = code-0.1.0.0:Genome.FixedList.Functions.double g_at4r
                      (g_at4r, gpart_at5l) = Genome.Split.split gpart_at5k
                      p_at4q = code-0.1.0.0:Genome.FixedList.Functions.double g_at4p
                      (g_at4p, gpart_at5k) = Genome.Split.split gpart_at5j
                      p_at4o = Functions.belowten' g_at4n
                      (g_at4n, gpart_at5j) = Genome.Split.split gpart_at5i
                      p_at4m = code-0.1.0.0:Genome.FixedList.Functions.double g_at4l
                      (g_at4l, gpart_at5i) = Genome.Split.split gpart_at5h
                      p_at4k = Functions.belowten' g_at4j
                      (g_at4j, gpart_at5h) = Genome.Split.split gpart_at5g
                      p_at4i = code-0.1.0.0:Genome.FixedList.Functions.double g_at4h
                      (g_at4h, gpart_at5g) = Genome.Split.split gpart_at5f
                      p_at4g
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4f
                      (g_at4f, gpart_at5f) = Genome.Split.split gpart_at5e
                      p_at4e
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4d
                      (g_at4d, gpart_at5e) = Genome.Split.split gpart_at5d
                      p_at4c = code-0.1.0.0:Genome.FixedList.Functions.double g_at4b
                      (g_at4b, gpart_at5d) = Genome.Split.split gpart_at5c
                      p_at4a = Functions.belowten' g_at49
                      (g_at49, gpart_at5c) = Genome.Split.split gpart_at5b
                      p_at48 = code-0.1.0.0:Genome.FixedList.Functions.double g_at47
                      (g_at47, gpart_at5b) = Genome.Split.split gpart_at5a
                      p_at46 = Functions.belowten' g_at45
                      (g_at45, gpart_at5a) = Genome.Split.split gpart_at59
                      p_at44 = code-0.1.0.0:Genome.FixedList.Functions.double g_at43
                      (g_at43, gpart_at59) = Genome.Split.split gpart_at58
                      p_at42 = code-0.1.0.0:Genome.FixedList.Functions.double g_at41
                      (g_at41, gpart_at58) = Genome.Split.split gpart_at57
                      p_at40 = Functions.belowten' g_at3Z
                      (g_at3Z, gpart_at57) = Genome.Split.split gpart_at56
                      p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                      (g_at3X, gpart_at56) = Genome.Split.split gpart_at55
                      p_at3W
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3V
                      (g_at3V, gpart_at55) = Genome.Split.split gpart_at54
                      p_at3U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3T
                      (g_at3T, gpart_at54) = Genome.Split.split gpart_at53
                      p_at3S = code-0.1.0.0:Genome.FixedList.Functions.double g_at3R
                      (g_at3R, gpart_at53) = Genome.Split.split gpart_at52
                      p_at3Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3P
                      (g_at3P, gpart_at52) = Genome.Split.split gpart_at51
                      p_at3O = code-0.1.0.0:Genome.FixedList.Functions.double g_at3N
                      (g_at3N, gpart_at51) = Genome.Split.split gpart_at50
                      p_at3M = code-0.1.0.0:Genome.FixedList.Functions.double g_at3L
                      (g_at3L, gpart_at50) = Genome.Split.split gpart_at4Z
                      p_at3K = code-0.1.0.0:Genome.FixedList.Functions.double g_at3J
                      (g_at3J, gpart_at4Z) = Genome.Split.split genome_at4X
                    in
                      [Reaction
                         (\ x_at5B
                            -> let c_MiRs_at5C = ((toVector x_at5B) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at3S
                                  / (1
                                     + (((p_at3K / p_at3U) ** p_at3W)
                                        + ((c_MiRs_at5C / p_at3Y) ** p_at40)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5D
                            -> let
                                 c_MiRs_at5E = ((toVector x_at5D) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5F = ((toVector x_at5D) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at42
                                  / (1
                                     + (((c_MiRs_at5E / p_at44) ** p_at46)
                                        + ((c_PTB_at5F / p_at48) ** p_at4a)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at5G
                            -> let
                                 c_RESTc_at5J = ((toVector x_at5G) Data.Vector.Unboxed.! 3)
                                 c_PTB_at5H = ((toVector x_at5G) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4c
                                  * ((p_at4q + ((c_PTB_at5H / p_at4i) ** p_at4k))
                                     / (((1 + p_at4q) + ((c_PTB_at5H / p_at4i) ** p_at4k))
                                        + ((c_RESTc_at5J / p_at4m) ** p_at4o)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at5K
                            -> let
                                 c_MiRs_at5N = ((toVector x_at5K) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5L = ((toVector x_at5K) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4s
                                  * ((p_at4G + ((c_PTB_at5L / p_at4u) ** p_at4w))
                                     / (((1 + p_at4G) + ((c_PTB_at5L / p_at4u) ** p_at4w))
                                        + ((c_MiRs_at5N / p_at4C) ** p_at4E)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at5O
                            -> let c_RESTc_at5P = ((toVector x_at5O) Data.Vector.Unboxed.! 3)
                               in (p_at4I / (1 + ((c_RESTc_at5P / p_at4K) ** p_at4M))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at5Q
                            -> let c_PTB_at5R = ((toVector x_at5Q) Data.Vector.Unboxed.! 0)
                               in (p_at4O * c_PTB_at5R))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5S
                            -> let c_NPTB_at5T = ((toVector x_at5S) Data.Vector.Unboxed.! 1)
                               in (p_at4Q * c_NPTB_at5T))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at5U
                            -> let c_MiRs_at5V = ((toVector x_at5U) Data.Vector.Unboxed.! 2)
                               in (p_at4S * c_MiRs_at5V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at5W
                            -> let c_RESTc_at5X = ((toVector x_at5W) Data.Vector.Unboxed.! 3)
                               in (p_at4U * c_RESTc_at5X))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at5Y
                            -> let
                                 c_EndoNeuroTFs_at5Z = ((toVector x_at5Y) Data.Vector.Unboxed.! 4)
                               in (p_at4W * c_EndoNeuroTFs_at5Z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121510",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121512",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121518",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121520",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121524",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121526",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121528",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121530",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121532",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121536",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121538",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121544",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121548",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121550",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121552",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121554",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121568",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at4X
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6B
                            p_at4W = code-0.1.0.0:Genome.FixedList.Functions.double g_at4V
                            (g_at4V, gpart_at6B) = Genome.Split.split gpart_at6A
                            p_at4U = code-0.1.0.0:Genome.FixedList.Functions.double g_at4T
                            (g_at4T, gpart_at6A) = Genome.Split.split gpart_at6z
                            p_at4S = code-0.1.0.0:Genome.FixedList.Functions.double g_at4R
                            (g_at4R, gpart_at6z) = Genome.Split.split gpart_at6y
                            p_at4Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at4P
                            (g_at4P, gpart_at6y) = Genome.Split.split gpart_at6x
                            p_at4O = code-0.1.0.0:Genome.FixedList.Functions.double g_at4N
                            (g_at4N, gpart_at6x) = Genome.Split.split gpart_at6w
                            p_at4M = Functions.belowten' g_at4L
                            (g_at4L, gpart_at6w) = Genome.Split.split gpart_at6v
                            p_at4K = code-0.1.0.0:Genome.FixedList.Functions.double g_at4J
                            (g_at4J, gpart_at6v) = Genome.Split.split gpart_at6u
                            p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                            (g_at4H, gpart_at6u) = Genome.Split.split gpart_at6t
                            p_at4G = code-0.1.0.0:Genome.FixedList.Functions.double g_at4F
                            (g_at4F, gpart_at6t) = Genome.Split.split gpart_at6s
                            p_at4E = Functions.belowten' g_at4D
                            (g_at4D, gpart_at6s) = Genome.Split.split gpart_at6r
                            p_at4C = code-0.1.0.0:Genome.FixedList.Functions.double g_at4B
                            (g_at4B, gpart_at6r) = Genome.Split.split gpart_at6q
                            p_at4A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4z
                            (g_at4z, gpart_at6q) = Genome.Split.split gpart_at6p
                            p_at4y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4x
                            (g_at4x, gpart_at6p) = Genome.Split.split gpart_at6o
                            p_at4w = Functions.belowten' g_at4v
                            (g_at4v, gpart_at6o) = Genome.Split.split gpart_at6n
                            p_at4u = code-0.1.0.0:Genome.FixedList.Functions.double g_at4t
                            (g_at4t, gpart_at6n) = Genome.Split.split gpart_at6m
                            p_at4s = code-0.1.0.0:Genome.FixedList.Functions.double g_at4r
                            (g_at4r, gpart_at6m) = Genome.Split.split gpart_at6l
                            p_at4q = code-0.1.0.0:Genome.FixedList.Functions.double g_at4p
                            (g_at4p, gpart_at6l) = Genome.Split.split gpart_at6k
                            p_at4o = Functions.belowten' g_at4n
                            (g_at4n, gpart_at6k) = Genome.Split.split gpart_at6j
                            p_at4m = code-0.1.0.0:Genome.FixedList.Functions.double g_at4l
                            (g_at4l, gpart_at6j) = Genome.Split.split gpart_at6i
                            p_at4k = Functions.belowten' g_at4j
                            (g_at4j, gpart_at6i) = Genome.Split.split gpart_at6h
                            p_at4i = code-0.1.0.0:Genome.FixedList.Functions.double g_at4h
                            (g_at4h, gpart_at6h) = Genome.Split.split gpart_at6g
                            p_at4g
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4f
                            (g_at4f, gpart_at6g) = Genome.Split.split gpart_at6f
                            p_at4e
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4d
                            (g_at4d, gpart_at6f) = Genome.Split.split gpart_at6e
                            p_at4c = code-0.1.0.0:Genome.FixedList.Functions.double g_at4b
                            (g_at4b, gpart_at6e) = Genome.Split.split gpart_at6d
                            p_at4a = Functions.belowten' g_at49
                            (g_at49, gpart_at6d) = Genome.Split.split gpart_at6c
                            p_at48 = code-0.1.0.0:Genome.FixedList.Functions.double g_at47
                            (g_at47, gpart_at6c) = Genome.Split.split gpart_at6b
                            p_at46 = Functions.belowten' g_at45
                            (g_at45, gpart_at6b) = Genome.Split.split gpart_at6a
                            p_at44 = code-0.1.0.0:Genome.FixedList.Functions.double g_at43
                            (g_at43, gpart_at6a) = Genome.Split.split gpart_at69
                            p_at42 = code-0.1.0.0:Genome.FixedList.Functions.double g_at41
                            (g_at41, gpart_at69) = Genome.Split.split gpart_at68
                            p_at40 = Functions.belowten' g_at3Z
                            (g_at3Z, gpart_at68) = Genome.Split.split gpart_at67
                            p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                            (g_at3X, gpart_at67) = Genome.Split.split gpart_at66
                            p_at3W
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3V
                            (g_at3V, gpart_at66) = Genome.Split.split gpart_at65
                            p_at3U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3T
                            (g_at3T, gpart_at65) = Genome.Split.split gpart_at64
                            p_at3S = code-0.1.0.0:Genome.FixedList.Functions.double g_at3R
                            (g_at3R, gpart_at64) = Genome.Split.split gpart_at63
                            p_at3Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3P
                            (g_at3P, gpart_at63) = Genome.Split.split gpart_at62
                            p_at3O = code-0.1.0.0:Genome.FixedList.Functions.double g_at3N
                            (g_at3N, gpart_at62) = Genome.Split.split gpart_at61
                            p_at3M = code-0.1.0.0:Genome.FixedList.Functions.double g_at3L
                            (g_at3L, gpart_at61) = Genome.Split.split gpart_at60
                            p_at3K = code-0.1.0.0:Genome.FixedList.Functions.double g_at3J
                            (g_at3J, gpart_at60) = Genome.Split.split genome_at4X
                          in
                            \ desc_at4Y
                              -> case desc_at4Y of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3K)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3M)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3O)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Q)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3S)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3U)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3W)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Y)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at40)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at42)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at44)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at46)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at48)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4a)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4c)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4e)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4g)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4i)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4k)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4m)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4o)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4q)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4s)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4u)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4w)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4y)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4A)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4C)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4E)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4G)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4I)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4K)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4M)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4O)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Q)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4S)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4U)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4W)
                                   _ -> Nothing }}
