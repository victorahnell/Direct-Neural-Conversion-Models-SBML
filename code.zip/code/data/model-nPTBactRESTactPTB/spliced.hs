src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24OX
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24PD
                      p_a24OW = double g_a24OV
                      (g_a24OV, gpart_a24PD) = Genome.Split.split gpart_a24PC
                      p_a24OU = double g_a24OT
                      (g_a24OT, gpart_a24PC) = Genome.Split.split gpart_a24PB
                      p_a24OS = double g_a24OR
                      (g_a24OR, gpart_a24PB) = Genome.Split.split gpart_a24PA
                      p_a24OQ = double g_a24OP
                      (g_a24OP, gpart_a24PA) = Genome.Split.split gpart_a24Pz
                      p_a24OO = double g_a24ON
                      (g_a24ON, gpart_a24Pz) = Genome.Split.split gpart_a24Py
                      p_a24OM = Functions.belowten' g_a24OL
                      (g_a24OL, gpart_a24Py) = Genome.Split.split gpart_a24Px
                      p_a24OK = double g_a24OJ
                      (g_a24OJ, gpart_a24Px) = Genome.Split.split gpart_a24Pw
                      p_a24OI = double g_a24OH
                      (g_a24OH, gpart_a24Pw) = Genome.Split.split gpart_a24Pv
                      p_a24OG = double g_a24OF
                      (g_a24OF, gpart_a24Pv) = Genome.Split.split gpart_a24Pu
                      p_a24OE = Functions.belowten' g_a24OD
                      (g_a24OD, gpart_a24Pu) = Genome.Split.split gpart_a24Pt
                      p_a24OC = double g_a24OB
                      (g_a24OB, gpart_a24Pt) = Genome.Split.split gpart_a24Ps
                      p_a24OA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oz
                      (g_a24Oz, gpart_a24Ps) = Genome.Split.split gpart_a24Pr
                      p_a24Oy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ox
                      (g_a24Ox, gpart_a24Pr) = Genome.Split.split gpart_a24Pq
                      p_a24Ow = Functions.belowten' g_a24Ov
                      (g_a24Ov, gpart_a24Pq) = Genome.Split.split gpart_a24Pp
                      p_a24Ou = double g_a24Ot
                      (g_a24Ot, gpart_a24Pp) = Genome.Split.split gpart_a24Po
                      p_a24Os = Functions.belowten' g_a24Or
                      (g_a24Or, gpart_a24Po) = Genome.Split.split gpart_a24Pn
                      p_a24Oq = double g_a24Op
                      (g_a24Op, gpart_a24Pn) = Genome.Split.split gpart_a24Pm
                      p_a24Oo = double g_a24On
                      (g_a24On, gpart_a24Pm) = Genome.Split.split gpart_a24Pl
                      p_a24Om = double g_a24Ol
                      (g_a24Ol, gpart_a24Pl) = Genome.Split.split gpart_a24Pk
                      p_a24Ok = Functions.belowten' g_a24Oj
                      (g_a24Oj, gpart_a24Pk) = Genome.Split.split gpart_a24Pj
                      p_a24Oi = double g_a24Oh
                      (g_a24Oh, gpart_a24Pj) = Genome.Split.split gpart_a24Pi
                      p_a24Og
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Of
                      (g_a24Of, gpart_a24Pi) = Genome.Split.split gpart_a24Ph
                      p_a24Oe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Od
                      (g_a24Od, gpart_a24Ph) = Genome.Split.split gpart_a24Pg
                      p_a24Oc = double g_a24Ob
                      (g_a24Ob, gpart_a24Pg) = Genome.Split.split gpart_a24Pf
                      p_a24Oa = Functions.belowten' g_a24O9
                      (g_a24O9, gpart_a24Pf) = Genome.Split.split gpart_a24Pe
                      p_a24O8 = double g_a24O7
                      (g_a24O7, gpart_a24Pe) = Genome.Split.split gpart_a24Pd
                      p_a24O6 = Functions.belowten' g_a24O5
                      (g_a24O5, gpart_a24Pd) = Genome.Split.split gpart_a24Pc
                      p_a24O4 = double g_a24O3
                      (g_a24O3, gpart_a24Pc) = Genome.Split.split gpart_a24Pb
                      p_a24O2 = double g_a24O1
                      (g_a24O1, gpart_a24Pb) = Genome.Split.split gpart_a24Pa
                      p_a24O0 = double g_a24NZ
                      (g_a24NZ, gpart_a24Pa) = Genome.Split.split gpart_a24P9
                      p_a24NY = Functions.belowten' g_a24NX
                      (g_a24NX, gpart_a24P9) = Genome.Split.split gpart_a24P8
                      p_a24NW = double g_a24NV
                      (g_a24NV, gpart_a24P8) = Genome.Split.split gpart_a24P7
                      p_a24NU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NT
                      (g_a24NT, gpart_a24P7) = Genome.Split.split gpart_a24P6
                      p_a24NS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NR
                      (g_a24NR, gpart_a24P6) = Genome.Split.split gpart_a24P5
                      p_a24NQ = Functions.belowten' g_a24NP
                      (g_a24NP, gpart_a24P5) = Genome.Split.split gpart_a24P4
                      p_a24NO = double g_a24NN
                      (g_a24NN, gpart_a24P4) = Genome.Split.split gpart_a24P3
                      p_a24NM = double g_a24NL
                      (g_a24NL, gpart_a24P3) = Genome.Split.split gpart_a24P2
                      p_a24NK = double g_a24NJ
                      (g_a24NJ, gpart_a24P2) = Genome.Split.split gpart_a24P1
                      p_a24NI = double g_a24NH
                      (g_a24NH, gpart_a24P1) = Genome.Split.split gpart_a24P0
                      p_a24NG = double g_a24NF
                      (g_a24NF, gpart_a24P0) = Genome.Split.split gpart_a24OZ
                      p_a24NE = double g_a24ND
                      (g_a24ND, gpart_a24OZ) = Genome.Split.split genome_a24OX
                    in  \ x_a24PE
                          -> let
                               c_PTB_a24PJ
                                 = ((Data.Fixed.Vector.toVector x_a24PE) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24PH
                                 = ((Data.Fixed.Vector.toVector x_a24PE) Data.Vector.Unboxed.! 2)
                               c_RESTc_a24PF
                                 = ((Data.Fixed.Vector.toVector x_a24PE) Data.Vector.Unboxed.! 3)
                               c_NPTB_a24PN
                                 = ((Data.Fixed.Vector.toVector x_a24PE) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a24Q0
                                 = ((Data.Fixed.Vector.toVector x_a24PE) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24NM
                                     * ((p_a24O0 + ((c_RESTc_a24PF / p_a24NO) ** p_a24NQ))
                                        / (((1 + p_a24O0) + ((c_RESTc_a24PF / p_a24NO) ** p_a24NQ))
                                           + ((c_MiRs_a24PH / p_a24NW) ** p_a24NY))))
                                    + (negate (p_a24OO * c_PTB_a24PJ))),
                                   ((p_a24O2
                                     / (1
                                        + (((c_MiRs_a24PH / p_a24O4) ** p_a24O6)
                                           + ((c_PTB_a24PJ / p_a24O8) ** p_a24Oa))))
                                    + (negate (p_a24OQ * c_NPTB_a24PN))),
                                   ((p_a24Oc
                                     * ((p_a24Om + ((p_a24NI / p_a24Oe) ** p_a24Og))
                                        / (((1 + p_a24Om) + ((p_a24NI / p_a24Oe) ** p_a24Og))
                                           + ((c_RESTc_a24PF / p_a24Oi) ** p_a24Ok))))
                                    + (negate (p_a24OS * c_MiRs_a24PH))),
                                   ((p_a24Oo
                                     * ((p_a24OG
                                         + (((c_NPTB_a24PN / p_a24Oq) ** p_a24Os)
                                            + ((c_PTB_a24PJ / p_a24Ou) ** p_a24Ow)))
                                        / (((1 + p_a24OG)
                                            + (((c_NPTB_a24PN / p_a24Oq) ** p_a24Os)
                                               + ((c_PTB_a24PJ / p_a24Ou) ** p_a24Ow)))
                                           + (((p_a24NE / p_a24Oy) ** p_a24OA)
                                              + ((c_MiRs_a24PH / p_a24OC) ** p_a24OE)))))
                                    + (negate (p_a24OU * c_RESTc_a24PF))),
                                   ((p_a24OI / (1 + ((c_RESTc_a24PF / p_a24OK) ** p_a24OM)))
                                    + (negate (p_a24OW * c_EndoNeuroTFs_a24Q0)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504916",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504918",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504938",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504940",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504958",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504960",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24OX
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24QF
                            p_a24OW = double g_a24OV
                            (g_a24OV, gpart_a24QF) = Genome.Split.split gpart_a24QE
                            p_a24OU = double g_a24OT
                            (g_a24OT, gpart_a24QE) = Genome.Split.split gpart_a24QD
                            p_a24OS = double g_a24OR
                            (g_a24OR, gpart_a24QD) = Genome.Split.split gpart_a24QC
                            p_a24OQ = double g_a24OP
                            (g_a24OP, gpart_a24QC) = Genome.Split.split gpart_a24QB
                            p_a24OO = double g_a24ON
                            (g_a24ON, gpart_a24QB) = Genome.Split.split gpart_a24QA
                            p_a24OM = Functions.belowten' g_a24OL
                            (g_a24OL, gpart_a24QA) = Genome.Split.split gpart_a24Qz
                            p_a24OK = double g_a24OJ
                            (g_a24OJ, gpart_a24Qz) = Genome.Split.split gpart_a24Qy
                            p_a24OI = double g_a24OH
                            (g_a24OH, gpart_a24Qy) = Genome.Split.split gpart_a24Qx
                            p_a24OG = double g_a24OF
                            (g_a24OF, gpart_a24Qx) = Genome.Split.split gpart_a24Qw
                            p_a24OE = Functions.belowten' g_a24OD
                            (g_a24OD, gpart_a24Qw) = Genome.Split.split gpart_a24Qv
                            p_a24OC = double g_a24OB
                            (g_a24OB, gpart_a24Qv) = Genome.Split.split gpart_a24Qu
                            p_a24OA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oz
                            (g_a24Oz, gpart_a24Qu) = Genome.Split.split gpart_a24Qt
                            p_a24Oy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ox
                            (g_a24Ox, gpart_a24Qt) = Genome.Split.split gpart_a24Qs
                            p_a24Ow = Functions.belowten' g_a24Ov
                            (g_a24Ov, gpart_a24Qs) = Genome.Split.split gpart_a24Qr
                            p_a24Ou = double g_a24Ot
                            (g_a24Ot, gpart_a24Qr) = Genome.Split.split gpart_a24Qq
                            p_a24Os = Functions.belowten' g_a24Or
                            (g_a24Or, gpart_a24Qq) = Genome.Split.split gpart_a24Qp
                            p_a24Oq = double g_a24Op
                            (g_a24Op, gpart_a24Qp) = Genome.Split.split gpart_a24Qo
                            p_a24Oo = double g_a24On
                            (g_a24On, gpart_a24Qo) = Genome.Split.split gpart_a24Qn
                            p_a24Om = double g_a24Ol
                            (g_a24Ol, gpart_a24Qn) = Genome.Split.split gpart_a24Qm
                            p_a24Ok = Functions.belowten' g_a24Oj
                            (g_a24Oj, gpart_a24Qm) = Genome.Split.split gpart_a24Ql
                            p_a24Oi = double g_a24Oh
                            (g_a24Oh, gpart_a24Ql) = Genome.Split.split gpart_a24Qk
                            p_a24Og
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Of
                            (g_a24Of, gpart_a24Qk) = Genome.Split.split gpart_a24Qj
                            p_a24Oe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Od
                            (g_a24Od, gpart_a24Qj) = Genome.Split.split gpart_a24Qi
                            p_a24Oc = double g_a24Ob
                            (g_a24Ob, gpart_a24Qi) = Genome.Split.split gpart_a24Qh
                            p_a24Oa = Functions.belowten' g_a24O9
                            (g_a24O9, gpart_a24Qh) = Genome.Split.split gpart_a24Qg
                            p_a24O8 = double g_a24O7
                            (g_a24O7, gpart_a24Qg) = Genome.Split.split gpart_a24Qf
                            p_a24O6 = Functions.belowten' g_a24O5
                            (g_a24O5, gpart_a24Qf) = Genome.Split.split gpart_a24Qe
                            p_a24O4 = double g_a24O3
                            (g_a24O3, gpart_a24Qe) = Genome.Split.split gpart_a24Qd
                            p_a24O2 = double g_a24O1
                            (g_a24O1, gpart_a24Qd) = Genome.Split.split gpart_a24Qc
                            p_a24O0 = double g_a24NZ
                            (g_a24NZ, gpart_a24Qc) = Genome.Split.split gpart_a24Qb
                            p_a24NY = Functions.belowten' g_a24NX
                            (g_a24NX, gpart_a24Qb) = Genome.Split.split gpart_a24Qa
                            p_a24NW = double g_a24NV
                            (g_a24NV, gpart_a24Qa) = Genome.Split.split gpart_a24Q9
                            p_a24NU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NT
                            (g_a24NT, gpart_a24Q9) = Genome.Split.split gpart_a24Q8
                            p_a24NS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NR
                            (g_a24NR, gpart_a24Q8) = Genome.Split.split gpart_a24Q7
                            p_a24NQ = Functions.belowten' g_a24NP
                            (g_a24NP, gpart_a24Q7) = Genome.Split.split gpart_a24Q6
                            p_a24NO = double g_a24NN
                            (g_a24NN, gpart_a24Q6) = Genome.Split.split gpart_a24Q5
                            p_a24NM = double g_a24NL
                            (g_a24NL, gpart_a24Q5) = Genome.Split.split gpart_a24Q4
                            p_a24NK = double g_a24NJ
                            (g_a24NJ, gpart_a24Q4) = Genome.Split.split gpart_a24Q3
                            p_a24NI = double g_a24NH
                            (g_a24NH, gpart_a24Q3) = Genome.Split.split gpart_a24Q2
                            p_a24NG = double g_a24NF
                            (g_a24NF, gpart_a24Q2) = Genome.Split.split gpart_a24Q1
                            p_a24NE = double g_a24ND
                            (g_a24ND, gpart_a24Q1) = Genome.Split.split genome_a24OX
                          in
                            \ desc_a24OY
                              -> case desc_a24OY of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NE)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NG)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NI)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NK)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NM)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NO)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NQ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NS)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NU)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NW)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NY)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O0)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O2)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O4)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O6)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O8)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oa)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oc)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oe)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Og)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oi)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ok)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Om)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oo)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oq)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Os)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ou)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ow)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oy)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OA)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OC)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OE)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OG)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OI)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OK)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OM)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OO)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OQ)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OS)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OU)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OW)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24T9
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24TP
                      p_a24T8 = double g_a24T7
                      (g_a24T7, gpart_a24TP) = Genome.Split.split gpart_a24TO
                      p_a24T6 = double g_a24T5
                      (g_a24T5, gpart_a24TO) = Genome.Split.split gpart_a24TN
                      p_a24T4 = double g_a24T3
                      (g_a24T3, gpart_a24TN) = Genome.Split.split gpart_a24TM
                      p_a24T2 = double g_a24T1
                      (g_a24T1, gpart_a24TM) = Genome.Split.split gpart_a24TL
                      p_a24T0 = double g_a24SZ
                      (g_a24SZ, gpart_a24TL) = Genome.Split.split gpart_a24TK
                      p_a24SY = Functions.belowten' g_a24SX
                      (g_a24SX, gpart_a24TK) = Genome.Split.split gpart_a24TJ
                      p_a24SW = double g_a24SV
                      (g_a24SV, gpart_a24TJ) = Genome.Split.split gpart_a24TI
                      p_a24SU = double g_a24ST
                      (g_a24ST, gpart_a24TI) = Genome.Split.split gpart_a24TH
                      p_a24SS = double g_a24SR
                      (g_a24SR, gpart_a24TH) = Genome.Split.split gpart_a24TG
                      p_a24SQ = Functions.belowten' g_a24SP
                      (g_a24SP, gpart_a24TG) = Genome.Split.split gpart_a24TF
                      p_a24SO = double g_a24SN
                      (g_a24SN, gpart_a24TF) = Genome.Split.split gpart_a24TE
                      p_a24SM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SL
                      (g_a24SL, gpart_a24TE) = Genome.Split.split gpart_a24TD
                      p_a24SK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SJ
                      (g_a24SJ, gpart_a24TD) = Genome.Split.split gpart_a24TC
                      p_a24SI = Functions.belowten' g_a24SH
                      (g_a24SH, gpart_a24TC) = Genome.Split.split gpart_a24TB
                      p_a24SG = double g_a24SF
                      (g_a24SF, gpart_a24TB) = Genome.Split.split gpart_a24TA
                      p_a24SE = Functions.belowten' g_a24SD
                      (g_a24SD, gpart_a24TA) = Genome.Split.split gpart_a24Tz
                      p_a24SC = double g_a24SB
                      (g_a24SB, gpart_a24Tz) = Genome.Split.split gpart_a24Ty
                      p_a24SA = double g_a24Sz
                      (g_a24Sz, gpart_a24Ty) = Genome.Split.split gpart_a24Tx
                      p_a24Sy = double g_a24Sx
                      (g_a24Sx, gpart_a24Tx) = Genome.Split.split gpart_a24Tw
                      p_a24Sw = Functions.belowten' g_a24Sv
                      (g_a24Sv, gpart_a24Tw) = Genome.Split.split gpart_a24Tv
                      p_a24Su = double g_a24St
                      (g_a24St, gpart_a24Tv) = Genome.Split.split gpart_a24Tu
                      p_a24Ss
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sr
                      (g_a24Sr, gpart_a24Tu) = Genome.Split.split gpart_a24Tt
                      p_a24Sq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sp
                      (g_a24Sp, gpart_a24Tt) = Genome.Split.split gpart_a24Ts
                      p_a24So = double g_a24Sn
                      (g_a24Sn, gpart_a24Ts) = Genome.Split.split gpart_a24Tr
                      p_a24Sm = Functions.belowten' g_a24Sl
                      (g_a24Sl, gpart_a24Tr) = Genome.Split.split gpart_a24Tq
                      p_a24Sk = double g_a24Sj
                      (g_a24Sj, gpart_a24Tq) = Genome.Split.split gpart_a24Tp
                      p_a24Si = Functions.belowten' g_a24Sh
                      (g_a24Sh, gpart_a24Tp) = Genome.Split.split gpart_a24To
                      p_a24Sg = double g_a24Sf
                      (g_a24Sf, gpart_a24To) = Genome.Split.split gpart_a24Tn
                      p_a24Se = double g_a24Sd
                      (g_a24Sd, gpart_a24Tn) = Genome.Split.split gpart_a24Tm
                      p_a24Sc = double g_a24Sb
                      (g_a24Sb, gpart_a24Tm) = Genome.Split.split gpart_a24Tl
                      p_a24Sa = Functions.belowten' g_a24S9
                      (g_a24S9, gpart_a24Tl) = Genome.Split.split gpart_a24Tk
                      p_a24S8 = double g_a24S7
                      (g_a24S7, gpart_a24Tk) = Genome.Split.split gpart_a24Tj
                      p_a24S6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S5
                      (g_a24S5, gpart_a24Tj) = Genome.Split.split gpart_a24Ti
                      p_a24S4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S3
                      (g_a24S3, gpart_a24Ti) = Genome.Split.split gpart_a24Th
                      p_a24S2 = Functions.belowten' g_a24S1
                      (g_a24S1, gpart_a24Th) = Genome.Split.split gpart_a24Tg
                      p_a24S0 = double g_a24RZ
                      (g_a24RZ, gpart_a24Tg) = Genome.Split.split gpart_a24Tf
                      p_a24RY = double g_a24RX
                      (g_a24RX, gpart_a24Tf) = Genome.Split.split gpart_a24Te
                      p_a24RW = double g_a24RV
                      (g_a24RV, gpart_a24Te) = Genome.Split.split gpart_a24Td
                      p_a24RU = double g_a24RT
                      (g_a24RT, gpart_a24Td) = Genome.Split.split gpart_a24Tc
                      p_a24RS = double g_a24RR
                      (g_a24RR, gpart_a24Tc) = Genome.Split.split gpart_a24Tb
                      p_a24RQ = double g_a24RP
                      (g_a24RP, gpart_a24Tb) = Genome.Split.split genome_a24T9
                    in  \ x_a24TQ
                          -> let
                               c_PTB_a24TV
                                 = ((Data.Fixed.Vector.toVector x_a24TQ) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24TT
                                 = ((Data.Fixed.Vector.toVector x_a24TQ) Data.Vector.Unboxed.! 2)
                               c_RESTc_a24TR
                                 = ((Data.Fixed.Vector.toVector x_a24TQ) Data.Vector.Unboxed.! 3)
                               c_NPTB_a24TZ
                                 = ((Data.Fixed.Vector.toVector x_a24TQ) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a24Uc
                                 = ((Data.Fixed.Vector.toVector x_a24TQ) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24RY
                                     * ((p_a24Sc + ((c_RESTc_a24TR / p_a24S0) ** p_a24S2))
                                        / (((1 + p_a24Sc) + ((c_RESTc_a24TR / p_a24S0) ** p_a24S2))
                                           + ((c_MiRs_a24TT / p_a24S8) ** p_a24Sa))))
                                    + (negate (p_a24T0 * c_PTB_a24TV))),
                                   ((p_a24Se
                                     / (1
                                        + (((c_MiRs_a24TT / p_a24Sg) ** p_a24Si)
                                           + ((c_PTB_a24TV / p_a24Sk) ** p_a24Sm))))
                                    + (negate (p_a24T2 * c_NPTB_a24TZ))),
                                   ((p_a24So
                                     * (p_a24Sy
                                        / ((1 + p_a24Sy) + ((c_RESTc_a24TR / p_a24Su) ** p_a24Sw))))
                                    + (negate (p_a24T4 * c_MiRs_a24TT))),
                                   ((p_a24SA
                                     * ((p_a24SS
                                         + (((c_NPTB_a24TZ / p_a24SC) ** p_a24SE)
                                            + ((c_PTB_a24TV / p_a24SG) ** p_a24SI)))
                                        / (((1 + p_a24SS)
                                            + (((c_NPTB_a24TZ / p_a24SC) ** p_a24SE)
                                               + ((c_PTB_a24TV / p_a24SG) ** p_a24SI)))
                                           + (((p_a24RQ / p_a24SK) ** p_a24SM)
                                              + ((c_MiRs_a24TT / p_a24SO) ** p_a24SQ)))))
                                    + (negate (p_a24T6 * c_RESTc_a24TR))),
                                   ((p_a24SU / (1 + ((c_RESTc_a24TR / p_a24SW) ** p_a24SY)))
                                    + (negate (p_a24T8 * c_EndoNeuroTFs_a24Uc)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505176",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505178",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505180",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505198",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505200",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505206",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505218",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505220",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505232",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505234",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24T9
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24UR
                            p_a24T8 = double g_a24T7
                            (g_a24T7, gpart_a24UR) = Genome.Split.split gpart_a24UQ
                            p_a24T6 = double g_a24T5
                            (g_a24T5, gpart_a24UQ) = Genome.Split.split gpart_a24UP
                            p_a24T4 = double g_a24T3
                            (g_a24T3, gpart_a24UP) = Genome.Split.split gpart_a24UO
                            p_a24T2 = double g_a24T1
                            (g_a24T1, gpart_a24UO) = Genome.Split.split gpart_a24UN
                            p_a24T0 = double g_a24SZ
                            (g_a24SZ, gpart_a24UN) = Genome.Split.split gpart_a24UM
                            p_a24SY = Functions.belowten' g_a24SX
                            (g_a24SX, gpart_a24UM) = Genome.Split.split gpart_a24UL
                            p_a24SW = double g_a24SV
                            (g_a24SV, gpart_a24UL) = Genome.Split.split gpart_a24UK
                            p_a24SU = double g_a24ST
                            (g_a24ST, gpart_a24UK) = Genome.Split.split gpart_a24UJ
                            p_a24SS = double g_a24SR
                            (g_a24SR, gpart_a24UJ) = Genome.Split.split gpart_a24UI
                            p_a24SQ = Functions.belowten' g_a24SP
                            (g_a24SP, gpart_a24UI) = Genome.Split.split gpart_a24UH
                            p_a24SO = double g_a24SN
                            (g_a24SN, gpart_a24UH) = Genome.Split.split gpart_a24UG
                            p_a24SM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SL
                            (g_a24SL, gpart_a24UG) = Genome.Split.split gpart_a24UF
                            p_a24SK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SJ
                            (g_a24SJ, gpart_a24UF) = Genome.Split.split gpart_a24UE
                            p_a24SI = Functions.belowten' g_a24SH
                            (g_a24SH, gpart_a24UE) = Genome.Split.split gpart_a24UD
                            p_a24SG = double g_a24SF
                            (g_a24SF, gpart_a24UD) = Genome.Split.split gpart_a24UC
                            p_a24SE = Functions.belowten' g_a24SD
                            (g_a24SD, gpart_a24UC) = Genome.Split.split gpart_a24UB
                            p_a24SC = double g_a24SB
                            (g_a24SB, gpart_a24UB) = Genome.Split.split gpart_a24UA
                            p_a24SA = double g_a24Sz
                            (g_a24Sz, gpart_a24UA) = Genome.Split.split gpart_a24Uz
                            p_a24Sy = double g_a24Sx
                            (g_a24Sx, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                            p_a24Sw = Functions.belowten' g_a24Sv
                            (g_a24Sv, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                            p_a24Su = double g_a24St
                            (g_a24St, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                            p_a24Ss
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sr
                            (g_a24Sr, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                            p_a24Sq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sp
                            (g_a24Sp, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                            p_a24So = double g_a24Sn
                            (g_a24Sn, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                            p_a24Sm = Functions.belowten' g_a24Sl
                            (g_a24Sl, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                            p_a24Sk = double g_a24Sj
                            (g_a24Sj, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                            p_a24Si = Functions.belowten' g_a24Sh
                            (g_a24Sh, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                            p_a24Sg = double g_a24Sf
                            (g_a24Sf, gpart_a24Uq) = Genome.Split.split gpart_a24Up
                            p_a24Se = double g_a24Sd
                            (g_a24Sd, gpart_a24Up) = Genome.Split.split gpart_a24Uo
                            p_a24Sc = double g_a24Sb
                            (g_a24Sb, gpart_a24Uo) = Genome.Split.split gpart_a24Un
                            p_a24Sa = Functions.belowten' g_a24S9
                            (g_a24S9, gpart_a24Un) = Genome.Split.split gpart_a24Um
                            p_a24S8 = double g_a24S7
                            (g_a24S7, gpart_a24Um) = Genome.Split.split gpart_a24Ul
                            p_a24S6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S5
                            (g_a24S5, gpart_a24Ul) = Genome.Split.split gpart_a24Uk
                            p_a24S4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S3
                            (g_a24S3, gpart_a24Uk) = Genome.Split.split gpart_a24Uj
                            p_a24S2 = Functions.belowten' g_a24S1
                            (g_a24S1, gpart_a24Uj) = Genome.Split.split gpart_a24Ui
                            p_a24S0 = double g_a24RZ
                            (g_a24RZ, gpart_a24Ui) = Genome.Split.split gpart_a24Uh
                            p_a24RY = double g_a24RX
                            (g_a24RX, gpart_a24Uh) = Genome.Split.split gpart_a24Ug
                            p_a24RW = double g_a24RV
                            (g_a24RV, gpart_a24Ug) = Genome.Split.split gpart_a24Uf
                            p_a24RU = double g_a24RT
                            (g_a24RT, gpart_a24Uf) = Genome.Split.split gpart_a24Ue
                            p_a24RS = double g_a24RR
                            (g_a24RR, gpart_a24Ue) = Genome.Split.split gpart_a24Ud
                            p_a24RQ = double g_a24RP
                            (g_a24RP, gpart_a24Ud) = Genome.Split.split genome_a24T9
                          in
                            \ desc_a24Ta
                              -> case desc_a24Ta of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RQ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RS)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RU)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RW)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RY)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S0)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S2)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S4)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S6)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S8)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sa)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sc)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Se)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sg)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Si)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sk)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sm)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24So)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sq)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ss)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Su)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sw)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sy)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SA)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SC)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SE)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SG)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SI)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SK)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SM)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SO)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SQ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SS)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SU)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SW)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SY)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T0)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T2)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T4)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T6)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T8)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24Xl
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Y1
                      p_a24Xk = double g_a24Xj
                      (g_a24Xj, gpart_a24Y1) = Genome.Split.split gpart_a24Y0
                      p_a24Xi = double g_a24Xh
                      (g_a24Xh, gpart_a24Y0) = Genome.Split.split gpart_a24XZ
                      p_a24Xg = double g_a24Xf
                      (g_a24Xf, gpart_a24XZ) = Genome.Split.split gpart_a24XY
                      p_a24Xe = double g_a24Xd
                      (g_a24Xd, gpart_a24XY) = Genome.Split.split gpart_a24XX
                      p_a24Xc = double g_a24Xb
                      (g_a24Xb, gpart_a24XX) = Genome.Split.split gpart_a24XW
                      p_a24Xa = Functions.belowten' g_a24X9
                      (g_a24X9, gpart_a24XW) = Genome.Split.split gpart_a24XV
                      p_a24X8 = double g_a24X7
                      (g_a24X7, gpart_a24XV) = Genome.Split.split gpart_a24XU
                      p_a24X6 = double g_a24X5
                      (g_a24X5, gpart_a24XU) = Genome.Split.split gpart_a24XT
                      p_a24X4 = double g_a24X3
                      (g_a24X3, gpart_a24XT) = Genome.Split.split gpart_a24XS
                      p_a24X2 = Functions.belowten' g_a24X1
                      (g_a24X1, gpart_a24XS) = Genome.Split.split gpart_a24XR
                      p_a24X0 = double g_a24WZ
                      (g_a24WZ, gpart_a24XR) = Genome.Split.split gpart_a24XQ
                      p_a24WY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WX
                      (g_a24WX, gpart_a24XQ) = Genome.Split.split gpart_a24XP
                      p_a24WW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WV
                      (g_a24WV, gpart_a24XP) = Genome.Split.split gpart_a24XO
                      p_a24WU = Functions.belowten' g_a24WT
                      (g_a24WT, gpart_a24XO) = Genome.Split.split gpart_a24XN
                      p_a24WS = double g_a24WR
                      (g_a24WR, gpart_a24XN) = Genome.Split.split gpart_a24XM
                      p_a24WQ = Functions.belowten' g_a24WP
                      (g_a24WP, gpart_a24XM) = Genome.Split.split gpart_a24XL
                      p_a24WO = double g_a24WN
                      (g_a24WN, gpart_a24XL) = Genome.Split.split gpart_a24XK
                      p_a24WM = double g_a24WL
                      (g_a24WL, gpart_a24XK) = Genome.Split.split gpart_a24XJ
                      p_a24WK = double g_a24WJ
                      (g_a24WJ, gpart_a24XJ) = Genome.Split.split gpart_a24XI
                      p_a24WI = Functions.belowten' g_a24WH
                      (g_a24WH, gpart_a24XI) = Genome.Split.split gpart_a24XH
                      p_a24WG = double g_a24WF
                      (g_a24WF, gpart_a24XH) = Genome.Split.split gpart_a24XG
                      p_a24WE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WD
                      (g_a24WD, gpart_a24XG) = Genome.Split.split gpart_a24XF
                      p_a24WC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WB
                      (g_a24WB, gpart_a24XF) = Genome.Split.split gpart_a24XE
                      p_a24WA = double g_a24Wz
                      (g_a24Wz, gpart_a24XE) = Genome.Split.split gpart_a24XD
                      p_a24Wy = Functions.belowten' g_a24Wx
                      (g_a24Wx, gpart_a24XD) = Genome.Split.split gpart_a24XC
                      p_a24Ww = double g_a24Wv
                      (g_a24Wv, gpart_a24XC) = Genome.Split.split gpart_a24XB
                      p_a24Wu = Functions.belowten' g_a24Wt
                      (g_a24Wt, gpart_a24XB) = Genome.Split.split gpart_a24XA
                      p_a24Ws = double g_a24Wr
                      (g_a24Wr, gpart_a24XA) = Genome.Split.split gpart_a24Xz
                      p_a24Wq = double g_a24Wp
                      (g_a24Wp, gpart_a24Xz) = Genome.Split.split gpart_a24Xy
                      p_a24Wo = double g_a24Wn
                      (g_a24Wn, gpart_a24Xy) = Genome.Split.split gpart_a24Xx
                      p_a24Wm = Functions.belowten' g_a24Wl
                      (g_a24Wl, gpart_a24Xx) = Genome.Split.split gpart_a24Xw
                      p_a24Wk = double g_a24Wj
                      (g_a24Wj, gpart_a24Xw) = Genome.Split.split gpart_a24Xv
                      p_a24Wi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wh
                      (g_a24Wh, gpart_a24Xv) = Genome.Split.split gpart_a24Xu
                      p_a24Wg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wf
                      (g_a24Wf, gpart_a24Xu) = Genome.Split.split gpart_a24Xt
                      p_a24We = Functions.belowten' g_a24Wd
                      (g_a24Wd, gpart_a24Xt) = Genome.Split.split gpart_a24Xs
                      p_a24Wc = double g_a24Wb
                      (g_a24Wb, gpart_a24Xs) = Genome.Split.split gpart_a24Xr
                      p_a24Wa = double g_a24W9
                      (g_a24W9, gpart_a24Xr) = Genome.Split.split gpart_a24Xq
                      p_a24W8 = double g_a24W7
                      (g_a24W7, gpart_a24Xq) = Genome.Split.split gpart_a24Xp
                      p_a24W6 = double g_a24W5
                      (g_a24W5, gpart_a24Xp) = Genome.Split.split gpart_a24Xo
                      p_a24W4 = double g_a24W3
                      (g_a24W3, gpart_a24Xo) = Genome.Split.split gpart_a24Xn
                      p_a24W2 = double g_a24W1
                      (g_a24W1, gpart_a24Xn) = Genome.Split.split genome_a24Xl
                    in  \ x_a24Y2
                          -> let
                               c_PTB_a24Y7
                                 = ((Data.Fixed.Vector.toVector x_a24Y2) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Y5
                                 = ((Data.Fixed.Vector.toVector x_a24Y2) Data.Vector.Unboxed.! 2)
                               c_RESTc_a24Y3
                                 = ((Data.Fixed.Vector.toVector x_a24Y2) Data.Vector.Unboxed.! 3)
                               c_NPTB_a24Yb
                                 = ((Data.Fixed.Vector.toVector x_a24Y2) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a24Yo
                                 = ((Data.Fixed.Vector.toVector x_a24Y2) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Wa
                                     * ((p_a24Wo + ((c_RESTc_a24Y3 / p_a24Wc) ** p_a24We))
                                        / (((1 + p_a24Wo) + ((c_RESTc_a24Y3 / p_a24Wc) ** p_a24We))
                                           + ((c_MiRs_a24Y5 / p_a24Wk) ** p_a24Wm))))
                                    + (negate (p_a24Xc * c_PTB_a24Y7))),
                                   ((p_a24Wq
                                     / (1
                                        + (((c_MiRs_a24Y5 / p_a24Ws) ** p_a24Wu)
                                           + ((c_PTB_a24Y7 / p_a24Ww) ** p_a24Wy))))
                                    + (negate (p_a24Xe * c_NPTB_a24Yb))),
                                   ((p_a24WA
                                     * (p_a24WK
                                        / ((1 + p_a24WK) + ((c_RESTc_a24Y3 / p_a24WG) ** p_a24WI))))
                                    + (negate (p_a24Xg * c_MiRs_a24Y5))),
                                   ((p_a24WM
                                     * ((p_a24X4
                                         + (((c_NPTB_a24Yb / p_a24WO) ** p_a24WQ)
                                            + ((c_PTB_a24Y7 / p_a24WS) ** p_a24WU)))
                                        / (((1 + p_a24X4)
                                            + (((c_NPTB_a24Yb / p_a24WO) ** p_a24WQ)
                                               + ((c_PTB_a24Y7 / p_a24WS) ** p_a24WU)))
                                           + ((c_MiRs_a24Y5 / p_a24X0) ** p_a24X2))))
                                    + (negate (p_a24Xi * c_RESTc_a24Y3))),
                                   ((p_a24X6 / (1 + ((c_RESTc_a24Y3 / p_a24X8) ** p_a24Xa)))
                                    + (negate (p_a24Xk * c_EndoNeuroTFs_a24Yo)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505436",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505438",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505458",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505460",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505478",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505480",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505490",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505492",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Xl
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Z3
                            p_a24Xk = double g_a24Xj
                            (g_a24Xj, gpart_a24Z3) = Genome.Split.split gpart_a24Z2
                            p_a24Xi = double g_a24Xh
                            (g_a24Xh, gpart_a24Z2) = Genome.Split.split gpart_a24Z1
                            p_a24Xg = double g_a24Xf
                            (g_a24Xf, gpart_a24Z1) = Genome.Split.split gpart_a24Z0
                            p_a24Xe = double g_a24Xd
                            (g_a24Xd, gpart_a24Z0) = Genome.Split.split gpart_a24YZ
                            p_a24Xc = double g_a24Xb
                            (g_a24Xb, gpart_a24YZ) = Genome.Split.split gpart_a24YY
                            p_a24Xa = Functions.belowten' g_a24X9
                            (g_a24X9, gpart_a24YY) = Genome.Split.split gpart_a24YX
                            p_a24X8 = double g_a24X7
                            (g_a24X7, gpart_a24YX) = Genome.Split.split gpart_a24YW
                            p_a24X6 = double g_a24X5
                            (g_a24X5, gpart_a24YW) = Genome.Split.split gpart_a24YV
                            p_a24X4 = double g_a24X3
                            (g_a24X3, gpart_a24YV) = Genome.Split.split gpart_a24YU
                            p_a24X2 = Functions.belowten' g_a24X1
                            (g_a24X1, gpart_a24YU) = Genome.Split.split gpart_a24YT
                            p_a24X0 = double g_a24WZ
                            (g_a24WZ, gpart_a24YT) = Genome.Split.split gpart_a24YS
                            p_a24WY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WX
                            (g_a24WX, gpart_a24YS) = Genome.Split.split gpart_a24YR
                            p_a24WW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WV
                            (g_a24WV, gpart_a24YR) = Genome.Split.split gpart_a24YQ
                            p_a24WU = Functions.belowten' g_a24WT
                            (g_a24WT, gpart_a24YQ) = Genome.Split.split gpart_a24YP
                            p_a24WS = double g_a24WR
                            (g_a24WR, gpart_a24YP) = Genome.Split.split gpart_a24YO
                            p_a24WQ = Functions.belowten' g_a24WP
                            (g_a24WP, gpart_a24YO) = Genome.Split.split gpart_a24YN
                            p_a24WO = double g_a24WN
                            (g_a24WN, gpart_a24YN) = Genome.Split.split gpart_a24YM
                            p_a24WM = double g_a24WL
                            (g_a24WL, gpart_a24YM) = Genome.Split.split gpart_a24YL
                            p_a24WK = double g_a24WJ
                            (g_a24WJ, gpart_a24YL) = Genome.Split.split gpart_a24YK
                            p_a24WI = Functions.belowten' g_a24WH
                            (g_a24WH, gpart_a24YK) = Genome.Split.split gpart_a24YJ
                            p_a24WG = double g_a24WF
                            (g_a24WF, gpart_a24YJ) = Genome.Split.split gpart_a24YI
                            p_a24WE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WD
                            (g_a24WD, gpart_a24YI) = Genome.Split.split gpart_a24YH
                            p_a24WC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WB
                            (g_a24WB, gpart_a24YH) = Genome.Split.split gpart_a24YG
                            p_a24WA = double g_a24Wz
                            (g_a24Wz, gpart_a24YG) = Genome.Split.split gpart_a24YF
                            p_a24Wy = Functions.belowten' g_a24Wx
                            (g_a24Wx, gpart_a24YF) = Genome.Split.split gpart_a24YE
                            p_a24Ww = double g_a24Wv
                            (g_a24Wv, gpart_a24YE) = Genome.Split.split gpart_a24YD
                            p_a24Wu = Functions.belowten' g_a24Wt
                            (g_a24Wt, gpart_a24YD) = Genome.Split.split gpart_a24YC
                            p_a24Ws = double g_a24Wr
                            (g_a24Wr, gpart_a24YC) = Genome.Split.split gpart_a24YB
                            p_a24Wq = double g_a24Wp
                            (g_a24Wp, gpart_a24YB) = Genome.Split.split gpart_a24YA
                            p_a24Wo = double g_a24Wn
                            (g_a24Wn, gpart_a24YA) = Genome.Split.split gpart_a24Yz
                            p_a24Wm = Functions.belowten' g_a24Wl
                            (g_a24Wl, gpart_a24Yz) = Genome.Split.split gpart_a24Yy
                            p_a24Wk = double g_a24Wj
                            (g_a24Wj, gpart_a24Yy) = Genome.Split.split gpart_a24Yx
                            p_a24Wi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wh
                            (g_a24Wh, gpart_a24Yx) = Genome.Split.split gpart_a24Yw
                            p_a24Wg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wf
                            (g_a24Wf, gpart_a24Yw) = Genome.Split.split gpart_a24Yv
                            p_a24We = Functions.belowten' g_a24Wd
                            (g_a24Wd, gpart_a24Yv) = Genome.Split.split gpart_a24Yu
                            p_a24Wc = double g_a24Wb
                            (g_a24Wb, gpart_a24Yu) = Genome.Split.split gpart_a24Yt
                            p_a24Wa = double g_a24W9
                            (g_a24W9, gpart_a24Yt) = Genome.Split.split gpart_a24Ys
                            p_a24W8 = double g_a24W7
                            (g_a24W7, gpart_a24Ys) = Genome.Split.split gpart_a24Yr
                            p_a24W6 = double g_a24W5
                            (g_a24W5, gpart_a24Yr) = Genome.Split.split gpart_a24Yq
                            p_a24W4 = double g_a24W3
                            (g_a24W3, gpart_a24Yq) = Genome.Split.split gpart_a24Yp
                            p_a24W2 = double g_a24W1
                            (g_a24W1, gpart_a24Yp) = Genome.Split.split genome_a24Xl
                          in
                            \ desc_a24Xm
                              -> case desc_a24Xm of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W2)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W4)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W6)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W8)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wa)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wc)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24We)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wg)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wi)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wk)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wm)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wo)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wq)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ws)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wu)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ww)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wy)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WA)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WC)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WE)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WG)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WI)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WK)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WM)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WO)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WQ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WS)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WU)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WW)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WY)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X0)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X2)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X4)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X6)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X8)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xa)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xc)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xe)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xg)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xi)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xk)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a251x
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a252d
                      p_a251w = double g_a251v
                      (g_a251v, gpart_a252d) = Genome.Split.split gpart_a252c
                      p_a251u = double g_a251t
                      (g_a251t, gpart_a252c) = Genome.Split.split gpart_a252b
                      p_a251s = double g_a251r
                      (g_a251r, gpart_a252b) = Genome.Split.split gpart_a252a
                      p_a251q = double g_a251p
                      (g_a251p, gpart_a252a) = Genome.Split.split gpart_a2529
                      p_a251o = double g_a251n
                      (g_a251n, gpart_a2529) = Genome.Split.split gpart_a2528
                      p_a251m = Functions.belowten' g_a251l
                      (g_a251l, gpart_a2528) = Genome.Split.split gpart_a2527
                      p_a251k = double g_a251j
                      (g_a251j, gpart_a2527) = Genome.Split.split gpart_a2526
                      p_a251i = double g_a251h
                      (g_a251h, gpart_a2526) = Genome.Split.split gpart_a2525
                      p_a251g = double g_a251f
                      (g_a251f, gpart_a2525) = Genome.Split.split gpart_a2524
                      p_a251e = Functions.belowten' g_a251d
                      (g_a251d, gpart_a2524) = Genome.Split.split gpart_a2523
                      p_a251c = double g_a251b
                      (g_a251b, gpart_a2523) = Genome.Split.split gpart_a2522
                      p_a251a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2519
                      (g_a2519, gpart_a2522) = Genome.Split.split gpart_a2521
                      p_a2518
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2517
                      (g_a2517, gpart_a2521) = Genome.Split.split gpart_a2520
                      p_a2516 = Functions.belowten' g_a2515
                      (g_a2515, gpart_a2520) = Genome.Split.split gpart_a251Z
                      p_a2514 = double g_a2513
                      (g_a2513, gpart_a251Z) = Genome.Split.split gpart_a251Y
                      p_a2512 = Functions.belowten' g_a2511
                      (g_a2511, gpart_a251Y) = Genome.Split.split gpart_a251X
                      p_a2510 = double g_a250Z
                      (g_a250Z, gpart_a251X) = Genome.Split.split gpart_a251W
                      p_a250Y = double g_a250X
                      (g_a250X, gpart_a251W) = Genome.Split.split gpart_a251V
                      p_a250W = double g_a250V
                      (g_a250V, gpart_a251V) = Genome.Split.split gpart_a251U
                      p_a250U = Functions.belowten' g_a250T
                      (g_a250T, gpart_a251U) = Genome.Split.split gpart_a251T
                      p_a250S = double g_a250R
                      (g_a250R, gpart_a251T) = Genome.Split.split gpart_a251S
                      p_a250Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250P
                      (g_a250P, gpart_a251S) = Genome.Split.split gpart_a251R
                      p_a250O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250N
                      (g_a250N, gpart_a251R) = Genome.Split.split gpart_a251Q
                      p_a250M = double g_a250L
                      (g_a250L, gpart_a251Q) = Genome.Split.split gpart_a251P
                      p_a250K = Functions.belowten' g_a250J
                      (g_a250J, gpart_a251P) = Genome.Split.split gpart_a251O
                      p_a250I = double g_a250H
                      (g_a250H, gpart_a251O) = Genome.Split.split gpart_a251N
                      p_a250G = Functions.belowten' g_a250F
                      (g_a250F, gpart_a251N) = Genome.Split.split gpart_a251M
                      p_a250E = double g_a250D
                      (g_a250D, gpart_a251M) = Genome.Split.split gpart_a251L
                      p_a250C = double g_a250B
                      (g_a250B, gpart_a251L) = Genome.Split.split gpart_a251K
                      p_a250A = double g_a250z
                      (g_a250z, gpart_a251K) = Genome.Split.split gpart_a251J
                      p_a250y = Functions.belowten' g_a250x
                      (g_a250x, gpart_a251J) = Genome.Split.split gpart_a251I
                      p_a250w = double g_a250v
                      (g_a250v, gpart_a251I) = Genome.Split.split gpart_a251H
                      p_a250u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250t
                      (g_a250t, gpart_a251H) = Genome.Split.split gpart_a251G
                      p_a250s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250r
                      (g_a250r, gpart_a251G) = Genome.Split.split gpart_a251F
                      p_a250q = Functions.belowten' g_a250p
                      (g_a250p, gpart_a251F) = Genome.Split.split gpart_a251E
                      p_a250o = double g_a250n
                      (g_a250n, gpart_a251E) = Genome.Split.split gpart_a251D
                      p_a250m = double g_a250l
                      (g_a250l, gpart_a251D) = Genome.Split.split gpart_a251C
                      p_a250k = double g_a250j
                      (g_a250j, gpart_a251C) = Genome.Split.split gpart_a251B
                      p_a250i = double g_a250h
                      (g_a250h, gpart_a251B) = Genome.Split.split gpart_a251A
                      p_a250g = double g_a250f
                      (g_a250f, gpart_a251A) = Genome.Split.split gpart_a251z
                      p_a250e = double g_a250d
                      (g_a250d, gpart_a251z) = Genome.Split.split genome_a251x
                    in  \ x_a252e
                          -> let
                               c_PTB_a252j
                                 = ((Data.Fixed.Vector.toVector x_a252e) Data.Vector.Unboxed.! 0)
                               c_MiRs_a252h
                                 = ((Data.Fixed.Vector.toVector x_a252e) Data.Vector.Unboxed.! 2)
                               c_RESTc_a252f
                                 = ((Data.Fixed.Vector.toVector x_a252e) Data.Vector.Unboxed.! 3)
                               c_NPTB_a252n
                                 = ((Data.Fixed.Vector.toVector x_a252e) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a252A
                                 = ((Data.Fixed.Vector.toVector x_a252e) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a250m
                                     * ((p_a250A + ((c_RESTc_a252f / p_a250o) ** p_a250q))
                                        / (((1 + p_a250A) + ((c_RESTc_a252f / p_a250o) ** p_a250q))
                                           + (((p_a250e / p_a250s) ** p_a250u)
                                              + ((c_MiRs_a252h / p_a250w) ** p_a250y)))))
                                    + (negate (p_a251o * c_PTB_a252j))),
                                   ((p_a250C
                                     / (1
                                        + (((c_MiRs_a252h / p_a250E) ** p_a250G)
                                           + ((c_PTB_a252j / p_a250I) ** p_a250K))))
                                    + (negate (p_a251q * c_NPTB_a252n))),
                                   ((p_a250M
                                     * (p_a250W
                                        / ((1 + p_a250W) + ((c_RESTc_a252f / p_a250S) ** p_a250U))))
                                    + (negate (p_a251s * c_MiRs_a252h))),
                                   ((p_a250Y
                                     * ((p_a251g
                                         + (((c_NPTB_a252n / p_a2510) ** p_a2512)
                                            + ((c_PTB_a252j / p_a2514) ** p_a2516)))
                                        / (((1 + p_a251g)
                                            + (((c_NPTB_a252n / p_a2510) ** p_a2512)
                                               + ((c_PTB_a252j / p_a2514) ** p_a2516)))
                                           + ((c_MiRs_a252h / p_a251c) ** p_a251e))))
                                    + (negate (p_a251u * c_RESTc_a252f))),
                                   ((p_a251i / (1 + ((c_RESTc_a252f / p_a251k) ** p_a251m)))
                                    + (negate (p_a251w * c_EndoNeuroTFs_a252A)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505684",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505696",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505698",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505700",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505702",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505704",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505705",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505706",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505707",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505708",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505710",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505712",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505714",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505716",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505718",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505720",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505722",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505724",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505726",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505728",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505730",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505738",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505740",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a251x
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a253f
                            p_a251w = double g_a251v
                            (g_a251v, gpart_a253f) = Genome.Split.split gpart_a253e
                            p_a251u = double g_a251t
                            (g_a251t, gpart_a253e) = Genome.Split.split gpart_a253d
                            p_a251s = double g_a251r
                            (g_a251r, gpart_a253d) = Genome.Split.split gpart_a253c
                            p_a251q = double g_a251p
                            (g_a251p, gpart_a253c) = Genome.Split.split gpart_a253b
                            p_a251o = double g_a251n
                            (g_a251n, gpart_a253b) = Genome.Split.split gpart_a253a
                            p_a251m = Functions.belowten' g_a251l
                            (g_a251l, gpart_a253a) = Genome.Split.split gpart_a2539
                            p_a251k = double g_a251j
                            (g_a251j, gpart_a2539) = Genome.Split.split gpart_a2538
                            p_a251i = double g_a251h
                            (g_a251h, gpart_a2538) = Genome.Split.split gpart_a2537
                            p_a251g = double g_a251f
                            (g_a251f, gpart_a2537) = Genome.Split.split gpart_a2536
                            p_a251e = Functions.belowten' g_a251d
                            (g_a251d, gpart_a2536) = Genome.Split.split gpart_a2535
                            p_a251c = double g_a251b
                            (g_a251b, gpart_a2535) = Genome.Split.split gpart_a2534
                            p_a251a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2519
                            (g_a2519, gpart_a2534) = Genome.Split.split gpart_a2533
                            p_a2518
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2517
                            (g_a2517, gpart_a2533) = Genome.Split.split gpart_a2532
                            p_a2516 = Functions.belowten' g_a2515
                            (g_a2515, gpart_a2532) = Genome.Split.split gpart_a2531
                            p_a2514 = double g_a2513
                            (g_a2513, gpart_a2531) = Genome.Split.split gpart_a2530
                            p_a2512 = Functions.belowten' g_a2511
                            (g_a2511, gpart_a2530) = Genome.Split.split gpart_a252Z
                            p_a2510 = double g_a250Z
                            (g_a250Z, gpart_a252Z) = Genome.Split.split gpart_a252Y
                            p_a250Y = double g_a250X
                            (g_a250X, gpart_a252Y) = Genome.Split.split gpart_a252X
                            p_a250W = double g_a250V
                            (g_a250V, gpart_a252X) = Genome.Split.split gpart_a252W
                            p_a250U = Functions.belowten' g_a250T
                            (g_a250T, gpart_a252W) = Genome.Split.split gpart_a252V
                            p_a250S = double g_a250R
                            (g_a250R, gpart_a252V) = Genome.Split.split gpart_a252U
                            p_a250Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250P
                            (g_a250P, gpart_a252U) = Genome.Split.split gpart_a252T
                            p_a250O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250N
                            (g_a250N, gpart_a252T) = Genome.Split.split gpart_a252S
                            p_a250M = double g_a250L
                            (g_a250L, gpart_a252S) = Genome.Split.split gpart_a252R
                            p_a250K = Functions.belowten' g_a250J
                            (g_a250J, gpart_a252R) = Genome.Split.split gpart_a252Q
                            p_a250I = double g_a250H
                            (g_a250H, gpart_a252Q) = Genome.Split.split gpart_a252P
                            p_a250G = Functions.belowten' g_a250F
                            (g_a250F, gpart_a252P) = Genome.Split.split gpart_a252O
                            p_a250E = double g_a250D
                            (g_a250D, gpart_a252O) = Genome.Split.split gpart_a252N
                            p_a250C = double g_a250B
                            (g_a250B, gpart_a252N) = Genome.Split.split gpart_a252M
                            p_a250A = double g_a250z
                            (g_a250z, gpart_a252M) = Genome.Split.split gpart_a252L
                            p_a250y = Functions.belowten' g_a250x
                            (g_a250x, gpart_a252L) = Genome.Split.split gpart_a252K
                            p_a250w = double g_a250v
                            (g_a250v, gpart_a252K) = Genome.Split.split gpart_a252J
                            p_a250u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250t
                            (g_a250t, gpart_a252J) = Genome.Split.split gpart_a252I
                            p_a250s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250r
                            (g_a250r, gpart_a252I) = Genome.Split.split gpart_a252H
                            p_a250q = Functions.belowten' g_a250p
                            (g_a250p, gpart_a252H) = Genome.Split.split gpart_a252G
                            p_a250o = double g_a250n
                            (g_a250n, gpart_a252G) = Genome.Split.split gpart_a252F
                            p_a250m = double g_a250l
                            (g_a250l, gpart_a252F) = Genome.Split.split gpart_a252E
                            p_a250k = double g_a250j
                            (g_a250j, gpart_a252E) = Genome.Split.split gpart_a252D
                            p_a250i = double g_a250h
                            (g_a250h, gpart_a252D) = Genome.Split.split gpart_a252C
                            p_a250g = double g_a250f
                            (g_a250f, gpart_a252C) = Genome.Split.split gpart_a252B
                            p_a250e = double g_a250d
                            (g_a250d, gpart_a252B) = Genome.Split.split genome_a251x
                          in
                            \ desc_a251y
                              -> case desc_a251y of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250e)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250g)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250i)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250k)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250m)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250o)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250q)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250s)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250u)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250w)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250y)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250A)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250C)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250E)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250G)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250I)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250K)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250M)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250O)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250Q)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250S)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250U)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250W)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250Y)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2510)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2512)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2514)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2516)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2518)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251a)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251c)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251e)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251g)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251i)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251k)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251m)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251o)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251q)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251s)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251u)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251w)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asWm
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asX2
                      p_asWl = code-0.1.0.0:Genome.FixedList.Functions.double g_asWk
                      (g_asWk, gpart_asX2) = Genome.Split.split gpart_asX1
                      p_asWj = code-0.1.0.0:Genome.FixedList.Functions.double g_asWi
                      (g_asWi, gpart_asX1) = Genome.Split.split gpart_asX0
                      p_asWh = code-0.1.0.0:Genome.FixedList.Functions.double g_asWg
                      (g_asWg, gpart_asX0) = Genome.Split.split gpart_asWZ
                      p_asWf = code-0.1.0.0:Genome.FixedList.Functions.double g_asWe
                      (g_asWe, gpart_asWZ) = Genome.Split.split gpart_asWY
                      p_asWd = code-0.1.0.0:Genome.FixedList.Functions.double g_asWc
                      (g_asWc, gpart_asWY) = Genome.Split.split gpart_asWX
                      p_asWb = Functions.belowten' g_asWa
                      (g_asWa, gpart_asWX) = Genome.Split.split gpart_asWW
                      p_asW9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW8
                      (g_asW8, gpart_asWW) = Genome.Split.split gpart_asWV
                      p_asW7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW6
                      (g_asW6, gpart_asWV) = Genome.Split.split gpart_asWU
                      p_asW5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW4
                      (g_asW4, gpart_asWU) = Genome.Split.split gpart_asWT
                      p_asW3 = Functions.belowten' g_asW2
                      (g_asW2, gpart_asWT) = Genome.Split.split gpart_asWS
                      p_asW1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW0
                      (g_asW0, gpart_asWS) = Genome.Split.split gpart_asWR
                      p_asVZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVY
                      (g_asVY, gpart_asWR) = Genome.Split.split gpart_asWQ
                      p_asVX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVW
                      (g_asVW, gpart_asWQ) = Genome.Split.split gpart_asWP
                      p_asVV = Functions.belowten' g_asVU
                      (g_asVU, gpart_asWP) = Genome.Split.split gpart_asWO
                      p_asVT = code-0.1.0.0:Genome.FixedList.Functions.double g_asVS
                      (g_asVS, gpart_asWO) = Genome.Split.split gpart_asWN
                      p_asVR = Functions.belowten' g_asVQ
                      (g_asVQ, gpart_asWN) = Genome.Split.split gpart_asWM
                      p_asVP = code-0.1.0.0:Genome.FixedList.Functions.double g_asVO
                      (g_asVO, gpart_asWM) = Genome.Split.split gpart_asWL
                      p_asVN = code-0.1.0.0:Genome.FixedList.Functions.double g_asVM
                      (g_asVM, gpart_asWL) = Genome.Split.split gpart_asWK
                      p_asVL = code-0.1.0.0:Genome.FixedList.Functions.double g_asVK
                      (g_asVK, gpart_asWK) = Genome.Split.split gpart_asWJ
                      p_asVJ = Functions.belowten' g_asVI
                      (g_asVI, gpart_asWJ) = Genome.Split.split gpart_asWI
                      p_asVH = code-0.1.0.0:Genome.FixedList.Functions.double g_asVG
                      (g_asVG, gpart_asWI) = Genome.Split.split gpart_asWH
                      p_asVF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVE
                      (g_asVE, gpart_asWH) = Genome.Split.split gpart_asWG
                      p_asVD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVC
                      (g_asVC, gpart_asWG) = Genome.Split.split gpart_asWF
                      p_asVB = code-0.1.0.0:Genome.FixedList.Functions.double g_asVA
                      (g_asVA, gpart_asWF) = Genome.Split.split gpart_asWE
                      p_asVz = Functions.belowten' g_asVy
                      (g_asVy, gpart_asWE) = Genome.Split.split gpart_asWD
                      p_asVx = code-0.1.0.0:Genome.FixedList.Functions.double g_asVw
                      (g_asVw, gpart_asWD) = Genome.Split.split gpart_asWC
                      p_asVv = Functions.belowten' g_asVu
                      (g_asVu, gpart_asWC) = Genome.Split.split gpart_asWB
                      p_asVt = code-0.1.0.0:Genome.FixedList.Functions.double g_asVs
                      (g_asVs, gpart_asWB) = Genome.Split.split gpart_asWA
                      p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                      (g_asVq, gpart_asWA) = Genome.Split.split gpart_asWz
                      p_asVp = code-0.1.0.0:Genome.FixedList.Functions.double g_asVo
                      (g_asVo, gpart_asWz) = Genome.Split.split gpart_asWy
                      p_asVn = Functions.belowten' g_asVm
                      (g_asVm, gpart_asWy) = Genome.Split.split gpart_asWx
                      p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                      (g_asVk, gpart_asWx) = Genome.Split.split gpart_asWw
                      p_asVj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVi
                      (g_asVi, gpart_asWw) = Genome.Split.split gpart_asWv
                      p_asVh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVg
                      (g_asVg, gpart_asWv) = Genome.Split.split gpart_asWu
                      p_asVf = Functions.belowten' g_asVe
                      (g_asVe, gpart_asWu) = Genome.Split.split gpart_asWt
                      p_asVd = code-0.1.0.0:Genome.FixedList.Functions.double g_asVc
                      (g_asVc, gpart_asWt) = Genome.Split.split gpart_asWs
                      p_asVb = code-0.1.0.0:Genome.FixedList.Functions.double g_asVa
                      (g_asVa, gpart_asWs) = Genome.Split.split gpart_asWr
                      p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                      (g_asV8, gpart_asWr) = Genome.Split.split gpart_asWq
                      p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                      (g_asV6, gpart_asWq) = Genome.Split.split gpart_asWp
                      p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                      (g_asV4, gpart_asWp) = Genome.Split.split gpart_asWo
                      p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                      (g_asV2, gpart_asWo) = Genome.Split.split genome_asWm
                    in
                      [Reaction
                         (\ x_asX3
                            -> let
                                 c_MiRs_asX6 = ((toVector x_asX3) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asX4 = ((toVector x_asX3) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asVb
                                  * ((p_asVp + ((c_RESTc_asX4 / p_asVd) ** p_asVf))
                                     / (((1 + p_asVp) + ((c_RESTc_asX4 / p_asVd) ** p_asVf))
                                        + ((c_MiRs_asX6 / p_asVl) ** p_asVn)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asX7
                            -> let
                                 c_MiRs_asX8 = ((toVector x_asX7) Data.Vector.Unboxed.! 2)
                                 c_PTB_asX9 = ((toVector x_asX7) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVr
                                  / (1
                                     + (((c_MiRs_asX8 / p_asVt) ** p_asVv)
                                        + ((c_PTB_asX9 / p_asVx) ** p_asVz)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asXa
                            -> let c_RESTc_asXb = ((toVector x_asXa) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asVB
                                  * ((p_asVL + ((p_asV7 / p_asVD) ** p_asVF))
                                     / (((1 + p_asVL) + ((p_asV7 / p_asVD) ** p_asVF))
                                        + ((c_RESTc_asXb / p_asVH) ** p_asVJ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asXc
                            -> let
                                 c_MiRs_asXh = ((toVector x_asXc) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXe = ((toVector x_asXc) Data.Vector.Unboxed.! 0)
                                 c_NPTB_asXd = ((toVector x_asXc) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asVN
                                  * ((p_asW5
                                      + (((c_NPTB_asXd / p_asVP) ** p_asVR)
                                         + ((c_PTB_asXe / p_asVT) ** p_asVV)))
                                     / (((1 + p_asW5)
                                         + (((c_NPTB_asXd / p_asVP) ** p_asVR)
                                            + ((c_PTB_asXe / p_asVT) ** p_asVV)))
                                        + (((p_asV3 / p_asVX) ** p_asVZ)
                                           + ((c_MiRs_asXh / p_asW1) ** p_asW3))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asXi
                            -> let c_RESTc_asXj = ((toVector x_asXi) Data.Vector.Unboxed.! 3)
                               in (p_asW7 / (1 + ((c_RESTc_asXj / p_asW9) ** p_asWb))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asXk
                            -> let c_PTB_asXl = ((toVector x_asXk) Data.Vector.Unboxed.! 0)
                               in (p_asWd * c_PTB_asXl))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXm
                            -> let c_NPTB_asXn = ((toVector x_asXm) Data.Vector.Unboxed.! 1)
                               in (p_asWf * c_NPTB_asXn))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asXo
                            -> let c_MiRs_asXp = ((toVector x_asXo) Data.Vector.Unboxed.! 2)
                               in (p_asWh * c_MiRs_asXp))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asXq
                            -> let c_RESTc_asXr = ((toVector x_asXq) Data.Vector.Unboxed.! 3)
                               in (p_asWj * c_RESTc_asXr))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asXs
                            -> let
                                 c_EndoNeuroTFs_asXt = ((toVector x_asXs) Data.Vector.Unboxed.! 4)
                               in (p_asWl * c_EndoNeuroTFs_asXt))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120969",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120971",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120973",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120975",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120977",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120981",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120983",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120986",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120987",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120988",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120989",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120990",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120991",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120992",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120993",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120994",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120995",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120996",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120997",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120998",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120999",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121000",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121001",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121002",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121003",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121004",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121005",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121006",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121007",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121008",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121009",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121010",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121011",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121012",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121013",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121014",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121015",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121016",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121017",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121018",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121019",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121020",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121021",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121023",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121025",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121027",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121034",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121035",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121036",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121037",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121038",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121039",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121040",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121041",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asWm
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYd
                            p_asWl = code-0.1.0.0:Genome.FixedList.Functions.double g_asWk
                            (g_asWk, gpart_asYd) = Genome.Split.split gpart_asYc
                            p_asWj = code-0.1.0.0:Genome.FixedList.Functions.double g_asWi
                            (g_asWi, gpart_asYc) = Genome.Split.split gpart_asYb
                            p_asWh = code-0.1.0.0:Genome.FixedList.Functions.double g_asWg
                            (g_asWg, gpart_asYb) = Genome.Split.split gpart_asYa
                            p_asWf = code-0.1.0.0:Genome.FixedList.Functions.double g_asWe
                            (g_asWe, gpart_asYa) = Genome.Split.split gpart_asY9
                            p_asWd = code-0.1.0.0:Genome.FixedList.Functions.double g_asWc
                            (g_asWc, gpart_asY9) = Genome.Split.split gpart_asY8
                            p_asWb = Functions.belowten' g_asWa
                            (g_asWa, gpart_asY8) = Genome.Split.split gpart_asY7
                            p_asW9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW8
                            (g_asW8, gpart_asY7) = Genome.Split.split gpart_asY6
                            p_asW7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW6
                            (g_asW6, gpart_asY6) = Genome.Split.split gpart_asY5
                            p_asW5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW4
                            (g_asW4, gpart_asY5) = Genome.Split.split gpart_asY4
                            p_asW3 = Functions.belowten' g_asW2
                            (g_asW2, gpart_asY4) = Genome.Split.split gpart_asY3
                            p_asW1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW0
                            (g_asW0, gpart_asY3) = Genome.Split.split gpart_asY2
                            p_asVZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVY
                            (g_asVY, gpart_asY2) = Genome.Split.split gpart_asY1
                            p_asVX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVW
                            (g_asVW, gpart_asY1) = Genome.Split.split gpart_asY0
                            p_asVV = Functions.belowten' g_asVU
                            (g_asVU, gpart_asY0) = Genome.Split.split gpart_asXZ
                            p_asVT = code-0.1.0.0:Genome.FixedList.Functions.double g_asVS
                            (g_asVS, gpart_asXZ) = Genome.Split.split gpart_asXY
                            p_asVR = Functions.belowten' g_asVQ
                            (g_asVQ, gpart_asXY) = Genome.Split.split gpart_asXX
                            p_asVP = code-0.1.0.0:Genome.FixedList.Functions.double g_asVO
                            (g_asVO, gpart_asXX) = Genome.Split.split gpart_asXW
                            p_asVN = code-0.1.0.0:Genome.FixedList.Functions.double g_asVM
                            (g_asVM, gpart_asXW) = Genome.Split.split gpart_asXV
                            p_asVL = code-0.1.0.0:Genome.FixedList.Functions.double g_asVK
                            (g_asVK, gpart_asXV) = Genome.Split.split gpart_asXU
                            p_asVJ = Functions.belowten' g_asVI
                            (g_asVI, gpart_asXU) = Genome.Split.split gpart_asXT
                            p_asVH = code-0.1.0.0:Genome.FixedList.Functions.double g_asVG
                            (g_asVG, gpart_asXT) = Genome.Split.split gpart_asXS
                            p_asVF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVE
                            (g_asVE, gpart_asXS) = Genome.Split.split gpart_asXR
                            p_asVD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVC
                            (g_asVC, gpart_asXR) = Genome.Split.split gpart_asXQ
                            p_asVB = code-0.1.0.0:Genome.FixedList.Functions.double g_asVA
                            (g_asVA, gpart_asXQ) = Genome.Split.split gpart_asXP
                            p_asVz = Functions.belowten' g_asVy
                            (g_asVy, gpart_asXP) = Genome.Split.split gpart_asXO
                            p_asVx = code-0.1.0.0:Genome.FixedList.Functions.double g_asVw
                            (g_asVw, gpart_asXO) = Genome.Split.split gpart_asXN
                            p_asVv = Functions.belowten' g_asVu
                            (g_asVu, gpart_asXN) = Genome.Split.split gpart_asXM
                            p_asVt = code-0.1.0.0:Genome.FixedList.Functions.double g_asVs
                            (g_asVs, gpart_asXM) = Genome.Split.split gpart_asXL
                            p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                            (g_asVq, gpart_asXL) = Genome.Split.split gpart_asXK
                            p_asVp = code-0.1.0.0:Genome.FixedList.Functions.double g_asVo
                            (g_asVo, gpart_asXK) = Genome.Split.split gpart_asXJ
                            p_asVn = Functions.belowten' g_asVm
                            (g_asVm, gpart_asXJ) = Genome.Split.split gpart_asXI
                            p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                            (g_asVk, gpart_asXI) = Genome.Split.split gpart_asXH
                            p_asVj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVi
                            (g_asVi, gpart_asXH) = Genome.Split.split gpart_asXG
                            p_asVh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVg
                            (g_asVg, gpart_asXG) = Genome.Split.split gpart_asXF
                            p_asVf = Functions.belowten' g_asVe
                            (g_asVe, gpart_asXF) = Genome.Split.split gpart_asXE
                            p_asVd = code-0.1.0.0:Genome.FixedList.Functions.double g_asVc
                            (g_asVc, gpart_asXE) = Genome.Split.split gpart_asXD
                            p_asVb = code-0.1.0.0:Genome.FixedList.Functions.double g_asVa
                            (g_asVa, gpart_asXD) = Genome.Split.split gpart_asXC
                            p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                            (g_asV8, gpart_asXC) = Genome.Split.split gpart_asXB
                            p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                            (g_asV6, gpart_asXB) = Genome.Split.split gpart_asXA
                            p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                            (g_asV4, gpart_asXA) = Genome.Split.split gpart_asXz
                            p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                            (g_asV2, gpart_asXz) = Genome.Split.split genome_asWm
                          in
                            \ desc_asWn
                              -> case desc_asWn of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV5)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV7)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV9)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVb)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVd)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVf)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVh)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVj)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVl)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVn)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVp)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVr)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVt)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVv)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVx)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVB)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVD)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVF)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVH)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVJ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVL)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVN)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVP)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVR)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVT)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVV)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVX)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW1)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW3)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW5)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW7)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW9)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWb)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWd)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWf)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWh)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWj)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWl)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_at0e
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0U
                      p_at0d = code-0.1.0.0:Genome.FixedList.Functions.double g_at0c
                      (g_at0c, gpart_at0U) = Genome.Split.split gpart_at0T
                      p_at0b = code-0.1.0.0:Genome.FixedList.Functions.double g_at0a
                      (g_at0a, gpart_at0T) = Genome.Split.split gpart_at0S
                      p_at09 = code-0.1.0.0:Genome.FixedList.Functions.double g_at08
                      (g_at08, gpart_at0S) = Genome.Split.split gpart_at0R
                      p_at07 = code-0.1.0.0:Genome.FixedList.Functions.double g_at06
                      (g_at06, gpart_at0R) = Genome.Split.split gpart_at0Q
                      p_at05 = code-0.1.0.0:Genome.FixedList.Functions.double g_at04
                      (g_at04, gpart_at0Q) = Genome.Split.split gpart_at0P
                      p_at03 = Functions.belowten' g_at02
                      (g_at02, gpart_at0P) = Genome.Split.split gpart_at0O
                      p_at01 = code-0.1.0.0:Genome.FixedList.Functions.double g_at00
                      (g_at00, gpart_at0O) = Genome.Split.split gpart_at0N
                      p_asZZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asZY
                      (g_asZY, gpart_at0N) = Genome.Split.split gpart_at0M
                      p_asZX = code-0.1.0.0:Genome.FixedList.Functions.double g_asZW
                      (g_asZW, gpart_at0M) = Genome.Split.split gpart_at0L
                      p_asZV = Functions.belowten' g_asZU
                      (g_asZU, gpart_at0L) = Genome.Split.split gpart_at0K
                      p_asZT = code-0.1.0.0:Genome.FixedList.Functions.double g_asZS
                      (g_asZS, gpart_at0K) = Genome.Split.split gpart_at0J
                      p_asZR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZQ
                      (g_asZQ, gpart_at0J) = Genome.Split.split gpart_at0I
                      p_asZP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZO
                      (g_asZO, gpart_at0I) = Genome.Split.split gpart_at0H
                      p_asZN = Functions.belowten' g_asZM
                      (g_asZM, gpart_at0H) = Genome.Split.split gpart_at0G
                      p_asZL = code-0.1.0.0:Genome.FixedList.Functions.double g_asZK
                      (g_asZK, gpart_at0G) = Genome.Split.split gpart_at0F
                      p_asZJ = Functions.belowten' g_asZI
                      (g_asZI, gpart_at0F) = Genome.Split.split gpart_at0E
                      p_asZH = code-0.1.0.0:Genome.FixedList.Functions.double g_asZG
                      (g_asZG, gpart_at0E) = Genome.Split.split gpart_at0D
                      p_asZF = code-0.1.0.0:Genome.FixedList.Functions.double g_asZE
                      (g_asZE, gpart_at0D) = Genome.Split.split gpart_at0C
                      p_asZD = code-0.1.0.0:Genome.FixedList.Functions.double g_asZC
                      (g_asZC, gpart_at0C) = Genome.Split.split gpart_at0B
                      p_asZB = Functions.belowten' g_asZA
                      (g_asZA, gpart_at0B) = Genome.Split.split gpart_at0A
                      p_asZz = code-0.1.0.0:Genome.FixedList.Functions.double g_asZy
                      (g_asZy, gpart_at0A) = Genome.Split.split gpart_at0z
                      p_asZx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZw
                      (g_asZw, gpart_at0z) = Genome.Split.split gpart_at0y
                      p_asZv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZu
                      (g_asZu, gpart_at0y) = Genome.Split.split gpart_at0x
                      p_asZt = code-0.1.0.0:Genome.FixedList.Functions.double g_asZs
                      (g_asZs, gpart_at0x) = Genome.Split.split gpart_at0w
                      p_asZr = Functions.belowten' g_asZq
                      (g_asZq, gpart_at0w) = Genome.Split.split gpart_at0v
                      p_asZp = code-0.1.0.0:Genome.FixedList.Functions.double g_asZo
                      (g_asZo, gpart_at0v) = Genome.Split.split gpart_at0u
                      p_asZn = Functions.belowten' g_asZm
                      (g_asZm, gpart_at0u) = Genome.Split.split gpart_at0t
                      p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                      (g_asZk, gpart_at0t) = Genome.Split.split gpart_at0s
                      p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                      (g_asZi, gpart_at0s) = Genome.Split.split gpart_at0r
                      p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                      (g_asZg, gpart_at0r) = Genome.Split.split gpart_at0q
                      p_asZf = Functions.belowten' g_asZe
                      (g_asZe, gpart_at0q) = Genome.Split.split gpart_at0p
                      p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                      (g_asZc, gpart_at0p) = Genome.Split.split gpart_at0o
                      p_asZb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZa
                      (g_asZa, gpart_at0o) = Genome.Split.split gpart_at0n
                      p_asZ9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ8
                      (g_asZ8, gpart_at0n) = Genome.Split.split gpart_at0m
                      p_asZ7 = Functions.belowten' g_asZ6
                      (g_asZ6, gpart_at0m) = Genome.Split.split gpart_at0l
                      p_asZ5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ4
                      (g_asZ4, gpart_at0l) = Genome.Split.split gpart_at0k
                      p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                      (g_asZ2, gpart_at0k) = Genome.Split.split gpart_at0j
                      p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                      (g_asZ0, gpart_at0j) = Genome.Split.split gpart_at0i
                      p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                      (g_asYY, gpart_at0i) = Genome.Split.split gpart_at0h
                      p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                      (g_asYW, gpart_at0h) = Genome.Split.split gpart_at0g
                      p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                      (g_asYU, gpart_at0g) = Genome.Split.split genome_at0e
                    in
                      [Reaction
                         (\ x_at0V
                            -> let
                                 c_MiRs_at0Y = ((toVector x_at0V) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at0W = ((toVector x_at0V) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asZ3
                                  * ((p_asZh + ((c_RESTc_at0W / p_asZ5) ** p_asZ7))
                                     / (((1 + p_asZh) + ((c_RESTc_at0W / p_asZ5) ** p_asZ7))
                                        + ((c_MiRs_at0Y / p_asZd) ** p_asZf)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0Z
                            -> let
                                 c_MiRs_at10 = ((toVector x_at0Z) Data.Vector.Unboxed.! 2)
                                 c_PTB_at11 = ((toVector x_at0Z) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZj
                                  / (1
                                     + (((c_MiRs_at10 / p_asZl) ** p_asZn)
                                        + ((c_PTB_at11 / p_asZp) ** p_asZr)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at12
                            -> let c_RESTc_at13 = ((toVector x_at12) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asZt
                                  * (p_asZD
                                     / ((1 + p_asZD) + ((c_RESTc_at13 / p_asZz) ** p_asZB)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at14
                            -> let
                                 c_MiRs_at19 = ((toVector x_at14) Data.Vector.Unboxed.! 2)
                                 c_PTB_at16 = ((toVector x_at14) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at15 = ((toVector x_at14) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asZF
                                  * ((p_asZX
                                      + (((c_NPTB_at15 / p_asZH) ** p_asZJ)
                                         + ((c_PTB_at16 / p_asZL) ** p_asZN)))
                                     / (((1 + p_asZX)
                                         + (((c_NPTB_at15 / p_asZH) ** p_asZJ)
                                            + ((c_PTB_at16 / p_asZL) ** p_asZN)))
                                        + (((p_asYV / p_asZP) ** p_asZR)
                                           + ((c_MiRs_at19 / p_asZT) ** p_asZV))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at1a
                            -> let c_RESTc_at1b = ((toVector x_at1a) Data.Vector.Unboxed.! 3)
                               in (p_asZZ / (1 + ((c_RESTc_at1b / p_at01) ** p_at03))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at1c
                            -> let c_PTB_at1d = ((toVector x_at1c) Data.Vector.Unboxed.! 0)
                               in (p_at05 * c_PTB_at1d))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1e
                            -> let c_NPTB_at1f = ((toVector x_at1e) Data.Vector.Unboxed.! 1)
                               in (p_at07 * c_NPTB_at1f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at1g
                            -> let c_MiRs_at1h = ((toVector x_at1g) Data.Vector.Unboxed.! 2)
                               in (p_at09 * c_MiRs_at1h))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at1i
                            -> let c_RESTc_at1j = ((toVector x_at1i) Data.Vector.Unboxed.! 3)
                               in (p_at0b * c_RESTc_at1j))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at1k
                            -> let
                                 c_EndoNeuroTFs_at1l = ((toVector x_at1k) Data.Vector.Unboxed.! 4)
                               in (p_at0d * c_EndoNeuroTFs_at1l))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121215",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121217",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121237",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121239",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121247",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121257",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121259",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121265",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121267",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121271",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121273",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121275",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at0e
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at20
                            p_at0d = code-0.1.0.0:Genome.FixedList.Functions.double g_at0c
                            (g_at0c, gpart_at20) = Genome.Split.split gpart_at1Z
                            p_at0b = code-0.1.0.0:Genome.FixedList.Functions.double g_at0a
                            (g_at0a, gpart_at1Z) = Genome.Split.split gpart_at1Y
                            p_at09 = code-0.1.0.0:Genome.FixedList.Functions.double g_at08
                            (g_at08, gpart_at1Y) = Genome.Split.split gpart_at1X
                            p_at07 = code-0.1.0.0:Genome.FixedList.Functions.double g_at06
                            (g_at06, gpart_at1X) = Genome.Split.split gpart_at1W
                            p_at05 = code-0.1.0.0:Genome.FixedList.Functions.double g_at04
                            (g_at04, gpart_at1W) = Genome.Split.split gpart_at1V
                            p_at03 = Functions.belowten' g_at02
                            (g_at02, gpart_at1V) = Genome.Split.split gpart_at1U
                            p_at01 = code-0.1.0.0:Genome.FixedList.Functions.double g_at00
                            (g_at00, gpart_at1U) = Genome.Split.split gpart_at1T
                            p_asZZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asZY
                            (g_asZY, gpart_at1T) = Genome.Split.split gpart_at1S
                            p_asZX = code-0.1.0.0:Genome.FixedList.Functions.double g_asZW
                            (g_asZW, gpart_at1S) = Genome.Split.split gpart_at1R
                            p_asZV = Functions.belowten' g_asZU
                            (g_asZU, gpart_at1R) = Genome.Split.split gpart_at1Q
                            p_asZT = code-0.1.0.0:Genome.FixedList.Functions.double g_asZS
                            (g_asZS, gpart_at1Q) = Genome.Split.split gpart_at1P
                            p_asZR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZQ
                            (g_asZQ, gpart_at1P) = Genome.Split.split gpart_at1O
                            p_asZP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZO
                            (g_asZO, gpart_at1O) = Genome.Split.split gpart_at1N
                            p_asZN = Functions.belowten' g_asZM
                            (g_asZM, gpart_at1N) = Genome.Split.split gpart_at1M
                            p_asZL = code-0.1.0.0:Genome.FixedList.Functions.double g_asZK
                            (g_asZK, gpart_at1M) = Genome.Split.split gpart_at1L
                            p_asZJ = Functions.belowten' g_asZI
                            (g_asZI, gpart_at1L) = Genome.Split.split gpart_at1K
                            p_asZH = code-0.1.0.0:Genome.FixedList.Functions.double g_asZG
                            (g_asZG, gpart_at1K) = Genome.Split.split gpart_at1J
                            p_asZF = code-0.1.0.0:Genome.FixedList.Functions.double g_asZE
                            (g_asZE, gpart_at1J) = Genome.Split.split gpart_at1I
                            p_asZD = code-0.1.0.0:Genome.FixedList.Functions.double g_asZC
                            (g_asZC, gpart_at1I) = Genome.Split.split gpart_at1H
                            p_asZB = Functions.belowten' g_asZA
                            (g_asZA, gpart_at1H) = Genome.Split.split gpart_at1G
                            p_asZz = code-0.1.0.0:Genome.FixedList.Functions.double g_asZy
                            (g_asZy, gpart_at1G) = Genome.Split.split gpart_at1F
                            p_asZx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZw
                            (g_asZw, gpart_at1F) = Genome.Split.split gpart_at1E
                            p_asZv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZu
                            (g_asZu, gpart_at1E) = Genome.Split.split gpart_at1D
                            p_asZt = code-0.1.0.0:Genome.FixedList.Functions.double g_asZs
                            (g_asZs, gpart_at1D) = Genome.Split.split gpart_at1C
                            p_asZr = Functions.belowten' g_asZq
                            (g_asZq, gpart_at1C) = Genome.Split.split gpart_at1B
                            p_asZp = code-0.1.0.0:Genome.FixedList.Functions.double g_asZo
                            (g_asZo, gpart_at1B) = Genome.Split.split gpart_at1A
                            p_asZn = Functions.belowten' g_asZm
                            (g_asZm, gpart_at1A) = Genome.Split.split gpart_at1z
                            p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                            (g_asZk, gpart_at1z) = Genome.Split.split gpart_at1y
                            p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                            (g_asZi, gpart_at1y) = Genome.Split.split gpart_at1x
                            p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                            (g_asZg, gpart_at1x) = Genome.Split.split gpart_at1w
                            p_asZf = Functions.belowten' g_asZe
                            (g_asZe, gpart_at1w) = Genome.Split.split gpart_at1v
                            p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                            (g_asZc, gpart_at1v) = Genome.Split.split gpart_at1u
                            p_asZb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZa
                            (g_asZa, gpart_at1u) = Genome.Split.split gpart_at1t
                            p_asZ9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ8
                            (g_asZ8, gpart_at1t) = Genome.Split.split gpart_at1s
                            p_asZ7 = Functions.belowten' g_asZ6
                            (g_asZ6, gpart_at1s) = Genome.Split.split gpart_at1r
                            p_asZ5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ4
                            (g_asZ4, gpart_at1r) = Genome.Split.split gpart_at1q
                            p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                            (g_asZ2, gpart_at1q) = Genome.Split.split gpart_at1p
                            p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                            (g_asZ0, gpart_at1p) = Genome.Split.split gpart_at1o
                            p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                            (g_asYY, gpart_at1o) = Genome.Split.split gpart_at1n
                            p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                            (g_asYW, gpart_at1n) = Genome.Split.split gpart_at1m
                            p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                            (g_asYU, gpart_at1m) = Genome.Split.split genome_at0e
                          in
                            \ desc_at0f
                              -> case desc_at0f of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYV)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYX)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYZ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ1)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ3)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ5)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ7)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ9)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZb)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZd)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZf)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZh)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZj)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZl)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZn)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZp)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZr)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZt)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZv)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZx)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZz)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZB)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZD)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZF)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZH)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZJ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZL)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZN)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZP)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZR)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZT)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZV)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZX)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZZ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at01)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at03)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at05)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at07)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at09)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0b)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0d)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at41
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4H
                      p_at40 = code-0.1.0.0:Genome.FixedList.Functions.double g_at3Z
                      (g_at3Z, gpart_at4H) = Genome.Split.split gpart_at4G
                      p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                      (g_at3X, gpart_at4G) = Genome.Split.split gpart_at4F
                      p_at3W = code-0.1.0.0:Genome.FixedList.Functions.double g_at3V
                      (g_at3V, gpart_at4F) = Genome.Split.split gpart_at4E
                      p_at3U = code-0.1.0.0:Genome.FixedList.Functions.double g_at3T
                      (g_at3T, gpart_at4E) = Genome.Split.split gpart_at4D
                      p_at3S = code-0.1.0.0:Genome.FixedList.Functions.double g_at3R
                      (g_at3R, gpart_at4D) = Genome.Split.split gpart_at4C
                      p_at3Q = Functions.belowten' g_at3P
                      (g_at3P, gpart_at4C) = Genome.Split.split gpart_at4B
                      p_at3O = code-0.1.0.0:Genome.FixedList.Functions.double g_at3N
                      (g_at3N, gpart_at4B) = Genome.Split.split gpart_at4A
                      p_at3M = code-0.1.0.0:Genome.FixedList.Functions.double g_at3L
                      (g_at3L, gpart_at4A) = Genome.Split.split gpart_at4z
                      p_at3K = code-0.1.0.0:Genome.FixedList.Functions.double g_at3J
                      (g_at3J, gpart_at4z) = Genome.Split.split gpart_at4y
                      p_at3I = Functions.belowten' g_at3H
                      (g_at3H, gpart_at4y) = Genome.Split.split gpart_at4x
                      p_at3G = code-0.1.0.0:Genome.FixedList.Functions.double g_at3F
                      (g_at3F, gpart_at4x) = Genome.Split.split gpart_at4w
                      p_at3E
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3D
                      (g_at3D, gpart_at4w) = Genome.Split.split gpart_at4v
                      p_at3C
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3B
                      (g_at3B, gpart_at4v) = Genome.Split.split gpart_at4u
                      p_at3A = Functions.belowten' g_at3z
                      (g_at3z, gpart_at4u) = Genome.Split.split gpart_at4t
                      p_at3y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3x
                      (g_at3x, gpart_at4t) = Genome.Split.split gpart_at4s
                      p_at3w = Functions.belowten' g_at3v
                      (g_at3v, gpart_at4s) = Genome.Split.split gpart_at4r
                      p_at3u = code-0.1.0.0:Genome.FixedList.Functions.double g_at3t
                      (g_at3t, gpart_at4r) = Genome.Split.split gpart_at4q
                      p_at3s = code-0.1.0.0:Genome.FixedList.Functions.double g_at3r
                      (g_at3r, gpart_at4q) = Genome.Split.split gpart_at4p
                      p_at3q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3p
                      (g_at3p, gpart_at4p) = Genome.Split.split gpart_at4o
                      p_at3o = Functions.belowten' g_at3n
                      (g_at3n, gpart_at4o) = Genome.Split.split gpart_at4n
                      p_at3m = code-0.1.0.0:Genome.FixedList.Functions.double g_at3l
                      (g_at3l, gpart_at4n) = Genome.Split.split gpart_at4m
                      p_at3k
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3j
                      (g_at3j, gpart_at4m) = Genome.Split.split gpart_at4l
                      p_at3i
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3h
                      (g_at3h, gpart_at4l) = Genome.Split.split gpart_at4k
                      p_at3g = code-0.1.0.0:Genome.FixedList.Functions.double g_at3f
                      (g_at3f, gpart_at4k) = Genome.Split.split gpart_at4j
                      p_at3e = Functions.belowten' g_at3d
                      (g_at3d, gpart_at4j) = Genome.Split.split gpart_at4i
                      p_at3c = code-0.1.0.0:Genome.FixedList.Functions.double g_at3b
                      (g_at3b, gpart_at4i) = Genome.Split.split gpart_at4h
                      p_at3a = Functions.belowten' g_at39
                      (g_at39, gpart_at4h) = Genome.Split.split gpart_at4g
                      p_at38 = code-0.1.0.0:Genome.FixedList.Functions.double g_at37
                      (g_at37, gpart_at4g) = Genome.Split.split gpart_at4f
                      p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                      (g_at35, gpart_at4f) = Genome.Split.split gpart_at4e
                      p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                      (g_at33, gpart_at4e) = Genome.Split.split gpart_at4d
                      p_at32 = Functions.belowten' g_at31
                      (g_at31, gpart_at4d) = Genome.Split.split gpart_at4c
                      p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                      (g_at2Z, gpart_at4c) = Genome.Split.split gpart_at4b
                      p_at2Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2X
                      (g_at2X, gpart_at4b) = Genome.Split.split gpart_at4a
                      p_at2W
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2V
                      (g_at2V, gpart_at4a) = Genome.Split.split gpart_at49
                      p_at2U = Functions.belowten' g_at2T
                      (g_at2T, gpart_at49) = Genome.Split.split gpart_at48
                      p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                      (g_at2R, gpart_at48) = Genome.Split.split gpart_at47
                      p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                      (g_at2P, gpart_at47) = Genome.Split.split gpart_at46
                      p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                      (g_at2N, gpart_at46) = Genome.Split.split gpart_at45
                      p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                      (g_at2L, gpart_at45) = Genome.Split.split gpart_at44
                      p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                      (g_at2J, gpart_at44) = Genome.Split.split gpart_at43
                      p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                      (g_at2H, gpart_at43) = Genome.Split.split genome_at41
                    in
                      [Reaction
                         (\ x_at4I
                            -> let
                                 c_MiRs_at4L = ((toVector x_at4I) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at4J = ((toVector x_at4I) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2Q
                                  * ((p_at34 + ((c_RESTc_at4J / p_at2S) ** p_at2U))
                                     / (((1 + p_at34) + ((c_RESTc_at4J / p_at2S) ** p_at2U))
                                        + ((c_MiRs_at4L / p_at30) ** p_at32)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4M
                            -> let
                                 c_MiRs_at4N = ((toVector x_at4M) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4O = ((toVector x_at4M) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at36
                                  / (1
                                     + (((c_MiRs_at4N / p_at38) ** p_at3a)
                                        + ((c_PTB_at4O / p_at3c) ** p_at3e)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at4P
                            -> let c_RESTc_at4Q = ((toVector x_at4P) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at3g
                                  * (p_at3q
                                     / ((1 + p_at3q) + ((c_RESTc_at4Q / p_at3m) ** p_at3o)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at4R
                            -> let
                                 c_MiRs_at4W = ((toVector x_at4R) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4T = ((toVector x_at4R) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at4S = ((toVector x_at4R) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at3s
                                  * ((p_at3K
                                      + (((c_NPTB_at4S / p_at3u) ** p_at3w)
                                         + ((c_PTB_at4T / p_at3y) ** p_at3A)))
                                     / (((1 + p_at3K)
                                         + (((c_NPTB_at4S / p_at3u) ** p_at3w)
                                            + ((c_PTB_at4T / p_at3y) ** p_at3A)))
                                        + ((c_MiRs_at4W / p_at3G) ** p_at3I)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at4X
                            -> let c_RESTc_at4Y = ((toVector x_at4X) Data.Vector.Unboxed.! 3)
                               in (p_at3M / (1 + ((c_RESTc_at4Y / p_at3O) ** p_at3Q))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at4Z
                            -> let c_PTB_at50 = ((toVector x_at4Z) Data.Vector.Unboxed.! 0)
                               in (p_at3S * c_PTB_at50))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at51
                            -> let c_NPTB_at52 = ((toVector x_at51) Data.Vector.Unboxed.! 1)
                               in (p_at3U * c_NPTB_at52))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at53
                            -> let c_MiRs_at54 = ((toVector x_at53) Data.Vector.Unboxed.! 2)
                               in (p_at3W * c_MiRs_at54))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at55
                            -> let c_RESTc_at56 = ((toVector x_at55) Data.Vector.Unboxed.! 3)
                               in (p_at3Y * c_RESTc_at56))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at57
                            -> let
                                 c_EndoNeuroTFs_at58 = ((toVector x_at57) Data.Vector.Unboxed.! 4)
                               in (p_at40 * c_EndoNeuroTFs_at58))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121450",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121452",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121472",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121474",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121490",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121492",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121494",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121510",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at41
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5N
                            p_at40 = code-0.1.0.0:Genome.FixedList.Functions.double g_at3Z
                            (g_at3Z, gpart_at5N) = Genome.Split.split gpart_at5M
                            p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                            (g_at3X, gpart_at5M) = Genome.Split.split gpart_at5L
                            p_at3W = code-0.1.0.0:Genome.FixedList.Functions.double g_at3V
                            (g_at3V, gpart_at5L) = Genome.Split.split gpart_at5K
                            p_at3U = code-0.1.0.0:Genome.FixedList.Functions.double g_at3T
                            (g_at3T, gpart_at5K) = Genome.Split.split gpart_at5J
                            p_at3S = code-0.1.0.0:Genome.FixedList.Functions.double g_at3R
                            (g_at3R, gpart_at5J) = Genome.Split.split gpart_at5I
                            p_at3Q = Functions.belowten' g_at3P
                            (g_at3P, gpart_at5I) = Genome.Split.split gpart_at5H
                            p_at3O = code-0.1.0.0:Genome.FixedList.Functions.double g_at3N
                            (g_at3N, gpart_at5H) = Genome.Split.split gpart_at5G
                            p_at3M = code-0.1.0.0:Genome.FixedList.Functions.double g_at3L
                            (g_at3L, gpart_at5G) = Genome.Split.split gpart_at5F
                            p_at3K = code-0.1.0.0:Genome.FixedList.Functions.double g_at3J
                            (g_at3J, gpart_at5F) = Genome.Split.split gpart_at5E
                            p_at3I = Functions.belowten' g_at3H
                            (g_at3H, gpart_at5E) = Genome.Split.split gpart_at5D
                            p_at3G = code-0.1.0.0:Genome.FixedList.Functions.double g_at3F
                            (g_at3F, gpart_at5D) = Genome.Split.split gpart_at5C
                            p_at3E
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3D
                            (g_at3D, gpart_at5C) = Genome.Split.split gpart_at5B
                            p_at3C
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3B
                            (g_at3B, gpart_at5B) = Genome.Split.split gpart_at5A
                            p_at3A = Functions.belowten' g_at3z
                            (g_at3z, gpart_at5A) = Genome.Split.split gpart_at5z
                            p_at3y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3x
                            (g_at3x, gpart_at5z) = Genome.Split.split gpart_at5y
                            p_at3w = Functions.belowten' g_at3v
                            (g_at3v, gpart_at5y) = Genome.Split.split gpart_at5x
                            p_at3u = code-0.1.0.0:Genome.FixedList.Functions.double g_at3t
                            (g_at3t, gpart_at5x) = Genome.Split.split gpart_at5w
                            p_at3s = code-0.1.0.0:Genome.FixedList.Functions.double g_at3r
                            (g_at3r, gpart_at5w) = Genome.Split.split gpart_at5v
                            p_at3q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3p
                            (g_at3p, gpart_at5v) = Genome.Split.split gpart_at5u
                            p_at3o = Functions.belowten' g_at3n
                            (g_at3n, gpart_at5u) = Genome.Split.split gpart_at5t
                            p_at3m = code-0.1.0.0:Genome.FixedList.Functions.double g_at3l
                            (g_at3l, gpart_at5t) = Genome.Split.split gpart_at5s
                            p_at3k
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3j
                            (g_at3j, gpart_at5s) = Genome.Split.split gpart_at5r
                            p_at3i
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3h
                            (g_at3h, gpart_at5r) = Genome.Split.split gpart_at5q
                            p_at3g = code-0.1.0.0:Genome.FixedList.Functions.double g_at3f
                            (g_at3f, gpart_at5q) = Genome.Split.split gpart_at5p
                            p_at3e = Functions.belowten' g_at3d
                            (g_at3d, gpart_at5p) = Genome.Split.split gpart_at5o
                            p_at3c = code-0.1.0.0:Genome.FixedList.Functions.double g_at3b
                            (g_at3b, gpart_at5o) = Genome.Split.split gpart_at5n
                            p_at3a = Functions.belowten' g_at39
                            (g_at39, gpart_at5n) = Genome.Split.split gpart_at5m
                            p_at38 = code-0.1.0.0:Genome.FixedList.Functions.double g_at37
                            (g_at37, gpart_at5m) = Genome.Split.split gpart_at5l
                            p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                            (g_at35, gpart_at5l) = Genome.Split.split gpart_at5k
                            p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                            (g_at33, gpart_at5k) = Genome.Split.split gpart_at5j
                            p_at32 = Functions.belowten' g_at31
                            (g_at31, gpart_at5j) = Genome.Split.split gpart_at5i
                            p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                            (g_at2Z, gpart_at5i) = Genome.Split.split gpart_at5h
                            p_at2Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2X
                            (g_at2X, gpart_at5h) = Genome.Split.split gpart_at5g
                            p_at2W
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2V
                            (g_at2V, gpart_at5g) = Genome.Split.split gpart_at5f
                            p_at2U = Functions.belowten' g_at2T
                            (g_at2T, gpart_at5f) = Genome.Split.split gpart_at5e
                            p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                            (g_at2R, gpart_at5e) = Genome.Split.split gpart_at5d
                            p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                            (g_at2P, gpart_at5d) = Genome.Split.split gpart_at5c
                            p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                            (g_at2N, gpart_at5c) = Genome.Split.split gpart_at5b
                            p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                            (g_at2L, gpart_at5b) = Genome.Split.split gpart_at5a
                            p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                            (g_at2J, gpart_at5a) = Genome.Split.split gpart_at59
                            p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                            (g_at2H, gpart_at59) = Genome.Split.split genome_at41
                          in
                            \ desc_at42
                              -> case desc_at42 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2M)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2O)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Q)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2S)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2U)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2W)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Y)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at30)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at32)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at34)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at36)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at38)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3a)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3c)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3e)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3g)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3i)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3k)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3m)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3o)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3q)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3s)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3u)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3w)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3y)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3A)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3C)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3E)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3G)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3I)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3K)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3M)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3O)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Q)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3S)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3U)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3W)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Y)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at40)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at7O
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8u
                      p_at7N = code-0.1.0.0:Genome.FixedList.Functions.double g_at7M
                      (g_at7M, gpart_at8u) = Genome.Split.split gpart_at8t
                      p_at7L = code-0.1.0.0:Genome.FixedList.Functions.double g_at7K
                      (g_at7K, gpart_at8t) = Genome.Split.split gpart_at8s
                      p_at7J = code-0.1.0.0:Genome.FixedList.Functions.double g_at7I
                      (g_at7I, gpart_at8s) = Genome.Split.split gpart_at8r
                      p_at7H = code-0.1.0.0:Genome.FixedList.Functions.double g_at7G
                      (g_at7G, gpart_at8r) = Genome.Split.split gpart_at8q
                      p_at7F = code-0.1.0.0:Genome.FixedList.Functions.double g_at7E
                      (g_at7E, gpart_at8q) = Genome.Split.split gpart_at8p
                      p_at7D = Functions.belowten' g_at7C
                      (g_at7C, gpart_at8p) = Genome.Split.split gpart_at8o
                      p_at7B = code-0.1.0.0:Genome.FixedList.Functions.double g_at7A
                      (g_at7A, gpart_at8o) = Genome.Split.split gpart_at8n
                      p_at7z = code-0.1.0.0:Genome.FixedList.Functions.double g_at7y
                      (g_at7y, gpart_at8n) = Genome.Split.split gpart_at8m
                      p_at7x = code-0.1.0.0:Genome.FixedList.Functions.double g_at7w
                      (g_at7w, gpart_at8m) = Genome.Split.split gpart_at8l
                      p_at7v = Functions.belowten' g_at7u
                      (g_at7u, gpart_at8l) = Genome.Split.split gpart_at8k
                      p_at7t = code-0.1.0.0:Genome.FixedList.Functions.double g_at7s
                      (g_at7s, gpart_at8k) = Genome.Split.split gpart_at8j
                      p_at7r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7q
                      (g_at7q, gpart_at8j) = Genome.Split.split gpart_at8i
                      p_at7p
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7o
                      (g_at7o, gpart_at8i) = Genome.Split.split gpart_at8h
                      p_at7n = Functions.belowten' g_at7m
                      (g_at7m, gpart_at8h) = Genome.Split.split gpart_at8g
                      p_at7l = code-0.1.0.0:Genome.FixedList.Functions.double g_at7k
                      (g_at7k, gpart_at8g) = Genome.Split.split gpart_at8f
                      p_at7j = Functions.belowten' g_at7i
                      (g_at7i, gpart_at8f) = Genome.Split.split gpart_at8e
                      p_at7h = code-0.1.0.0:Genome.FixedList.Functions.double g_at7g
                      (g_at7g, gpart_at8e) = Genome.Split.split gpart_at8d
                      p_at7f = code-0.1.0.0:Genome.FixedList.Functions.double g_at7e
                      (g_at7e, gpart_at8d) = Genome.Split.split gpart_at8c
                      p_at7d = code-0.1.0.0:Genome.FixedList.Functions.double g_at7c
                      (g_at7c, gpart_at8c) = Genome.Split.split gpart_at8b
                      p_at7b = Functions.belowten' g_at7a
                      (g_at7a, gpart_at8b) = Genome.Split.split gpart_at8a
                      p_at79 = code-0.1.0.0:Genome.FixedList.Functions.double g_at78
                      (g_at78, gpart_at8a) = Genome.Split.split gpart_at89
                      p_at77
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at76
                      (g_at76, gpart_at89) = Genome.Split.split gpart_at88
                      p_at75
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at74
                      (g_at74, gpart_at88) = Genome.Split.split gpart_at87
                      p_at73 = code-0.1.0.0:Genome.FixedList.Functions.double g_at72
                      (g_at72, gpart_at87) = Genome.Split.split gpart_at86
                      p_at71 = Functions.belowten' g_at70
                      (g_at70, gpart_at86) = Genome.Split.split gpart_at85
                      p_at6Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Y
                      (g_at6Y, gpart_at85) = Genome.Split.split gpart_at84
                      p_at6X = Functions.belowten' g_at6W
                      (g_at6W, gpart_at84) = Genome.Split.split gpart_at83
                      p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                      (g_at6U, gpart_at83) = Genome.Split.split gpart_at82
                      p_at6T = code-0.1.0.0:Genome.FixedList.Functions.double g_at6S
                      (g_at6S, gpart_at82) = Genome.Split.split gpart_at81
                      p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                      (g_at6Q, gpart_at81) = Genome.Split.split gpart_at80
                      p_at6P = Functions.belowten' g_at6O
                      (g_at6O, gpart_at80) = Genome.Split.split gpart_at7Z
                      p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                      (g_at6M, gpart_at7Z) = Genome.Split.split gpart_at7Y
                      p_at6L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6K
                      (g_at6K, gpart_at7Y) = Genome.Split.split gpart_at7X
                      p_at6J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6I
                      (g_at6I, gpart_at7X) = Genome.Split.split gpart_at7W
                      p_at6H = Functions.belowten' g_at6G
                      (g_at6G, gpart_at7W) = Genome.Split.split gpart_at7V
                      p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                      (g_at6E, gpart_at7V) = Genome.Split.split gpart_at7U
                      p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                      (g_at6C, gpart_at7U) = Genome.Split.split gpart_at7T
                      p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                      (g_at6A, gpart_at7T) = Genome.Split.split gpart_at7S
                      p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                      (g_at6y, gpart_at7S) = Genome.Split.split gpart_at7R
                      p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                      (g_at6w, gpart_at7R) = Genome.Split.split gpart_at7Q
                      p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                      (g_at6u, gpart_at7Q) = Genome.Split.split genome_at7O
                    in
                      [Reaction
                         (\ x_at8v
                            -> let
                                 c_MiRs_at8y = ((toVector x_at8v) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at8w = ((toVector x_at8v) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at6D
                                  * ((p_at6R + ((c_RESTc_at8w / p_at6F) ** p_at6H))
                                     / (((1 + p_at6R) + ((c_RESTc_at8w / p_at6F) ** p_at6H))
                                        + (((p_at6v / p_at6J) ** p_at6L)
                                           + ((c_MiRs_at8y / p_at6N) ** p_at6P))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at8z
                            -> let
                                 c_MiRs_at8A = ((toVector x_at8z) Data.Vector.Unboxed.! 2)
                                 c_PTB_at8B = ((toVector x_at8z) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6T
                                  / (1
                                     + (((c_MiRs_at8A / p_at6V) ** p_at6X)
                                        + ((c_PTB_at8B / p_at6Z) ** p_at71)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at8C
                            -> let c_RESTc_at8D = ((toVector x_at8C) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at73
                                  * (p_at7d
                                     / ((1 + p_at7d) + ((c_RESTc_at8D / p_at79) ** p_at7b)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at8E
                            -> let
                                 c_MiRs_at8J = ((toVector x_at8E) Data.Vector.Unboxed.! 2)
                                 c_PTB_at8G = ((toVector x_at8E) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at8F = ((toVector x_at8E) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at7f
                                  * ((p_at7x
                                      + (((c_NPTB_at8F / p_at7h) ** p_at7j)
                                         + ((c_PTB_at8G / p_at7l) ** p_at7n)))
                                     / (((1 + p_at7x)
                                         + (((c_NPTB_at8F / p_at7h) ** p_at7j)
                                            + ((c_PTB_at8G / p_at7l) ** p_at7n)))
                                        + ((c_MiRs_at8J / p_at7t) ** p_at7v)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at8K
                            -> let c_RESTc_at8L = ((toVector x_at8K) Data.Vector.Unboxed.! 3)
                               in (p_at7z / (1 + ((c_RESTc_at8L / p_at7B) ** p_at7D))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at8M
                            -> let c_PTB_at8N = ((toVector x_at8M) Data.Vector.Unboxed.! 0)
                               in (p_at7F * c_PTB_at8N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at8O
                            -> let c_NPTB_at8P = ((toVector x_at8O) Data.Vector.Unboxed.! 1)
                               in (p_at7H * c_NPTB_at8P))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at8Q
                            -> let c_MiRs_at8R = ((toVector x_at8Q) Data.Vector.Unboxed.! 2)
                               in (p_at7J * c_MiRs_at8R))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at8S
                            -> let c_RESTc_at8T = ((toVector x_at8S) Data.Vector.Unboxed.! 3)
                               in (p_at7L * c_RESTc_at8T))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at8U
                            -> let
                                 c_EndoNeuroTFs_at8V = ((toVector x_at8U) Data.Vector.Unboxed.! 4)
                               in (p_at7N * c_EndoNeuroTFs_at8V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121685",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121687",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121707",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121709",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121711",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121713",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121717",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121719",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121727",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121729",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121737",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121739",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121742",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121743",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121744",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121745",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121746",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121747",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121748",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121749",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121750",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121751",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at7O
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at9A
                            p_at7N = code-0.1.0.0:Genome.FixedList.Functions.double g_at7M
                            (g_at7M, gpart_at9A) = Genome.Split.split gpart_at9z
                            p_at7L = code-0.1.0.0:Genome.FixedList.Functions.double g_at7K
                            (g_at7K, gpart_at9z) = Genome.Split.split gpart_at9y
                            p_at7J = code-0.1.0.0:Genome.FixedList.Functions.double g_at7I
                            (g_at7I, gpart_at9y) = Genome.Split.split gpart_at9x
                            p_at7H = code-0.1.0.0:Genome.FixedList.Functions.double g_at7G
                            (g_at7G, gpart_at9x) = Genome.Split.split gpart_at9w
                            p_at7F = code-0.1.0.0:Genome.FixedList.Functions.double g_at7E
                            (g_at7E, gpart_at9w) = Genome.Split.split gpart_at9v
                            p_at7D = Functions.belowten' g_at7C
                            (g_at7C, gpart_at9v) = Genome.Split.split gpart_at9u
                            p_at7B = code-0.1.0.0:Genome.FixedList.Functions.double g_at7A
                            (g_at7A, gpart_at9u) = Genome.Split.split gpart_at9t
                            p_at7z = code-0.1.0.0:Genome.FixedList.Functions.double g_at7y
                            (g_at7y, gpart_at9t) = Genome.Split.split gpart_at9s
                            p_at7x = code-0.1.0.0:Genome.FixedList.Functions.double g_at7w
                            (g_at7w, gpart_at9s) = Genome.Split.split gpart_at9r
                            p_at7v = Functions.belowten' g_at7u
                            (g_at7u, gpart_at9r) = Genome.Split.split gpart_at9q
                            p_at7t = code-0.1.0.0:Genome.FixedList.Functions.double g_at7s
                            (g_at7s, gpart_at9q) = Genome.Split.split gpart_at9p
                            p_at7r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7q
                            (g_at7q, gpart_at9p) = Genome.Split.split gpart_at9o
                            p_at7p
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7o
                            (g_at7o, gpart_at9o) = Genome.Split.split gpart_at9n
                            p_at7n = Functions.belowten' g_at7m
                            (g_at7m, gpart_at9n) = Genome.Split.split gpart_at9m
                            p_at7l = code-0.1.0.0:Genome.FixedList.Functions.double g_at7k
                            (g_at7k, gpart_at9m) = Genome.Split.split gpart_at9l
                            p_at7j = Functions.belowten' g_at7i
                            (g_at7i, gpart_at9l) = Genome.Split.split gpart_at9k
                            p_at7h = code-0.1.0.0:Genome.FixedList.Functions.double g_at7g
                            (g_at7g, gpart_at9k) = Genome.Split.split gpart_at9j
                            p_at7f = code-0.1.0.0:Genome.FixedList.Functions.double g_at7e
                            (g_at7e, gpart_at9j) = Genome.Split.split gpart_at9i
                            p_at7d = code-0.1.0.0:Genome.FixedList.Functions.double g_at7c
                            (g_at7c, gpart_at9i) = Genome.Split.split gpart_at9h
                            p_at7b = Functions.belowten' g_at7a
                            (g_at7a, gpart_at9h) = Genome.Split.split gpart_at9g
                            p_at79 = code-0.1.0.0:Genome.FixedList.Functions.double g_at78
                            (g_at78, gpart_at9g) = Genome.Split.split gpart_at9f
                            p_at77
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at76
                            (g_at76, gpart_at9f) = Genome.Split.split gpart_at9e
                            p_at75
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at74
                            (g_at74, gpart_at9e) = Genome.Split.split gpart_at9d
                            p_at73 = code-0.1.0.0:Genome.FixedList.Functions.double g_at72
                            (g_at72, gpart_at9d) = Genome.Split.split gpart_at9c
                            p_at71 = Functions.belowten' g_at70
                            (g_at70, gpart_at9c) = Genome.Split.split gpart_at9b
                            p_at6Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Y
                            (g_at6Y, gpart_at9b) = Genome.Split.split gpart_at9a
                            p_at6X = Functions.belowten' g_at6W
                            (g_at6W, gpart_at9a) = Genome.Split.split gpart_at99
                            p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                            (g_at6U, gpart_at99) = Genome.Split.split gpart_at98
                            p_at6T = code-0.1.0.0:Genome.FixedList.Functions.double g_at6S
                            (g_at6S, gpart_at98) = Genome.Split.split gpart_at97
                            p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                            (g_at6Q, gpart_at97) = Genome.Split.split gpart_at96
                            p_at6P = Functions.belowten' g_at6O
                            (g_at6O, gpart_at96) = Genome.Split.split gpart_at95
                            p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                            (g_at6M, gpart_at95) = Genome.Split.split gpart_at94
                            p_at6L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6K
                            (g_at6K, gpart_at94) = Genome.Split.split gpart_at93
                            p_at6J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6I
                            (g_at6I, gpart_at93) = Genome.Split.split gpart_at92
                            p_at6H = Functions.belowten' g_at6G
                            (g_at6G, gpart_at92) = Genome.Split.split gpart_at91
                            p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                            (g_at6E, gpart_at91) = Genome.Split.split gpart_at90
                            p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                            (g_at6C, gpart_at90) = Genome.Split.split gpart_at8Z
                            p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                            (g_at6A, gpart_at8Z) = Genome.Split.split gpart_at8Y
                            p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                            (g_at6y, gpart_at8Y) = Genome.Split.split gpart_at8X
                            p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                            (g_at6w, gpart_at8X) = Genome.Split.split gpart_at8W
                            p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                            (g_at6u, gpart_at8W) = Genome.Split.split genome_at7O
                          in
                            \ desc_at7P
                              -> case desc_at7P of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6v)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6x)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6z)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6B)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6D)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6F)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6H)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6J)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6L)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6N)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6P)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6R)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6T)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6V)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6X)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Z)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at71)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at73)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at75)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at77)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at79)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7b)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7d)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7f)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7h)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7j)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7l)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7n)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7p)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7r)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7t)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7v)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7x)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7z)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7B)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7D)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7F)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7H)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7J)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7L)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7N)
                                   _ -> Nothing }}
