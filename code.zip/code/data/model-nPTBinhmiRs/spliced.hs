src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1Zm7
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZmK
                      p_a1Zm6 = double g_a1Zm5
                      (g_a1Zm5, gpart_a1ZmK) = Genome.Split.split gpart_a1ZmJ
                      p_a1Zm4 = double g_a1Zm3
                      (g_a1Zm3, gpart_a1ZmJ) = Genome.Split.split gpart_a1ZmI
                      p_a1Zm2 = double g_a1Zm1
                      (g_a1Zm1, gpart_a1ZmI) = Genome.Split.split gpart_a1ZmH
                      p_a1Zm0 = double g_a1ZlZ
                      (g_a1ZlZ, gpart_a1ZmH) = Genome.Split.split gpart_a1ZmG
                      p_a1ZlY = double g_a1ZlX
                      (g_a1ZlX, gpart_a1ZmG) = Genome.Split.split gpart_a1ZmF
                      p_a1ZlW = Functions.belowten' g_a1ZlV
                      (g_a1ZlV, gpart_a1ZmF) = Genome.Split.split gpart_a1ZmE
                      p_a1ZlU = double g_a1ZlT
                      (g_a1ZlT, gpart_a1ZmE) = Genome.Split.split gpart_a1ZmD
                      p_a1ZlS = double g_a1ZlR
                      (g_a1ZlR, gpart_a1ZmD) = Genome.Split.split gpart_a1ZmC
                      p_a1ZlQ = double g_a1ZlP
                      (g_a1ZlP, gpart_a1ZmC) = Genome.Split.split gpart_a1ZmB
                      p_a1ZlO = Functions.belowten' g_a1ZlN
                      (g_a1ZlN, gpart_a1ZmB) = Genome.Split.split gpart_a1ZmA
                      p_a1ZlM = double g_a1ZlL
                      (g_a1ZlL, gpart_a1ZmA) = Genome.Split.split gpart_a1Zmz
                      p_a1ZlK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlJ
                      (g_a1ZlJ, gpart_a1Zmz) = Genome.Split.split gpart_a1Zmy
                      p_a1ZlI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlH
                      (g_a1ZlH, gpart_a1Zmy) = Genome.Split.split gpart_a1Zmx
                      p_a1ZlG = Functions.belowten' g_a1ZlF
                      (g_a1ZlF, gpart_a1Zmx) = Genome.Split.split gpart_a1Zmw
                      p_a1ZlE = double g_a1ZlD
                      (g_a1ZlD, gpart_a1Zmw) = Genome.Split.split gpart_a1Zmv
                      p_a1ZlC = double g_a1ZlB
                      (g_a1ZlB, gpart_a1Zmv) = Genome.Split.split gpart_a1Zmu
                      p_a1ZlA = double g_a1Zlz
                      (g_a1Zlz, gpart_a1Zmu) = Genome.Split.split gpart_a1Zmt
                      p_a1Zly = Functions.belowten' g_a1Zlx
                      (g_a1Zlx, gpart_a1Zmt) = Genome.Split.split gpart_a1Zms
                      p_a1Zlw = double g_a1Zlv
                      (g_a1Zlv, gpart_a1Zms) = Genome.Split.split gpart_a1Zmr
                      p_a1Zlu = Functions.belowten' g_a1Zlt
                      (g_a1Zlt, gpart_a1Zmr) = Genome.Split.split gpart_a1Zmq
                      p_a1Zls = double g_a1Zlr
                      (g_a1Zlr, gpart_a1Zmq) = Genome.Split.split gpart_a1Zmp
                      p_a1Zlq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlp
                      (g_a1Zlp, gpart_a1Zmp) = Genome.Split.split gpart_a1Zmo
                      p_a1Zlo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zln
                      (g_a1Zln, gpart_a1Zmo) = Genome.Split.split gpart_a1Zmn
                      p_a1Zlm = double g_a1Zll
                      (g_a1Zll, gpart_a1Zmn) = Genome.Split.split gpart_a1Zmm
                      p_a1Zlk = Functions.belowten' g_a1Zlj
                      (g_a1Zlj, gpart_a1Zmm) = Genome.Split.split gpart_a1Zml
                      p_a1Zli = double g_a1Zlh
                      (g_a1Zlh, gpart_a1Zml) = Genome.Split.split gpart_a1Zmk
                      p_a1Zlg = Functions.belowten' g_a1Zlf
                      (g_a1Zlf, gpart_a1Zmk) = Genome.Split.split gpart_a1Zmj
                      p_a1Zle = double g_a1Zld
                      (g_a1Zld, gpart_a1Zmj) = Genome.Split.split gpart_a1Zmi
                      p_a1Zlc = double g_a1Zlb
                      (g_a1Zlb, gpart_a1Zmi) = Genome.Split.split gpart_a1Zmh
                      p_a1Zla = Functions.belowten' g_a1Zl9
                      (g_a1Zl9, gpart_a1Zmh) = Genome.Split.split gpart_a1Zmg
                      p_a1Zl8 = double g_a1Zl7
                      (g_a1Zl7, gpart_a1Zmg) = Genome.Split.split gpart_a1Zmf
                      p_a1Zl6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zl5
                      (g_a1Zl5, gpart_a1Zmf) = Genome.Split.split gpart_a1Zme
                      p_a1Zl4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zl3
                      (g_a1Zl3, gpart_a1Zme) = Genome.Split.split gpart_a1Zmd
                      p_a1Zl2 = double g_a1Zl1
                      (g_a1Zl1, gpart_a1Zmd) = Genome.Split.split gpart_a1Zmc
                      p_a1Zl0 = double g_a1ZkZ
                      (g_a1ZkZ, gpart_a1Zmc) = Genome.Split.split gpart_a1Zmb
                      p_a1ZkY = double g_a1ZkX
                      (g_a1ZkX, gpart_a1Zmb) = Genome.Split.split gpart_a1Zma
                      p_a1ZkW = double g_a1ZkV
                      (g_a1ZkV, gpart_a1Zma) = Genome.Split.split gpart_a1Zm9
                      p_a1ZkU = double g_a1ZkT
                      (g_a1ZkT, gpart_a1Zm9) = Genome.Split.split genome_a1Zm7
                    in  \ x_a1ZmL
                          -> let
                               c_PTB_a1ZmO
                                 = ((Data.Fixed.Vector.toVector x_a1ZmL) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZmM
                                 = ((Data.Fixed.Vector.toVector x_a1ZmL) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZmS
                                 = ((Data.Fixed.Vector.toVector x_a1ZmL) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZmU
                                 = ((Data.Fixed.Vector.toVector x_a1ZmL) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zn4
                                 = ((Data.Fixed.Vector.toVector x_a1ZmL) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zl2 / (1 + ((c_MiRs_a1ZmM / p_a1Zl8) ** p_a1Zla)))
                                    + (negate (p_a1ZlY * c_PTB_a1ZmO))),
                                   ((p_a1Zlc
                                     / (1
                                        + (((c_MiRs_a1ZmM / p_a1Zle) ** p_a1Zlg)
                                           + ((c_PTB_a1ZmO / p_a1Zli) ** p_a1Zlk))))
                                    + (negate (p_a1Zm0 * c_NPTB_a1ZmS))),
                                   ((p_a1Zlm
                                     * ((p_a1ZlA + ((p_a1ZkY / p_a1Zlo) ** p_a1Zlq))
                                        / (((1 + p_a1ZlA) + ((p_a1ZkY / p_a1Zlo) ** p_a1Zlq))
                                           + (((c_NPTB_a1ZmS / p_a1Zls) ** p_a1Zlu)
                                              + ((c_RESTc_a1ZmU / p_a1Zlw) ** p_a1Zly)))))
                                    + (negate (p_a1Zm2 * c_MiRs_a1ZmM))),
                                   ((p_a1ZlC
                                     * ((p_a1ZlQ + ((c_PTB_a1ZmO / p_a1ZlE) ** p_a1ZlG))
                                        / (((1 + p_a1ZlQ) + ((c_PTB_a1ZmO / p_a1ZlE) ** p_a1ZlG))
                                           + (((p_a1ZkU / p_a1ZlI) ** p_a1ZlK)
                                              + ((c_MiRs_a1ZmM / p_a1ZlM) ** p_a1ZlO)))))
                                    + (negate (p_a1Zm4 * c_RESTc_a1ZmU))),
                                   ((p_a1ZlS / (1 + ((c_RESTc_a1ZmU / p_a1ZlU) ** p_a1ZlW)))
                                    + (negate (p_a1Zm6 * c_EndoNeuroTFs_a1Zn4)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483910",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483912",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483930",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483932",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483950",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483952",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zm7
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZnG
                            p_a1Zm6 = double g_a1Zm5
                            (g_a1Zm5, gpart_a1ZnG) = Genome.Split.split gpart_a1ZnF
                            p_a1Zm4 = double g_a1Zm3
                            (g_a1Zm3, gpart_a1ZnF) = Genome.Split.split gpart_a1ZnE
                            p_a1Zm2 = double g_a1Zm1
                            (g_a1Zm1, gpart_a1ZnE) = Genome.Split.split gpart_a1ZnD
                            p_a1Zm0 = double g_a1ZlZ
                            (g_a1ZlZ, gpart_a1ZnD) = Genome.Split.split gpart_a1ZnC
                            p_a1ZlY = double g_a1ZlX
                            (g_a1ZlX, gpart_a1ZnC) = Genome.Split.split gpart_a1ZnB
                            p_a1ZlW = Functions.belowten' g_a1ZlV
                            (g_a1ZlV, gpart_a1ZnB) = Genome.Split.split gpart_a1ZnA
                            p_a1ZlU = double g_a1ZlT
                            (g_a1ZlT, gpart_a1ZnA) = Genome.Split.split gpart_a1Znz
                            p_a1ZlS = double g_a1ZlR
                            (g_a1ZlR, gpart_a1Znz) = Genome.Split.split gpart_a1Zny
                            p_a1ZlQ = double g_a1ZlP
                            (g_a1ZlP, gpart_a1Zny) = Genome.Split.split gpart_a1Znx
                            p_a1ZlO = Functions.belowten' g_a1ZlN
                            (g_a1ZlN, gpart_a1Znx) = Genome.Split.split gpart_a1Znw
                            p_a1ZlM = double g_a1ZlL
                            (g_a1ZlL, gpart_a1Znw) = Genome.Split.split gpart_a1Znv
                            p_a1ZlK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlJ
                            (g_a1ZlJ, gpart_a1Znv) = Genome.Split.split gpart_a1Znu
                            p_a1ZlI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlH
                            (g_a1ZlH, gpart_a1Znu) = Genome.Split.split gpart_a1Znt
                            p_a1ZlG = Functions.belowten' g_a1ZlF
                            (g_a1ZlF, gpart_a1Znt) = Genome.Split.split gpart_a1Zns
                            p_a1ZlE = double g_a1ZlD
                            (g_a1ZlD, gpart_a1Zns) = Genome.Split.split gpart_a1Znr
                            p_a1ZlC = double g_a1ZlB
                            (g_a1ZlB, gpart_a1Znr) = Genome.Split.split gpart_a1Znq
                            p_a1ZlA = double g_a1Zlz
                            (g_a1Zlz, gpart_a1Znq) = Genome.Split.split gpart_a1Znp
                            p_a1Zly = Functions.belowten' g_a1Zlx
                            (g_a1Zlx, gpart_a1Znp) = Genome.Split.split gpart_a1Zno
                            p_a1Zlw = double g_a1Zlv
                            (g_a1Zlv, gpart_a1Zno) = Genome.Split.split gpart_a1Znn
                            p_a1Zlu = Functions.belowten' g_a1Zlt
                            (g_a1Zlt, gpart_a1Znn) = Genome.Split.split gpart_a1Znm
                            p_a1Zls = double g_a1Zlr
                            (g_a1Zlr, gpart_a1Znm) = Genome.Split.split gpart_a1Znl
                            p_a1Zlq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlp
                            (g_a1Zlp, gpart_a1Znl) = Genome.Split.split gpart_a1Znk
                            p_a1Zlo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zln
                            (g_a1Zln, gpart_a1Znk) = Genome.Split.split gpart_a1Znj
                            p_a1Zlm = double g_a1Zll
                            (g_a1Zll, gpart_a1Znj) = Genome.Split.split gpart_a1Zni
                            p_a1Zlk = Functions.belowten' g_a1Zlj
                            (g_a1Zlj, gpart_a1Zni) = Genome.Split.split gpart_a1Znh
                            p_a1Zli = double g_a1Zlh
                            (g_a1Zlh, gpart_a1Znh) = Genome.Split.split gpart_a1Zng
                            p_a1Zlg = Functions.belowten' g_a1Zlf
                            (g_a1Zlf, gpart_a1Zng) = Genome.Split.split gpart_a1Znf
                            p_a1Zle = double g_a1Zld
                            (g_a1Zld, gpart_a1Znf) = Genome.Split.split gpart_a1Zne
                            p_a1Zlc = double g_a1Zlb
                            (g_a1Zlb, gpart_a1Zne) = Genome.Split.split gpart_a1Znd
                            p_a1Zla = Functions.belowten' g_a1Zl9
                            (g_a1Zl9, gpart_a1Znd) = Genome.Split.split gpart_a1Znc
                            p_a1Zl8 = double g_a1Zl7
                            (g_a1Zl7, gpart_a1Znc) = Genome.Split.split gpart_a1Znb
                            p_a1Zl6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zl5
                            (g_a1Zl5, gpart_a1Znb) = Genome.Split.split gpart_a1Zna
                            p_a1Zl4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zl3
                            (g_a1Zl3, gpart_a1Zna) = Genome.Split.split gpart_a1Zn9
                            p_a1Zl2 = double g_a1Zl1
                            (g_a1Zl1, gpart_a1Zn9) = Genome.Split.split gpart_a1Zn8
                            p_a1Zl0 = double g_a1ZkZ
                            (g_a1ZkZ, gpart_a1Zn8) = Genome.Split.split gpart_a1Zn7
                            p_a1ZkY = double g_a1ZkX
                            (g_a1ZkX, gpart_a1Zn7) = Genome.Split.split gpart_a1Zn6
                            p_a1ZkW = double g_a1ZkV
                            (g_a1ZkV, gpart_a1Zn6) = Genome.Split.split gpart_a1Zn5
                            p_a1ZkU = double g_a1ZkT
                            (g_a1ZkT, gpart_a1Zn5) = Genome.Split.split genome_a1Zm7
                          in
                            \ desc_a1Zm8
                              -> case desc_a1Zm8 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkU)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkW)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkY)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl0)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl2)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl4)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl6)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl8)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zla)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlc)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zle)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlg)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zli)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlk)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlm)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlo)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlq)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zls)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlu)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlw)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zly)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlA)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlC)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlE)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlG)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlI)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlK)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlM)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlO)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlQ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlS)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlU)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlW)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlY)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm0)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm2)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm4)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm6)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1Zq4
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZqH
                      p_a1Zq3 = double g_a1Zq2
                      (g_a1Zq2, gpart_a1ZqH) = Genome.Split.split gpart_a1ZqG
                      p_a1Zq1 = double g_a1Zq0
                      (g_a1Zq0, gpart_a1ZqG) = Genome.Split.split gpart_a1ZqF
                      p_a1ZpZ = double g_a1ZpY
                      (g_a1ZpY, gpart_a1ZqF) = Genome.Split.split gpart_a1ZqE
                      p_a1ZpX = double g_a1ZpW
                      (g_a1ZpW, gpart_a1ZqE) = Genome.Split.split gpart_a1ZqD
                      p_a1ZpV = double g_a1ZpU
                      (g_a1ZpU, gpart_a1ZqD) = Genome.Split.split gpart_a1ZqC
                      p_a1ZpT = Functions.belowten' g_a1ZpS
                      (g_a1ZpS, gpart_a1ZqC) = Genome.Split.split gpart_a1ZqB
                      p_a1ZpR = double g_a1ZpQ
                      (g_a1ZpQ, gpart_a1ZqB) = Genome.Split.split gpart_a1ZqA
                      p_a1ZpP = double g_a1ZpO
                      (g_a1ZpO, gpart_a1ZqA) = Genome.Split.split gpart_a1Zqz
                      p_a1ZpN = double g_a1ZpM
                      (g_a1ZpM, gpart_a1Zqz) = Genome.Split.split gpart_a1Zqy
                      p_a1ZpL = Functions.belowten' g_a1ZpK
                      (g_a1ZpK, gpart_a1Zqy) = Genome.Split.split gpart_a1Zqx
                      p_a1ZpJ = double g_a1ZpI
                      (g_a1ZpI, gpart_a1Zqx) = Genome.Split.split gpart_a1Zqw
                      p_a1ZpH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZpG
                      (g_a1ZpG, gpart_a1Zqw) = Genome.Split.split gpart_a1Zqv
                      p_a1ZpF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZpE
                      (g_a1ZpE, gpart_a1Zqv) = Genome.Split.split gpart_a1Zqu
                      p_a1ZpD = Functions.belowten' g_a1ZpC
                      (g_a1ZpC, gpart_a1Zqu) = Genome.Split.split gpart_a1Zqt
                      p_a1ZpB = double g_a1ZpA
                      (g_a1ZpA, gpart_a1Zqt) = Genome.Split.split gpart_a1Zqs
                      p_a1Zpz = double g_a1Zpy
                      (g_a1Zpy, gpart_a1Zqs) = Genome.Split.split gpart_a1Zqr
                      p_a1Zpx = double g_a1Zpw
                      (g_a1Zpw, gpart_a1Zqr) = Genome.Split.split gpart_a1Zqq
                      p_a1Zpv = Functions.belowten' g_a1Zpu
                      (g_a1Zpu, gpart_a1Zqq) = Genome.Split.split gpart_a1Zqp
                      p_a1Zpt = double g_a1Zps
                      (g_a1Zps, gpart_a1Zqp) = Genome.Split.split gpart_a1Zqo
                      p_a1Zpr = Functions.belowten' g_a1Zpq
                      (g_a1Zpq, gpart_a1Zqo) = Genome.Split.split gpart_a1Zqn
                      p_a1Zpp = double g_a1Zpo
                      (g_a1Zpo, gpart_a1Zqn) = Genome.Split.split gpart_a1Zqm
                      p_a1Zpn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zpm
                      (g_a1Zpm, gpart_a1Zqm) = Genome.Split.split gpart_a1Zql
                      p_a1Zpl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zpk
                      (g_a1Zpk, gpart_a1Zql) = Genome.Split.split gpart_a1Zqk
                      p_a1Zpj = double g_a1Zpi
                      (g_a1Zpi, gpart_a1Zqk) = Genome.Split.split gpart_a1Zqj
                      p_a1Zph = Functions.belowten' g_a1Zpg
                      (g_a1Zpg, gpart_a1Zqj) = Genome.Split.split gpart_a1Zqi
                      p_a1Zpf = double g_a1Zpe
                      (g_a1Zpe, gpart_a1Zqi) = Genome.Split.split gpart_a1Zqh
                      p_a1Zpd = Functions.belowten' g_a1Zpc
                      (g_a1Zpc, gpart_a1Zqh) = Genome.Split.split gpart_a1Zqg
                      p_a1Zpb = double g_a1Zpa
                      (g_a1Zpa, gpart_a1Zqg) = Genome.Split.split gpart_a1Zqf
                      p_a1Zp9 = double g_a1Zp8
                      (g_a1Zp8, gpart_a1Zqf) = Genome.Split.split gpart_a1Zqe
                      p_a1Zp7 = Functions.belowten' g_a1Zp6
                      (g_a1Zp6, gpart_a1Zqe) = Genome.Split.split gpart_a1Zqd
                      p_a1Zp5 = double g_a1Zp4
                      (g_a1Zp4, gpart_a1Zqd) = Genome.Split.split gpart_a1Zqc
                      p_a1Zp3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zp2
                      (g_a1Zp2, gpart_a1Zqc) = Genome.Split.split gpart_a1Zqb
                      p_a1Zp1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zp0
                      (g_a1Zp0, gpart_a1Zqb) = Genome.Split.split gpart_a1Zqa
                      p_a1ZoZ = double g_a1ZoY
                      (g_a1ZoY, gpart_a1Zqa) = Genome.Split.split gpart_a1Zq9
                      p_a1ZoX = double g_a1ZoW
                      (g_a1ZoW, gpart_a1Zq9) = Genome.Split.split gpart_a1Zq8
                      p_a1ZoV = double g_a1ZoU
                      (g_a1ZoU, gpart_a1Zq8) = Genome.Split.split gpart_a1Zq7
                      p_a1ZoT = double g_a1ZoS
                      (g_a1ZoS, gpart_a1Zq7) = Genome.Split.split gpart_a1Zq6
                      p_a1ZoR = double g_a1ZoQ
                      (g_a1ZoQ, gpart_a1Zq6) = Genome.Split.split genome_a1Zq4
                    in  \ x_a1ZqI
                          -> let
                               c_PTB_a1ZqL
                                 = ((Data.Fixed.Vector.toVector x_a1ZqI) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZqJ
                                 = ((Data.Fixed.Vector.toVector x_a1ZqI) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZqP
                                 = ((Data.Fixed.Vector.toVector x_a1ZqI) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZqR
                                 = ((Data.Fixed.Vector.toVector x_a1ZqI) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zr1
                                 = ((Data.Fixed.Vector.toVector x_a1ZqI) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1ZoZ / (1 + ((c_MiRs_a1ZqJ / p_a1Zp5) ** p_a1Zp7)))
                                    + (negate (p_a1ZpV * c_PTB_a1ZqL))),
                                   ((p_a1Zp9
                                     / (1
                                        + (((c_MiRs_a1ZqJ / p_a1Zpb) ** p_a1Zpd)
                                           + ((c_PTB_a1ZqL / p_a1Zpf) ** p_a1Zph))))
                                    + (negate (p_a1ZpX * c_NPTB_a1ZqP))),
                                   ((p_a1Zpj
                                     * (p_a1Zpx
                                        / ((1 + p_a1Zpx)
                                           + (((c_NPTB_a1ZqP / p_a1Zpp) ** p_a1Zpr)
                                              + ((c_RESTc_a1ZqR / p_a1Zpt) ** p_a1Zpv)))))
                                    + (negate (p_a1ZpZ * c_MiRs_a1ZqJ))),
                                   ((p_a1Zpz
                                     * ((p_a1ZpN + ((c_PTB_a1ZqL / p_a1ZpB) ** p_a1ZpD))
                                        / (((1 + p_a1ZpN) + ((c_PTB_a1ZqL / p_a1ZpB) ** p_a1ZpD))
                                           + (((p_a1ZoR / p_a1ZpF) ** p_a1ZpH)
                                              + ((c_MiRs_a1ZqJ / p_a1ZpJ) ** p_a1ZpL)))))
                                    + (negate (p_a1Zq1 * c_RESTc_a1ZqR))),
                                   ((p_a1ZpP / (1 + ((c_RESTc_a1ZqR / p_a1ZpR) ** p_a1ZpT)))
                                    + (negate (p_a1Zq3 * c_EndoNeuroTFs_a1Zr1)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484155",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484157",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484175",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484177",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484195",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484197",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zq4
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZrD
                            p_a1Zq3 = double g_a1Zq2
                            (g_a1Zq2, gpart_a1ZrD) = Genome.Split.split gpart_a1ZrC
                            p_a1Zq1 = double g_a1Zq0
                            (g_a1Zq0, gpart_a1ZrC) = Genome.Split.split gpart_a1ZrB
                            p_a1ZpZ = double g_a1ZpY
                            (g_a1ZpY, gpart_a1ZrB) = Genome.Split.split gpart_a1ZrA
                            p_a1ZpX = double g_a1ZpW
                            (g_a1ZpW, gpart_a1ZrA) = Genome.Split.split gpart_a1Zrz
                            p_a1ZpV = double g_a1ZpU
                            (g_a1ZpU, gpart_a1Zrz) = Genome.Split.split gpart_a1Zry
                            p_a1ZpT = Functions.belowten' g_a1ZpS
                            (g_a1ZpS, gpart_a1Zry) = Genome.Split.split gpart_a1Zrx
                            p_a1ZpR = double g_a1ZpQ
                            (g_a1ZpQ, gpart_a1Zrx) = Genome.Split.split gpart_a1Zrw
                            p_a1ZpP = double g_a1ZpO
                            (g_a1ZpO, gpart_a1Zrw) = Genome.Split.split gpart_a1Zrv
                            p_a1ZpN = double g_a1ZpM
                            (g_a1ZpM, gpart_a1Zrv) = Genome.Split.split gpart_a1Zru
                            p_a1ZpL = Functions.belowten' g_a1ZpK
                            (g_a1ZpK, gpart_a1Zru) = Genome.Split.split gpart_a1Zrt
                            p_a1ZpJ = double g_a1ZpI
                            (g_a1ZpI, gpart_a1Zrt) = Genome.Split.split gpart_a1Zrs
                            p_a1ZpH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZpG
                            (g_a1ZpG, gpart_a1Zrs) = Genome.Split.split gpart_a1Zrr
                            p_a1ZpF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZpE
                            (g_a1ZpE, gpart_a1Zrr) = Genome.Split.split gpart_a1Zrq
                            p_a1ZpD = Functions.belowten' g_a1ZpC
                            (g_a1ZpC, gpart_a1Zrq) = Genome.Split.split gpart_a1Zrp
                            p_a1ZpB = double g_a1ZpA
                            (g_a1ZpA, gpart_a1Zrp) = Genome.Split.split gpart_a1Zro
                            p_a1Zpz = double g_a1Zpy
                            (g_a1Zpy, gpart_a1Zro) = Genome.Split.split gpart_a1Zrn
                            p_a1Zpx = double g_a1Zpw
                            (g_a1Zpw, gpart_a1Zrn) = Genome.Split.split gpart_a1Zrm
                            p_a1Zpv = Functions.belowten' g_a1Zpu
                            (g_a1Zpu, gpart_a1Zrm) = Genome.Split.split gpart_a1Zrl
                            p_a1Zpt = double g_a1Zps
                            (g_a1Zps, gpart_a1Zrl) = Genome.Split.split gpart_a1Zrk
                            p_a1Zpr = Functions.belowten' g_a1Zpq
                            (g_a1Zpq, gpart_a1Zrk) = Genome.Split.split gpart_a1Zrj
                            p_a1Zpp = double g_a1Zpo
                            (g_a1Zpo, gpart_a1Zrj) = Genome.Split.split gpart_a1Zri
                            p_a1Zpn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zpm
                            (g_a1Zpm, gpart_a1Zri) = Genome.Split.split gpart_a1Zrh
                            p_a1Zpl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zpk
                            (g_a1Zpk, gpart_a1Zrh) = Genome.Split.split gpart_a1Zrg
                            p_a1Zpj = double g_a1Zpi
                            (g_a1Zpi, gpart_a1Zrg) = Genome.Split.split gpart_a1Zrf
                            p_a1Zph = Functions.belowten' g_a1Zpg
                            (g_a1Zpg, gpart_a1Zrf) = Genome.Split.split gpart_a1Zre
                            p_a1Zpf = double g_a1Zpe
                            (g_a1Zpe, gpart_a1Zre) = Genome.Split.split gpart_a1Zrd
                            p_a1Zpd = Functions.belowten' g_a1Zpc
                            (g_a1Zpc, gpart_a1Zrd) = Genome.Split.split gpart_a1Zrc
                            p_a1Zpb = double g_a1Zpa
                            (g_a1Zpa, gpart_a1Zrc) = Genome.Split.split gpart_a1Zrb
                            p_a1Zp9 = double g_a1Zp8
                            (g_a1Zp8, gpart_a1Zrb) = Genome.Split.split gpart_a1Zra
                            p_a1Zp7 = Functions.belowten' g_a1Zp6
                            (g_a1Zp6, gpart_a1Zra) = Genome.Split.split gpart_a1Zr9
                            p_a1Zp5 = double g_a1Zp4
                            (g_a1Zp4, gpart_a1Zr9) = Genome.Split.split gpart_a1Zr8
                            p_a1Zp3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zp2
                            (g_a1Zp2, gpart_a1Zr8) = Genome.Split.split gpart_a1Zr7
                            p_a1Zp1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zp0
                            (g_a1Zp0, gpart_a1Zr7) = Genome.Split.split gpart_a1Zr6
                            p_a1ZoZ = double g_a1ZoY
                            (g_a1ZoY, gpart_a1Zr6) = Genome.Split.split gpart_a1Zr5
                            p_a1ZoX = double g_a1ZoW
                            (g_a1ZoW, gpart_a1Zr5) = Genome.Split.split gpart_a1Zr4
                            p_a1ZoV = double g_a1ZoU
                            (g_a1ZoU, gpart_a1Zr4) = Genome.Split.split gpart_a1Zr3
                            p_a1ZoT = double g_a1ZoS
                            (g_a1ZoS, gpart_a1Zr3) = Genome.Split.split gpart_a1Zr2
                            p_a1ZoR = double g_a1ZoQ
                            (g_a1ZoQ, gpart_a1Zr2) = Genome.Split.split genome_a1Zq4
                          in
                            \ desc_a1Zq5
                              -> case desc_a1Zq5 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoR)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoT)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoV)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoX)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoZ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp1)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp3)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp5)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp7)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zp9)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpb)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpd)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpf)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zph)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpj)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpl)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpn)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpp)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpr)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpt)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpv)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpx)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zpz)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpB)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpD)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpF)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpH)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpJ)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpL)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpN)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpP)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpR)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpT)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpV)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpX)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZpZ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zq1)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zq3)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1Zu1
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZuE
                      p_a1Zu0 = double g_a1ZtZ
                      (g_a1ZtZ, gpart_a1ZuE) = Genome.Split.split gpart_a1ZuD
                      p_a1ZtY = double g_a1ZtX
                      (g_a1ZtX, gpart_a1ZuD) = Genome.Split.split gpart_a1ZuC
                      p_a1ZtW = double g_a1ZtV
                      (g_a1ZtV, gpart_a1ZuC) = Genome.Split.split gpart_a1ZuB
                      p_a1ZtU = double g_a1ZtT
                      (g_a1ZtT, gpart_a1ZuB) = Genome.Split.split gpart_a1ZuA
                      p_a1ZtS = double g_a1ZtR
                      (g_a1ZtR, gpart_a1ZuA) = Genome.Split.split gpart_a1Zuz
                      p_a1ZtQ = Functions.belowten' g_a1ZtP
                      (g_a1ZtP, gpart_a1Zuz) = Genome.Split.split gpart_a1Zuy
                      p_a1ZtO = double g_a1ZtN
                      (g_a1ZtN, gpart_a1Zuy) = Genome.Split.split gpart_a1Zux
                      p_a1ZtM = double g_a1ZtL
                      (g_a1ZtL, gpart_a1Zux) = Genome.Split.split gpart_a1Zuw
                      p_a1ZtK = double g_a1ZtJ
                      (g_a1ZtJ, gpart_a1Zuw) = Genome.Split.split gpart_a1Zuv
                      p_a1ZtI = Functions.belowten' g_a1ZtH
                      (g_a1ZtH, gpart_a1Zuv) = Genome.Split.split gpart_a1Zuu
                      p_a1ZtG = double g_a1ZtF
                      (g_a1ZtF, gpart_a1Zuu) = Genome.Split.split gpart_a1Zut
                      p_a1ZtE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZtD
                      (g_a1ZtD, gpart_a1Zut) = Genome.Split.split gpart_a1Zus
                      p_a1ZtC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZtB
                      (g_a1ZtB, gpart_a1Zus) = Genome.Split.split gpart_a1Zur
                      p_a1ZtA = Functions.belowten' g_a1Ztz
                      (g_a1Ztz, gpart_a1Zur) = Genome.Split.split gpart_a1Zuq
                      p_a1Zty = double g_a1Ztx
                      (g_a1Ztx, gpart_a1Zuq) = Genome.Split.split gpart_a1Zup
                      p_a1Ztw = double g_a1Ztv
                      (g_a1Ztv, gpart_a1Zup) = Genome.Split.split gpart_a1Zuo
                      p_a1Ztu = double g_a1Ztt
                      (g_a1Ztt, gpart_a1Zuo) = Genome.Split.split gpart_a1Zun
                      p_a1Zts = Functions.belowten' g_a1Ztr
                      (g_a1Ztr, gpart_a1Zun) = Genome.Split.split gpart_a1Zum
                      p_a1Ztq = double g_a1Ztp
                      (g_a1Ztp, gpart_a1Zum) = Genome.Split.split gpart_a1Zul
                      p_a1Zto = Functions.belowten' g_a1Ztn
                      (g_a1Ztn, gpart_a1Zul) = Genome.Split.split gpart_a1Zuk
                      p_a1Ztm = double g_a1Ztl
                      (g_a1Ztl, gpart_a1Zuk) = Genome.Split.split gpart_a1Zuj
                      p_a1Ztk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Ztj
                      (g_a1Ztj, gpart_a1Zuj) = Genome.Split.split gpart_a1Zui
                      p_a1Zti
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zth
                      (g_a1Zth, gpart_a1Zui) = Genome.Split.split gpart_a1Zuh
                      p_a1Ztg = double g_a1Ztf
                      (g_a1Ztf, gpart_a1Zuh) = Genome.Split.split gpart_a1Zug
                      p_a1Zte = Functions.belowten' g_a1Ztd
                      (g_a1Ztd, gpart_a1Zug) = Genome.Split.split gpart_a1Zuf
                      p_a1Ztc = double g_a1Ztb
                      (g_a1Ztb, gpart_a1Zuf) = Genome.Split.split gpart_a1Zue
                      p_a1Zta = Functions.belowten' g_a1Zt9
                      (g_a1Zt9, gpart_a1Zue) = Genome.Split.split gpart_a1Zud
                      p_a1Zt8 = double g_a1Zt7
                      (g_a1Zt7, gpart_a1Zud) = Genome.Split.split gpart_a1Zuc
                      p_a1Zt6 = double g_a1Zt5
                      (g_a1Zt5, gpart_a1Zuc) = Genome.Split.split gpart_a1Zub
                      p_a1Zt4 = Functions.belowten' g_a1Zt3
                      (g_a1Zt3, gpart_a1Zub) = Genome.Split.split gpart_a1Zua
                      p_a1Zt2 = double g_a1Zt1
                      (g_a1Zt1, gpart_a1Zua) = Genome.Split.split gpart_a1Zu9
                      p_a1Zt0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZsZ
                      (g_a1ZsZ, gpart_a1Zu9) = Genome.Split.split gpart_a1Zu8
                      p_a1ZsY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZsX
                      (g_a1ZsX, gpart_a1Zu8) = Genome.Split.split gpart_a1Zu7
                      p_a1ZsW = double g_a1ZsV
                      (g_a1ZsV, gpart_a1Zu7) = Genome.Split.split gpart_a1Zu6
                      p_a1ZsU = double g_a1ZsT
                      (g_a1ZsT, gpart_a1Zu6) = Genome.Split.split gpart_a1Zu5
                      p_a1ZsS = double g_a1ZsR
                      (g_a1ZsR, gpart_a1Zu5) = Genome.Split.split gpart_a1Zu4
                      p_a1ZsQ = double g_a1ZsP
                      (g_a1ZsP, gpart_a1Zu4) = Genome.Split.split gpart_a1Zu3
                      p_a1ZsO = double g_a1ZsN
                      (g_a1ZsN, gpart_a1Zu3) = Genome.Split.split genome_a1Zu1
                    in  \ x_a1ZuF
                          -> let
                               c_PTB_a1ZuI
                                 = ((Data.Fixed.Vector.toVector x_a1ZuF) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZuG
                                 = ((Data.Fixed.Vector.toVector x_a1ZuF) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZuM
                                 = ((Data.Fixed.Vector.toVector x_a1ZuF) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZuO
                                 = ((Data.Fixed.Vector.toVector x_a1ZuF) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1ZuY
                                 = ((Data.Fixed.Vector.toVector x_a1ZuF) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1ZsW / (1 + ((c_MiRs_a1ZuG / p_a1Zt2) ** p_a1Zt4)))
                                    + (negate (p_a1ZtS * c_PTB_a1ZuI))),
                                   ((p_a1Zt6
                                     / (1
                                        + (((c_MiRs_a1ZuG / p_a1Zt8) ** p_a1Zta)
                                           + ((c_PTB_a1ZuI / p_a1Ztc) ** p_a1Zte))))
                                    + (negate (p_a1ZtU * c_NPTB_a1ZuM))),
                                   ((p_a1Ztg
                                     * (p_a1Ztu
                                        / ((1 + p_a1Ztu)
                                           + (((c_NPTB_a1ZuM / p_a1Ztm) ** p_a1Zto)
                                              + ((c_RESTc_a1ZuO / p_a1Ztq) ** p_a1Zts)))))
                                    + (negate (p_a1ZtW * c_MiRs_a1ZuG))),
                                   ((p_a1Ztw
                                     * ((p_a1ZtK + ((c_PTB_a1ZuI / p_a1Zty) ** p_a1ZtA))
                                        / (((1 + p_a1ZtK) + ((c_PTB_a1ZuI / p_a1Zty) ** p_a1ZtA))
                                           + ((c_MiRs_a1ZuG / p_a1ZtG) ** p_a1ZtI))))
                                    + (negate (p_a1ZtY * c_RESTc_a1ZuO))),
                                   ((p_a1ZtM / (1 + ((c_RESTc_a1ZuO / p_a1ZtO) ** p_a1ZtQ)))
                                    + (negate (p_a1Zu0 * c_EndoNeuroTFs_a1ZuY)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484400",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484402",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484420",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484422",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484440",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484442",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zu1
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZvA
                            p_a1Zu0 = double g_a1ZtZ
                            (g_a1ZtZ, gpart_a1ZvA) = Genome.Split.split gpart_a1Zvz
                            p_a1ZtY = double g_a1ZtX
                            (g_a1ZtX, gpart_a1Zvz) = Genome.Split.split gpart_a1Zvy
                            p_a1ZtW = double g_a1ZtV
                            (g_a1ZtV, gpart_a1Zvy) = Genome.Split.split gpart_a1Zvx
                            p_a1ZtU = double g_a1ZtT
                            (g_a1ZtT, gpart_a1Zvx) = Genome.Split.split gpart_a1Zvw
                            p_a1ZtS = double g_a1ZtR
                            (g_a1ZtR, gpart_a1Zvw) = Genome.Split.split gpart_a1Zvv
                            p_a1ZtQ = Functions.belowten' g_a1ZtP
                            (g_a1ZtP, gpart_a1Zvv) = Genome.Split.split gpart_a1Zvu
                            p_a1ZtO = double g_a1ZtN
                            (g_a1ZtN, gpart_a1Zvu) = Genome.Split.split gpart_a1Zvt
                            p_a1ZtM = double g_a1ZtL
                            (g_a1ZtL, gpart_a1Zvt) = Genome.Split.split gpart_a1Zvs
                            p_a1ZtK = double g_a1ZtJ
                            (g_a1ZtJ, gpart_a1Zvs) = Genome.Split.split gpart_a1Zvr
                            p_a1ZtI = Functions.belowten' g_a1ZtH
                            (g_a1ZtH, gpart_a1Zvr) = Genome.Split.split gpart_a1Zvq
                            p_a1ZtG = double g_a1ZtF
                            (g_a1ZtF, gpart_a1Zvq) = Genome.Split.split gpart_a1Zvp
                            p_a1ZtE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZtD
                            (g_a1ZtD, gpart_a1Zvp) = Genome.Split.split gpart_a1Zvo
                            p_a1ZtC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZtB
                            (g_a1ZtB, gpart_a1Zvo) = Genome.Split.split gpart_a1Zvn
                            p_a1ZtA = Functions.belowten' g_a1Ztz
                            (g_a1Ztz, gpart_a1Zvn) = Genome.Split.split gpart_a1Zvm
                            p_a1Zty = double g_a1Ztx
                            (g_a1Ztx, gpart_a1Zvm) = Genome.Split.split gpart_a1Zvl
                            p_a1Ztw = double g_a1Ztv
                            (g_a1Ztv, gpart_a1Zvl) = Genome.Split.split gpart_a1Zvk
                            p_a1Ztu = double g_a1Ztt
                            (g_a1Ztt, gpart_a1Zvk) = Genome.Split.split gpart_a1Zvj
                            p_a1Zts = Functions.belowten' g_a1Ztr
                            (g_a1Ztr, gpart_a1Zvj) = Genome.Split.split gpart_a1Zvi
                            p_a1Ztq = double g_a1Ztp
                            (g_a1Ztp, gpart_a1Zvi) = Genome.Split.split gpart_a1Zvh
                            p_a1Zto = Functions.belowten' g_a1Ztn
                            (g_a1Ztn, gpart_a1Zvh) = Genome.Split.split gpart_a1Zvg
                            p_a1Ztm = double g_a1Ztl
                            (g_a1Ztl, gpart_a1Zvg) = Genome.Split.split gpart_a1Zvf
                            p_a1Ztk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Ztj
                            (g_a1Ztj, gpart_a1Zvf) = Genome.Split.split gpart_a1Zve
                            p_a1Zti
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zth
                            (g_a1Zth, gpart_a1Zve) = Genome.Split.split gpart_a1Zvd
                            p_a1Ztg = double g_a1Ztf
                            (g_a1Ztf, gpart_a1Zvd) = Genome.Split.split gpart_a1Zvc
                            p_a1Zte = Functions.belowten' g_a1Ztd
                            (g_a1Ztd, gpart_a1Zvc) = Genome.Split.split gpart_a1Zvb
                            p_a1Ztc = double g_a1Ztb
                            (g_a1Ztb, gpart_a1Zvb) = Genome.Split.split gpart_a1Zva
                            p_a1Zta = Functions.belowten' g_a1Zt9
                            (g_a1Zt9, gpart_a1Zva) = Genome.Split.split gpart_a1Zv9
                            p_a1Zt8 = double g_a1Zt7
                            (g_a1Zt7, gpart_a1Zv9) = Genome.Split.split gpart_a1Zv8
                            p_a1Zt6 = double g_a1Zt5
                            (g_a1Zt5, gpart_a1Zv8) = Genome.Split.split gpart_a1Zv7
                            p_a1Zt4 = Functions.belowten' g_a1Zt3
                            (g_a1Zt3, gpart_a1Zv7) = Genome.Split.split gpart_a1Zv6
                            p_a1Zt2 = double g_a1Zt1
                            (g_a1Zt1, gpart_a1Zv6) = Genome.Split.split gpart_a1Zv5
                            p_a1Zt0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZsZ
                            (g_a1ZsZ, gpart_a1Zv5) = Genome.Split.split gpart_a1Zv4
                            p_a1ZsY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZsX
                            (g_a1ZsX, gpart_a1Zv4) = Genome.Split.split gpart_a1Zv3
                            p_a1ZsW = double g_a1ZsV
                            (g_a1ZsV, gpart_a1Zv3) = Genome.Split.split gpart_a1Zv2
                            p_a1ZsU = double g_a1ZsT
                            (g_a1ZsT, gpart_a1Zv2) = Genome.Split.split gpart_a1Zv1
                            p_a1ZsS = double g_a1ZsR
                            (g_a1ZsR, gpart_a1Zv1) = Genome.Split.split gpart_a1Zv0
                            p_a1ZsQ = double g_a1ZsP
                            (g_a1ZsP, gpart_a1Zv0) = Genome.Split.split gpart_a1ZuZ
                            p_a1ZsO = double g_a1ZsN
                            (g_a1ZsN, gpart_a1ZuZ) = Genome.Split.split genome_a1Zu1
                          in
                            \ desc_a1Zu2
                              -> case desc_a1Zu2 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsO)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsQ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsS)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsU)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsW)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsY)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zt0)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zt2)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zt4)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zt6)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zt8)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zta)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ztc)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zte)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ztg)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zti)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ztk)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ztm)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zto)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ztq)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zts)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ztu)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ztw)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zty)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtA)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtC)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtE)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtG)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtI)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtK)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtM)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtO)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtQ)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtS)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtU)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtW)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZtY)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zu0)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1ZxY
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZyB
                      p_a1ZxX = double g_a1ZxW
                      (g_a1ZxW, gpart_a1ZyB) = Genome.Split.split gpart_a1ZyA
                      p_a1ZxV = double g_a1ZxU
                      (g_a1ZxU, gpart_a1ZyA) = Genome.Split.split gpart_a1Zyz
                      p_a1ZxT = double g_a1ZxS
                      (g_a1ZxS, gpart_a1Zyz) = Genome.Split.split gpart_a1Zyy
                      p_a1ZxR = double g_a1ZxQ
                      (g_a1ZxQ, gpart_a1Zyy) = Genome.Split.split gpart_a1Zyx
                      p_a1ZxP = double g_a1ZxO
                      (g_a1ZxO, gpart_a1Zyx) = Genome.Split.split gpart_a1Zyw
                      p_a1ZxN = Functions.belowten' g_a1ZxM
                      (g_a1ZxM, gpart_a1Zyw) = Genome.Split.split gpart_a1Zyv
                      p_a1ZxL = double g_a1ZxK
                      (g_a1ZxK, gpart_a1Zyv) = Genome.Split.split gpart_a1Zyu
                      p_a1ZxJ = double g_a1ZxI
                      (g_a1ZxI, gpart_a1Zyu) = Genome.Split.split gpart_a1Zyt
                      p_a1ZxH = double g_a1ZxG
                      (g_a1ZxG, gpart_a1Zyt) = Genome.Split.split gpart_a1Zys
                      p_a1ZxF = Functions.belowten' g_a1ZxE
                      (g_a1ZxE, gpart_a1Zys) = Genome.Split.split gpart_a1Zyr
                      p_a1ZxD = double g_a1ZxC
                      (g_a1ZxC, gpart_a1Zyr) = Genome.Split.split gpart_a1Zyq
                      p_a1ZxB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZxA
                      (g_a1ZxA, gpart_a1Zyq) = Genome.Split.split gpart_a1Zyp
                      p_a1Zxz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zxy
                      (g_a1Zxy, gpart_a1Zyp) = Genome.Split.split gpart_a1Zyo
                      p_a1Zxx = Functions.belowten' g_a1Zxw
                      (g_a1Zxw, gpart_a1Zyo) = Genome.Split.split gpart_a1Zyn
                      p_a1Zxv = double g_a1Zxu
                      (g_a1Zxu, gpart_a1Zyn) = Genome.Split.split gpart_a1Zym
                      p_a1Zxt = double g_a1Zxs
                      (g_a1Zxs, gpart_a1Zym) = Genome.Split.split gpart_a1Zyl
                      p_a1Zxr = double g_a1Zxq
                      (g_a1Zxq, gpart_a1Zyl) = Genome.Split.split gpart_a1Zyk
                      p_a1Zxp = Functions.belowten' g_a1Zxo
                      (g_a1Zxo, gpart_a1Zyk) = Genome.Split.split gpart_a1Zyj
                      p_a1Zxn = double g_a1Zxm
                      (g_a1Zxm, gpart_a1Zyj) = Genome.Split.split gpart_a1Zyi
                      p_a1Zxl = Functions.belowten' g_a1Zxk
                      (g_a1Zxk, gpart_a1Zyi) = Genome.Split.split gpart_a1Zyh
                      p_a1Zxj = double g_a1Zxi
                      (g_a1Zxi, gpart_a1Zyh) = Genome.Split.split gpart_a1Zyg
                      p_a1Zxh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zxg
                      (g_a1Zxg, gpart_a1Zyg) = Genome.Split.split gpart_a1Zyf
                      p_a1Zxf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zxe
                      (g_a1Zxe, gpart_a1Zyf) = Genome.Split.split gpart_a1Zye
                      p_a1Zxd = double g_a1Zxc
                      (g_a1Zxc, gpart_a1Zye) = Genome.Split.split gpart_a1Zyd
                      p_a1Zxb = Functions.belowten' g_a1Zxa
                      (g_a1Zxa, gpart_a1Zyd) = Genome.Split.split gpart_a1Zyc
                      p_a1Zx9 = double g_a1Zx8
                      (g_a1Zx8, gpart_a1Zyc) = Genome.Split.split gpart_a1Zyb
                      p_a1Zx7 = Functions.belowten' g_a1Zx6
                      (g_a1Zx6, gpart_a1Zyb) = Genome.Split.split gpart_a1Zya
                      p_a1Zx5 = double g_a1Zx4
                      (g_a1Zx4, gpart_a1Zya) = Genome.Split.split gpart_a1Zy9
                      p_a1Zx3 = double g_a1Zx2
                      (g_a1Zx2, gpart_a1Zy9) = Genome.Split.split gpart_a1Zy8
                      p_a1Zx1 = Functions.belowten' g_a1Zx0
                      (g_a1Zx0, gpart_a1Zy8) = Genome.Split.split gpart_a1Zy7
                      p_a1ZwZ = double g_a1ZwY
                      (g_a1ZwY, gpart_a1Zy7) = Genome.Split.split gpart_a1Zy6
                      p_a1ZwX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZwW
                      (g_a1ZwW, gpart_a1Zy6) = Genome.Split.split gpart_a1Zy5
                      p_a1ZwV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZwU
                      (g_a1ZwU, gpart_a1Zy5) = Genome.Split.split gpart_a1Zy4
                      p_a1ZwT = double g_a1ZwS
                      (g_a1ZwS, gpart_a1Zy4) = Genome.Split.split gpart_a1Zy3
                      p_a1ZwR = double g_a1ZwQ
                      (g_a1ZwQ, gpart_a1Zy3) = Genome.Split.split gpart_a1Zy2
                      p_a1ZwP = double g_a1ZwO
                      (g_a1ZwO, gpart_a1Zy2) = Genome.Split.split gpart_a1Zy1
                      p_a1ZwN = double g_a1ZwM
                      (g_a1ZwM, gpart_a1Zy1) = Genome.Split.split gpart_a1Zy0
                      p_a1ZwL = double g_a1ZwK
                      (g_a1ZwK, gpart_a1Zy0) = Genome.Split.split genome_a1ZxY
                    in  \ x_a1ZyC
                          -> let
                               c_PTB_a1ZyF
                                 = ((Data.Fixed.Vector.toVector x_a1ZyC) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZyD
                                 = ((Data.Fixed.Vector.toVector x_a1ZyC) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZyJ
                                 = ((Data.Fixed.Vector.toVector x_a1ZyC) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZyL
                                 = ((Data.Fixed.Vector.toVector x_a1ZyC) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1ZyV
                                 = ((Data.Fixed.Vector.toVector x_a1ZyC) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1ZwT
                                     / (1
                                        + (((p_a1ZwL / p_a1ZwV) ** p_a1ZwX)
                                           + ((c_MiRs_a1ZyD / p_a1ZwZ) ** p_a1Zx1))))
                                    + (negate (p_a1ZxP * c_PTB_a1ZyF))),
                                   ((p_a1Zx3
                                     / (1
                                        + (((c_MiRs_a1ZyD / p_a1Zx5) ** p_a1Zx7)
                                           + ((c_PTB_a1ZyF / p_a1Zx9) ** p_a1Zxb))))
                                    + (negate (p_a1ZxR * c_NPTB_a1ZyJ))),
                                   ((p_a1Zxd
                                     * (p_a1Zxr
                                        / ((1 + p_a1Zxr)
                                           + (((c_NPTB_a1ZyJ / p_a1Zxj) ** p_a1Zxl)
                                              + ((c_RESTc_a1ZyL / p_a1Zxn) ** p_a1Zxp)))))
                                    + (negate (p_a1ZxT * c_MiRs_a1ZyD))),
                                   ((p_a1Zxt
                                     * ((p_a1ZxH + ((c_PTB_a1ZyF / p_a1Zxv) ** p_a1Zxx))
                                        / (((1 + p_a1ZxH) + ((c_PTB_a1ZyF / p_a1Zxv) ** p_a1Zxx))
                                           + ((c_MiRs_a1ZyD / p_a1ZxD) ** p_a1ZxF))))
                                    + (negate (p_a1ZxV * c_RESTc_a1ZyL))),
                                   ((p_a1ZxJ / (1 + ((c_RESTc_a1ZyL / p_a1ZxL) ** p_a1ZxN)))
                                    + (negate (p_a1ZxX * c_EndoNeuroTFs_a1ZyV)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484645",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484647",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484649",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484651",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484665",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484667",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484685",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484687",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484709",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1ZxY
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zzx
                            p_a1ZxX = double g_a1ZxW
                            (g_a1ZxW, gpart_a1Zzx) = Genome.Split.split gpart_a1Zzw
                            p_a1ZxV = double g_a1ZxU
                            (g_a1ZxU, gpart_a1Zzw) = Genome.Split.split gpart_a1Zzv
                            p_a1ZxT = double g_a1ZxS
                            (g_a1ZxS, gpart_a1Zzv) = Genome.Split.split gpart_a1Zzu
                            p_a1ZxR = double g_a1ZxQ
                            (g_a1ZxQ, gpart_a1Zzu) = Genome.Split.split gpart_a1Zzt
                            p_a1ZxP = double g_a1ZxO
                            (g_a1ZxO, gpart_a1Zzt) = Genome.Split.split gpart_a1Zzs
                            p_a1ZxN = Functions.belowten' g_a1ZxM
                            (g_a1ZxM, gpart_a1Zzs) = Genome.Split.split gpart_a1Zzr
                            p_a1ZxL = double g_a1ZxK
                            (g_a1ZxK, gpart_a1Zzr) = Genome.Split.split gpart_a1Zzq
                            p_a1ZxJ = double g_a1ZxI
                            (g_a1ZxI, gpart_a1Zzq) = Genome.Split.split gpart_a1Zzp
                            p_a1ZxH = double g_a1ZxG
                            (g_a1ZxG, gpart_a1Zzp) = Genome.Split.split gpart_a1Zzo
                            p_a1ZxF = Functions.belowten' g_a1ZxE
                            (g_a1ZxE, gpart_a1Zzo) = Genome.Split.split gpart_a1Zzn
                            p_a1ZxD = double g_a1ZxC
                            (g_a1ZxC, gpart_a1Zzn) = Genome.Split.split gpart_a1Zzm
                            p_a1ZxB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZxA
                            (g_a1ZxA, gpart_a1Zzm) = Genome.Split.split gpart_a1Zzl
                            p_a1Zxz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zxy
                            (g_a1Zxy, gpart_a1Zzl) = Genome.Split.split gpart_a1Zzk
                            p_a1Zxx = Functions.belowten' g_a1Zxw
                            (g_a1Zxw, gpart_a1Zzk) = Genome.Split.split gpart_a1Zzj
                            p_a1Zxv = double g_a1Zxu
                            (g_a1Zxu, gpart_a1Zzj) = Genome.Split.split gpart_a1Zzi
                            p_a1Zxt = double g_a1Zxs
                            (g_a1Zxs, gpart_a1Zzi) = Genome.Split.split gpart_a1Zzh
                            p_a1Zxr = double g_a1Zxq
                            (g_a1Zxq, gpart_a1Zzh) = Genome.Split.split gpart_a1Zzg
                            p_a1Zxp = Functions.belowten' g_a1Zxo
                            (g_a1Zxo, gpart_a1Zzg) = Genome.Split.split gpart_a1Zzf
                            p_a1Zxn = double g_a1Zxm
                            (g_a1Zxm, gpart_a1Zzf) = Genome.Split.split gpart_a1Zze
                            p_a1Zxl = Functions.belowten' g_a1Zxk
                            (g_a1Zxk, gpart_a1Zze) = Genome.Split.split gpart_a1Zzd
                            p_a1Zxj = double g_a1Zxi
                            (g_a1Zxi, gpart_a1Zzd) = Genome.Split.split gpart_a1Zzc
                            p_a1Zxh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zxg
                            (g_a1Zxg, gpart_a1Zzc) = Genome.Split.split gpart_a1Zzb
                            p_a1Zxf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zxe
                            (g_a1Zxe, gpart_a1Zzb) = Genome.Split.split gpart_a1Zza
                            p_a1Zxd = double g_a1Zxc
                            (g_a1Zxc, gpart_a1Zza) = Genome.Split.split gpart_a1Zz9
                            p_a1Zxb = Functions.belowten' g_a1Zxa
                            (g_a1Zxa, gpart_a1Zz9) = Genome.Split.split gpart_a1Zz8
                            p_a1Zx9 = double g_a1Zx8
                            (g_a1Zx8, gpart_a1Zz8) = Genome.Split.split gpart_a1Zz7
                            p_a1Zx7 = Functions.belowten' g_a1Zx6
                            (g_a1Zx6, gpart_a1Zz7) = Genome.Split.split gpart_a1Zz6
                            p_a1Zx5 = double g_a1Zx4
                            (g_a1Zx4, gpart_a1Zz6) = Genome.Split.split gpart_a1Zz5
                            p_a1Zx3 = double g_a1Zx2
                            (g_a1Zx2, gpart_a1Zz5) = Genome.Split.split gpart_a1Zz4
                            p_a1Zx1 = Functions.belowten' g_a1Zx0
                            (g_a1Zx0, gpart_a1Zz4) = Genome.Split.split gpart_a1Zz3
                            p_a1ZwZ = double g_a1ZwY
                            (g_a1ZwY, gpart_a1Zz3) = Genome.Split.split gpart_a1Zz2
                            p_a1ZwX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZwW
                            (g_a1ZwW, gpart_a1Zz2) = Genome.Split.split gpart_a1Zz1
                            p_a1ZwV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZwU
                            (g_a1ZwU, gpart_a1Zz1) = Genome.Split.split gpart_a1Zz0
                            p_a1ZwT = double g_a1ZwS
                            (g_a1ZwS, gpart_a1Zz0) = Genome.Split.split gpart_a1ZyZ
                            p_a1ZwR = double g_a1ZwQ
                            (g_a1ZwQ, gpart_a1ZyZ) = Genome.Split.split gpart_a1ZyY
                            p_a1ZwP = double g_a1ZwO
                            (g_a1ZwO, gpart_a1ZyY) = Genome.Split.split gpart_a1ZyX
                            p_a1ZwN = double g_a1ZwM
                            (g_a1ZwM, gpart_a1ZyX) = Genome.Split.split gpart_a1ZyW
                            p_a1ZwL = double g_a1ZwK
                            (g_a1ZwK, gpart_a1ZyW) = Genome.Split.split genome_a1ZxY
                          in
                            \ desc_a1ZxZ
                              -> case desc_a1ZxZ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZwL)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZwN)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZwP)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZwR)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZwT)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZwV)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZwX)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZwZ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zx1)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zx3)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zx5)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zx7)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zx9)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxb)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxd)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxf)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxh)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxj)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxl)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxn)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxp)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxr)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxt)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxv)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxx)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zxz)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxB)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxD)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxF)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxH)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxJ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxL)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxN)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxP)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxR)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxT)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxV)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZxX)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asX8
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXL
                      p_asX7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX6
                      (g_asX6, gpart_asXL) = Genome.Split.split gpart_asXK
                      p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                      (g_asX4, gpart_asXK) = Genome.Split.split gpart_asXJ
                      p_asX3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX2
                      (g_asX2, gpart_asXJ) = Genome.Split.split gpart_asXI
                      p_asX1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX0
                      (g_asX0, gpart_asXI) = Genome.Split.split gpart_asXH
                      p_asWZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWY
                      (g_asWY, gpart_asXH) = Genome.Split.split gpart_asXG
                      p_asWX = Functions.belowten' g_asWW
                      (g_asWW, gpart_asXG) = Genome.Split.split gpart_asXF
                      p_asWV = code-0.1.0.0:Genome.FixedList.Functions.double g_asWU
                      (g_asWU, gpart_asXF) = Genome.Split.split gpart_asXE
                      p_asWT = code-0.1.0.0:Genome.FixedList.Functions.double g_asWS
                      (g_asWS, gpart_asXE) = Genome.Split.split gpart_asXD
                      p_asWR = code-0.1.0.0:Genome.FixedList.Functions.double g_asWQ
                      (g_asWQ, gpart_asXD) = Genome.Split.split gpart_asXC
                      p_asWP = Functions.belowten' g_asWO
                      (g_asWO, gpart_asXC) = Genome.Split.split gpart_asXB
                      p_asWN = code-0.1.0.0:Genome.FixedList.Functions.double g_asWM
                      (g_asWM, gpart_asXB) = Genome.Split.split gpart_asXA
                      p_asWL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWK
                      (g_asWK, gpart_asXA) = Genome.Split.split gpart_asXz
                      p_asWJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWI
                      (g_asWI, gpart_asXz) = Genome.Split.split gpart_asXy
                      p_asWH = Functions.belowten' g_asWG
                      (g_asWG, gpart_asXy) = Genome.Split.split gpart_asXx
                      p_asWF = code-0.1.0.0:Genome.FixedList.Functions.double g_asWE
                      (g_asWE, gpart_asXx) = Genome.Split.split gpart_asXw
                      p_asWD = code-0.1.0.0:Genome.FixedList.Functions.double g_asWC
                      (g_asWC, gpart_asXw) = Genome.Split.split gpart_asXv
                      p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                      (g_asWA, gpart_asXv) = Genome.Split.split gpart_asXu
                      p_asWz = Functions.belowten' g_asWy
                      (g_asWy, gpart_asXu) = Genome.Split.split gpart_asXt
                      p_asWx = code-0.1.0.0:Genome.FixedList.Functions.double g_asWw
                      (g_asWw, gpart_asXt) = Genome.Split.split gpart_asXs
                      p_asWv = Functions.belowten' g_asWu
                      (g_asWu, gpart_asXs) = Genome.Split.split gpart_asXr
                      p_asWt = code-0.1.0.0:Genome.FixedList.Functions.double g_asWs
                      (g_asWs, gpart_asXr) = Genome.Split.split gpart_asXq
                      p_asWr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWq
                      (g_asWq, gpart_asXq) = Genome.Split.split gpart_asXp
                      p_asWp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWo
                      (g_asWo, gpart_asXp) = Genome.Split.split gpart_asXo
                      p_asWn = code-0.1.0.0:Genome.FixedList.Functions.double g_asWm
                      (g_asWm, gpart_asXo) = Genome.Split.split gpart_asXn
                      p_asWl = Functions.belowten' g_asWk
                      (g_asWk, gpart_asXn) = Genome.Split.split gpart_asXm
                      p_asWj = code-0.1.0.0:Genome.FixedList.Functions.double g_asWi
                      (g_asWi, gpart_asXm) = Genome.Split.split gpart_asXl
                      p_asWh = Functions.belowten' g_asWg
                      (g_asWg, gpart_asXl) = Genome.Split.split gpart_asXk
                      p_asWf = code-0.1.0.0:Genome.FixedList.Functions.double g_asWe
                      (g_asWe, gpart_asXk) = Genome.Split.split gpart_asXj
                      p_asWd = code-0.1.0.0:Genome.FixedList.Functions.double g_asWc
                      (g_asWc, gpart_asXj) = Genome.Split.split gpart_asXi
                      p_asWb = Functions.belowten' g_asWa
                      (g_asWa, gpart_asXi) = Genome.Split.split gpart_asXh
                      p_asW9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW8
                      (g_asW8, gpart_asXh) = Genome.Split.split gpart_asXg
                      p_asW7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW6
                      (g_asW6, gpart_asXg) = Genome.Split.split gpart_asXf
                      p_asW5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW4
                      (g_asW4, gpart_asXf) = Genome.Split.split gpart_asXe
                      p_asW3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW2
                      (g_asW2, gpart_asXe) = Genome.Split.split gpart_asXd
                      p_asW1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW0
                      (g_asW0, gpart_asXd) = Genome.Split.split gpart_asXc
                      p_asVZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVY
                      (g_asVY, gpart_asXc) = Genome.Split.split gpart_asXb
                      p_asVX = code-0.1.0.0:Genome.FixedList.Functions.double g_asVW
                      (g_asVW, gpart_asXb) = Genome.Split.split gpart_asXa
                      p_asVV = code-0.1.0.0:Genome.FixedList.Functions.double g_asVU
                      (g_asVU, gpart_asXa) = Genome.Split.split genome_asX8
                    in
                      [Reaction
                         (\ x_asXM
                            -> let c_MiRs_asXN = ((toVector x_asXM) Data.Vector.Unboxed.! 2)
                               in (p_asW3 / (1 + ((c_MiRs_asXN / p_asW9) ** p_asWb))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXO
                            -> let
                                 c_MiRs_asXP = ((toVector x_asXO) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXQ = ((toVector x_asXO) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWd
                                  / (1
                                     + (((c_MiRs_asXP / p_asWf) ** p_asWh)
                                        + ((c_PTB_asXQ / p_asWj) ** p_asWl)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asXR
                            -> let
                                 c_RESTc_asXT = ((toVector x_asXR) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asXS = ((toVector x_asXR) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asWn
                                  * ((p_asWB + ((p_asVZ / p_asWp) ** p_asWr))
                                     / (((1 + p_asWB) + ((p_asVZ / p_asWp) ** p_asWr))
                                        + (((c_NPTB_asXS / p_asWt) ** p_asWv)
                                           + ((c_RESTc_asXT / p_asWx) ** p_asWz))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asXU
                            -> let
                                 c_MiRs_asXX = ((toVector x_asXU) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXV = ((toVector x_asXU) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWD
                                  * ((p_asWR + ((c_PTB_asXV / p_asWF) ** p_asWH))
                                     / (((1 + p_asWR) + ((c_PTB_asXV / p_asWF) ** p_asWH))
                                        + (((p_asVV / p_asWJ) ** p_asWL)
                                           + ((c_MiRs_asXX / p_asWN) ** p_asWP))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asXY
                            -> let c_RESTc_asXZ = ((toVector x_asXY) Data.Vector.Unboxed.! 3)
                               in (p_asWT / (1 + ((c_RESTc_asXZ / p_asWV) ** p_asWX))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asY0
                            -> let c_PTB_asY1 = ((toVector x_asY0) Data.Vector.Unboxed.! 0)
                               in (p_asWZ * c_PTB_asY1))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asY2
                            -> let c_NPTB_asY3 = ((toVector x_asY2) Data.Vector.Unboxed.! 1)
                               in (p_asX1 * c_NPTB_asY3))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asY4
                            -> let c_MiRs_asY5 = ((toVector x_asY4) Data.Vector.Unboxed.! 2)
                               in (p_asX3 * c_MiRs_asY5))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asY6
                            -> let c_RESTc_asY7 = ((toVector x_asY6) Data.Vector.Unboxed.! 3)
                               in (p_asX5 * c_RESTc_asY7))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asY8
                            -> let
                                 c_EndoNeuroTFs_asY9 = ((toVector x_asY8) Data.Vector.Unboxed.! 4)
                               in (p_asX7 * c_EndoNeuroTFs_asY9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121014",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121015",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121016",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121017",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121018",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121019",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121020",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121021",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121023",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121025",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121027",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121034",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121035",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121036",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121037",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121038",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121039",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121040",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121041",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121042",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121043",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121044",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121045",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121046",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121047",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121048",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121049",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121050",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121051",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121059",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121061",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121063",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121065",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121067",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121069",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121085",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121087",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asX8
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYQ
                            p_asX7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX6
                            (g_asX6, gpart_asYQ) = Genome.Split.split gpart_asYP
                            p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                            (g_asX4, gpart_asYP) = Genome.Split.split gpart_asYO
                            p_asX3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX2
                            (g_asX2, gpart_asYO) = Genome.Split.split gpart_asYN
                            p_asX1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX0
                            (g_asX0, gpart_asYN) = Genome.Split.split gpart_asYM
                            p_asWZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWY
                            (g_asWY, gpart_asYM) = Genome.Split.split gpart_asYL
                            p_asWX = Functions.belowten' g_asWW
                            (g_asWW, gpart_asYL) = Genome.Split.split gpart_asYK
                            p_asWV = code-0.1.0.0:Genome.FixedList.Functions.double g_asWU
                            (g_asWU, gpart_asYK) = Genome.Split.split gpart_asYJ
                            p_asWT = code-0.1.0.0:Genome.FixedList.Functions.double g_asWS
                            (g_asWS, gpart_asYJ) = Genome.Split.split gpart_asYI
                            p_asWR = code-0.1.0.0:Genome.FixedList.Functions.double g_asWQ
                            (g_asWQ, gpart_asYI) = Genome.Split.split gpart_asYH
                            p_asWP = Functions.belowten' g_asWO
                            (g_asWO, gpart_asYH) = Genome.Split.split gpart_asYG
                            p_asWN = code-0.1.0.0:Genome.FixedList.Functions.double g_asWM
                            (g_asWM, gpart_asYG) = Genome.Split.split gpart_asYF
                            p_asWL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWK
                            (g_asWK, gpart_asYF) = Genome.Split.split gpart_asYE
                            p_asWJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWI
                            (g_asWI, gpart_asYE) = Genome.Split.split gpart_asYD
                            p_asWH = Functions.belowten' g_asWG
                            (g_asWG, gpart_asYD) = Genome.Split.split gpart_asYC
                            p_asWF = code-0.1.0.0:Genome.FixedList.Functions.double g_asWE
                            (g_asWE, gpart_asYC) = Genome.Split.split gpart_asYB
                            p_asWD = code-0.1.0.0:Genome.FixedList.Functions.double g_asWC
                            (g_asWC, gpart_asYB) = Genome.Split.split gpart_asYA
                            p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                            (g_asWA, gpart_asYA) = Genome.Split.split gpart_asYz
                            p_asWz = Functions.belowten' g_asWy
                            (g_asWy, gpart_asYz) = Genome.Split.split gpart_asYy
                            p_asWx = code-0.1.0.0:Genome.FixedList.Functions.double g_asWw
                            (g_asWw, gpart_asYy) = Genome.Split.split gpart_asYx
                            p_asWv = Functions.belowten' g_asWu
                            (g_asWu, gpart_asYx) = Genome.Split.split gpart_asYw
                            p_asWt = code-0.1.0.0:Genome.FixedList.Functions.double g_asWs
                            (g_asWs, gpart_asYw) = Genome.Split.split gpart_asYv
                            p_asWr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWq
                            (g_asWq, gpart_asYv) = Genome.Split.split gpart_asYu
                            p_asWp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWo
                            (g_asWo, gpart_asYu) = Genome.Split.split gpart_asYt
                            p_asWn = code-0.1.0.0:Genome.FixedList.Functions.double g_asWm
                            (g_asWm, gpart_asYt) = Genome.Split.split gpart_asYs
                            p_asWl = Functions.belowten' g_asWk
                            (g_asWk, gpart_asYs) = Genome.Split.split gpart_asYr
                            p_asWj = code-0.1.0.0:Genome.FixedList.Functions.double g_asWi
                            (g_asWi, gpart_asYr) = Genome.Split.split gpart_asYq
                            p_asWh = Functions.belowten' g_asWg
                            (g_asWg, gpart_asYq) = Genome.Split.split gpart_asYp
                            p_asWf = code-0.1.0.0:Genome.FixedList.Functions.double g_asWe
                            (g_asWe, gpart_asYp) = Genome.Split.split gpart_asYo
                            p_asWd = code-0.1.0.0:Genome.FixedList.Functions.double g_asWc
                            (g_asWc, gpart_asYo) = Genome.Split.split gpart_asYn
                            p_asWb = Functions.belowten' g_asWa
                            (g_asWa, gpart_asYn) = Genome.Split.split gpart_asYm
                            p_asW9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW8
                            (g_asW8, gpart_asYm) = Genome.Split.split gpart_asYl
                            p_asW7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW6
                            (g_asW6, gpart_asYl) = Genome.Split.split gpart_asYk
                            p_asW5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW4
                            (g_asW4, gpart_asYk) = Genome.Split.split gpart_asYj
                            p_asW3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW2
                            (g_asW2, gpart_asYj) = Genome.Split.split gpart_asYi
                            p_asW1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW0
                            (g_asW0, gpart_asYi) = Genome.Split.split gpart_asYh
                            p_asVZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVY
                            (g_asVY, gpart_asYh) = Genome.Split.split gpart_asYg
                            p_asVX = code-0.1.0.0:Genome.FixedList.Functions.double g_asVW
                            (g_asVW, gpart_asYg) = Genome.Split.split gpart_asYf
                            p_asVV = code-0.1.0.0:Genome.FixedList.Functions.double g_asVU
                            (g_asVU, gpart_asYf) = Genome.Split.split genome_asX8
                          in
                            \ desc_asX9
                              -> case desc_asX9 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVV)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVX)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVZ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW1)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW3)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW5)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW7)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW9)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWb)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWd)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWf)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWh)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWj)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWl)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWn)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWp)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWr)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWt)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWv)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWx)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWz)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWB)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWD)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWF)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWH)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWJ)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWL)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWN)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWP)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWR)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWT)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWV)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWX)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWZ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX1)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX3)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX5)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX7)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_at0L
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1o
                      p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                      (g_at0J, gpart_at1o) = Genome.Split.split gpart_at1n
                      p_at0I = code-0.1.0.0:Genome.FixedList.Functions.double g_at0H
                      (g_at0H, gpart_at1n) = Genome.Split.split gpart_at1m
                      p_at0G = code-0.1.0.0:Genome.FixedList.Functions.double g_at0F
                      (g_at0F, gpart_at1m) = Genome.Split.split gpart_at1l
                      p_at0E = code-0.1.0.0:Genome.FixedList.Functions.double g_at0D
                      (g_at0D, gpart_at1l) = Genome.Split.split gpart_at1k
                      p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                      (g_at0B, gpart_at1k) = Genome.Split.split gpart_at1j
                      p_at0A = Functions.belowten' g_at0z
                      (g_at0z, gpart_at1j) = Genome.Split.split gpart_at1i
                      p_at0y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0x
                      (g_at0x, gpart_at1i) = Genome.Split.split gpart_at1h
                      p_at0w = code-0.1.0.0:Genome.FixedList.Functions.double g_at0v
                      (g_at0v, gpart_at1h) = Genome.Split.split gpart_at1g
                      p_at0u = code-0.1.0.0:Genome.FixedList.Functions.double g_at0t
                      (g_at0t, gpart_at1g) = Genome.Split.split gpart_at1f
                      p_at0s = Functions.belowten' g_at0r
                      (g_at0r, gpart_at1f) = Genome.Split.split gpart_at1e
                      p_at0q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0p
                      (g_at0p, gpart_at1e) = Genome.Split.split gpart_at1d
                      p_at0o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0n
                      (g_at0n, gpart_at1d) = Genome.Split.split gpart_at1c
                      p_at0m
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0l
                      (g_at0l, gpart_at1c) = Genome.Split.split gpart_at1b
                      p_at0k = Functions.belowten' g_at0j
                      (g_at0j, gpart_at1b) = Genome.Split.split gpart_at1a
                      p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                      (g_at0h, gpart_at1a) = Genome.Split.split gpart_at19
                      p_at0g = code-0.1.0.0:Genome.FixedList.Functions.double g_at0f
                      (g_at0f, gpart_at19) = Genome.Split.split gpart_at18
                      p_at0e = code-0.1.0.0:Genome.FixedList.Functions.double g_at0d
                      (g_at0d, gpart_at18) = Genome.Split.split gpart_at17
                      p_at0c = Functions.belowten' g_at0b
                      (g_at0b, gpart_at17) = Genome.Split.split gpart_at16
                      p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                      (g_at09, gpart_at16) = Genome.Split.split gpart_at15
                      p_at08 = Functions.belowten' g_at07
                      (g_at07, gpart_at15) = Genome.Split.split gpart_at14
                      p_at06 = code-0.1.0.0:Genome.FixedList.Functions.double g_at05
                      (g_at05, gpart_at14) = Genome.Split.split gpart_at13
                      p_at04
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at03
                      (g_at03, gpart_at13) = Genome.Split.split gpart_at12
                      p_at02
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at01
                      (g_at01, gpart_at12) = Genome.Split.split gpart_at11
                      p_at00 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZZ
                      (g_asZZ, gpart_at11) = Genome.Split.split gpart_at10
                      p_asZY = Functions.belowten' g_asZX
                      (g_asZX, gpart_at10) = Genome.Split.split gpart_at0Z
                      p_asZW = code-0.1.0.0:Genome.FixedList.Functions.double g_asZV
                      (g_asZV, gpart_at0Z) = Genome.Split.split gpart_at0Y
                      p_asZU = Functions.belowten' g_asZT
                      (g_asZT, gpart_at0Y) = Genome.Split.split gpart_at0X
                      p_asZS = code-0.1.0.0:Genome.FixedList.Functions.double g_asZR
                      (g_asZR, gpart_at0X) = Genome.Split.split gpart_at0W
                      p_asZQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asZP
                      (g_asZP, gpart_at0W) = Genome.Split.split gpart_at0V
                      p_asZO = Functions.belowten' g_asZN
                      (g_asZN, gpart_at0V) = Genome.Split.split gpart_at0U
                      p_asZM = code-0.1.0.0:Genome.FixedList.Functions.double g_asZL
                      (g_asZL, gpart_at0U) = Genome.Split.split gpart_at0T
                      p_asZK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZJ
                      (g_asZJ, gpart_at0T) = Genome.Split.split gpart_at0S
                      p_asZI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZH
                      (g_asZH, gpart_at0S) = Genome.Split.split gpart_at0R
                      p_asZG = code-0.1.0.0:Genome.FixedList.Functions.double g_asZF
                      (g_asZF, gpart_at0R) = Genome.Split.split gpart_at0Q
                      p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                      (g_asZD, gpart_at0Q) = Genome.Split.split gpart_at0P
                      p_asZC = code-0.1.0.0:Genome.FixedList.Functions.double g_asZB
                      (g_asZB, gpart_at0P) = Genome.Split.split gpart_at0O
                      p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                      (g_asZz, gpart_at0O) = Genome.Split.split gpart_at0N
                      p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                      (g_asZx, gpart_at0N) = Genome.Split.split genome_at0L
                    in
                      [Reaction
                         (\ x_at1p
                            -> let c_MiRs_at1q = ((toVector x_at1p) Data.Vector.Unboxed.! 2)
                               in (p_asZG / (1 + ((c_MiRs_at1q / p_asZM) ** p_asZO))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1r
                            -> let
                                 c_MiRs_at1s = ((toVector x_at1r) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1t = ((toVector x_at1r) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZQ
                                  / (1
                                     + (((c_MiRs_at1s / p_asZS) ** p_asZU)
                                        + ((c_PTB_at1t / p_asZW) ** p_asZY)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at1u
                            -> let
                                 c_RESTc_at1w = ((toVector x_at1u) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at1v = ((toVector x_at1u) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at00
                                  * (p_at0e
                                     / ((1 + p_at0e)
                                        + (((c_NPTB_at1v / p_at06) ** p_at08)
                                           + ((c_RESTc_at1w / p_at0a) ** p_at0c))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at1x
                            -> let
                                 c_MiRs_at1A = ((toVector x_at1x) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1y = ((toVector x_at1x) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0g
                                  * ((p_at0u + ((c_PTB_at1y / p_at0i) ** p_at0k))
                                     / (((1 + p_at0u) + ((c_PTB_at1y / p_at0i) ** p_at0k))
                                        + (((p_asZy / p_at0m) ** p_at0o)
                                           + ((c_MiRs_at1A / p_at0q) ** p_at0s))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at1B
                            -> let c_RESTc_at1C = ((toVector x_at1B) Data.Vector.Unboxed.! 3)
                               in (p_at0w / (1 + ((c_RESTc_at1C / p_at0y) ** p_at0A))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at1D
                            -> let c_PTB_at1E = ((toVector x_at1D) Data.Vector.Unboxed.! 0)
                               in (p_at0C * c_PTB_at1E))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1F
                            -> let c_NPTB_at1G = ((toVector x_at1F) Data.Vector.Unboxed.! 1)
                               in (p_at0E * c_NPTB_at1G))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at1H
                            -> let c_MiRs_at1I = ((toVector x_at1H) Data.Vector.Unboxed.! 2)
                               in (p_at0G * c_MiRs_at1I))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at1J
                            -> let c_RESTc_at1K = ((toVector x_at1J) Data.Vector.Unboxed.! 3)
                               in (p_at0I * c_RESTc_at1K))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at1L
                            -> let
                                 c_EndoNeuroTFs_at1M = ((toVector x_at1L) Data.Vector.Unboxed.! 4)
                               in (p_at0K * c_EndoNeuroTFs_at1M))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121244",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121250",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121252",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121253",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121254",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121257",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121258",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121259",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121260",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121261",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121262",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121263",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121264",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121265",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121266",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121268",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121270",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121272",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121274",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121276",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121284",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121286",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121290",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121292",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121298",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121300",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121302",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at0L
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2o
                            p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                            (g_at0J, gpart_at2o) = Genome.Split.split gpart_at2n
                            p_at0I = code-0.1.0.0:Genome.FixedList.Functions.double g_at0H
                            (g_at0H, gpart_at2n) = Genome.Split.split gpart_at2m
                            p_at0G = code-0.1.0.0:Genome.FixedList.Functions.double g_at0F
                            (g_at0F, gpart_at2m) = Genome.Split.split gpart_at2l
                            p_at0E = code-0.1.0.0:Genome.FixedList.Functions.double g_at0D
                            (g_at0D, gpart_at2l) = Genome.Split.split gpart_at2k
                            p_at0C = code-0.1.0.0:Genome.FixedList.Functions.double g_at0B
                            (g_at0B, gpart_at2k) = Genome.Split.split gpart_at2j
                            p_at0A = Functions.belowten' g_at0z
                            (g_at0z, gpart_at2j) = Genome.Split.split gpart_at2i
                            p_at0y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0x
                            (g_at0x, gpart_at2i) = Genome.Split.split gpart_at2h
                            p_at0w = code-0.1.0.0:Genome.FixedList.Functions.double g_at0v
                            (g_at0v, gpart_at2h) = Genome.Split.split gpart_at2g
                            p_at0u = code-0.1.0.0:Genome.FixedList.Functions.double g_at0t
                            (g_at0t, gpart_at2g) = Genome.Split.split gpart_at2f
                            p_at0s = Functions.belowten' g_at0r
                            (g_at0r, gpart_at2f) = Genome.Split.split gpart_at2e
                            p_at0q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0p
                            (g_at0p, gpart_at2e) = Genome.Split.split gpart_at2d
                            p_at0o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0n
                            (g_at0n, gpart_at2d) = Genome.Split.split gpart_at2c
                            p_at0m
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0l
                            (g_at0l, gpart_at2c) = Genome.Split.split gpart_at2b
                            p_at0k = Functions.belowten' g_at0j
                            (g_at0j, gpart_at2b) = Genome.Split.split gpart_at2a
                            p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                            (g_at0h, gpart_at2a) = Genome.Split.split gpart_at29
                            p_at0g = code-0.1.0.0:Genome.FixedList.Functions.double g_at0f
                            (g_at0f, gpart_at29) = Genome.Split.split gpart_at28
                            p_at0e = code-0.1.0.0:Genome.FixedList.Functions.double g_at0d
                            (g_at0d, gpart_at28) = Genome.Split.split gpart_at27
                            p_at0c = Functions.belowten' g_at0b
                            (g_at0b, gpart_at27) = Genome.Split.split gpart_at26
                            p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                            (g_at09, gpart_at26) = Genome.Split.split gpart_at25
                            p_at08 = Functions.belowten' g_at07
                            (g_at07, gpart_at25) = Genome.Split.split gpart_at24
                            p_at06 = code-0.1.0.0:Genome.FixedList.Functions.double g_at05
                            (g_at05, gpart_at24) = Genome.Split.split gpart_at23
                            p_at04
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at03
                            (g_at03, gpart_at23) = Genome.Split.split gpart_at22
                            p_at02
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at01
                            (g_at01, gpart_at22) = Genome.Split.split gpart_at21
                            p_at00 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZZ
                            (g_asZZ, gpart_at21) = Genome.Split.split gpart_at20
                            p_asZY = Functions.belowten' g_asZX
                            (g_asZX, gpart_at20) = Genome.Split.split gpart_at1Z
                            p_asZW = code-0.1.0.0:Genome.FixedList.Functions.double g_asZV
                            (g_asZV, gpart_at1Z) = Genome.Split.split gpart_at1Y
                            p_asZU = Functions.belowten' g_asZT
                            (g_asZT, gpart_at1Y) = Genome.Split.split gpart_at1X
                            p_asZS = code-0.1.0.0:Genome.FixedList.Functions.double g_asZR
                            (g_asZR, gpart_at1X) = Genome.Split.split gpart_at1W
                            p_asZQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asZP
                            (g_asZP, gpart_at1W) = Genome.Split.split gpart_at1V
                            p_asZO = Functions.belowten' g_asZN
                            (g_asZN, gpart_at1V) = Genome.Split.split gpart_at1U
                            p_asZM = code-0.1.0.0:Genome.FixedList.Functions.double g_asZL
                            (g_asZL, gpart_at1U) = Genome.Split.split gpart_at1T
                            p_asZK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZJ
                            (g_asZJ, gpart_at1T) = Genome.Split.split gpart_at1S
                            p_asZI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZH
                            (g_asZH, gpart_at1S) = Genome.Split.split gpart_at1R
                            p_asZG = code-0.1.0.0:Genome.FixedList.Functions.double g_asZF
                            (g_asZF, gpart_at1R) = Genome.Split.split gpart_at1Q
                            p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                            (g_asZD, gpart_at1Q) = Genome.Split.split gpart_at1P
                            p_asZC = code-0.1.0.0:Genome.FixedList.Functions.double g_asZB
                            (g_asZB, gpart_at1P) = Genome.Split.split gpart_at1O
                            p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                            (g_asZz, gpart_at1O) = Genome.Split.split gpart_at1N
                            p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                            (g_asZx, gpart_at1N) = Genome.Split.split genome_at0L
                          in
                            \ desc_at0M
                              -> case desc_at0M of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZy)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZA)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZC)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZE)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZG)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZI)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZK)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZM)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZO)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZQ)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZS)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZU)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZW)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZY)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at00)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at02)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at04)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at06)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at08)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0a)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0c)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0e)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0g)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0i)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0k)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0m)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0o)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0q)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0s)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0u)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0w)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0y)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0A)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0C)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0E)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0G)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0I)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0K)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at4j
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4W
                      p_at4i = code-0.1.0.0:Genome.FixedList.Functions.double g_at4h
                      (g_at4h, gpart_at4W) = Genome.Split.split gpart_at4V
                      p_at4g = code-0.1.0.0:Genome.FixedList.Functions.double g_at4f
                      (g_at4f, gpart_at4V) = Genome.Split.split gpart_at4U
                      p_at4e = code-0.1.0.0:Genome.FixedList.Functions.double g_at4d
                      (g_at4d, gpart_at4U) = Genome.Split.split gpart_at4T
                      p_at4c = code-0.1.0.0:Genome.FixedList.Functions.double g_at4b
                      (g_at4b, gpart_at4T) = Genome.Split.split gpart_at4S
                      p_at4a = code-0.1.0.0:Genome.FixedList.Functions.double g_at49
                      (g_at49, gpart_at4S) = Genome.Split.split gpart_at4R
                      p_at48 = Functions.belowten' g_at47
                      (g_at47, gpart_at4R) = Genome.Split.split gpart_at4Q
                      p_at46 = code-0.1.0.0:Genome.FixedList.Functions.double g_at45
                      (g_at45, gpart_at4Q) = Genome.Split.split gpart_at4P
                      p_at44 = code-0.1.0.0:Genome.FixedList.Functions.double g_at43
                      (g_at43, gpart_at4P) = Genome.Split.split gpart_at4O
                      p_at42 = code-0.1.0.0:Genome.FixedList.Functions.double g_at41
                      (g_at41, gpart_at4O) = Genome.Split.split gpart_at4N
                      p_at40 = Functions.belowten' g_at3Z
                      (g_at3Z, gpart_at4N) = Genome.Split.split gpart_at4M
                      p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                      (g_at3X, gpart_at4M) = Genome.Split.split gpart_at4L
                      p_at3W
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3V
                      (g_at3V, gpart_at4L) = Genome.Split.split gpart_at4K
                      p_at3U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3T
                      (g_at3T, gpart_at4K) = Genome.Split.split gpart_at4J
                      p_at3S = Functions.belowten' g_at3R
                      (g_at3R, gpart_at4J) = Genome.Split.split gpart_at4I
                      p_at3Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3P
                      (g_at3P, gpart_at4I) = Genome.Split.split gpart_at4H
                      p_at3O = code-0.1.0.0:Genome.FixedList.Functions.double g_at3N
                      (g_at3N, gpart_at4H) = Genome.Split.split gpart_at4G
                      p_at3M = code-0.1.0.0:Genome.FixedList.Functions.double g_at3L
                      (g_at3L, gpart_at4G) = Genome.Split.split gpart_at4F
                      p_at3K = Functions.belowten' g_at3J
                      (g_at3J, gpart_at4F) = Genome.Split.split gpart_at4E
                      p_at3I = code-0.1.0.0:Genome.FixedList.Functions.double g_at3H
                      (g_at3H, gpart_at4E) = Genome.Split.split gpart_at4D
                      p_at3G = Functions.belowten' g_at3F
                      (g_at3F, gpart_at4D) = Genome.Split.split gpart_at4C
                      p_at3E = code-0.1.0.0:Genome.FixedList.Functions.double g_at3D
                      (g_at3D, gpart_at4C) = Genome.Split.split gpart_at4B
                      p_at3C
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3B
                      (g_at3B, gpart_at4B) = Genome.Split.split gpart_at4A
                      p_at3A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3z
                      (g_at3z, gpart_at4A) = Genome.Split.split gpart_at4z
                      p_at3y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3x
                      (g_at3x, gpart_at4z) = Genome.Split.split gpart_at4y
                      p_at3w = Functions.belowten' g_at3v
                      (g_at3v, gpart_at4y) = Genome.Split.split gpart_at4x
                      p_at3u = code-0.1.0.0:Genome.FixedList.Functions.double g_at3t
                      (g_at3t, gpart_at4x) = Genome.Split.split gpart_at4w
                      p_at3s = Functions.belowten' g_at3r
                      (g_at3r, gpart_at4w) = Genome.Split.split gpart_at4v
                      p_at3q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3p
                      (g_at3p, gpart_at4v) = Genome.Split.split gpart_at4u
                      p_at3o = code-0.1.0.0:Genome.FixedList.Functions.double g_at3n
                      (g_at3n, gpart_at4u) = Genome.Split.split gpart_at4t
                      p_at3m = Functions.belowten' g_at3l
                      (g_at3l, gpart_at4t) = Genome.Split.split gpart_at4s
                      p_at3k = code-0.1.0.0:Genome.FixedList.Functions.double g_at3j
                      (g_at3j, gpart_at4s) = Genome.Split.split gpart_at4r
                      p_at3i
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3h
                      (g_at3h, gpart_at4r) = Genome.Split.split gpart_at4q
                      p_at3g
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3f
                      (g_at3f, gpart_at4q) = Genome.Split.split gpart_at4p
                      p_at3e = code-0.1.0.0:Genome.FixedList.Functions.double g_at3d
                      (g_at3d, gpart_at4p) = Genome.Split.split gpart_at4o
                      p_at3c = code-0.1.0.0:Genome.FixedList.Functions.double g_at3b
                      (g_at3b, gpart_at4o) = Genome.Split.split gpart_at4n
                      p_at3a = code-0.1.0.0:Genome.FixedList.Functions.double g_at39
                      (g_at39, gpart_at4n) = Genome.Split.split gpart_at4m
                      p_at38 = code-0.1.0.0:Genome.FixedList.Functions.double g_at37
                      (g_at37, gpart_at4m) = Genome.Split.split gpart_at4l
                      p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                      (g_at35, gpart_at4l) = Genome.Split.split genome_at4j
                    in
                      [Reaction
                         (\ x_at4X
                            -> let c_MiRs_at4Y = ((toVector x_at4X) Data.Vector.Unboxed.! 2)
                               in (p_at3e / (1 + ((c_MiRs_at4Y / p_at3k) ** p_at3m))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4Z
                            -> let
                                 c_MiRs_at50 = ((toVector x_at4Z) Data.Vector.Unboxed.! 2)
                                 c_PTB_at51 = ((toVector x_at4Z) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3o
                                  / (1
                                     + (((c_MiRs_at50 / p_at3q) ** p_at3s)
                                        + ((c_PTB_at51 / p_at3u) ** p_at3w)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at52
                            -> let
                                 c_RESTc_at54 = ((toVector x_at52) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at53 = ((toVector x_at52) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at3y
                                  * (p_at3M
                                     / ((1 + p_at3M)
                                        + (((c_NPTB_at53 / p_at3E) ** p_at3G)
                                           + ((c_RESTc_at54 / p_at3I) ** p_at3K))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at55
                            -> let
                                 c_MiRs_at58 = ((toVector x_at55) Data.Vector.Unboxed.! 2)
                                 c_PTB_at56 = ((toVector x_at55) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3O
                                  * ((p_at42 + ((c_PTB_at56 / p_at3Q) ** p_at3S))
                                     / (((1 + p_at42) + ((c_PTB_at56 / p_at3Q) ** p_at3S))
                                        + ((c_MiRs_at58 / p_at3Y) ** p_at40)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at59
                            -> let c_RESTc_at5a = ((toVector x_at59) Data.Vector.Unboxed.! 3)
                               in (p_at44 / (1 + ((c_RESTc_at5a / p_at46) ** p_at48))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at5b
                            -> let c_PTB_at5c = ((toVector x_at5b) Data.Vector.Unboxed.! 0)
                               in (p_at4a * c_PTB_at5c))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5d
                            -> let c_NPTB_at5e = ((toVector x_at5d) Data.Vector.Unboxed.! 1)
                               in (p_at4c * c_NPTB_at5e))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at5f
                            -> let c_MiRs_at5g = ((toVector x_at5f) Data.Vector.Unboxed.! 2)
                               in (p_at4e * c_MiRs_at5g))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at5h
                            -> let c_RESTc_at5i = ((toVector x_at5h) Data.Vector.Unboxed.! 3)
                               in (p_at4g * c_RESTc_at5i))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at5j
                            -> let
                                 c_EndoNeuroTFs_at5k = ((toVector x_at5j) Data.Vector.Unboxed.! 4)
                               in (p_at4i * c_EndoNeuroTFs_at5k))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121470",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121472",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121490",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121492",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121510",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121512",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121518",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121520",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121524",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121526",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121528",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121530",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121532",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at4j
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5W
                            p_at4i = code-0.1.0.0:Genome.FixedList.Functions.double g_at4h
                            (g_at4h, gpart_at5W) = Genome.Split.split gpart_at5V
                            p_at4g = code-0.1.0.0:Genome.FixedList.Functions.double g_at4f
                            (g_at4f, gpart_at5V) = Genome.Split.split gpart_at5U
                            p_at4e = code-0.1.0.0:Genome.FixedList.Functions.double g_at4d
                            (g_at4d, gpart_at5U) = Genome.Split.split gpart_at5T
                            p_at4c = code-0.1.0.0:Genome.FixedList.Functions.double g_at4b
                            (g_at4b, gpart_at5T) = Genome.Split.split gpart_at5S
                            p_at4a = code-0.1.0.0:Genome.FixedList.Functions.double g_at49
                            (g_at49, gpart_at5S) = Genome.Split.split gpart_at5R
                            p_at48 = Functions.belowten' g_at47
                            (g_at47, gpart_at5R) = Genome.Split.split gpart_at5Q
                            p_at46 = code-0.1.0.0:Genome.FixedList.Functions.double g_at45
                            (g_at45, gpart_at5Q) = Genome.Split.split gpart_at5P
                            p_at44 = code-0.1.0.0:Genome.FixedList.Functions.double g_at43
                            (g_at43, gpart_at5P) = Genome.Split.split gpart_at5O
                            p_at42 = code-0.1.0.0:Genome.FixedList.Functions.double g_at41
                            (g_at41, gpart_at5O) = Genome.Split.split gpart_at5N
                            p_at40 = Functions.belowten' g_at3Z
                            (g_at3Z, gpart_at5N) = Genome.Split.split gpart_at5M
                            p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                            (g_at3X, gpart_at5M) = Genome.Split.split gpart_at5L
                            p_at3W
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3V
                            (g_at3V, gpart_at5L) = Genome.Split.split gpart_at5K
                            p_at3U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3T
                            (g_at3T, gpart_at5K) = Genome.Split.split gpart_at5J
                            p_at3S = Functions.belowten' g_at3R
                            (g_at3R, gpart_at5J) = Genome.Split.split gpart_at5I
                            p_at3Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3P
                            (g_at3P, gpart_at5I) = Genome.Split.split gpart_at5H
                            p_at3O = code-0.1.0.0:Genome.FixedList.Functions.double g_at3N
                            (g_at3N, gpart_at5H) = Genome.Split.split gpart_at5G
                            p_at3M = code-0.1.0.0:Genome.FixedList.Functions.double g_at3L
                            (g_at3L, gpart_at5G) = Genome.Split.split gpart_at5F
                            p_at3K = Functions.belowten' g_at3J
                            (g_at3J, gpart_at5F) = Genome.Split.split gpart_at5E
                            p_at3I = code-0.1.0.0:Genome.FixedList.Functions.double g_at3H
                            (g_at3H, gpart_at5E) = Genome.Split.split gpart_at5D
                            p_at3G = Functions.belowten' g_at3F
                            (g_at3F, gpart_at5D) = Genome.Split.split gpart_at5C
                            p_at3E = code-0.1.0.0:Genome.FixedList.Functions.double g_at3D
                            (g_at3D, gpart_at5C) = Genome.Split.split gpart_at5B
                            p_at3C
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3B
                            (g_at3B, gpart_at5B) = Genome.Split.split gpart_at5A
                            p_at3A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3z
                            (g_at3z, gpart_at5A) = Genome.Split.split gpart_at5z
                            p_at3y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3x
                            (g_at3x, gpart_at5z) = Genome.Split.split gpart_at5y
                            p_at3w = Functions.belowten' g_at3v
                            (g_at3v, gpart_at5y) = Genome.Split.split gpart_at5x
                            p_at3u = code-0.1.0.0:Genome.FixedList.Functions.double g_at3t
                            (g_at3t, gpart_at5x) = Genome.Split.split gpart_at5w
                            p_at3s = Functions.belowten' g_at3r
                            (g_at3r, gpart_at5w) = Genome.Split.split gpart_at5v
                            p_at3q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3p
                            (g_at3p, gpart_at5v) = Genome.Split.split gpart_at5u
                            p_at3o = code-0.1.0.0:Genome.FixedList.Functions.double g_at3n
                            (g_at3n, gpart_at5u) = Genome.Split.split gpart_at5t
                            p_at3m = Functions.belowten' g_at3l
                            (g_at3l, gpart_at5t) = Genome.Split.split gpart_at5s
                            p_at3k = code-0.1.0.0:Genome.FixedList.Functions.double g_at3j
                            (g_at3j, gpart_at5s) = Genome.Split.split gpart_at5r
                            p_at3i
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3h
                            (g_at3h, gpart_at5r) = Genome.Split.split gpart_at5q
                            p_at3g
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3f
                            (g_at3f, gpart_at5q) = Genome.Split.split gpart_at5p
                            p_at3e = code-0.1.0.0:Genome.FixedList.Functions.double g_at3d
                            (g_at3d, gpart_at5p) = Genome.Split.split gpart_at5o
                            p_at3c = code-0.1.0.0:Genome.FixedList.Functions.double g_at3b
                            (g_at3b, gpart_at5o) = Genome.Split.split gpart_at5n
                            p_at3a = code-0.1.0.0:Genome.FixedList.Functions.double g_at39
                            (g_at39, gpart_at5n) = Genome.Split.split gpart_at5m
                            p_at38 = code-0.1.0.0:Genome.FixedList.Functions.double g_at37
                            (g_at37, gpart_at5m) = Genome.Split.split gpart_at5l
                            p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                            (g_at35, gpart_at5l) = Genome.Split.split genome_at4j
                          in
                            \ desc_at4k
                              -> case desc_at4k of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at36)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at38)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3a)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3c)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3e)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3g)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3i)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3k)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3m)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3o)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3q)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3s)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3u)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3w)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3y)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3A)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3C)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3E)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3G)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3I)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3K)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3M)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3O)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Q)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3S)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3U)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3W)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Y)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at40)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at42)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at44)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at46)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at48)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4a)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4c)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4e)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4g)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4i)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at7R
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8u
                      p_at7Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7P
                      (g_at7P, gpart_at8u) = Genome.Split.split gpart_at8t
                      p_at7O = code-0.1.0.0:Genome.FixedList.Functions.double g_at7N
                      (g_at7N, gpart_at8t) = Genome.Split.split gpart_at8s
                      p_at7M = code-0.1.0.0:Genome.FixedList.Functions.double g_at7L
                      (g_at7L, gpart_at8s) = Genome.Split.split gpart_at8r
                      p_at7K = code-0.1.0.0:Genome.FixedList.Functions.double g_at7J
                      (g_at7J, gpart_at8r) = Genome.Split.split gpart_at8q
                      p_at7I = code-0.1.0.0:Genome.FixedList.Functions.double g_at7H
                      (g_at7H, gpart_at8q) = Genome.Split.split gpart_at8p
                      p_at7G = Functions.belowten' g_at7F
                      (g_at7F, gpart_at8p) = Genome.Split.split gpart_at8o
                      p_at7E = code-0.1.0.0:Genome.FixedList.Functions.double g_at7D
                      (g_at7D, gpart_at8o) = Genome.Split.split gpart_at8n
                      p_at7C = code-0.1.0.0:Genome.FixedList.Functions.double g_at7B
                      (g_at7B, gpart_at8n) = Genome.Split.split gpart_at8m
                      p_at7A = code-0.1.0.0:Genome.FixedList.Functions.double g_at7z
                      (g_at7z, gpart_at8m) = Genome.Split.split gpart_at8l
                      p_at7y = Functions.belowten' g_at7x
                      (g_at7x, gpart_at8l) = Genome.Split.split gpart_at8k
                      p_at7w = code-0.1.0.0:Genome.FixedList.Functions.double g_at7v
                      (g_at7v, gpart_at8k) = Genome.Split.split gpart_at8j
                      p_at7u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7t
                      (g_at7t, gpart_at8j) = Genome.Split.split gpart_at8i
                      p_at7s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7r
                      (g_at7r, gpart_at8i) = Genome.Split.split gpart_at8h
                      p_at7q = Functions.belowten' g_at7p
                      (g_at7p, gpart_at8h) = Genome.Split.split gpart_at8g
                      p_at7o = code-0.1.0.0:Genome.FixedList.Functions.double g_at7n
                      (g_at7n, gpart_at8g) = Genome.Split.split gpart_at8f
                      p_at7m = code-0.1.0.0:Genome.FixedList.Functions.double g_at7l
                      (g_at7l, gpart_at8f) = Genome.Split.split gpart_at8e
                      p_at7k = code-0.1.0.0:Genome.FixedList.Functions.double g_at7j
                      (g_at7j, gpart_at8e) = Genome.Split.split gpart_at8d
                      p_at7i = Functions.belowten' g_at7h
                      (g_at7h, gpart_at8d) = Genome.Split.split gpart_at8c
                      p_at7g = code-0.1.0.0:Genome.FixedList.Functions.double g_at7f
                      (g_at7f, gpart_at8c) = Genome.Split.split gpart_at8b
                      p_at7e = Functions.belowten' g_at7d
                      (g_at7d, gpart_at8b) = Genome.Split.split gpart_at8a
                      p_at7c = code-0.1.0.0:Genome.FixedList.Functions.double g_at7b
                      (g_at7b, gpart_at8a) = Genome.Split.split gpart_at89
                      p_at7a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at79
                      (g_at79, gpart_at89) = Genome.Split.split gpart_at88
                      p_at78
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at77
                      (g_at77, gpart_at88) = Genome.Split.split gpart_at87
                      p_at76 = code-0.1.0.0:Genome.FixedList.Functions.double g_at75
                      (g_at75, gpart_at87) = Genome.Split.split gpart_at86
                      p_at74 = Functions.belowten' g_at73
                      (g_at73, gpart_at86) = Genome.Split.split gpart_at85
                      p_at72 = code-0.1.0.0:Genome.FixedList.Functions.double g_at71
                      (g_at71, gpart_at85) = Genome.Split.split gpart_at84
                      p_at70 = Functions.belowten' g_at6Z
                      (g_at6Z, gpart_at84) = Genome.Split.split gpart_at83
                      p_at6Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6X
                      (g_at6X, gpart_at83) = Genome.Split.split gpart_at82
                      p_at6W = code-0.1.0.0:Genome.FixedList.Functions.double g_at6V
                      (g_at6V, gpart_at82) = Genome.Split.split gpart_at81
                      p_at6U = Functions.belowten' g_at6T
                      (g_at6T, gpart_at81) = Genome.Split.split gpart_at80
                      p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                      (g_at6R, gpart_at80) = Genome.Split.split gpart_at7Z
                      p_at6Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6P
                      (g_at6P, gpart_at7Z) = Genome.Split.split gpart_at7Y
                      p_at6O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6N
                      (g_at6N, gpart_at7Y) = Genome.Split.split gpart_at7X
                      p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                      (g_at6L, gpart_at7X) = Genome.Split.split gpart_at7W
                      p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                      (g_at6J, gpart_at7W) = Genome.Split.split gpart_at7V
                      p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                      (g_at6H, gpart_at7V) = Genome.Split.split gpart_at7U
                      p_at6G = code-0.1.0.0:Genome.FixedList.Functions.double g_at6F
                      (g_at6F, gpart_at7U) = Genome.Split.split gpart_at7T
                      p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                      (g_at6D, gpart_at7T) = Genome.Split.split genome_at7R
                    in
                      [Reaction
                         (\ x_at8v
                            -> let c_MiRs_at8w = ((toVector x_at8v) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6M
                                  / (1
                                     + (((p_at6E / p_at6O) ** p_at6Q)
                                        + ((c_MiRs_at8w / p_at6S) ** p_at6U)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at8x
                            -> let
                                 c_MiRs_at8y = ((toVector x_at8x) Data.Vector.Unboxed.! 2)
                                 c_PTB_at8z = ((toVector x_at8x) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6W
                                  / (1
                                     + (((c_MiRs_at8y / p_at6Y) ** p_at70)
                                        + ((c_PTB_at8z / p_at72) ** p_at74)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at8A
                            -> let
                                 c_RESTc_at8C = ((toVector x_at8A) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at8B = ((toVector x_at8A) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at76
                                  * (p_at7k
                                     / ((1 + p_at7k)
                                        + (((c_NPTB_at8B / p_at7c) ** p_at7e)
                                           + ((c_RESTc_at8C / p_at7g) ** p_at7i))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at8D
                            -> let
                                 c_MiRs_at8G = ((toVector x_at8D) Data.Vector.Unboxed.! 2)
                                 c_PTB_at8E = ((toVector x_at8D) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at7m
                                  * ((p_at7A + ((c_PTB_at8E / p_at7o) ** p_at7q))
                                     / (((1 + p_at7A) + ((c_PTB_at8E / p_at7o) ** p_at7q))
                                        + ((c_MiRs_at8G / p_at7w) ** p_at7y)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at8H
                            -> let c_RESTc_at8I = ((toVector x_at8H) Data.Vector.Unboxed.! 3)
                               in (p_at7C / (1 + ((c_RESTc_at8I / p_at7E) ** p_at7G))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at8J
                            -> let c_PTB_at8K = ((toVector x_at8J) Data.Vector.Unboxed.! 0)
                               in (p_at7I * c_PTB_at8K))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at8L
                            -> let c_NPTB_at8M = ((toVector x_at8L) Data.Vector.Unboxed.! 1)
                               in (p_at7K * c_NPTB_at8M))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at8N
                            -> let c_MiRs_at8O = ((toVector x_at8N) Data.Vector.Unboxed.! 2)
                               in (p_at7M * c_MiRs_at8O))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at8P
                            -> let c_RESTc_at8Q = ((toVector x_at8P) Data.Vector.Unboxed.! 3)
                               in (p_at7O * c_RESTc_at8Q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at8R
                            -> let
                                 c_EndoNeuroTFs_at8S = ((toVector x_at8R) Data.Vector.Unboxed.! 4)
                               in (p_at7Q * c_EndoNeuroTFs_at8S))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121684",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121690",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121692",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121696",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121698",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121700",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121702",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121704",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121705",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121706",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121707",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121708",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121710",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121712",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121714",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121716",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121718",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121720",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121722",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121724",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121726",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121728",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121730",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121732",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at7R
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at9u
                            p_at7Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7P
                            (g_at7P, gpart_at9u) = Genome.Split.split gpart_at9t
                            p_at7O = code-0.1.0.0:Genome.FixedList.Functions.double g_at7N
                            (g_at7N, gpart_at9t) = Genome.Split.split gpart_at9s
                            p_at7M = code-0.1.0.0:Genome.FixedList.Functions.double g_at7L
                            (g_at7L, gpart_at9s) = Genome.Split.split gpart_at9r
                            p_at7K = code-0.1.0.0:Genome.FixedList.Functions.double g_at7J
                            (g_at7J, gpart_at9r) = Genome.Split.split gpart_at9q
                            p_at7I = code-0.1.0.0:Genome.FixedList.Functions.double g_at7H
                            (g_at7H, gpart_at9q) = Genome.Split.split gpart_at9p
                            p_at7G = Functions.belowten' g_at7F
                            (g_at7F, gpart_at9p) = Genome.Split.split gpart_at9o
                            p_at7E = code-0.1.0.0:Genome.FixedList.Functions.double g_at7D
                            (g_at7D, gpart_at9o) = Genome.Split.split gpart_at9n
                            p_at7C = code-0.1.0.0:Genome.FixedList.Functions.double g_at7B
                            (g_at7B, gpart_at9n) = Genome.Split.split gpart_at9m
                            p_at7A = code-0.1.0.0:Genome.FixedList.Functions.double g_at7z
                            (g_at7z, gpart_at9m) = Genome.Split.split gpart_at9l
                            p_at7y = Functions.belowten' g_at7x
                            (g_at7x, gpart_at9l) = Genome.Split.split gpart_at9k
                            p_at7w = code-0.1.0.0:Genome.FixedList.Functions.double g_at7v
                            (g_at7v, gpart_at9k) = Genome.Split.split gpart_at9j
                            p_at7u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7t
                            (g_at7t, gpart_at9j) = Genome.Split.split gpart_at9i
                            p_at7s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7r
                            (g_at7r, gpart_at9i) = Genome.Split.split gpart_at9h
                            p_at7q = Functions.belowten' g_at7p
                            (g_at7p, gpart_at9h) = Genome.Split.split gpart_at9g
                            p_at7o = code-0.1.0.0:Genome.FixedList.Functions.double g_at7n
                            (g_at7n, gpart_at9g) = Genome.Split.split gpart_at9f
                            p_at7m = code-0.1.0.0:Genome.FixedList.Functions.double g_at7l
                            (g_at7l, gpart_at9f) = Genome.Split.split gpart_at9e
                            p_at7k = code-0.1.0.0:Genome.FixedList.Functions.double g_at7j
                            (g_at7j, gpart_at9e) = Genome.Split.split gpart_at9d
                            p_at7i = Functions.belowten' g_at7h
                            (g_at7h, gpart_at9d) = Genome.Split.split gpart_at9c
                            p_at7g = code-0.1.0.0:Genome.FixedList.Functions.double g_at7f
                            (g_at7f, gpart_at9c) = Genome.Split.split gpart_at9b
                            p_at7e = Functions.belowten' g_at7d
                            (g_at7d, gpart_at9b) = Genome.Split.split gpart_at9a
                            p_at7c = code-0.1.0.0:Genome.FixedList.Functions.double g_at7b
                            (g_at7b, gpart_at9a) = Genome.Split.split gpart_at99
                            p_at7a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at79
                            (g_at79, gpart_at99) = Genome.Split.split gpart_at98
                            p_at78
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at77
                            (g_at77, gpart_at98) = Genome.Split.split gpart_at97
                            p_at76 = code-0.1.0.0:Genome.FixedList.Functions.double g_at75
                            (g_at75, gpart_at97) = Genome.Split.split gpart_at96
                            p_at74 = Functions.belowten' g_at73
                            (g_at73, gpart_at96) = Genome.Split.split gpart_at95
                            p_at72 = code-0.1.0.0:Genome.FixedList.Functions.double g_at71
                            (g_at71, gpart_at95) = Genome.Split.split gpart_at94
                            p_at70 = Functions.belowten' g_at6Z
                            (g_at6Z, gpart_at94) = Genome.Split.split gpart_at93
                            p_at6Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6X
                            (g_at6X, gpart_at93) = Genome.Split.split gpart_at92
                            p_at6W = code-0.1.0.0:Genome.FixedList.Functions.double g_at6V
                            (g_at6V, gpart_at92) = Genome.Split.split gpart_at91
                            p_at6U = Functions.belowten' g_at6T
                            (g_at6T, gpart_at91) = Genome.Split.split gpart_at90
                            p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                            (g_at6R, gpart_at90) = Genome.Split.split gpart_at8Z
                            p_at6Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6P
                            (g_at6P, gpart_at8Z) = Genome.Split.split gpart_at8Y
                            p_at6O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6N
                            (g_at6N, gpart_at8Y) = Genome.Split.split gpart_at8X
                            p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                            (g_at6L, gpart_at8X) = Genome.Split.split gpart_at8W
                            p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                            (g_at6J, gpart_at8W) = Genome.Split.split gpart_at8V
                            p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                            (g_at6H, gpart_at8V) = Genome.Split.split gpart_at8U
                            p_at6G = code-0.1.0.0:Genome.FixedList.Functions.double g_at6F
                            (g_at6F, gpart_at8U) = Genome.Split.split gpart_at8T
                            p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                            (g_at6D, gpart_at8T) = Genome.Split.split genome_at7R
                          in
                            \ desc_at7S
                              -> case desc_at7S of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6E)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6G)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6I)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6K)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6M)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6O)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Q)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6S)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6U)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at70)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at72)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at74)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at76)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at78)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7a)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7c)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7e)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7g)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7i)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7k)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7m)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7o)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7q)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7s)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7u)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7w)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7y)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7A)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7C)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7E)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7G)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7I)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7K)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7M)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7O)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7Q)
                                   _ -> Nothing }}
