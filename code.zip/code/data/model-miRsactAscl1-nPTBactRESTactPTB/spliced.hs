src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a2asi
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2at1
                      p_a2ash = double g_a2asg
                      (g_a2asg, gpart_a2at1) = Genome.Split.split gpart_a2at0
                      p_a2asf = double g_a2ase
                      (g_a2ase, gpart_a2at0) = Genome.Split.split gpart_a2asZ
                      p_a2asd = double g_a2asc
                      (g_a2asc, gpart_a2asZ) = Genome.Split.split gpart_a2asY
                      p_a2asb = double g_a2asa
                      (g_a2asa, gpart_a2asY) = Genome.Split.split gpart_a2asX
                      p_a2as9 = double g_a2as8
                      (g_a2as8, gpart_a2asX) = Genome.Split.split gpart_a2asW
                      p_a2as7 = double g_a2as6
                      (g_a2as6, gpart_a2asW) = Genome.Split.split gpart_a2asV
                      p_a2as5 = Functions.belowten' g_a2as4
                      (g_a2as4, gpart_a2asV) = Genome.Split.split gpart_a2asU
                      p_a2as3 = double g_a2as2
                      (g_a2as2, gpart_a2asU) = Genome.Split.split gpart_a2asT
                      p_a2as1 = Functions.belowten' g_a2as0
                      (g_a2as0, gpart_a2asT) = Genome.Split.split gpart_a2asS
                      p_a2arZ = double g_a2arY
                      (g_a2arY, gpart_a2asS) = Genome.Split.split gpart_a2asR
                      p_a2arX = double g_a2arW
                      (g_a2arW, gpart_a2asR) = Genome.Split.split gpart_a2asQ
                      p_a2arV = double g_a2arU
                      (g_a2arU, gpart_a2asQ) = Genome.Split.split gpart_a2asP
                      p_a2arT = Functions.belowten' g_a2arS
                      (g_a2arS, gpart_a2asP) = Genome.Split.split gpart_a2asO
                      p_a2arR = double g_a2arQ
                      (g_a2arQ, gpart_a2asO) = Genome.Split.split gpart_a2asN
                      p_a2arP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2arO
                      (g_a2arO, gpart_a2asN) = Genome.Split.split gpart_a2asM
                      p_a2arN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2arM
                      (g_a2arM, gpart_a2asM) = Genome.Split.split gpart_a2asL
                      p_a2arL = Functions.belowten' g_a2arK
                      (g_a2arK, gpart_a2asL) = Genome.Split.split gpart_a2asK
                      p_a2arJ = double g_a2arI
                      (g_a2arI, gpart_a2asK) = Genome.Split.split gpart_a2asJ
                      p_a2arH = Functions.belowten' g_a2arG
                      (g_a2arG, gpart_a2asJ) = Genome.Split.split gpart_a2asI
                      p_a2arF = double g_a2arE
                      (g_a2arE, gpart_a2asI) = Genome.Split.split gpart_a2asH
                      p_a2arD = double g_a2arC
                      (g_a2arC, gpart_a2asH) = Genome.Split.split gpart_a2asG
                      p_a2arB = double g_a2arA
                      (g_a2arA, gpart_a2asG) = Genome.Split.split gpart_a2asF
                      p_a2arz = Functions.belowten' g_a2ary
                      (g_a2ary, gpart_a2asF) = Genome.Split.split gpart_a2asE
                      p_a2arx = double g_a2arw
                      (g_a2arw, gpart_a2asE) = Genome.Split.split gpart_a2asD
                      p_a2arv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aru
                      (g_a2aru, gpart_a2asD) = Genome.Split.split gpart_a2asC
                      p_a2art
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ars
                      (g_a2ars, gpart_a2asC) = Genome.Split.split gpart_a2asB
                      p_a2arr = double g_a2arq
                      (g_a2arq, gpart_a2asB) = Genome.Split.split gpart_a2asA
                      p_a2arp = Functions.belowten' g_a2aro
                      (g_a2aro, gpart_a2asA) = Genome.Split.split gpart_a2asz
                      p_a2arn = double g_a2arm
                      (g_a2arm, gpart_a2asz) = Genome.Split.split gpart_a2asy
                      p_a2arl = Functions.belowten' g_a2ark
                      (g_a2ark, gpart_a2asy) = Genome.Split.split gpart_a2asx
                      p_a2arj = double g_a2ari
                      (g_a2ari, gpart_a2asx) = Genome.Split.split gpart_a2asw
                      p_a2arh = double g_a2arg
                      (g_a2arg, gpart_a2asw) = Genome.Split.split gpart_a2asv
                      p_a2arf = double g_a2are
                      (g_a2are, gpart_a2asv) = Genome.Split.split gpart_a2asu
                      p_a2ard = Functions.belowten' g_a2arc
                      (g_a2arc, gpart_a2asu) = Genome.Split.split gpart_a2ast
                      p_a2arb = double g_a2ara
                      (g_a2ara, gpart_a2ast) = Genome.Split.split gpart_a2ass
                      p_a2ar9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ar8
                      (g_a2ar8, gpart_a2ass) = Genome.Split.split gpart_a2asr
                      p_a2ar7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ar6
                      (g_a2ar6, gpart_a2asr) = Genome.Split.split gpart_a2asq
                      p_a2ar5 = Functions.belowten' g_a2ar4
                      (g_a2ar4, gpart_a2asq) = Genome.Split.split gpart_a2asp
                      p_a2ar3 = double g_a2ar2
                      (g_a2ar2, gpart_a2asp) = Genome.Split.split gpart_a2aso
                      p_a2ar1 = double g_a2ar0
                      (g_a2ar0, gpart_a2aso) = Genome.Split.split gpart_a2asn
                      p_a2aqZ = double g_a2aqY
                      (g_a2aqY, gpart_a2asn) = Genome.Split.split gpart_a2asm
                      p_a2aqX = double g_a2aqW
                      (g_a2aqW, gpart_a2asm) = Genome.Split.split gpart_a2asl
                      p_a2aqV = double g_a2aqU
                      (g_a2aqU, gpart_a2asl) = Genome.Split.split gpart_a2ask
                      p_a2aqT = double g_a2aqS
                      (g_a2aqS, gpart_a2ask) = Genome.Split.split genome_a2asi
                    in  \ x_a2at2
                          -> let
                               c_PTB_a2at7
                                 = ((Data.Fixed.Vector.toVector x_a2at2) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2at5
                                 = ((Data.Fixed.Vector.toVector x_a2at2) Data.Vector.Unboxed.! 2)
                               c_RESTc_a2at3
                                 = ((Data.Fixed.Vector.toVector x_a2at2) Data.Vector.Unboxed.! 3)
                               c_NPTB_a2atb
                                 = ((Data.Fixed.Vector.toVector x_a2at2) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a2atq
                                 = ((Data.Fixed.Vector.toVector x_a2at2) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2ar1
                                     * ((p_a2arf + ((c_RESTc_a2at3 / p_a2ar3) ** p_a2ar5))
                                        / (((1 + p_a2arf) + ((c_RESTc_a2at3 / p_a2ar3) ** p_a2ar5))
                                           + ((c_MiRs_a2at5 / p_a2arb) ** p_a2ard))))
                                    + (negate (p_a2as9 * c_PTB_a2at7))),
                                   ((p_a2arh
                                     / (1
                                        + (((c_MiRs_a2at5 / p_a2arj) ** p_a2arl)
                                           + ((c_PTB_a2at7 / p_a2arn) ** p_a2arp))))
                                    + (negate (p_a2asb * c_NPTB_a2atb))),
                                   ((p_a2arr
                                     * ((p_a2arB + ((p_a2aqX / p_a2art) ** p_a2arv))
                                        / (((1 + p_a2arB) + ((p_a2aqX / p_a2art) ** p_a2arv))
                                           + ((c_RESTc_a2at3 / p_a2arx) ** p_a2arz))))
                                    + (negate (p_a2asd * c_MiRs_a2at5))),
                                   ((p_a2arD
                                     * ((p_a2arV
                                         + (((c_NPTB_a2atb / p_a2arF) ** p_a2arH)
                                            + ((c_PTB_a2at7 / p_a2arJ) ** p_a2arL)))
                                        / (((1 + p_a2arV)
                                            + (((c_NPTB_a2atb / p_a2arF) ** p_a2arH)
                                               + ((c_PTB_a2at7 / p_a2arJ) ** p_a2arL)))
                                           + (((p_a2aqT / p_a2arN) ** p_a2arP)
                                              + ((c_MiRs_a2at5 / p_a2arR) ** p_a2arT)))))
                                    + (negate (p_a2asf * c_RESTc_a2at3))),
                                   ((p_a2arX
                                     * ((p_a2as7 + ((c_MiRs_a2at5 / p_a2arZ) ** p_a2as1))
                                        / (((1 + p_a2as7) + ((c_MiRs_a2at5 / p_a2arZ) ** p_a2as1))
                                           + ((c_RESTc_a2at3 / p_a2as3) ** p_a2as5))))
                                    + (negate (p_a2ash * c_EndoNeuroTFs_a2atq)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526569",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526571",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526581",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526583",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526591",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526593",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526599",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526611",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526613",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2asi
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2au8
                            p_a2ash = double g_a2asg
                            (g_a2asg, gpart_a2au8) = Genome.Split.split gpart_a2au7
                            p_a2asf = double g_a2ase
                            (g_a2ase, gpart_a2au7) = Genome.Split.split gpart_a2au6
                            p_a2asd = double g_a2asc
                            (g_a2asc, gpart_a2au6) = Genome.Split.split gpart_a2au5
                            p_a2asb = double g_a2asa
                            (g_a2asa, gpart_a2au5) = Genome.Split.split gpart_a2au4
                            p_a2as9 = double g_a2as8
                            (g_a2as8, gpart_a2au4) = Genome.Split.split gpart_a2au3
                            p_a2as7 = double g_a2as6
                            (g_a2as6, gpart_a2au3) = Genome.Split.split gpart_a2au2
                            p_a2as5 = Functions.belowten' g_a2as4
                            (g_a2as4, gpart_a2au2) = Genome.Split.split gpart_a2au1
                            p_a2as3 = double g_a2as2
                            (g_a2as2, gpart_a2au1) = Genome.Split.split gpart_a2au0
                            p_a2as1 = Functions.belowten' g_a2as0
                            (g_a2as0, gpart_a2au0) = Genome.Split.split gpart_a2atZ
                            p_a2arZ = double g_a2arY
                            (g_a2arY, gpart_a2atZ) = Genome.Split.split gpart_a2atY
                            p_a2arX = double g_a2arW
                            (g_a2arW, gpart_a2atY) = Genome.Split.split gpart_a2atX
                            p_a2arV = double g_a2arU
                            (g_a2arU, gpart_a2atX) = Genome.Split.split gpart_a2atW
                            p_a2arT = Functions.belowten' g_a2arS
                            (g_a2arS, gpart_a2atW) = Genome.Split.split gpart_a2atV
                            p_a2arR = double g_a2arQ
                            (g_a2arQ, gpart_a2atV) = Genome.Split.split gpart_a2atU
                            p_a2arP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2arO
                            (g_a2arO, gpart_a2atU) = Genome.Split.split gpart_a2atT
                            p_a2arN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2arM
                            (g_a2arM, gpart_a2atT) = Genome.Split.split gpart_a2atS
                            p_a2arL = Functions.belowten' g_a2arK
                            (g_a2arK, gpart_a2atS) = Genome.Split.split gpart_a2atR
                            p_a2arJ = double g_a2arI
                            (g_a2arI, gpart_a2atR) = Genome.Split.split gpart_a2atQ
                            p_a2arH = Functions.belowten' g_a2arG
                            (g_a2arG, gpart_a2atQ) = Genome.Split.split gpart_a2atP
                            p_a2arF = double g_a2arE
                            (g_a2arE, gpart_a2atP) = Genome.Split.split gpart_a2atO
                            p_a2arD = double g_a2arC
                            (g_a2arC, gpart_a2atO) = Genome.Split.split gpart_a2atN
                            p_a2arB = double g_a2arA
                            (g_a2arA, gpart_a2atN) = Genome.Split.split gpart_a2atM
                            p_a2arz = Functions.belowten' g_a2ary
                            (g_a2ary, gpart_a2atM) = Genome.Split.split gpart_a2atL
                            p_a2arx = double g_a2arw
                            (g_a2arw, gpart_a2atL) = Genome.Split.split gpart_a2atK
                            p_a2arv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aru
                            (g_a2aru, gpart_a2atK) = Genome.Split.split gpart_a2atJ
                            p_a2art
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ars
                            (g_a2ars, gpart_a2atJ) = Genome.Split.split gpart_a2atI
                            p_a2arr = double g_a2arq
                            (g_a2arq, gpart_a2atI) = Genome.Split.split gpart_a2atH
                            p_a2arp = Functions.belowten' g_a2aro
                            (g_a2aro, gpart_a2atH) = Genome.Split.split gpart_a2atG
                            p_a2arn = double g_a2arm
                            (g_a2arm, gpart_a2atG) = Genome.Split.split gpart_a2atF
                            p_a2arl = Functions.belowten' g_a2ark
                            (g_a2ark, gpart_a2atF) = Genome.Split.split gpart_a2atE
                            p_a2arj = double g_a2ari
                            (g_a2ari, gpart_a2atE) = Genome.Split.split gpart_a2atD
                            p_a2arh = double g_a2arg
                            (g_a2arg, gpart_a2atD) = Genome.Split.split gpart_a2atC
                            p_a2arf = double g_a2are
                            (g_a2are, gpart_a2atC) = Genome.Split.split gpart_a2atB
                            p_a2ard = Functions.belowten' g_a2arc
                            (g_a2arc, gpart_a2atB) = Genome.Split.split gpart_a2atA
                            p_a2arb = double g_a2ara
                            (g_a2ara, gpart_a2atA) = Genome.Split.split gpart_a2atz
                            p_a2ar9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ar8
                            (g_a2ar8, gpart_a2atz) = Genome.Split.split gpart_a2aty
                            p_a2ar7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ar6
                            (g_a2ar6, gpart_a2aty) = Genome.Split.split gpart_a2atx
                            p_a2ar5 = Functions.belowten' g_a2ar4
                            (g_a2ar4, gpart_a2atx) = Genome.Split.split gpart_a2atw
                            p_a2ar3 = double g_a2ar2
                            (g_a2ar2, gpart_a2atw) = Genome.Split.split gpart_a2atv
                            p_a2ar1 = double g_a2ar0
                            (g_a2ar0, gpart_a2atv) = Genome.Split.split gpart_a2atu
                            p_a2aqZ = double g_a2aqY
                            (g_a2aqY, gpart_a2atu) = Genome.Split.split gpart_a2att
                            p_a2aqX = double g_a2aqW
                            (g_a2aqW, gpart_a2att) = Genome.Split.split gpart_a2ats
                            p_a2aqV = double g_a2aqU
                            (g_a2aqU, gpart_a2ats) = Genome.Split.split gpart_a2atr
                            p_a2aqT = double g_a2aqS
                            (g_a2aqS, gpart_a2atr) = Genome.Split.split genome_a2asi
                          in
                            \ desc_a2asj
                              -> case desc_a2asj of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqT)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqV)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqX)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aqZ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar1)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar3)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar5)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar7)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ar9)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arb)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ard)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arf)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arh)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arj)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arl)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arn)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arp)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arr)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2art)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arv)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arx)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arz)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arB)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arD)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arF)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arH)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arJ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arL)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arN)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arP)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arR)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arT)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arV)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arX)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2arZ)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2as1)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2as3)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2as5)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2as7)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2as9)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2asb)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2asd)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2asf)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ash)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a2awI
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2axr
                      p_a2awH = double g_a2awG
                      (g_a2awG, gpart_a2axr) = Genome.Split.split gpart_a2axq
                      p_a2awF = double g_a2awE
                      (g_a2awE, gpart_a2axq) = Genome.Split.split gpart_a2axp
                      p_a2awD = double g_a2awC
                      (g_a2awC, gpart_a2axp) = Genome.Split.split gpart_a2axo
                      p_a2awB = double g_a2awA
                      (g_a2awA, gpart_a2axo) = Genome.Split.split gpart_a2axn
                      p_a2awz = double g_a2awy
                      (g_a2awy, gpart_a2axn) = Genome.Split.split gpart_a2axm
                      p_a2awx = double g_a2aww
                      (g_a2aww, gpart_a2axm) = Genome.Split.split gpart_a2axl
                      p_a2awv = Functions.belowten' g_a2awu
                      (g_a2awu, gpart_a2axl) = Genome.Split.split gpart_a2axk
                      p_a2awt = double g_a2aws
                      (g_a2aws, gpart_a2axk) = Genome.Split.split gpart_a2axj
                      p_a2awr = Functions.belowten' g_a2awq
                      (g_a2awq, gpart_a2axj) = Genome.Split.split gpart_a2axi
                      p_a2awp = double g_a2awo
                      (g_a2awo, gpart_a2axi) = Genome.Split.split gpart_a2axh
                      p_a2awn = double g_a2awm
                      (g_a2awm, gpart_a2axh) = Genome.Split.split gpart_a2axg
                      p_a2awl = double g_a2awk
                      (g_a2awk, gpart_a2axg) = Genome.Split.split gpart_a2axf
                      p_a2awj = Functions.belowten' g_a2awi
                      (g_a2awi, gpart_a2axf) = Genome.Split.split gpart_a2axe
                      p_a2awh = double g_a2awg
                      (g_a2awg, gpart_a2axe) = Genome.Split.split gpart_a2axd
                      p_a2awf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2awe
                      (g_a2awe, gpart_a2axd) = Genome.Split.split gpart_a2axc
                      p_a2awd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2awc
                      (g_a2awc, gpart_a2axc) = Genome.Split.split gpart_a2axb
                      p_a2awb = Functions.belowten' g_a2awa
                      (g_a2awa, gpart_a2axb) = Genome.Split.split gpart_a2axa
                      p_a2aw9 = double g_a2aw8
                      (g_a2aw8, gpart_a2axa) = Genome.Split.split gpart_a2ax9
                      p_a2aw7 = Functions.belowten' g_a2aw6
                      (g_a2aw6, gpart_a2ax9) = Genome.Split.split gpart_a2ax8
                      p_a2aw5 = double g_a2aw4
                      (g_a2aw4, gpart_a2ax8) = Genome.Split.split gpart_a2ax7
                      p_a2aw3 = double g_a2aw2
                      (g_a2aw2, gpart_a2ax7) = Genome.Split.split gpart_a2ax6
                      p_a2aw1 = double g_a2aw0
                      (g_a2aw0, gpart_a2ax6) = Genome.Split.split gpart_a2ax5
                      p_a2avZ = Functions.belowten' g_a2avY
                      (g_a2avY, gpart_a2ax5) = Genome.Split.split gpart_a2ax4
                      p_a2avX = double g_a2avW
                      (g_a2avW, gpart_a2ax4) = Genome.Split.split gpart_a2ax3
                      p_a2avV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avU
                      (g_a2avU, gpart_a2ax3) = Genome.Split.split gpart_a2ax2
                      p_a2avT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avS
                      (g_a2avS, gpart_a2ax2) = Genome.Split.split gpart_a2ax1
                      p_a2avR = double g_a2avQ
                      (g_a2avQ, gpart_a2ax1) = Genome.Split.split gpart_a2ax0
                      p_a2avP = Functions.belowten' g_a2avO
                      (g_a2avO, gpart_a2ax0) = Genome.Split.split gpart_a2awZ
                      p_a2avN = double g_a2avM
                      (g_a2avM, gpart_a2awZ) = Genome.Split.split gpart_a2awY
                      p_a2avL = Functions.belowten' g_a2avK
                      (g_a2avK, gpart_a2awY) = Genome.Split.split gpart_a2awX
                      p_a2avJ = double g_a2avI
                      (g_a2avI, gpart_a2awX) = Genome.Split.split gpart_a2awW
                      p_a2avH = double g_a2avG
                      (g_a2avG, gpart_a2awW) = Genome.Split.split gpart_a2awV
                      p_a2avF = double g_a2avE
                      (g_a2avE, gpart_a2awV) = Genome.Split.split gpart_a2awU
                      p_a2avD = Functions.belowten' g_a2avC
                      (g_a2avC, gpart_a2awU) = Genome.Split.split gpart_a2awT
                      p_a2avB = double g_a2avA
                      (g_a2avA, gpart_a2awT) = Genome.Split.split gpart_a2awS
                      p_a2avz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avy
                      (g_a2avy, gpart_a2awS) = Genome.Split.split gpart_a2awR
                      p_a2avx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avw
                      (g_a2avw, gpart_a2awR) = Genome.Split.split gpart_a2awQ
                      p_a2avv = Functions.belowten' g_a2avu
                      (g_a2avu, gpart_a2awQ) = Genome.Split.split gpart_a2awP
                      p_a2avt = double g_a2avs
                      (g_a2avs, gpart_a2awP) = Genome.Split.split gpart_a2awO
                      p_a2avr = double g_a2avq
                      (g_a2avq, gpart_a2awO) = Genome.Split.split gpart_a2awN
                      p_a2avp = double g_a2avo
                      (g_a2avo, gpart_a2awN) = Genome.Split.split gpart_a2awM
                      p_a2avn = double g_a2avm
                      (g_a2avm, gpart_a2awM) = Genome.Split.split gpart_a2awL
                      p_a2avl = double g_a2avk
                      (g_a2avk, gpart_a2awL) = Genome.Split.split gpart_a2awK
                      p_a2avj = double g_a2avi
                      (g_a2avi, gpart_a2awK) = Genome.Split.split genome_a2awI
                    in  \ x_a2axs
                          -> let
                               c_PTB_a2axx
                                 = ((Data.Fixed.Vector.toVector x_a2axs) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2axv
                                 = ((Data.Fixed.Vector.toVector x_a2axs) Data.Vector.Unboxed.! 2)
                               c_RESTc_a2axt
                                 = ((Data.Fixed.Vector.toVector x_a2axs) Data.Vector.Unboxed.! 3)
                               c_NPTB_a2axB
                                 = ((Data.Fixed.Vector.toVector x_a2axs) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a2axQ
                                 = ((Data.Fixed.Vector.toVector x_a2axs) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2avr
                                     * ((p_a2avF + ((c_RESTc_a2axt / p_a2avt) ** p_a2avv))
                                        / (((1 + p_a2avF) + ((c_RESTc_a2axt / p_a2avt) ** p_a2avv))
                                           + ((c_MiRs_a2axv / p_a2avB) ** p_a2avD))))
                                    + (negate (p_a2awz * c_PTB_a2axx))),
                                   ((p_a2avH
                                     / (1
                                        + (((c_MiRs_a2axv / p_a2avJ) ** p_a2avL)
                                           + ((c_PTB_a2axx / p_a2avN) ** p_a2avP))))
                                    + (negate (p_a2awB * c_NPTB_a2axB))),
                                   ((p_a2avR
                                     * (p_a2aw1
                                        / ((1 + p_a2aw1) + ((c_RESTc_a2axt / p_a2avX) ** p_a2avZ))))
                                    + (negate (p_a2awD * c_MiRs_a2axv))),
                                   ((p_a2aw3
                                     * ((p_a2awl
                                         + (((c_NPTB_a2axB / p_a2aw5) ** p_a2aw7)
                                            + ((c_PTB_a2axx / p_a2aw9) ** p_a2awb)))
                                        / (((1 + p_a2awl)
                                            + (((c_NPTB_a2axB / p_a2aw5) ** p_a2aw7)
                                               + ((c_PTB_a2axx / p_a2aw9) ** p_a2awb)))
                                           + (((p_a2avj / p_a2awd) ** p_a2awf)
                                              + ((c_MiRs_a2axv / p_a2awh) ** p_a2awj)))))
                                    + (negate (p_a2awF * c_RESTc_a2axt))),
                                   ((p_a2awn
                                     * ((p_a2awx + ((c_MiRs_a2axv / p_a2awp) ** p_a2awr))
                                        / (((1 + p_a2awx) + ((c_MiRs_a2axv / p_a2awp) ** p_a2awr))
                                           + ((c_RESTc_a2axt / p_a2awt) ** p_a2awv))))
                                    + (negate (p_a2awH * c_EndoNeuroTFs_a2axQ)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526829",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526839",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526841",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526843",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526845",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526847",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526865",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526867",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526879",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526881",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526885",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526887",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2awI
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ayy
                            p_a2awH = double g_a2awG
                            (g_a2awG, gpart_a2ayy) = Genome.Split.split gpart_a2ayx
                            p_a2awF = double g_a2awE
                            (g_a2awE, gpart_a2ayx) = Genome.Split.split gpart_a2ayw
                            p_a2awD = double g_a2awC
                            (g_a2awC, gpart_a2ayw) = Genome.Split.split gpart_a2ayv
                            p_a2awB = double g_a2awA
                            (g_a2awA, gpart_a2ayv) = Genome.Split.split gpart_a2ayu
                            p_a2awz = double g_a2awy
                            (g_a2awy, gpart_a2ayu) = Genome.Split.split gpart_a2ayt
                            p_a2awx = double g_a2aww
                            (g_a2aww, gpart_a2ayt) = Genome.Split.split gpart_a2ays
                            p_a2awv = Functions.belowten' g_a2awu
                            (g_a2awu, gpart_a2ays) = Genome.Split.split gpart_a2ayr
                            p_a2awt = double g_a2aws
                            (g_a2aws, gpart_a2ayr) = Genome.Split.split gpart_a2ayq
                            p_a2awr = Functions.belowten' g_a2awq
                            (g_a2awq, gpart_a2ayq) = Genome.Split.split gpart_a2ayp
                            p_a2awp = double g_a2awo
                            (g_a2awo, gpart_a2ayp) = Genome.Split.split gpart_a2ayo
                            p_a2awn = double g_a2awm
                            (g_a2awm, gpart_a2ayo) = Genome.Split.split gpart_a2ayn
                            p_a2awl = double g_a2awk
                            (g_a2awk, gpart_a2ayn) = Genome.Split.split gpart_a2aym
                            p_a2awj = Functions.belowten' g_a2awi
                            (g_a2awi, gpart_a2aym) = Genome.Split.split gpart_a2ayl
                            p_a2awh = double g_a2awg
                            (g_a2awg, gpart_a2ayl) = Genome.Split.split gpart_a2ayk
                            p_a2awf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2awe
                            (g_a2awe, gpart_a2ayk) = Genome.Split.split gpart_a2ayj
                            p_a2awd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2awc
                            (g_a2awc, gpart_a2ayj) = Genome.Split.split gpart_a2ayi
                            p_a2awb = Functions.belowten' g_a2awa
                            (g_a2awa, gpart_a2ayi) = Genome.Split.split gpart_a2ayh
                            p_a2aw9 = double g_a2aw8
                            (g_a2aw8, gpart_a2ayh) = Genome.Split.split gpart_a2ayg
                            p_a2aw7 = Functions.belowten' g_a2aw6
                            (g_a2aw6, gpart_a2ayg) = Genome.Split.split gpart_a2ayf
                            p_a2aw5 = double g_a2aw4
                            (g_a2aw4, gpart_a2ayf) = Genome.Split.split gpart_a2aye
                            p_a2aw3 = double g_a2aw2
                            (g_a2aw2, gpart_a2aye) = Genome.Split.split gpart_a2ayd
                            p_a2aw1 = double g_a2aw0
                            (g_a2aw0, gpart_a2ayd) = Genome.Split.split gpart_a2ayc
                            p_a2avZ = Functions.belowten' g_a2avY
                            (g_a2avY, gpart_a2ayc) = Genome.Split.split gpart_a2ayb
                            p_a2avX = double g_a2avW
                            (g_a2avW, gpart_a2ayb) = Genome.Split.split gpart_a2aya
                            p_a2avV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avU
                            (g_a2avU, gpart_a2aya) = Genome.Split.split gpart_a2ay9
                            p_a2avT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avS
                            (g_a2avS, gpart_a2ay9) = Genome.Split.split gpart_a2ay8
                            p_a2avR = double g_a2avQ
                            (g_a2avQ, gpart_a2ay8) = Genome.Split.split gpart_a2ay7
                            p_a2avP = Functions.belowten' g_a2avO
                            (g_a2avO, gpart_a2ay7) = Genome.Split.split gpart_a2ay6
                            p_a2avN = double g_a2avM
                            (g_a2avM, gpart_a2ay6) = Genome.Split.split gpart_a2ay5
                            p_a2avL = Functions.belowten' g_a2avK
                            (g_a2avK, gpart_a2ay5) = Genome.Split.split gpart_a2ay4
                            p_a2avJ = double g_a2avI
                            (g_a2avI, gpart_a2ay4) = Genome.Split.split gpart_a2ay3
                            p_a2avH = double g_a2avG
                            (g_a2avG, gpart_a2ay3) = Genome.Split.split gpart_a2ay2
                            p_a2avF = double g_a2avE
                            (g_a2avE, gpart_a2ay2) = Genome.Split.split gpart_a2ay1
                            p_a2avD = Functions.belowten' g_a2avC
                            (g_a2avC, gpart_a2ay1) = Genome.Split.split gpart_a2ay0
                            p_a2avB = double g_a2avA
                            (g_a2avA, gpart_a2ay0) = Genome.Split.split gpart_a2axZ
                            p_a2avz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avy
                            (g_a2avy, gpart_a2axZ) = Genome.Split.split gpart_a2axY
                            p_a2avx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2avw
                            (g_a2avw, gpart_a2axY) = Genome.Split.split gpart_a2axX
                            p_a2avv = Functions.belowten' g_a2avu
                            (g_a2avu, gpart_a2axX) = Genome.Split.split gpart_a2axW
                            p_a2avt = double g_a2avs
                            (g_a2avs, gpart_a2axW) = Genome.Split.split gpart_a2axV
                            p_a2avr = double g_a2avq
                            (g_a2avq, gpart_a2axV) = Genome.Split.split gpart_a2axU
                            p_a2avp = double g_a2avo
                            (g_a2avo, gpart_a2axU) = Genome.Split.split gpart_a2axT
                            p_a2avn = double g_a2avm
                            (g_a2avm, gpart_a2axT) = Genome.Split.split gpart_a2axS
                            p_a2avl = double g_a2avk
                            (g_a2avk, gpart_a2axS) = Genome.Split.split gpart_a2axR
                            p_a2avj = double g_a2avi
                            (g_a2avi, gpart_a2axR) = Genome.Split.split genome_a2awI
                          in
                            \ desc_a2awJ
                              -> case desc_a2awJ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avj)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avl)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avn)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avp)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avr)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avt)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avv)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avx)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avz)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avB)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avD)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avF)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avH)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avJ)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avL)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avN)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avP)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avR)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avT)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avV)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avX)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2avZ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aw1)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aw3)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aw5)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aw7)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aw9)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awb)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awd)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awf)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awh)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awj)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awl)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awn)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awp)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awr)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awt)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awv)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awx)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awz)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awB)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awD)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awF)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2awH)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a2aB8
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2aBR
                      p_a2aB7 = double g_a2aB6
                      (g_a2aB6, gpart_a2aBR) = Genome.Split.split gpart_a2aBQ
                      p_a2aB5 = double g_a2aB4
                      (g_a2aB4, gpart_a2aBQ) = Genome.Split.split gpart_a2aBP
                      p_a2aB3 = double g_a2aB2
                      (g_a2aB2, gpart_a2aBP) = Genome.Split.split gpart_a2aBO
                      p_a2aB1 = double g_a2aB0
                      (g_a2aB0, gpart_a2aBO) = Genome.Split.split gpart_a2aBN
                      p_a2aAZ = double g_a2aAY
                      (g_a2aAY, gpart_a2aBN) = Genome.Split.split gpart_a2aBM
                      p_a2aAX = double g_a2aAW
                      (g_a2aAW, gpart_a2aBM) = Genome.Split.split gpart_a2aBL
                      p_a2aAV = Functions.belowten' g_a2aAU
                      (g_a2aAU, gpart_a2aBL) = Genome.Split.split gpart_a2aBK
                      p_a2aAT = double g_a2aAS
                      (g_a2aAS, gpart_a2aBK) = Genome.Split.split gpart_a2aBJ
                      p_a2aAR = Functions.belowten' g_a2aAQ
                      (g_a2aAQ, gpart_a2aBJ) = Genome.Split.split gpart_a2aBI
                      p_a2aAP = double g_a2aAO
                      (g_a2aAO, gpart_a2aBI) = Genome.Split.split gpart_a2aBH
                      p_a2aAN = double g_a2aAM
                      (g_a2aAM, gpart_a2aBH) = Genome.Split.split gpart_a2aBG
                      p_a2aAL = double g_a2aAK
                      (g_a2aAK, gpart_a2aBG) = Genome.Split.split gpart_a2aBF
                      p_a2aAJ = Functions.belowten' g_a2aAI
                      (g_a2aAI, gpart_a2aBF) = Genome.Split.split gpart_a2aBE
                      p_a2aAH = double g_a2aAG
                      (g_a2aAG, gpart_a2aBE) = Genome.Split.split gpart_a2aBD
                      p_a2aAF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aAE
                      (g_a2aAE, gpart_a2aBD) = Genome.Split.split gpart_a2aBC
                      p_a2aAD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aAC
                      (g_a2aAC, gpart_a2aBC) = Genome.Split.split gpart_a2aBB
                      p_a2aAB = Functions.belowten' g_a2aAA
                      (g_a2aAA, gpart_a2aBB) = Genome.Split.split gpart_a2aBA
                      p_a2aAz = double g_a2aAy
                      (g_a2aAy, gpart_a2aBA) = Genome.Split.split gpart_a2aBz
                      p_a2aAx = Functions.belowten' g_a2aAw
                      (g_a2aAw, gpart_a2aBz) = Genome.Split.split gpart_a2aBy
                      p_a2aAv = double g_a2aAu
                      (g_a2aAu, gpart_a2aBy) = Genome.Split.split gpart_a2aBx
                      p_a2aAt = double g_a2aAs
                      (g_a2aAs, gpart_a2aBx) = Genome.Split.split gpart_a2aBw
                      p_a2aAr = double g_a2aAq
                      (g_a2aAq, gpart_a2aBw) = Genome.Split.split gpart_a2aBv
                      p_a2aAp = Functions.belowten' g_a2aAo
                      (g_a2aAo, gpart_a2aBv) = Genome.Split.split gpart_a2aBu
                      p_a2aAn = double g_a2aAm
                      (g_a2aAm, gpart_a2aBu) = Genome.Split.split gpart_a2aBt
                      p_a2aAl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aAk
                      (g_a2aAk, gpart_a2aBt) = Genome.Split.split gpart_a2aBs
                      p_a2aAj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aAi
                      (g_a2aAi, gpart_a2aBs) = Genome.Split.split gpart_a2aBr
                      p_a2aAh = double g_a2aAg
                      (g_a2aAg, gpart_a2aBr) = Genome.Split.split gpart_a2aBq
                      p_a2aAf = Functions.belowten' g_a2aAe
                      (g_a2aAe, gpart_a2aBq) = Genome.Split.split gpart_a2aBp
                      p_a2aAd = double g_a2aAc
                      (g_a2aAc, gpart_a2aBp) = Genome.Split.split gpart_a2aBo
                      p_a2aAb = Functions.belowten' g_a2aAa
                      (g_a2aAa, gpart_a2aBo) = Genome.Split.split gpart_a2aBn
                      p_a2aA9 = double g_a2aA8
                      (g_a2aA8, gpart_a2aBn) = Genome.Split.split gpart_a2aBm
                      p_a2aA7 = double g_a2aA6
                      (g_a2aA6, gpart_a2aBm) = Genome.Split.split gpart_a2aBl
                      p_a2aA5 = double g_a2aA4
                      (g_a2aA4, gpart_a2aBl) = Genome.Split.split gpart_a2aBk
                      p_a2aA3 = Functions.belowten' g_a2aA2
                      (g_a2aA2, gpart_a2aBk) = Genome.Split.split gpart_a2aBj
                      p_a2aA1 = double g_a2aA0
                      (g_a2aA0, gpart_a2aBj) = Genome.Split.split gpart_a2aBi
                      p_a2azZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2azY
                      (g_a2azY, gpart_a2aBi) = Genome.Split.split gpart_a2aBh
                      p_a2azX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2azW
                      (g_a2azW, gpart_a2aBh) = Genome.Split.split gpart_a2aBg
                      p_a2azV = Functions.belowten' g_a2azU
                      (g_a2azU, gpart_a2aBg) = Genome.Split.split gpart_a2aBf
                      p_a2azT = double g_a2azS
                      (g_a2azS, gpart_a2aBf) = Genome.Split.split gpart_a2aBe
                      p_a2azR = double g_a2azQ
                      (g_a2azQ, gpart_a2aBe) = Genome.Split.split gpart_a2aBd
                      p_a2azP = double g_a2azO
                      (g_a2azO, gpart_a2aBd) = Genome.Split.split gpart_a2aBc
                      p_a2azN = double g_a2azM
                      (g_a2azM, gpart_a2aBc) = Genome.Split.split gpart_a2aBb
                      p_a2azL = double g_a2azK
                      (g_a2azK, gpart_a2aBb) = Genome.Split.split gpart_a2aBa
                      p_a2azJ = double g_a2azI
                      (g_a2azI, gpart_a2aBa) = Genome.Split.split genome_a2aB8
                    in  \ x_a2aBS
                          -> let
                               c_PTB_a2aBX
                                 = ((Data.Fixed.Vector.toVector x_a2aBS) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2aBV
                                 = ((Data.Fixed.Vector.toVector x_a2aBS) Data.Vector.Unboxed.! 2)
                               c_RESTc_a2aBT
                                 = ((Data.Fixed.Vector.toVector x_a2aBS) Data.Vector.Unboxed.! 3)
                               c_NPTB_a2aC1
                                 = ((Data.Fixed.Vector.toVector x_a2aBS) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a2aCg
                                 = ((Data.Fixed.Vector.toVector x_a2aBS) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2azR
                                     * ((p_a2aA5 + ((c_RESTc_a2aBT / p_a2azT) ** p_a2azV))
                                        / (((1 + p_a2aA5) + ((c_RESTc_a2aBT / p_a2azT) ** p_a2azV))
                                           + ((c_MiRs_a2aBV / p_a2aA1) ** p_a2aA3))))
                                    + (negate (p_a2aAZ * c_PTB_a2aBX))),
                                   ((p_a2aA7
                                     / (1
                                        + (((c_MiRs_a2aBV / p_a2aA9) ** p_a2aAb)
                                           + ((c_PTB_a2aBX / p_a2aAd) ** p_a2aAf))))
                                    + (negate (p_a2aB1 * c_NPTB_a2aC1))),
                                   ((p_a2aAh
                                     * (p_a2aAr
                                        / ((1 + p_a2aAr) + ((c_RESTc_a2aBT / p_a2aAn) ** p_a2aAp))))
                                    + (negate (p_a2aB3 * c_MiRs_a2aBV))),
                                   ((p_a2aAt
                                     * ((p_a2aAL
                                         + (((c_NPTB_a2aC1 / p_a2aAv) ** p_a2aAx)
                                            + ((c_PTB_a2aBX / p_a2aAz) ** p_a2aAB)))
                                        / (((1 + p_a2aAL)
                                            + (((c_NPTB_a2aC1 / p_a2aAv) ** p_a2aAx)
                                               + ((c_PTB_a2aBX / p_a2aAz) ** p_a2aAB)))
                                           + ((c_MiRs_a2aBV / p_a2aAH) ** p_a2aAJ))))
                                    + (negate (p_a2aB5 * c_RESTc_a2aBT))),
                                   ((p_a2aAN
                                     * ((p_a2aAX + ((c_MiRs_a2aBV / p_a2aAP) ** p_a2aAR))
                                        / (((1 + p_a2aAX) + ((c_MiRs_a2aBV / p_a2aAP) ** p_a2aAR))
                                           + ((c_RESTc_a2aBT / p_a2aAT) ** p_a2aAV))))
                                    + (negate (p_a2aB7 * c_EndoNeuroTFs_a2aCg)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527107",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527117",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527119",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527139",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527141",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527159",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527161",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2aB8
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2aCY
                            p_a2aB7 = double g_a2aB6
                            (g_a2aB6, gpart_a2aCY) = Genome.Split.split gpart_a2aCX
                            p_a2aB5 = double g_a2aB4
                            (g_a2aB4, gpart_a2aCX) = Genome.Split.split gpart_a2aCW
                            p_a2aB3 = double g_a2aB2
                            (g_a2aB2, gpart_a2aCW) = Genome.Split.split gpart_a2aCV
                            p_a2aB1 = double g_a2aB0
                            (g_a2aB0, gpart_a2aCV) = Genome.Split.split gpart_a2aCU
                            p_a2aAZ = double g_a2aAY
                            (g_a2aAY, gpart_a2aCU) = Genome.Split.split gpart_a2aCT
                            p_a2aAX = double g_a2aAW
                            (g_a2aAW, gpart_a2aCT) = Genome.Split.split gpart_a2aCS
                            p_a2aAV = Functions.belowten' g_a2aAU
                            (g_a2aAU, gpart_a2aCS) = Genome.Split.split gpart_a2aCR
                            p_a2aAT = double g_a2aAS
                            (g_a2aAS, gpart_a2aCR) = Genome.Split.split gpart_a2aCQ
                            p_a2aAR = Functions.belowten' g_a2aAQ
                            (g_a2aAQ, gpart_a2aCQ) = Genome.Split.split gpart_a2aCP
                            p_a2aAP = double g_a2aAO
                            (g_a2aAO, gpart_a2aCP) = Genome.Split.split gpart_a2aCO
                            p_a2aAN = double g_a2aAM
                            (g_a2aAM, gpart_a2aCO) = Genome.Split.split gpart_a2aCN
                            p_a2aAL = double g_a2aAK
                            (g_a2aAK, gpart_a2aCN) = Genome.Split.split gpart_a2aCM
                            p_a2aAJ = Functions.belowten' g_a2aAI
                            (g_a2aAI, gpart_a2aCM) = Genome.Split.split gpart_a2aCL
                            p_a2aAH = double g_a2aAG
                            (g_a2aAG, gpart_a2aCL) = Genome.Split.split gpart_a2aCK
                            p_a2aAF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aAE
                            (g_a2aAE, gpart_a2aCK) = Genome.Split.split gpart_a2aCJ
                            p_a2aAD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aAC
                            (g_a2aAC, gpart_a2aCJ) = Genome.Split.split gpart_a2aCI
                            p_a2aAB = Functions.belowten' g_a2aAA
                            (g_a2aAA, gpart_a2aCI) = Genome.Split.split gpart_a2aCH
                            p_a2aAz = double g_a2aAy
                            (g_a2aAy, gpart_a2aCH) = Genome.Split.split gpart_a2aCG
                            p_a2aAx = Functions.belowten' g_a2aAw
                            (g_a2aAw, gpart_a2aCG) = Genome.Split.split gpart_a2aCF
                            p_a2aAv = double g_a2aAu
                            (g_a2aAu, gpart_a2aCF) = Genome.Split.split gpart_a2aCE
                            p_a2aAt = double g_a2aAs
                            (g_a2aAs, gpart_a2aCE) = Genome.Split.split gpart_a2aCD
                            p_a2aAr = double g_a2aAq
                            (g_a2aAq, gpart_a2aCD) = Genome.Split.split gpart_a2aCC
                            p_a2aAp = Functions.belowten' g_a2aAo
                            (g_a2aAo, gpart_a2aCC) = Genome.Split.split gpart_a2aCB
                            p_a2aAn = double g_a2aAm
                            (g_a2aAm, gpart_a2aCB) = Genome.Split.split gpart_a2aCA
                            p_a2aAl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aAk
                            (g_a2aAk, gpart_a2aCA) = Genome.Split.split gpart_a2aCz
                            p_a2aAj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aAi
                            (g_a2aAi, gpart_a2aCz) = Genome.Split.split gpart_a2aCy
                            p_a2aAh = double g_a2aAg
                            (g_a2aAg, gpart_a2aCy) = Genome.Split.split gpart_a2aCx
                            p_a2aAf = Functions.belowten' g_a2aAe
                            (g_a2aAe, gpart_a2aCx) = Genome.Split.split gpart_a2aCw
                            p_a2aAd = double g_a2aAc
                            (g_a2aAc, gpart_a2aCw) = Genome.Split.split gpart_a2aCv
                            p_a2aAb = Functions.belowten' g_a2aAa
                            (g_a2aAa, gpart_a2aCv) = Genome.Split.split gpart_a2aCu
                            p_a2aA9 = double g_a2aA8
                            (g_a2aA8, gpart_a2aCu) = Genome.Split.split gpart_a2aCt
                            p_a2aA7 = double g_a2aA6
                            (g_a2aA6, gpart_a2aCt) = Genome.Split.split gpart_a2aCs
                            p_a2aA5 = double g_a2aA4
                            (g_a2aA4, gpart_a2aCs) = Genome.Split.split gpart_a2aCr
                            p_a2aA3 = Functions.belowten' g_a2aA2
                            (g_a2aA2, gpart_a2aCr) = Genome.Split.split gpart_a2aCq
                            p_a2aA1 = double g_a2aA0
                            (g_a2aA0, gpart_a2aCq) = Genome.Split.split gpart_a2aCp
                            p_a2azZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2azY
                            (g_a2azY, gpart_a2aCp) = Genome.Split.split gpart_a2aCo
                            p_a2azX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2azW
                            (g_a2azW, gpart_a2aCo) = Genome.Split.split gpart_a2aCn
                            p_a2azV = Functions.belowten' g_a2azU
                            (g_a2azU, gpart_a2aCn) = Genome.Split.split gpart_a2aCm
                            p_a2azT = double g_a2azS
                            (g_a2azS, gpart_a2aCm) = Genome.Split.split gpart_a2aCl
                            p_a2azR = double g_a2azQ
                            (g_a2azQ, gpart_a2aCl) = Genome.Split.split gpart_a2aCk
                            p_a2azP = double g_a2azO
                            (g_a2azO, gpart_a2aCk) = Genome.Split.split gpart_a2aCj
                            p_a2azN = double g_a2azM
                            (g_a2azM, gpart_a2aCj) = Genome.Split.split gpart_a2aCi
                            p_a2azL = double g_a2azK
                            (g_a2azK, gpart_a2aCi) = Genome.Split.split gpart_a2aCh
                            p_a2azJ = double g_a2azI
                            (g_a2azI, gpart_a2aCh) = Genome.Split.split genome_a2aB8
                          in
                            \ desc_a2aB9
                              -> case desc_a2aB9 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2azJ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2azL)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2azN)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2azP)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2azR)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2azT)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2azV)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2azX)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2azZ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aA1)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aA3)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aA5)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aA7)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aA9)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAb)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAd)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAf)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAh)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAj)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAl)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAn)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAp)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAr)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAt)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAv)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAx)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAz)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAB)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAD)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAF)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAH)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAJ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAL)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAN)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAP)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAR)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAT)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAV)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAX)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aAZ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aB1)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aB3)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aB5)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aB7)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a2aFy
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2aGh
                      p_a2aFx = double g_a2aFw
                      (g_a2aFw, gpart_a2aGh) = Genome.Split.split gpart_a2aGg
                      p_a2aFv = double g_a2aFu
                      (g_a2aFu, gpart_a2aGg) = Genome.Split.split gpart_a2aGf
                      p_a2aFt = double g_a2aFs
                      (g_a2aFs, gpart_a2aGf) = Genome.Split.split gpart_a2aGe
                      p_a2aFr = double g_a2aFq
                      (g_a2aFq, gpart_a2aGe) = Genome.Split.split gpart_a2aGd
                      p_a2aFp = double g_a2aFo
                      (g_a2aFo, gpart_a2aGd) = Genome.Split.split gpart_a2aGc
                      p_a2aFn = double g_a2aFm
                      (g_a2aFm, gpart_a2aGc) = Genome.Split.split gpart_a2aGb
                      p_a2aFl = Functions.belowten' g_a2aFk
                      (g_a2aFk, gpart_a2aGb) = Genome.Split.split gpart_a2aGa
                      p_a2aFj = double g_a2aFi
                      (g_a2aFi, gpart_a2aGa) = Genome.Split.split gpart_a2aG9
                      p_a2aFh = Functions.belowten' g_a2aFg
                      (g_a2aFg, gpart_a2aG9) = Genome.Split.split gpart_a2aG8
                      p_a2aFf = double g_a2aFe
                      (g_a2aFe, gpart_a2aG8) = Genome.Split.split gpart_a2aG7
                      p_a2aFd = double g_a2aFc
                      (g_a2aFc, gpart_a2aG7) = Genome.Split.split gpart_a2aG6
                      p_a2aFb = double g_a2aFa
                      (g_a2aFa, gpart_a2aG6) = Genome.Split.split gpart_a2aG5
                      p_a2aF9 = Functions.belowten' g_a2aF8
                      (g_a2aF8, gpart_a2aG5) = Genome.Split.split gpart_a2aG4
                      p_a2aF7 = double g_a2aF6
                      (g_a2aF6, gpart_a2aG4) = Genome.Split.split gpart_a2aG3
                      p_a2aF5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aF4
                      (g_a2aF4, gpart_a2aG3) = Genome.Split.split gpart_a2aG2
                      p_a2aF3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aF2
                      (g_a2aF2, gpart_a2aG2) = Genome.Split.split gpart_a2aG1
                      p_a2aF1 = Functions.belowten' g_a2aF0
                      (g_a2aF0, gpart_a2aG1) = Genome.Split.split gpart_a2aG0
                      p_a2aEZ = double g_a2aEY
                      (g_a2aEY, gpart_a2aG0) = Genome.Split.split gpart_a2aFZ
                      p_a2aEX = Functions.belowten' g_a2aEW
                      (g_a2aEW, gpart_a2aFZ) = Genome.Split.split gpart_a2aFY
                      p_a2aEV = double g_a2aEU
                      (g_a2aEU, gpart_a2aFY) = Genome.Split.split gpart_a2aFX
                      p_a2aET = double g_a2aES
                      (g_a2aES, gpart_a2aFX) = Genome.Split.split gpart_a2aFW
                      p_a2aER = double g_a2aEQ
                      (g_a2aEQ, gpart_a2aFW) = Genome.Split.split gpart_a2aFV
                      p_a2aEP = Functions.belowten' g_a2aEO
                      (g_a2aEO, gpart_a2aFV) = Genome.Split.split gpart_a2aFU
                      p_a2aEN = double g_a2aEM
                      (g_a2aEM, gpart_a2aFU) = Genome.Split.split gpart_a2aFT
                      p_a2aEL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aEK
                      (g_a2aEK, gpart_a2aFT) = Genome.Split.split gpart_a2aFS
                      p_a2aEJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aEI
                      (g_a2aEI, gpart_a2aFS) = Genome.Split.split gpart_a2aFR
                      p_a2aEH = double g_a2aEG
                      (g_a2aEG, gpart_a2aFR) = Genome.Split.split gpart_a2aFQ
                      p_a2aEF = Functions.belowten' g_a2aEE
                      (g_a2aEE, gpart_a2aFQ) = Genome.Split.split gpart_a2aFP
                      p_a2aED = double g_a2aEC
                      (g_a2aEC, gpart_a2aFP) = Genome.Split.split gpart_a2aFO
                      p_a2aEB = Functions.belowten' g_a2aEA
                      (g_a2aEA, gpart_a2aFO) = Genome.Split.split gpart_a2aFN
                      p_a2aEz = double g_a2aEy
                      (g_a2aEy, gpart_a2aFN) = Genome.Split.split gpart_a2aFM
                      p_a2aEx = double g_a2aEw
                      (g_a2aEw, gpart_a2aFM) = Genome.Split.split gpart_a2aFL
                      p_a2aEv = double g_a2aEu
                      (g_a2aEu, gpart_a2aFL) = Genome.Split.split gpart_a2aFK
                      p_a2aEt = Functions.belowten' g_a2aEs
                      (g_a2aEs, gpart_a2aFK) = Genome.Split.split gpart_a2aFJ
                      p_a2aEr = double g_a2aEq
                      (g_a2aEq, gpart_a2aFJ) = Genome.Split.split gpart_a2aFI
                      p_a2aEp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aEo
                      (g_a2aEo, gpart_a2aFI) = Genome.Split.split gpart_a2aFH
                      p_a2aEn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aEm
                      (g_a2aEm, gpart_a2aFH) = Genome.Split.split gpart_a2aFG
                      p_a2aEl = Functions.belowten' g_a2aEk
                      (g_a2aEk, gpart_a2aFG) = Genome.Split.split gpart_a2aFF
                      p_a2aEj = double g_a2aEi
                      (g_a2aEi, gpart_a2aFF) = Genome.Split.split gpart_a2aFE
                      p_a2aEh = double g_a2aEg
                      (g_a2aEg, gpart_a2aFE) = Genome.Split.split gpart_a2aFD
                      p_a2aEf = double g_a2aEe
                      (g_a2aEe, gpart_a2aFD) = Genome.Split.split gpart_a2aFC
                      p_a2aEd = double g_a2aEc
                      (g_a2aEc, gpart_a2aFC) = Genome.Split.split gpart_a2aFB
                      p_a2aEb = double g_a2aEa
                      (g_a2aEa, gpart_a2aFB) = Genome.Split.split gpart_a2aFA
                      p_a2aE9 = double g_a2aE8
                      (g_a2aE8, gpart_a2aFA) = Genome.Split.split genome_a2aFy
                    in  \ x_a2aGi
                          -> let
                               c_PTB_a2aGn
                                 = ((Data.Fixed.Vector.toVector x_a2aGi) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2aGl
                                 = ((Data.Fixed.Vector.toVector x_a2aGi) Data.Vector.Unboxed.! 2)
                               c_RESTc_a2aGj
                                 = ((Data.Fixed.Vector.toVector x_a2aGi) Data.Vector.Unboxed.! 3)
                               c_NPTB_a2aGr
                                 = ((Data.Fixed.Vector.toVector x_a2aGi) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a2aGG
                                 = ((Data.Fixed.Vector.toVector x_a2aGi) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2aEh
                                     * ((p_a2aEv + ((c_RESTc_a2aGj / p_a2aEj) ** p_a2aEl))
                                        / (((1 + p_a2aEv) + ((c_RESTc_a2aGj / p_a2aEj) ** p_a2aEl))
                                           + (((p_a2aE9 / p_a2aEn) ** p_a2aEp)
                                              + ((c_MiRs_a2aGl / p_a2aEr) ** p_a2aEt)))))
                                    + (negate (p_a2aFp * c_PTB_a2aGn))),
                                   ((p_a2aEx
                                     / (1
                                        + (((c_MiRs_a2aGl / p_a2aEz) ** p_a2aEB)
                                           + ((c_PTB_a2aGn / p_a2aED) ** p_a2aEF))))
                                    + (negate (p_a2aFr * c_NPTB_a2aGr))),
                                   ((p_a2aEH
                                     * (p_a2aER
                                        / ((1 + p_a2aER) + ((c_RESTc_a2aGj / p_a2aEN) ** p_a2aEP))))
                                    + (negate (p_a2aFt * c_MiRs_a2aGl))),
                                   ((p_a2aET
                                     * ((p_a2aFb
                                         + (((c_NPTB_a2aGr / p_a2aEV) ** p_a2aEX)
                                            + ((c_PTB_a2aGn / p_a2aEZ) ** p_a2aF1)))
                                        / (((1 + p_a2aFb)
                                            + (((c_NPTB_a2aGr / p_a2aEV) ** p_a2aEX)
                                               + ((c_PTB_a2aGn / p_a2aEZ) ** p_a2aF1)))
                                           + ((c_MiRs_a2aGl / p_a2aF7) ** p_a2aF9))))
                                    + (negate (p_a2aFv * c_RESTc_a2aGj))),
                                   ((p_a2aFd
                                     * ((p_a2aFn + ((c_MiRs_a2aGl / p_a2aFf) ** p_a2aFh))
                                        / (((1 + p_a2aFn) + ((c_MiRs_a2aGl / p_a2aFf) ** p_a2aFh))
                                           + ((c_RESTc_a2aGj / p_a2aFj) ** p_a2aFl))))
                                    + (negate (p_a2aFx * c_EndoNeuroTFs_a2aGG)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527379",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527381",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527387",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527391",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527393",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527413",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527415",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527433",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527435",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527449",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527451",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527457",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527459",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679527462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679527463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2aFy
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2aHo
                            p_a2aFx = double g_a2aFw
                            (g_a2aFw, gpart_a2aHo) = Genome.Split.split gpart_a2aHn
                            p_a2aFv = double g_a2aFu
                            (g_a2aFu, gpart_a2aHn) = Genome.Split.split gpart_a2aHm
                            p_a2aFt = double g_a2aFs
                            (g_a2aFs, gpart_a2aHm) = Genome.Split.split gpart_a2aHl
                            p_a2aFr = double g_a2aFq
                            (g_a2aFq, gpart_a2aHl) = Genome.Split.split gpart_a2aHk
                            p_a2aFp = double g_a2aFo
                            (g_a2aFo, gpart_a2aHk) = Genome.Split.split gpart_a2aHj
                            p_a2aFn = double g_a2aFm
                            (g_a2aFm, gpart_a2aHj) = Genome.Split.split gpart_a2aHi
                            p_a2aFl = Functions.belowten' g_a2aFk
                            (g_a2aFk, gpart_a2aHi) = Genome.Split.split gpart_a2aHh
                            p_a2aFj = double g_a2aFi
                            (g_a2aFi, gpart_a2aHh) = Genome.Split.split gpart_a2aHg
                            p_a2aFh = Functions.belowten' g_a2aFg
                            (g_a2aFg, gpart_a2aHg) = Genome.Split.split gpart_a2aHf
                            p_a2aFf = double g_a2aFe
                            (g_a2aFe, gpart_a2aHf) = Genome.Split.split gpart_a2aHe
                            p_a2aFd = double g_a2aFc
                            (g_a2aFc, gpart_a2aHe) = Genome.Split.split gpart_a2aHd
                            p_a2aFb = double g_a2aFa
                            (g_a2aFa, gpart_a2aHd) = Genome.Split.split gpart_a2aHc
                            p_a2aF9 = Functions.belowten' g_a2aF8
                            (g_a2aF8, gpart_a2aHc) = Genome.Split.split gpart_a2aHb
                            p_a2aF7 = double g_a2aF6
                            (g_a2aF6, gpart_a2aHb) = Genome.Split.split gpart_a2aHa
                            p_a2aF5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aF4
                            (g_a2aF4, gpart_a2aHa) = Genome.Split.split gpart_a2aH9
                            p_a2aF3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aF2
                            (g_a2aF2, gpart_a2aH9) = Genome.Split.split gpart_a2aH8
                            p_a2aF1 = Functions.belowten' g_a2aF0
                            (g_a2aF0, gpart_a2aH8) = Genome.Split.split gpart_a2aH7
                            p_a2aEZ = double g_a2aEY
                            (g_a2aEY, gpart_a2aH7) = Genome.Split.split gpart_a2aH6
                            p_a2aEX = Functions.belowten' g_a2aEW
                            (g_a2aEW, gpart_a2aH6) = Genome.Split.split gpart_a2aH5
                            p_a2aEV = double g_a2aEU
                            (g_a2aEU, gpart_a2aH5) = Genome.Split.split gpart_a2aH4
                            p_a2aET = double g_a2aES
                            (g_a2aES, gpart_a2aH4) = Genome.Split.split gpart_a2aH3
                            p_a2aER = double g_a2aEQ
                            (g_a2aEQ, gpart_a2aH3) = Genome.Split.split gpart_a2aH2
                            p_a2aEP = Functions.belowten' g_a2aEO
                            (g_a2aEO, gpart_a2aH2) = Genome.Split.split gpart_a2aH1
                            p_a2aEN = double g_a2aEM
                            (g_a2aEM, gpart_a2aH1) = Genome.Split.split gpart_a2aH0
                            p_a2aEL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aEK
                            (g_a2aEK, gpart_a2aH0) = Genome.Split.split gpart_a2aGZ
                            p_a2aEJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aEI
                            (g_a2aEI, gpart_a2aGZ) = Genome.Split.split gpart_a2aGY
                            p_a2aEH = double g_a2aEG
                            (g_a2aEG, gpart_a2aGY) = Genome.Split.split gpart_a2aGX
                            p_a2aEF = Functions.belowten' g_a2aEE
                            (g_a2aEE, gpart_a2aGX) = Genome.Split.split gpart_a2aGW
                            p_a2aED = double g_a2aEC
                            (g_a2aEC, gpart_a2aGW) = Genome.Split.split gpart_a2aGV
                            p_a2aEB = Functions.belowten' g_a2aEA
                            (g_a2aEA, gpart_a2aGV) = Genome.Split.split gpart_a2aGU
                            p_a2aEz = double g_a2aEy
                            (g_a2aEy, gpart_a2aGU) = Genome.Split.split gpart_a2aGT
                            p_a2aEx = double g_a2aEw
                            (g_a2aEw, gpart_a2aGT) = Genome.Split.split gpart_a2aGS
                            p_a2aEv = double g_a2aEu
                            (g_a2aEu, gpart_a2aGS) = Genome.Split.split gpart_a2aGR
                            p_a2aEt = Functions.belowten' g_a2aEs
                            (g_a2aEs, gpart_a2aGR) = Genome.Split.split gpart_a2aGQ
                            p_a2aEr = double g_a2aEq
                            (g_a2aEq, gpart_a2aGQ) = Genome.Split.split gpart_a2aGP
                            p_a2aEp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aEo
                            (g_a2aEo, gpart_a2aGP) = Genome.Split.split gpart_a2aGO
                            p_a2aEn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aEm
                            (g_a2aEm, gpart_a2aGO) = Genome.Split.split gpart_a2aGN
                            p_a2aEl = Functions.belowten' g_a2aEk
                            (g_a2aEk, gpart_a2aGN) = Genome.Split.split gpart_a2aGM
                            p_a2aEj = double g_a2aEi
                            (g_a2aEi, gpart_a2aGM) = Genome.Split.split gpart_a2aGL
                            p_a2aEh = double g_a2aEg
                            (g_a2aEg, gpart_a2aGL) = Genome.Split.split gpart_a2aGK
                            p_a2aEf = double g_a2aEe
                            (g_a2aEe, gpart_a2aGK) = Genome.Split.split gpart_a2aGJ
                            p_a2aEd = double g_a2aEc
                            (g_a2aEc, gpart_a2aGJ) = Genome.Split.split gpart_a2aGI
                            p_a2aEb = double g_a2aEa
                            (g_a2aEa, gpart_a2aGI) = Genome.Split.split gpart_a2aGH
                            p_a2aE9 = double g_a2aE8
                            (g_a2aE8, gpart_a2aGH) = Genome.Split.split genome_a2aFy
                          in
                            \ desc_a2aFz
                              -> case desc_a2aFz of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aE9)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEb)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEd)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEf)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEh)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEj)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEl)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEn)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEp)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEr)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEt)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEv)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEx)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEz)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEB)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aED)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEF)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEH)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEJ)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEL)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEN)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEP)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aER)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aET)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEV)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEX)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aEZ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aF1)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aF3)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aF5)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aF7)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aF9)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFb)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFd)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFf)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFh)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFj)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFl)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFn)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFp)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFr)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFt)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFv)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aFx)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asYR
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZA
                      p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                      (g_asYP, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                      (g_asYN, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                      (g_asYL, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                      (g_asYJ, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                      (g_asYH, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                      (g_asYF, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYE = Functions.belowten' g_asYD
                      (g_asYD, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                      (g_asYB, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYA = Functions.belowten' g_asYz
                      (g_asYz, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                      (g_asYx, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asYw = code-0.1.0.0:Genome.FixedList.Functions.double g_asYv
                      (g_asYv, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                      (g_asYt, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asYs = Functions.belowten' g_asYr
                      (g_asYr, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                      (g_asYp, gpart_asZn) = Genome.Split.split gpart_asZm
                      p_asYo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYn
                      (g_asYn, gpart_asZm) = Genome.Split.split gpart_asZl
                      p_asYm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYl
                      (g_asYl, gpart_asZl) = Genome.Split.split gpart_asZk
                      p_asYk = Functions.belowten' g_asYj
                      (g_asYj, gpart_asZk) = Genome.Split.split gpart_asZj
                      p_asYi = code-0.1.0.0:Genome.FixedList.Functions.double g_asYh
                      (g_asYh, gpart_asZj) = Genome.Split.split gpart_asZi
                      p_asYg = Functions.belowten' g_asYf
                      (g_asYf, gpart_asZi) = Genome.Split.split gpart_asZh
                      p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                      (g_asYd, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                      (g_asYb, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                      (g_asY9, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asY8 = Functions.belowten' g_asY7
                      (g_asY7, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                      (g_asY5, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asY4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY3
                      (g_asY3, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asY2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY1
                      (g_asY1, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                      (g_asXZ, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asXY = Functions.belowten' g_asXX
                      (g_asXX, gpart_asZ9) = Genome.Split.split gpart_asZ8
                      p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                      (g_asXV, gpart_asZ8) = Genome.Split.split gpart_asZ7
                      p_asXU = Functions.belowten' g_asXT
                      (g_asXT, gpart_asZ7) = Genome.Split.split gpart_asZ6
                      p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                      (g_asXR, gpart_asZ6) = Genome.Split.split gpart_asZ5
                      p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                      (g_asXP, gpart_asZ5) = Genome.Split.split gpart_asZ4
                      p_asXO = code-0.1.0.0:Genome.FixedList.Functions.double g_asXN
                      (g_asXN, gpart_asZ4) = Genome.Split.split gpart_asZ3
                      p_asXM = Functions.belowten' g_asXL
                      (g_asXL, gpart_asZ3) = Genome.Split.split gpart_asZ2
                      p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                      (g_asXJ, gpart_asZ2) = Genome.Split.split gpart_asZ1
                      p_asXI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXH
                      (g_asXH, gpart_asZ1) = Genome.Split.split gpart_asZ0
                      p_asXG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXF
                      (g_asXF, gpart_asZ0) = Genome.Split.split gpart_asYZ
                      p_asXE = Functions.belowten' g_asXD
                      (g_asXD, gpart_asYZ) = Genome.Split.split gpart_asYY
                      p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                      (g_asXB, gpart_asYY) = Genome.Split.split gpart_asYX
                      p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                      (g_asXz, gpart_asYX) = Genome.Split.split gpart_asYW
                      p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                      (g_asXx, gpart_asYW) = Genome.Split.split gpart_asYV
                      p_asXw = code-0.1.0.0:Genome.FixedList.Functions.double g_asXv
                      (g_asXv, gpart_asYV) = Genome.Split.split gpart_asYU
                      p_asXu = code-0.1.0.0:Genome.FixedList.Functions.double g_asXt
                      (g_asXt, gpart_asYU) = Genome.Split.split gpart_asYT
                      p_asXs = code-0.1.0.0:Genome.FixedList.Functions.double g_asXr
                      (g_asXr, gpart_asYT) = Genome.Split.split genome_asYR
                    in
                      [Reaction
                         (\ x_asZB
                            -> let
                                 c_MiRs_asZE = ((toVector x_asZB) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asZC = ((toVector x_asZB) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asXA
                                  * ((p_asXO + ((c_RESTc_asZC / p_asXC) ** p_asXE))
                                     / (((1 + p_asXO) + ((c_RESTc_asZC / p_asXC) ** p_asXE))
                                        + ((c_MiRs_asZE / p_asXK) ** p_asXM)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZF
                            -> let
                                 c_MiRs_asZG = ((toVector x_asZF) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZH = ((toVector x_asZF) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXQ
                                  / (1
                                     + (((c_MiRs_asZG / p_asXS) ** p_asXU)
                                        + ((c_PTB_asZH / p_asXW) ** p_asXY)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZI
                            -> let c_RESTc_asZJ = ((toVector x_asZI) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asY0
                                  * ((p_asYa + ((p_asXw / p_asY2) ** p_asY4))
                                     / (((1 + p_asYa) + ((p_asXw / p_asY2) ** p_asY4))
                                        + ((c_RESTc_asZJ / p_asY6) ** p_asY8)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZK
                            -> let
                                 c_MiRs_asZP = ((toVector x_asZK) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZM = ((toVector x_asZK) Data.Vector.Unboxed.! 0)
                                 c_NPTB_asZL = ((toVector x_asZK) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asYc
                                  * ((p_asYu
                                      + (((c_NPTB_asZL / p_asYe) ** p_asYg)
                                         + ((c_PTB_asZM / p_asYi) ** p_asYk)))
                                     / (((1 + p_asYu)
                                         + (((c_NPTB_asZL / p_asYe) ** p_asYg)
                                            + ((c_PTB_asZM / p_asYi) ** p_asYk)))
                                        + (((p_asXs / p_asYm) ** p_asYo)
                                           + ((c_MiRs_asZP / p_asYq) ** p_asYs))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZQ
                            -> let
                                 c_RESTc_asZT = ((toVector x_asZQ) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asZR = ((toVector x_asZQ) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asYw
                                  * ((p_asYG + ((c_MiRs_asZR / p_asYy) ** p_asYA))
                                     / (((1 + p_asYG) + ((c_MiRs_asZR / p_asYy) ** p_asYA))
                                        + ((c_RESTc_asZT / p_asYC) ** p_asYE)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZU
                            -> let c_PTB_asZV = ((toVector x_asZU) Data.Vector.Unboxed.! 0)
                               in (p_asYI * c_PTB_asZV))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZW
                            -> let c_NPTB_asZX = ((toVector x_asZW) Data.Vector.Unboxed.! 1)
                               in (p_asYK * c_NPTB_asZX))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZY
                            -> let c_MiRs_asZZ = ((toVector x_asZY) Data.Vector.Unboxed.! 2)
                               in (p_asYM * c_MiRs_asZZ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at00
                            -> let c_RESTc_at01 = ((toVector x_at00) Data.Vector.Unboxed.! 3)
                               in (p_asYO * c_RESTc_at01))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at02
                            -> let
                                 c_EndoNeuroTFs_at03 = ((toVector x_at02) Data.Vector.Unboxed.! 4)
                               in (p_asYQ * c_EndoNeuroTFs_at03))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121110",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121122",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121124",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121126",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121128",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121132",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121138",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121140",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121146",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121148",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121166",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121168",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121178",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121180",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYR
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0Q
                            p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                            (g_asYP, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                            (g_asYN, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                            (g_asYL, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                            (g_asYJ, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                            (g_asYH, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                            (g_asYF, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYE = Functions.belowten' g_asYD
                            (g_asYD, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                            (g_asYB, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYA = Functions.belowten' g_asYz
                            (g_asYz, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                            (g_asYx, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYw = code-0.1.0.0:Genome.FixedList.Functions.double g_asYv
                            (g_asYv, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                            (g_asYt, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYs = Functions.belowten' g_asYr
                            (g_asYr, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                            (g_asYp, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYn
                            (g_asYn, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYl
                            (g_asYl, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYk = Functions.belowten' g_asYj
                            (g_asYj, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYi = code-0.1.0.0:Genome.FixedList.Functions.double g_asYh
                            (g_asYh, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYg = Functions.belowten' g_asYf
                            (g_asYf, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                            (g_asYd, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                            (g_asYb, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                            (g_asY9, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asY8 = Functions.belowten' g_asY7
                            (g_asY7, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                            (g_asY5, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asY4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY3
                            (g_asY3, gpart_at0s) = Genome.Split.split gpart_at0r
                            p_asY2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY1
                            (g_asY1, gpart_at0r) = Genome.Split.split gpart_at0q
                            p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                            (g_asXZ, gpart_at0q) = Genome.Split.split gpart_at0p
                            p_asXY = Functions.belowten' g_asXX
                            (g_asXX, gpart_at0p) = Genome.Split.split gpart_at0o
                            p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                            (g_asXV, gpart_at0o) = Genome.Split.split gpart_at0n
                            p_asXU = Functions.belowten' g_asXT
                            (g_asXT, gpart_at0n) = Genome.Split.split gpart_at0m
                            p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                            (g_asXR, gpart_at0m) = Genome.Split.split gpart_at0l
                            p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                            (g_asXP, gpart_at0l) = Genome.Split.split gpart_at0k
                            p_asXO = code-0.1.0.0:Genome.FixedList.Functions.double g_asXN
                            (g_asXN, gpart_at0k) = Genome.Split.split gpart_at0j
                            p_asXM = Functions.belowten' g_asXL
                            (g_asXL, gpart_at0j) = Genome.Split.split gpart_at0i
                            p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                            (g_asXJ, gpart_at0i) = Genome.Split.split gpart_at0h
                            p_asXI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXH
                            (g_asXH, gpart_at0h) = Genome.Split.split gpart_at0g
                            p_asXG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXF
                            (g_asXF, gpart_at0g) = Genome.Split.split gpart_at0f
                            p_asXE = Functions.belowten' g_asXD
                            (g_asXD, gpart_at0f) = Genome.Split.split gpart_at0e
                            p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                            (g_asXB, gpart_at0e) = Genome.Split.split gpart_at0d
                            p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                            (g_asXz, gpart_at0d) = Genome.Split.split gpart_at0c
                            p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                            (g_asXx, gpart_at0c) = Genome.Split.split gpart_at0b
                            p_asXw = code-0.1.0.0:Genome.FixedList.Functions.double g_asXv
                            (g_asXv, gpart_at0b) = Genome.Split.split gpart_at0a
                            p_asXu = code-0.1.0.0:Genome.FixedList.Functions.double g_asXt
                            (g_asXt, gpart_at0a) = Genome.Split.split gpart_at09
                            p_asXs = code-0.1.0.0:Genome.FixedList.Functions.double g_asXr
                            (g_asXr, gpart_at09) = Genome.Split.split genome_asYR
                          in
                            \ desc_asYS
                              -> case desc_asYS of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXs)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXu)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXw)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXy)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXA)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXC)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXE)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXG)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXI)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXK)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXM)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXO)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXQ)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXS)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXU)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXW)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXY)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY0)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY2)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY4)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY6)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY8)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYa)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYc)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYe)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYg)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYi)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYk)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYm)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYo)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYq)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYs)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYu)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYw)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYy)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYA)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYM)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYO)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYQ)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_at2X
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3G
                      p_at2W = code-0.1.0.0:Genome.FixedList.Functions.double g_at2V
                      (g_at2V, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                      (g_at2T, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                      (g_at2R, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                      (g_at2P, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                      (g_at2N, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                      (g_at2L, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2K = Functions.belowten' g_at2J
                      (g_at2J, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                      (g_at2H, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2G = Functions.belowten' g_at2F
                      (g_at2F, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                      (g_at2D, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                      (g_at2B, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                      (g_at2z, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2y = Functions.belowten' g_at2x
                      (g_at2x, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                      (g_at2v, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2t
                      (g_at2t, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2r
                      (g_at2r, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2q = Functions.belowten' g_at2p
                      (g_at2p, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                      (g_at2n, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2m = Functions.belowten' g_at2l
                      (g_at2l, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                      (g_at2j, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                      (g_at2h, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                      (g_at2f, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at2e = Functions.belowten' g_at2d
                      (g_at2d, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                      (g_at2b, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at2a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at29
                      (g_at29, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at28
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at27
                      (g_at27, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                      (g_at25, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at24 = Functions.belowten' g_at23
                      (g_at23, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                      (g_at21, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at20 = Functions.belowten' g_at1Z
                      (g_at1Z, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                      (g_at1X, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at3b) = Genome.Split.split gpart_at3a
                      p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                      (g_at1T, gpart_at3a) = Genome.Split.split gpart_at39
                      p_at1S = Functions.belowten' g_at1R
                      (g_at1R, gpart_at39) = Genome.Split.split gpart_at38
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at38) = Genome.Split.split gpart_at37
                      p_at1O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1N
                      (g_at1N, gpart_at37) = Genome.Split.split gpart_at36
                      p_at1M
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1L
                      (g_at1L, gpart_at36) = Genome.Split.split gpart_at35
                      p_at1K = Functions.belowten' g_at1J
                      (g_at1J, gpart_at35) = Genome.Split.split gpart_at34
                      p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                      (g_at1H, gpart_at34) = Genome.Split.split gpart_at33
                      p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                      (g_at1F, gpart_at33) = Genome.Split.split gpart_at32
                      p_at1E = code-0.1.0.0:Genome.FixedList.Functions.double g_at1D
                      (g_at1D, gpart_at32) = Genome.Split.split gpart_at31
                      p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                      (g_at1B, gpart_at31) = Genome.Split.split gpart_at30
                      p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                      (g_at1z, gpart_at30) = Genome.Split.split gpart_at2Z
                      p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                      (g_at1x, gpart_at2Z) = Genome.Split.split genome_at2X
                    in
                      [Reaction
                         (\ x_at3H
                            -> let
                                 c_MiRs_at3K = ((toVector x_at3H) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at3I = ((toVector x_at3H) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at1G
                                  * ((p_at1U + ((c_RESTc_at3I / p_at1I) ** p_at1K))
                                     / (((1 + p_at1U) + ((c_RESTc_at3I / p_at1I) ** p_at1K))
                                        + ((c_MiRs_at3K / p_at1Q) ** p_at1S)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3L
                            -> let
                                 c_MiRs_at3M = ((toVector x_at3L) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3N = ((toVector x_at3L) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1W
                                  / (1
                                     + (((c_MiRs_at3M / p_at1Y) ** p_at20)
                                        + ((c_PTB_at3N / p_at22) ** p_at24)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3O
                            -> let c_RESTc_at3P = ((toVector x_at3O) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at26
                                  * (p_at2g
                                     / ((1 + p_at2g) + ((c_RESTc_at3P / p_at2c) ** p_at2e)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3Q
                            -> let
                                 c_MiRs_at3V = ((toVector x_at3Q) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3S = ((toVector x_at3Q) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at3R = ((toVector x_at3Q) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at2i
                                  * ((p_at2A
                                      + (((c_NPTB_at3R / p_at2k) ** p_at2m)
                                         + ((c_PTB_at3S / p_at2o) ** p_at2q)))
                                     / (((1 + p_at2A)
                                         + (((c_NPTB_at3R / p_at2k) ** p_at2m)
                                            + ((c_PTB_at3S / p_at2o) ** p_at2q)))
                                        + (((p_at1y / p_at2s) ** p_at2u)
                                           + ((c_MiRs_at3V / p_at2w) ** p_at2y))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3W
                            -> let
                                 c_RESTc_at3Z = ((toVector x_at3W) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at3X = ((toVector x_at3W) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2C
                                  * ((p_at2M + ((c_MiRs_at3X / p_at2E) ** p_at2G))
                                     / (((1 + p_at2M) + ((c_MiRs_at3X / p_at2E) ** p_at2G))
                                        + ((c_RESTc_at3Z / p_at2I) ** p_at2K)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at40
                            -> let c_PTB_at41 = ((toVector x_at40) Data.Vector.Unboxed.! 0)
                               in (p_at2O * c_PTB_at41))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at42
                            -> let c_NPTB_at43 = ((toVector x_at42) Data.Vector.Unboxed.! 1)
                               in (p_at2Q * c_NPTB_at43))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at44
                            -> let c_MiRs_at45 = ((toVector x_at44) Data.Vector.Unboxed.! 2)
                               in (p_at2S * c_MiRs_at45))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at46
                            -> let c_RESTc_at47 = ((toVector x_at46) Data.Vector.Unboxed.! 3)
                               in (p_at2U * c_RESTc_at47))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at48
                            -> let
                                 c_EndoNeuroTFs_at49 = ((toVector x_at48) Data.Vector.Unboxed.! 4)
                               in (p_at2W * c_EndoNeuroTFs_at49))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121364",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121422",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2X
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4R
                            p_at2W = code-0.1.0.0:Genome.FixedList.Functions.double g_at2V
                            (g_at2V, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                            (g_at2T, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                            (g_at2R, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                            (g_at2P, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                            (g_at2N, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                            (g_at2L, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2K = Functions.belowten' g_at2J
                            (g_at2J, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                            (g_at2H, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2G = Functions.belowten' g_at2F
                            (g_at2F, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                            (g_at2D, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                            (g_at2B, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                            (g_at2z, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2y = Functions.belowten' g_at2x
                            (g_at2x, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                            (g_at2v, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2t
                            (g_at2t, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2r
                            (g_at2r, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2q = Functions.belowten' g_at2p
                            (g_at2p, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                            (g_at2n, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2m = Functions.belowten' g_at2l
                            (g_at2l, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                            (g_at2j, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                            (g_at2h, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                            (g_at2f, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2e = Functions.belowten' g_at2d
                            (g_at2d, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                            (g_at2b, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at29
                            (g_at29, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at28
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at27
                            (g_at27, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                            (g_at25, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at24 = Functions.belowten' g_at23
                            (g_at23, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                            (g_at21, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at20 = Functions.belowten' g_at1Z
                            (g_at1Z, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                            (g_at1X, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                            (g_at1T, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at1S = Functions.belowten' g_at1R
                            (g_at1R, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at1O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1N
                            (g_at1N, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at1M
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1L
                            (g_at1L, gpart_at4h) = Genome.Split.split gpart_at4g
                            p_at1K = Functions.belowten' g_at1J
                            (g_at1J, gpart_at4g) = Genome.Split.split gpart_at4f
                            p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                            (g_at1H, gpart_at4f) = Genome.Split.split gpart_at4e
                            p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                            (g_at1F, gpart_at4e) = Genome.Split.split gpart_at4d
                            p_at1E = code-0.1.0.0:Genome.FixedList.Functions.double g_at1D
                            (g_at1D, gpart_at4d) = Genome.Split.split gpart_at4c
                            p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                            (g_at1B, gpart_at4c) = Genome.Split.split gpart_at4b
                            p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                            (g_at1z, gpart_at4b) = Genome.Split.split gpart_at4a
                            p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                            (g_at1x, gpart_at4a) = Genome.Split.split genome_at2X
                          in
                            \ desc_at2Y
                              -> case desc_at2Y of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1y)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2u)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2w)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2y)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2A)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2C)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2E)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2G)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2M)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2O)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Q)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2S)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2U)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2W)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at6Y
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7H
                      p_at6X = code-0.1.0.0:Genome.FixedList.Functions.double g_at6W
                      (g_at6W, gpart_at7H) = Genome.Split.split gpart_at7G
                      p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                      (g_at6U, gpart_at7G) = Genome.Split.split gpart_at7F
                      p_at6T = code-0.1.0.0:Genome.FixedList.Functions.double g_at6S
                      (g_at6S, gpart_at7F) = Genome.Split.split gpart_at7E
                      p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                      (g_at6Q, gpart_at7E) = Genome.Split.split gpart_at7D
                      p_at6P = code-0.1.0.0:Genome.FixedList.Functions.double g_at6O
                      (g_at6O, gpart_at7D) = Genome.Split.split gpart_at7C
                      p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                      (g_at6M, gpart_at7C) = Genome.Split.split gpart_at7B
                      p_at6L = Functions.belowten' g_at6K
                      (g_at6K, gpart_at7B) = Genome.Split.split gpart_at7A
                      p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                      (g_at6I, gpart_at7A) = Genome.Split.split gpart_at7z
                      p_at6H = Functions.belowten' g_at6G
                      (g_at6G, gpart_at7z) = Genome.Split.split gpart_at7y
                      p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                      (g_at6E, gpart_at7y) = Genome.Split.split gpart_at7x
                      p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                      (g_at6C, gpart_at7x) = Genome.Split.split gpart_at7w
                      p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                      (g_at6A, gpart_at7w) = Genome.Split.split gpart_at7v
                      p_at6z = Functions.belowten' g_at6y
                      (g_at6y, gpart_at7v) = Genome.Split.split gpart_at7u
                      p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                      (g_at6w, gpart_at7u) = Genome.Split.split gpart_at7t
                      p_at6v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6u
                      (g_at6u, gpart_at7t) = Genome.Split.split gpart_at7s
                      p_at6t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6s
                      (g_at6s, gpart_at7s) = Genome.Split.split gpart_at7r
                      p_at6r = Functions.belowten' g_at6q
                      (g_at6q, gpart_at7r) = Genome.Split.split gpart_at7q
                      p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                      (g_at6o, gpart_at7q) = Genome.Split.split gpart_at7p
                      p_at6n = Functions.belowten' g_at6m
                      (g_at6m, gpart_at7p) = Genome.Split.split gpart_at7o
                      p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                      (g_at6k, gpart_at7o) = Genome.Split.split gpart_at7n
                      p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                      (g_at6i, gpart_at7n) = Genome.Split.split gpart_at7m
                      p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                      (g_at6g, gpart_at7m) = Genome.Split.split gpart_at7l
                      p_at6f = Functions.belowten' g_at6e
                      (g_at6e, gpart_at7l) = Genome.Split.split gpart_at7k
                      p_at6d = code-0.1.0.0:Genome.FixedList.Functions.double g_at6c
                      (g_at6c, gpart_at7k) = Genome.Split.split gpart_at7j
                      p_at6b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6a
                      (g_at6a, gpart_at7j) = Genome.Split.split gpart_at7i
                      p_at69
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at68
                      (g_at68, gpart_at7i) = Genome.Split.split gpart_at7h
                      p_at67 = code-0.1.0.0:Genome.FixedList.Functions.double g_at66
                      (g_at66, gpart_at7h) = Genome.Split.split gpart_at7g
                      p_at65 = Functions.belowten' g_at64
                      (g_at64, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                      (g_at62, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at61 = Functions.belowten' g_at60
                      (g_at60, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                      (g_at5Y, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                      (g_at5W, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                      (g_at5U, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at5T = Functions.belowten' g_at5S
                      (g_at5S, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                      (g_at5Q, gpart_at79) = Genome.Split.split gpart_at78
                      p_at5P
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5O
                      (g_at5O, gpart_at78) = Genome.Split.split gpart_at77
                      p_at5N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5M
                      (g_at5M, gpart_at77) = Genome.Split.split gpart_at76
                      p_at5L = Functions.belowten' g_at5K
                      (g_at5K, gpart_at76) = Genome.Split.split gpart_at75
                      p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                      (g_at5I, gpart_at75) = Genome.Split.split gpart_at74
                      p_at5H = code-0.1.0.0:Genome.FixedList.Functions.double g_at5G
                      (g_at5G, gpart_at74) = Genome.Split.split gpart_at73
                      p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                      (g_at5E, gpart_at73) = Genome.Split.split gpart_at72
                      p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                      (g_at5C, gpart_at72) = Genome.Split.split gpart_at71
                      p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                      (g_at5A, gpart_at71) = Genome.Split.split gpart_at70
                      p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                      (g_at5y, gpart_at70) = Genome.Split.split genome_at6Y
                    in
                      [Reaction
                         (\ x_at7I
                            -> let
                                 c_MiRs_at7L = ((toVector x_at7I) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at7J = ((toVector x_at7I) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at5H
                                  * ((p_at5V + ((c_RESTc_at7J / p_at5J) ** p_at5L))
                                     / (((1 + p_at5V) + ((c_RESTc_at7J / p_at5J) ** p_at5L))
                                        + ((c_MiRs_at7L / p_at5R) ** p_at5T)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7M
                            -> let
                                 c_MiRs_at7N = ((toVector x_at7M) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7O = ((toVector x_at7M) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5X
                                  / (1
                                     + (((c_MiRs_at7N / p_at5Z) ** p_at61)
                                        + ((c_PTB_at7O / p_at63) ** p_at65)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7P
                            -> let c_RESTc_at7Q = ((toVector x_at7P) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at67
                                  * (p_at6h
                                     / ((1 + p_at6h) + ((c_RESTc_at7Q / p_at6d) ** p_at6f)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7R
                            -> let
                                 c_MiRs_at7W = ((toVector x_at7R) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7T = ((toVector x_at7R) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at7S = ((toVector x_at7R) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at6j
                                  * ((p_at6B
                                      + (((c_NPTB_at7S / p_at6l) ** p_at6n)
                                         + ((c_PTB_at7T / p_at6p) ** p_at6r)))
                                     / (((1 + p_at6B)
                                         + (((c_NPTB_at7S / p_at6l) ** p_at6n)
                                            + ((c_PTB_at7T / p_at6p) ** p_at6r)))
                                        + ((c_MiRs_at7W / p_at6x) ** p_at6z)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7X
                            -> let
                                 c_RESTc_at80 = ((toVector x_at7X) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at7Y = ((toVector x_at7X) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6D
                                  * ((p_at6N + ((c_MiRs_at7Y / p_at6F) ** p_at6H))
                                     / (((1 + p_at6N) + ((c_MiRs_at7Y / p_at6F) ** p_at6H))
                                        + ((c_RESTc_at80 / p_at6J) ** p_at6L)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at81
                            -> let c_PTB_at82 = ((toVector x_at81) Data.Vector.Unboxed.! 0)
                               in (p_at6P * c_PTB_at82))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at83
                            -> let c_NPTB_at84 = ((toVector x_at83) Data.Vector.Unboxed.! 1)
                               in (p_at6R * c_NPTB_at84))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at85
                            -> let c_MiRs_at86 = ((toVector x_at85) Data.Vector.Unboxed.! 2)
                               in (p_at6T * c_MiRs_at86))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at87
                            -> let c_RESTc_at88 = ((toVector x_at87) Data.Vector.Unboxed.! 3)
                               in (p_at6V * c_RESTc_at88))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at89
                            -> let
                                 c_EndoNeuroTFs_at8a = ((toVector x_at89) Data.Vector.Unboxed.! 4)
                               in (p_at6X * c_EndoNeuroTFs_at8a))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121627",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121629",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121647",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121649",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121651",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121669",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121671",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6Y
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8S
                            p_at6X = code-0.1.0.0:Genome.FixedList.Functions.double g_at6W
                            (g_at6W, gpart_at8S) = Genome.Split.split gpart_at8R
                            p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                            (g_at6U, gpart_at8R) = Genome.Split.split gpart_at8Q
                            p_at6T = code-0.1.0.0:Genome.FixedList.Functions.double g_at6S
                            (g_at6S, gpart_at8Q) = Genome.Split.split gpart_at8P
                            p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                            (g_at6Q, gpart_at8P) = Genome.Split.split gpart_at8O
                            p_at6P = code-0.1.0.0:Genome.FixedList.Functions.double g_at6O
                            (g_at6O, gpart_at8O) = Genome.Split.split gpart_at8N
                            p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                            (g_at6M, gpart_at8N) = Genome.Split.split gpart_at8M
                            p_at6L = Functions.belowten' g_at6K
                            (g_at6K, gpart_at8M) = Genome.Split.split gpart_at8L
                            p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                            (g_at6I, gpart_at8L) = Genome.Split.split gpart_at8K
                            p_at6H = Functions.belowten' g_at6G
                            (g_at6G, gpart_at8K) = Genome.Split.split gpart_at8J
                            p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                            (g_at6E, gpart_at8J) = Genome.Split.split gpart_at8I
                            p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                            (g_at6C, gpart_at8I) = Genome.Split.split gpart_at8H
                            p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                            (g_at6A, gpart_at8H) = Genome.Split.split gpart_at8G
                            p_at6z = Functions.belowten' g_at6y
                            (g_at6y, gpart_at8G) = Genome.Split.split gpart_at8F
                            p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                            (g_at6w, gpart_at8F) = Genome.Split.split gpart_at8E
                            p_at6v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6u
                            (g_at6u, gpart_at8E) = Genome.Split.split gpart_at8D
                            p_at6t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6s
                            (g_at6s, gpart_at8D) = Genome.Split.split gpart_at8C
                            p_at6r = Functions.belowten' g_at6q
                            (g_at6q, gpart_at8C) = Genome.Split.split gpart_at8B
                            p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                            (g_at6o, gpart_at8B) = Genome.Split.split gpart_at8A
                            p_at6n = Functions.belowten' g_at6m
                            (g_at6m, gpart_at8A) = Genome.Split.split gpart_at8z
                            p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                            (g_at6k, gpart_at8z) = Genome.Split.split gpart_at8y
                            p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                            (g_at6i, gpart_at8y) = Genome.Split.split gpart_at8x
                            p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                            (g_at6g, gpart_at8x) = Genome.Split.split gpart_at8w
                            p_at6f = Functions.belowten' g_at6e
                            (g_at6e, gpart_at8w) = Genome.Split.split gpart_at8v
                            p_at6d = code-0.1.0.0:Genome.FixedList.Functions.double g_at6c
                            (g_at6c, gpart_at8v) = Genome.Split.split gpart_at8u
                            p_at6b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6a
                            (g_at6a, gpart_at8u) = Genome.Split.split gpart_at8t
                            p_at69
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at68
                            (g_at68, gpart_at8t) = Genome.Split.split gpart_at8s
                            p_at67 = code-0.1.0.0:Genome.FixedList.Functions.double g_at66
                            (g_at66, gpart_at8s) = Genome.Split.split gpart_at8r
                            p_at65 = Functions.belowten' g_at64
                            (g_at64, gpart_at8r) = Genome.Split.split gpart_at8q
                            p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                            (g_at62, gpart_at8q) = Genome.Split.split gpart_at8p
                            p_at61 = Functions.belowten' g_at60
                            (g_at60, gpart_at8p) = Genome.Split.split gpart_at8o
                            p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                            (g_at5Y, gpart_at8o) = Genome.Split.split gpart_at8n
                            p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                            (g_at5W, gpart_at8n) = Genome.Split.split gpart_at8m
                            p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                            (g_at5U, gpart_at8m) = Genome.Split.split gpart_at8l
                            p_at5T = Functions.belowten' g_at5S
                            (g_at5S, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                            (g_at5Q, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at5P
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5O
                            (g_at5O, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at5N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5M
                            (g_at5M, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at5L = Functions.belowten' g_at5K
                            (g_at5K, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                            (g_at5I, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at5H = code-0.1.0.0:Genome.FixedList.Functions.double g_at5G
                            (g_at5G, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                            (g_at5E, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                            (g_at5C, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                            (g_at5A, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                            (g_at5y, gpart_at8b) = Genome.Split.split genome_at6Y
                          in
                            \ desc_at6Z
                              -> case desc_at6Z of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5z)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5B)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5J)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5L)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5N)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5P)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5R)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5T)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5V)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5X)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Z)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at61)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at63)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at65)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at67)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at69)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6b)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6d)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6f)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6h)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6j)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6l)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6n)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6p)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6r)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6t)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6v)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6x)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6z)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6B)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6D)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6F)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6H)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6J)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6L)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6N)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6P)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6R)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6T)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6V)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6X)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_ataZ
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_atbI
                      p_ataY = code-0.1.0.0:Genome.FixedList.Functions.double g_ataX
                      (g_ataX, gpart_atbI) = Genome.Split.split gpart_atbH
                      p_ataW = code-0.1.0.0:Genome.FixedList.Functions.double g_ataV
                      (g_ataV, gpart_atbH) = Genome.Split.split gpart_atbG
                      p_ataU = code-0.1.0.0:Genome.FixedList.Functions.double g_ataT
                      (g_ataT, gpart_atbG) = Genome.Split.split gpart_atbF
                      p_ataS = code-0.1.0.0:Genome.FixedList.Functions.double g_ataR
                      (g_ataR, gpart_atbF) = Genome.Split.split gpart_atbE
                      p_ataQ = code-0.1.0.0:Genome.FixedList.Functions.double g_ataP
                      (g_ataP, gpart_atbE) = Genome.Split.split gpart_atbD
                      p_ataO = code-0.1.0.0:Genome.FixedList.Functions.double g_ataN
                      (g_ataN, gpart_atbD) = Genome.Split.split gpart_atbC
                      p_ataM = Functions.belowten' g_ataL
                      (g_ataL, gpart_atbC) = Genome.Split.split gpart_atbB
                      p_ataK = code-0.1.0.0:Genome.FixedList.Functions.double g_ataJ
                      (g_ataJ, gpart_atbB) = Genome.Split.split gpart_atbA
                      p_ataI = Functions.belowten' g_ataH
                      (g_ataH, gpart_atbA) = Genome.Split.split gpart_atbz
                      p_ataG = code-0.1.0.0:Genome.FixedList.Functions.double g_ataF
                      (g_ataF, gpart_atbz) = Genome.Split.split gpart_atby
                      p_ataE = code-0.1.0.0:Genome.FixedList.Functions.double g_ataD
                      (g_ataD, gpart_atby) = Genome.Split.split gpart_atbx
                      p_ataC = code-0.1.0.0:Genome.FixedList.Functions.double g_ataB
                      (g_ataB, gpart_atbx) = Genome.Split.split gpart_atbw
                      p_ataA = Functions.belowten' g_ataz
                      (g_ataz, gpart_atbw) = Genome.Split.split gpart_atbv
                      p_atay = code-0.1.0.0:Genome.FixedList.Functions.double g_atax
                      (g_atax, gpart_atbv) = Genome.Split.split gpart_atbu
                      p_ataw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_atav
                      (g_atav, gpart_atbu) = Genome.Split.split gpart_atbt
                      p_atau
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_atat
                      (g_atat, gpart_atbt) = Genome.Split.split gpart_atbs
                      p_atas = Functions.belowten' g_atar
                      (g_atar, gpart_atbs) = Genome.Split.split gpart_atbr
                      p_ataq = code-0.1.0.0:Genome.FixedList.Functions.double g_atap
                      (g_atap, gpart_atbr) = Genome.Split.split gpart_atbq
                      p_atao = Functions.belowten' g_atan
                      (g_atan, gpart_atbq) = Genome.Split.split gpart_atbp
                      p_atam = code-0.1.0.0:Genome.FixedList.Functions.double g_atal
                      (g_atal, gpart_atbp) = Genome.Split.split gpart_atbo
                      p_atak = code-0.1.0.0:Genome.FixedList.Functions.double g_ataj
                      (g_ataj, gpart_atbo) = Genome.Split.split gpart_atbn
                      p_atai = code-0.1.0.0:Genome.FixedList.Functions.double g_atah
                      (g_atah, gpart_atbn) = Genome.Split.split gpart_atbm
                      p_atag = Functions.belowten' g_ataf
                      (g_ataf, gpart_atbm) = Genome.Split.split gpart_atbl
                      p_atae = code-0.1.0.0:Genome.FixedList.Functions.double g_atad
                      (g_atad, gpart_atbl) = Genome.Split.split gpart_atbk
                      p_atac
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_atab
                      (g_atab, gpart_atbk) = Genome.Split.split gpart_atbj
                      p_ataa
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_ata9
                      (g_ata9, gpart_atbj) = Genome.Split.split gpart_atbi
                      p_ata8 = code-0.1.0.0:Genome.FixedList.Functions.double g_ata7
                      (g_ata7, gpart_atbi) = Genome.Split.split gpart_atbh
                      p_ata6 = Functions.belowten' g_ata5
                      (g_ata5, gpart_atbh) = Genome.Split.split gpart_atbg
                      p_ata4 = code-0.1.0.0:Genome.FixedList.Functions.double g_ata3
                      (g_ata3, gpart_atbg) = Genome.Split.split gpart_atbf
                      p_ata2 = Functions.belowten' g_ata1
                      (g_ata1, gpart_atbf) = Genome.Split.split gpart_atbe
                      p_ata0 = code-0.1.0.0:Genome.FixedList.Functions.double g_at9Z
                      (g_at9Z, gpart_atbe) = Genome.Split.split gpart_atbd
                      p_at9Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at9X
                      (g_at9X, gpart_atbd) = Genome.Split.split gpart_atbc
                      p_at9W = code-0.1.0.0:Genome.FixedList.Functions.double g_at9V
                      (g_at9V, gpart_atbc) = Genome.Split.split gpart_atbb
                      p_at9U = Functions.belowten' g_at9T
                      (g_at9T, gpart_atbb) = Genome.Split.split gpart_atba
                      p_at9S = code-0.1.0.0:Genome.FixedList.Functions.double g_at9R
                      (g_at9R, gpart_atba) = Genome.Split.split gpart_atb9
                      p_at9Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at9P
                      (g_at9P, gpart_atb9) = Genome.Split.split gpart_atb8
                      p_at9O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at9N
                      (g_at9N, gpart_atb8) = Genome.Split.split gpart_atb7
                      p_at9M = Functions.belowten' g_at9L
                      (g_at9L, gpart_atb7) = Genome.Split.split gpart_atb6
                      p_at9K = code-0.1.0.0:Genome.FixedList.Functions.double g_at9J
                      (g_at9J, gpart_atb6) = Genome.Split.split gpart_atb5
                      p_at9I = code-0.1.0.0:Genome.FixedList.Functions.double g_at9H
                      (g_at9H, gpart_atb5) = Genome.Split.split gpart_atb4
                      p_at9G = code-0.1.0.0:Genome.FixedList.Functions.double g_at9F
                      (g_at9F, gpart_atb4) = Genome.Split.split gpart_atb3
                      p_at9E = code-0.1.0.0:Genome.FixedList.Functions.double g_at9D
                      (g_at9D, gpart_atb3) = Genome.Split.split gpart_atb2
                      p_at9C = code-0.1.0.0:Genome.FixedList.Functions.double g_at9B
                      (g_at9B, gpart_atb2) = Genome.Split.split gpart_atb1
                      p_at9A = code-0.1.0.0:Genome.FixedList.Functions.double g_at9z
                      (g_at9z, gpart_atb1) = Genome.Split.split genome_ataZ
                    in
                      [Reaction
                         (\ x_atbJ
                            -> let
                                 c_MiRs_atbM = ((toVector x_atbJ) Data.Vector.Unboxed.! 2)
                                 c_RESTc_atbK = ((toVector x_atbJ) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at9I
                                  * ((p_at9W + ((c_RESTc_atbK / p_at9K) ** p_at9M))
                                     / (((1 + p_at9W) + ((c_RESTc_atbK / p_at9K) ** p_at9M))
                                        + (((p_at9A / p_at9O) ** p_at9Q)
                                           + ((c_MiRs_atbM / p_at9S) ** p_at9U))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_atbN
                            -> let
                                 c_MiRs_atbO = ((toVector x_atbN) Data.Vector.Unboxed.! 2)
                                 c_PTB_atbP = ((toVector x_atbN) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at9Y
                                  / (1
                                     + (((c_MiRs_atbO / p_ata0) ** p_ata2)
                                        + ((c_PTB_atbP / p_ata4) ** p_ata6)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_atbQ
                            -> let c_RESTc_atbR = ((toVector x_atbQ) Data.Vector.Unboxed.! 3)
                               in
                                 (p_ata8
                                  * (p_atai
                                     / ((1 + p_atai) + ((c_RESTc_atbR / p_atae) ** p_atag)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_atbS
                            -> let
                                 c_MiRs_atbX = ((toVector x_atbS) Data.Vector.Unboxed.! 2)
                                 c_PTB_atbU = ((toVector x_atbS) Data.Vector.Unboxed.! 0)
                                 c_NPTB_atbT = ((toVector x_atbS) Data.Vector.Unboxed.! 1)
                               in
                                 (p_atak
                                  * ((p_ataC
                                      + (((c_NPTB_atbT / p_atam) ** p_atao)
                                         + ((c_PTB_atbU / p_ataq) ** p_atas)))
                                     / (((1 + p_ataC)
                                         + (((c_NPTB_atbT / p_atam) ** p_atao)
                                            + ((c_PTB_atbU / p_ataq) ** p_atas)))
                                        + ((c_MiRs_atbX / p_atay) ** p_ataA)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_atbY
                            -> let
                                 c_RESTc_atc1 = ((toVector x_atbY) Data.Vector.Unboxed.! 3)
                                 c_MiRs_atbZ = ((toVector x_atbY) Data.Vector.Unboxed.! 2)
                               in
                                 (p_ataE
                                  * ((p_ataO + ((c_MiRs_atbZ / p_ataG) ** p_ataI))
                                     / (((1 + p_ataO) + ((c_MiRs_atbZ / p_ataG) ** p_ataI))
                                        + ((c_RESTc_atc1 / p_ataK) ** p_ataM)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_atc2
                            -> let c_PTB_atc3 = ((toVector x_atc2) Data.Vector.Unboxed.! 0)
                               in (p_ataQ * c_PTB_atc3))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_atc4
                            -> let c_NPTB_atc5 = ((toVector x_atc4) Data.Vector.Unboxed.! 1)
                               in (p_ataS * c_NPTB_atc5))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_atc6
                            -> let c_MiRs_atc7 = ((toVector x_atc6) Data.Vector.Unboxed.! 2)
                               in (p_ataU * c_MiRs_atc7))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_atc8
                            -> let c_RESTc_atc9 = ((toVector x_atc8) Data.Vector.Unboxed.! 3)
                               in (p_ataW * c_RESTc_atc9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_atca
                            -> let
                                 c_EndoNeuroTFs_atcb = ((toVector x_atca) Data.Vector.Unboxed.! 4)
                               in (p_ataY * c_EndoNeuroTFs_atcb))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121862",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121864",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121866",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121868",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121876",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121878",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121882",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121884",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121898",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121900",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121918",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121920",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_ataZ
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_atcT
                            p_ataY = code-0.1.0.0:Genome.FixedList.Functions.double g_ataX
                            (g_ataX, gpart_atcT) = Genome.Split.split gpart_atcS
                            p_ataW = code-0.1.0.0:Genome.FixedList.Functions.double g_ataV
                            (g_ataV, gpart_atcS) = Genome.Split.split gpart_atcR
                            p_ataU = code-0.1.0.0:Genome.FixedList.Functions.double g_ataT
                            (g_ataT, gpart_atcR) = Genome.Split.split gpart_atcQ
                            p_ataS = code-0.1.0.0:Genome.FixedList.Functions.double g_ataR
                            (g_ataR, gpart_atcQ) = Genome.Split.split gpart_atcP
                            p_ataQ = code-0.1.0.0:Genome.FixedList.Functions.double g_ataP
                            (g_ataP, gpart_atcP) = Genome.Split.split gpart_atcO
                            p_ataO = code-0.1.0.0:Genome.FixedList.Functions.double g_ataN
                            (g_ataN, gpart_atcO) = Genome.Split.split gpart_atcN
                            p_ataM = Functions.belowten' g_ataL
                            (g_ataL, gpart_atcN) = Genome.Split.split gpart_atcM
                            p_ataK = code-0.1.0.0:Genome.FixedList.Functions.double g_ataJ
                            (g_ataJ, gpart_atcM) = Genome.Split.split gpart_atcL
                            p_ataI = Functions.belowten' g_ataH
                            (g_ataH, gpart_atcL) = Genome.Split.split gpart_atcK
                            p_ataG = code-0.1.0.0:Genome.FixedList.Functions.double g_ataF
                            (g_ataF, gpart_atcK) = Genome.Split.split gpart_atcJ
                            p_ataE = code-0.1.0.0:Genome.FixedList.Functions.double g_ataD
                            (g_ataD, gpart_atcJ) = Genome.Split.split gpart_atcI
                            p_ataC = code-0.1.0.0:Genome.FixedList.Functions.double g_ataB
                            (g_ataB, gpart_atcI) = Genome.Split.split gpart_atcH
                            p_ataA = Functions.belowten' g_ataz
                            (g_ataz, gpart_atcH) = Genome.Split.split gpart_atcG
                            p_atay = code-0.1.0.0:Genome.FixedList.Functions.double g_atax
                            (g_atax, gpart_atcG) = Genome.Split.split gpart_atcF
                            p_ataw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_atav
                            (g_atav, gpart_atcF) = Genome.Split.split gpart_atcE
                            p_atau
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_atat
                            (g_atat, gpart_atcE) = Genome.Split.split gpart_atcD
                            p_atas = Functions.belowten' g_atar
                            (g_atar, gpart_atcD) = Genome.Split.split gpart_atcC
                            p_ataq = code-0.1.0.0:Genome.FixedList.Functions.double g_atap
                            (g_atap, gpart_atcC) = Genome.Split.split gpart_atcB
                            p_atao = Functions.belowten' g_atan
                            (g_atan, gpart_atcB) = Genome.Split.split gpart_atcA
                            p_atam = code-0.1.0.0:Genome.FixedList.Functions.double g_atal
                            (g_atal, gpart_atcA) = Genome.Split.split gpart_atcz
                            p_atak = code-0.1.0.0:Genome.FixedList.Functions.double g_ataj
                            (g_ataj, gpart_atcz) = Genome.Split.split gpart_atcy
                            p_atai = code-0.1.0.0:Genome.FixedList.Functions.double g_atah
                            (g_atah, gpart_atcy) = Genome.Split.split gpart_atcx
                            p_atag = Functions.belowten' g_ataf
                            (g_ataf, gpart_atcx) = Genome.Split.split gpart_atcw
                            p_atae = code-0.1.0.0:Genome.FixedList.Functions.double g_atad
                            (g_atad, gpart_atcw) = Genome.Split.split gpart_atcv
                            p_atac
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_atab
                            (g_atab, gpart_atcv) = Genome.Split.split gpart_atcu
                            p_ataa
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_ata9
                            (g_ata9, gpart_atcu) = Genome.Split.split gpart_atct
                            p_ata8 = code-0.1.0.0:Genome.FixedList.Functions.double g_ata7
                            (g_ata7, gpart_atct) = Genome.Split.split gpart_atcs
                            p_ata6 = Functions.belowten' g_ata5
                            (g_ata5, gpart_atcs) = Genome.Split.split gpart_atcr
                            p_ata4 = code-0.1.0.0:Genome.FixedList.Functions.double g_ata3
                            (g_ata3, gpart_atcr) = Genome.Split.split gpart_atcq
                            p_ata2 = Functions.belowten' g_ata1
                            (g_ata1, gpart_atcq) = Genome.Split.split gpart_atcp
                            p_ata0 = code-0.1.0.0:Genome.FixedList.Functions.double g_at9Z
                            (g_at9Z, gpart_atcp) = Genome.Split.split gpart_atco
                            p_at9Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at9X
                            (g_at9X, gpart_atco) = Genome.Split.split gpart_atcn
                            p_at9W = code-0.1.0.0:Genome.FixedList.Functions.double g_at9V
                            (g_at9V, gpart_atcn) = Genome.Split.split gpart_atcm
                            p_at9U = Functions.belowten' g_at9T
                            (g_at9T, gpart_atcm) = Genome.Split.split gpart_atcl
                            p_at9S = code-0.1.0.0:Genome.FixedList.Functions.double g_at9R
                            (g_at9R, gpart_atcl) = Genome.Split.split gpart_atck
                            p_at9Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at9P
                            (g_at9P, gpart_atck) = Genome.Split.split gpart_atcj
                            p_at9O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at9N
                            (g_at9N, gpart_atcj) = Genome.Split.split gpart_atci
                            p_at9M = Functions.belowten' g_at9L
                            (g_at9L, gpart_atci) = Genome.Split.split gpart_atch
                            p_at9K = code-0.1.0.0:Genome.FixedList.Functions.double g_at9J
                            (g_at9J, gpart_atch) = Genome.Split.split gpart_atcg
                            p_at9I = code-0.1.0.0:Genome.FixedList.Functions.double g_at9H
                            (g_at9H, gpart_atcg) = Genome.Split.split gpart_atcf
                            p_at9G = code-0.1.0.0:Genome.FixedList.Functions.double g_at9F
                            (g_at9F, gpart_atcf) = Genome.Split.split gpart_atce
                            p_at9E = code-0.1.0.0:Genome.FixedList.Functions.double g_at9D
                            (g_at9D, gpart_atce) = Genome.Split.split gpart_atcd
                            p_at9C = code-0.1.0.0:Genome.FixedList.Functions.double g_at9B
                            (g_at9B, gpart_atcd) = Genome.Split.split gpart_atcc
                            p_at9A = code-0.1.0.0:Genome.FixedList.Functions.double g_at9z
                            (g_at9z, gpart_atcc) = Genome.Split.split genome_ataZ
                          in
                            \ desc_atb0
                              -> case desc_atb0 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9A)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9C)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9E)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9G)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9I)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9K)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9M)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9O)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9Q)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9S)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9U)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9W)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at9Y)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ata0)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ata2)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ata4)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ata6)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ata8)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataa)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atac)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atae)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atag)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atai)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atak)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atam)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atao)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataq)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atas)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atau)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataw)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_atay)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataA)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataC)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataE)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataG)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataI)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataK)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataM)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataO)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataQ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataS)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataU)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataW)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_ataY)
                                   _ -> Nothing }}
